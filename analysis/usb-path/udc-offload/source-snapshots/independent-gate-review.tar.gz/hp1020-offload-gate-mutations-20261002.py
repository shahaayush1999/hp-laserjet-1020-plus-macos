from pathlib import Path
import copy,hashlib,json,runpy

root=Path('/tmp/hp1020-offload-gate-root-20261002')
path=root/'analysis/usb-path/udc-offload/validation.json'
original=path.read_bytes();baseline=json.loads(original)
gate_path=Path('/tmp/hp1020-offload-gate-v4-20261002.py')
gate=runpy.run_path(str(gate_path))['usb_offload_consistency_gate']
assert gate(root)[0]

def select(r,name):
    i=next(i for i,c in enumerate(r['cases']) if c['scenario']==name and c['fill']==0)
    return r['cases'][i],r['target']['cases'][i]

def pixels(r):
    c,n=select(r,'configuration-delayed-grant')
    wrong=hashlib.sha256(bytes(32)).hexdigest()
    c['expected_pixels_sha256']=c['capture_sha256']['pixels']=n['capture_sha256']['pixels']=wrong

def documents(r):
    c,n=select(r,'configuration-delayed-grant')
    c['expected_documents'][0][0]=99
    raw=b''.join(v.to_bytes(4,'big') for doc in c['expected_documents'] for v in doc)
    c['capture_sha256']['documents']=n['capture_sha256']['documents']=hashlib.sha256(raw).hexdigest()

def zlp(r):
    c,n=select(r,'repeat-configuration-recovery')
    c['packet_oracles']=[]

def promises(r):
    c,n=select(r,'configuration-delayed-grant')
    event=next(e for e in c['events'] if e['words'][0]==11 and e['result']==0)
    event['words'][2]=7

def failure(r):
    c,n=select(r,'raw-programming-failure-IN')
    for row in c['offload_steps']:
        if row[59]: row[60]=row[69]=99

def current_grant(r):
    c,n=select(r,'configuration-delayed-grant')
    i=next(i for i,e in enumerate(c['events']) if e['words'][0]==102 and e['result']==0)
    c['events'][i]['words'][1]+=1

def effective(r):
    r['effective_source']['effective_sha256']['src/device/usbd.c']='0'*64

def target(r):
    r['target']['elf_sha256']=r['target']['captured_artifact_sha256']['target-check.elf']='0'*64

checks=[]
try:
    for name,mutate,reason in [
        ('agreed-wrong-pixels',pixels,'independent full image bytes'),
        ('agreed-wrong-doc-generation',documents,'independent original-generation document bytes'),
        ('missing-zero-length-packet',zlp,'individual literal packets including ZLPs'),
        ('combined-invented-promises',promises,'one explicitly supplied current-ticket promise'),
        ('retagged-raw-failure',failure,'original partial-programming failure'),
        ('grant-for-different-event',current_grant,'one current exact-original status proposal'),
        ('wrong-effective-core',effective,'all effective-source result bytes bound'),
        ('agreed-wrong-target-hash',target,'exact current target artifacts')]:
        changed=copy.deepcopy(baseline);mutate(changed)
        path.write_text(json.dumps(changed,separators=(',',':'))+'\n')
        passed,detail=gate(root)
        assert not passed,(name,detail)
        assert reason in detail,(name,detail)
        checks.append(dict(control=name,status='rejected',detail=detail))
finally:
    path.write_bytes(original)
assert gate(root)[0] and path.read_bytes()==original
report=dict(gate_sha256=hashlib.sha256(gate_path.read_bytes()).hexdigest(),
    original_report_sha256=hashlib.sha256(original).hexdigest(),status='pass',
    controls=checks,scope='Disposable report mutations only; original captures, firmware sources and live reports untouched.')
Path('/tmp/hp1020-offload-gate-mutations-20261002.json').write_text(json.dumps(report,indent=2)+'\n')
print('Eight independent negative controls rejected; original evidence restored and rechecked.')
