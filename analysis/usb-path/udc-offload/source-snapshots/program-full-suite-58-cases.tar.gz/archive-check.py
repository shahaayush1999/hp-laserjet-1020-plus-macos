from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import struct
import tarfile

ROOT = Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
FULL_LOG = Path('/tmp/hp1020-full-program-20261002.log')
CHILD_LOG = Path('/var/folders/46/5hjsxnq13752lvrwdm2q1fk80000gn/T/hp1020-validation.xVacWU/validate-hp1020-offline-analysis.log')
assert 'All offline checks passed. No printer was contacted.' in FULL_LOG.read_text()
locations = re.findall(r'Typed offload captures: (.+)', CHILD_LOG.read_text())
assert len(locations) == 1
CAPTURE = Path(locations[0])
OUT = ROOT/'analysis/usb-path/udc-offload/source-snapshots'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
report_raw = (CAPTURE/'validation.json').read_bytes()
report = json.loads(report_raw)
assert report_raw == (ROOT/'analysis/usb-path/udc-offload/validation.json').read_bytes()
for group, folder in (('source_sha256', 'source'), ('fixture_sha256', 'tested-fixtures')):
    for name, digest in report[group].items():
        assert sha((CAPTURE/folder/name).read_bytes()) == digest
        assert sha((ROOT/name).read_bytes()) == digest
names = {'pixels':'pixels', 'wire':'wire', 'receive':'receive', 'output':'output',
         'documents':'documents', 'ep0':'output.ep0-descriptors',
         'bulk_descriptor':'output.udc-descriptor', 'setup_record':'output.setup-record'}
steps = 0
for i, case in enumerate(report['cases']):
    directory = CAPTURE/f'case-{i:03}'
    assert (directory/'case-name').read_text().strip() == case['case']
    rows = [case['initial']+case['initial_ep0']+case['initial_bulk']+case['initial_setup']+case['initial_offload']]
    assert len({len(case[n]) for n in ('events','steps','ep0_steps','bulk_steps','setup_steps','offload_steps')}) == 1
    rows += [sum((list(part) for part in parts), []) for parts in zip(*(case[n] for n in
             ('steps','ep0_steps','bulk_steps','setup_steps','offload_steps')))]
    observed = [json.loads(line) for line in (directory/'raw-stdout').read_text().splitlines()]
    assert observed == rows
    target = [json.loads(line) for line in (directory/'target-steps.jsonl').read_text().splitlines()]
    assert len(target) == len(rows)-1
    for host, native in zip(rows[1:], target):
        assert len(host) == len(native) == 368
        assert host[:59]+host[60:] == native[:59]+native[60:]
        assert native[59] == 128588
    encoded = b''
    for event in case['events']:
        data = bytes.fromhex(event['data_hex'])
        encoded += struct.pack('>6I', *event['words'], len(data)) + data
    assert encoded == (directory/'events.bin').read_bytes()
    for name, local in names.items():
        raw = (directory/local).read_bytes()
        assert sha(raw) == case['capture_sha256'][name]
        assert raw == (directory/('target-'+name)).read_bytes()
    steps += len(target)

def save(label, files, note):
    OUT.mkdir(parents=True, exist_ok=True)
    content = {name: path.read_bytes() for name, path in files.items()}
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as archive:
            for name, raw in sorted(content.items()):
                assert not Path(name).is_absolute() and '..' not in Path(name).parts
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                archive.addfile(info, io.BytesIO(raw))
    payload = buffer.getvalue()
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
        assert set(archive.getnames()) == set(content)
        for name, raw in content.items():
            assert archive.extractfile(name).read() == raw
    (OUT/(label+'.tar.gz')).write_bytes(payload)
    metadata = dict(note, archive_sha256=sha(payload), archive_bytes=len(payload),
                    member_count=len(content), member_sha256={n:sha(raw) for n, raw in sorted(content.items())})
    (OUT/(label+'.json')).write_text(json.dumps(metadata, indent=2)+'\n')
    print(label, len(content), len(payload), sha(payload))

capture_files = {p.relative_to(CAPTURE).as_posix():p for p in CAPTURE.rglob('*') if p.is_file()}
capture_files.update({'run.log':FULL_LOG, 'full-analysis.log':CHILD_LOG,
    'full-probes.log':CHILD_LOG.with_name('validate-open-firmware-probes.log'),
    'full-consistency.json':ROOT/'analysis/offline-consistency/offline-consistency.json',
    'archive-check.py':Path(__file__)})
save('program-full-suite-58-cases', capture_files, dict(status='58 sanitized host and 58 QEMU regression cases passed after optional recording-program fixture seams; full sequential validation passed',
    report_sha256=sha(report_raw), source_files=len(report['source_sha256']), fixture_files=6,
    verified_host_and_target_event_pairs=steps, verified_raw_capture_pairs=len(report['cases'])*8,
    limits='Synthetic RAM only; no USB, MMIO, native page lifecycle or physical printing.'))
