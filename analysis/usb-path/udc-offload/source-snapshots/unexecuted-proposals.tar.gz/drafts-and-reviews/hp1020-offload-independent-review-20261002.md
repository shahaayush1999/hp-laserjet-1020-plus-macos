# Typed SC/SI integration: independent review and oracle

2026-10-02. Static review only. No build, import, validator, QEMU, controller,
USB, or installed-printing operation was performed. This is a proposed fixture
contract, not a test result. Root owns integration and execution.

## Scope and decisions

Use one external, original, nonzero increasing sequence for raw SETUP, actual
bus reset, and typed configuration/interface notifications. Keep the typed
notification separate from the immutable raw 16-byte SETUP capture. Its canonical
eight-byte TinyUSB request is reconstructed software input, never recovered wire
bytes. For the initial profile, configuration 0/1 and interface 0/alternate 0
are supported. Root explicitly chose to retain unsupported values with no grant
until an actual ordered reset; this is a bounded limitation, not an implemented
STALL/recovery path or a finished controller port.

One accepted automatic-status owner is IN0, NULL, length 0. It keeps its original
cookie even after document generation changes. Taking a CSR_DONE proposal is
neither a controller write, transfer settlement, nor host ACK. No automatic owner
may produce a TinyUSB completion/ACK callback. Explicit ABORTED/0 settlement can
retire it; a newer request or reset alone cannot. Grant consumption must remain
serialized with original-ingress observation: a saved proposal is not permission
to write CSR_DONE after a newer event has arrived.

## Source findings that constrain the design

1. `vendor/tinyusb-0.21.0/src/device/usbd.c:981` processes SET_CONFIGURATION only
   when the selected number changes, then always attempts status. The nonzero
   old-configuration branch closes all endpoints and resets class state. It
   assigns the new number before opening the descriptor and sets the number
   back to 0 on failure. It does not unwind a partial failed open.
2. `open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.c:183` opens OUT
   before IN. If OUT succeeds and IN fails, the baseline leaves OUT programmed
   while `opened` is false. A later configuration 1 attempt sees TinyUSB config
   0, so it skips the close-all branch. Root selected a retained
   programming-dirty condition and explicit cleanup completion, keyed to the
   original failed attempt, before any later open/grant. Neither a new request
   nor a reset notification clears it. The fixture must retain visible partial
   OUT programming instead of equating !mounted with clean endpoint state.
3. `usbd.c:1148` forwards standard interface requests to the class; if the class
   returns false, its fallback ACKs SET_INTERFACE without checking `wValue`.
   Our class at `hp1020_tusb_adapter.c:262` accepts class-type requests only.
   Hence unsupported alt/interface values must be held before this fallback.
   Accepted SI(0,0) does not call `driver_open`; its one explicit reselection
   recovery must not be counted as a reopened endpoint.
4. `hp1020_tusb_adapter.c:212` allows new-binding recovery only after the current
   status owner is bound and core BUSY is set. Returning true from a synthetic
   DCD submission with no retained owner is insufficient. `usbd.c:1575` sets
   BUSY before the DCD call and clears it when the call returns false; the
   existing initial-submission check at adapter line 636 handles this distinction.
5. Admission (`hp1020_tusb_adapter.c:408`) invalidates reply permission and fences
   destructive changes before waiting for owners. Completion and packet fault
   (`:492`, `:527`) retain original cookies. Recovery finish (`:812`) can advance
   document generation while a control owner remains borrowed. Therefore an
   automatic owner with old receive generation may still be the current control
   owner; rewriting its generation is wrong, and an old-generation fault must
   not stop the new document.
6. The raw bridge (`open-firmware/udc-setup/hp1020_udc_setup.c:67`, `:129`, `:159`)
   retains an unknown capture, retains the exact reset retry, and blocks forward
   progress before adapter dispatch. The new grant path must enforce that same
   gate, rather than checking only the adapter control epoch. SERVICE-only while
   an already admitted reset drains does not authorize a status grant.
7. Effective TinyUSB already has the failed-EP0 latch from
   `open-firmware/tinyusb-device/patches/protocol-compatibility.patch`. Unpatched
   upstream ignores failure, but current patched code does not. Suppressing all
   automatic-owner completion dispatch remains necessary to avoid manufacturing
   either success or failure protocol progression from a status grant.

## Independent fixture observations

Record ordered DCD open attempts/results and close/close-all calls independently
of `adapter.opened` and `tud_mounted()`. Keep a synthetic programmed-endpoint map
whose entries change only through those actual callbacks or an explicitly named
external cleanup operation. Preserve a by-value history of every bound cookie;
do not retrieve a historical identity from the current owner.

Separately record: copied typed capture; prior raw 16-byte capture; adapter
control/transport identities; each owner and BUSY state; each class recovery
ticket and supplied promise; generation; canonical TinyUSB fields; successful
grant proposals; normal EP0 descriptor prepares/publications; control status/ACK
hooks; stream output and document notification traces. A protocol status hook,
grant proposal, and physical wire event are three different counters. The last
one is always unobserved here.

Literal canonical inputs for the supported interface-0 profile are:

- SC(1): `00 09 01 00 00 00 00 00`.
- SC(0): `00 09 00 00 00 00 00 00`.
- SI(0,0): `01 0b 00 00 00 00 00 00`.

TinyUSB must see native numeric fields 1/0 for configuration, 0 for interface,
alternate and length on both host and big-endian target. These bytes must never
appear as a newly acquired raw capture or a transmitted packet. Do not import
the production canonicalization routine into the oracle.

For all automatic paths assert zero new normal EP0 descriptor preparations,
zero wire-byte appends, zero control completion/ACK callbacks, and no class
response borrow. A later ordinary raw GET_CONFIGURATION is a separate real
control path and should return the literal selected byte after old-owner
settlement. Identical raw SET_CONFIGURATION bytes must use ordinary EP0 binding,
not gain automatic provenance by matching their contents.

## Bounded adversarial matrix

Starting states: U is full-speed configured 0, no owners, stopped document;
R is configured 1 after exactly one successful three-promise recovery, with
ordinary input permitted; H is a current automatic status owner retained from a
successful SC/SI. Sequence N, cookie C, control epoch E and receive generation G
below are values recorded at their original creation, never recomputed later.
Expected deltas exclude diagnostics explicitly written to report a rejected call.

| Case | Operations | Independent required outcome |
|---|---|---|
| Initial SC1 | U; offer N; dispatch; service | Offer alone blocks progress and changes no raw capture/adapter state. Exactly OUT then IN open attempts, mounted 1, one IN0 NULL/0 automatic owner, one recovery ticket; no promise, restart, grant, descriptor or ACK inferred. |
| Delayed grant | H; no grant facts; service polls | Owner/BUSY/cookie and pending recovery remain. No extra open/recovery/status/grant. Missing each fact separately waits; value 2 for each Boolean is invalid. |
| One grant | H; all supplied grant facts; take twice | First proposal contains exact C and original typed N/fields. Second creates no proposal and no owner release. Neither changes generation/promises/output. |
| Recovery before grant | SC1 owner at G; supply three promises separately; finish; then grant | Finish waits while any promise is missing, then generation G+1 once. Owner remains C at G. Current control grant is still allowed with C, without restamping it. No extra status. |
| Grant before recovery | Take grant before finishing SC1 recovery | Grant alone does not allow receive ARM/PUMP or satisfy any promise. Finish still requires all three. This does not model host ACK. |
| Same SC1 | R; new SC1 after any old EP0 settlement | One new control/automatic owner and one eligible grant; zero open/close deltas, no new recovery, unchanged receive generation and transport binding. Feed split document around this request and compare exact continuous pixels/END_DOC trace. |
| Same SC1 while fenced | Mounted 1 but document fault-fenced; new SC1 | No new recovery or input permission merely from the repeat or service polls. Status grant is independent of document recovery. |
| SC0 with active input | R with owned OUT/retained output; admit SC0 | Document stops at admission before EP0 wait. Existing owners/output bytes stay held until their separate promises/settlement. After settlement, exactly one close-all, mounted/opened 0, no new recovery. One current automatic status grant remains legal despite !mounted/!opened. |
| Repeat SC0 | U; SC0 then another SC0 | No open/close/recovery. Each distinct admitted current request can own one grant after previous status settlement; duplicate sequence cannot. |
| Reconfigure | R; SC0 settled; then SC1 | Close-all belongs to SC0; two new successful endpoint opens belong to SC1; exactly one new recovery, independently acknowledged. No hidden recovery on SC0. |
| SI supported | R; SI interface0/alt0 | Destructive admission fences old receive and waits owners. No descriptor open/close callbacks from TinyUSB fallback. Exactly one reselection recovery and one automatic owner/grant; no extra recovery from polls. Transport reset promise explicitly covers real reselection/toggle work. |
| SI unsupported/unconfigured | SI alt1, interface1, sampled config0, or while U | No generic fallback status/grant, no fictitious accepted interface, no recovery. Retain typed capture and block later normal progress until actual ordered reset; report this bounded limitation. |
| Unsupported SC/format | SC configuration2; separately unknown kind and out-of-domain sampled values | No low-bit truncation or canonical alias to configuration0/1; no grant/open. Supported-format unsupported values remain held under the chosen profile. Invalid format and known unsupported requests remain distinguishable in metadata. |
| OUT open failure | U; fail first open | Exactly one failed OUT attempt; no IN attempt, no owner/grant/recovery; document fenced and mounted0. No erased programming trace. |
| IN open failure | U; OUT succeeds; IN fails | Exactly two attempts, no owner/grant/recovery, mounted0. Independently assert selected cleanup policy; never infer OUT closed from mounted0. Follow with SC1 retry to prove cleanup is not skipped. |
| Dirty across supersession/reset | Failed open retains token F and programmed OUT; admit newer raw request/reset and try SC1 again | F and dirty remain, partial programming is not silently erased, and no new open or grant bypasses cleanup. F does not change to the newer control epoch. |
| Cleanup identity | Dirty F; wrong/stale token; missing cleanup facts; then exact F after all owners settle | Wrong/stale cleanup changes nothing; missing facts wait. Exact F may clear only this dirty condition and the explicitly modeled external programming state. No new binding, generation, recovery ticket, or recovery promise is created. |
| Cleanup replay after new failure | Clean F; attempt SC1 again and fail with F2; replay cleanup F | F2 remains dirty and its partial programming stays visible. Original F cannot be restamped or accepted against F2. Matching F2 still requires all owners to be settled. |
| Status submission failure | Successful endpoint programming; reject automatic bind or return false after a successful bind | Before-bind rejection leaves no owner; after-bind false retains exact C, queues cancellation, and leaves core BUSY clear. Both stay fenced, grant nothing and begin no recovery. Retained C needs explicit settlement. |
| Wrong binding route | On typed SC/SI, call normal descriptor bind; on raw request, call automatic bind | Rejected; neither silently falls back to the other owner type. Also reject OUT0, non-NULL buffer, or nonzero length for automatic binding. |
| Generic auto SUCCESS | H; complete(C,SUCCESS,0) | Reject/retain C; no TinyUSB event, callback, ACK or implicit settlement. Same-generation invalid current completion fences and requests cancellation. Repeat after recovery at G+1: do not fault new work merely by attributing the old C to G+1. |
| Explicit auto cancellation | H; exact settled ABORTED/0; service | Owner retires without any TinyUSB completion/ACK. Current unrequested cancellation leaves request fenced; an expected supersession cancellation does not create a new fault. BUSY clears only with a justified new control/reset path, not a fabricated completion. |
| Current packet fault | H at current G; nonzero reason twice | First fences/requests cancellation while retaining C; repeat is idempotent. No grant after the fault, even if a later malformed SUCCESS is supplied. Exact cancellation eventually retires C. |
| Stale owner variations | Mutate each of C.id/epoch/generation/sequence/endpoint, and replay C after owner reuse | Stale calls do not grant, settle, cancel or fault the new owner. Preserve historical C in fixture storage through reuse. Test same address/endpoint with a different id. |
| New raw held before dispatch | H; offer raw N+1 with missing stable/visible/stall facts; attempt old grant and finish-reset | Both forward actions blocked while E is still unchanged. Original C stays owned, raw snapshot retained. No retagging old C/N to N+1. |
| New typed held before dispatch | H; offer SC/SI N+1 with any missing capture fact | Same pre-dispatch block as raw ingress. Changing caller's source struct afterwards does not change the frozen notification or permit an old grant. |
| New raw admitted | H; dispatch newer raw request; do not settle C yet | Old grant stale, original cancellation requested once, service waits. Only original C settlement permits the new request's ordinary reply. New control owner never inherits old automatic grant state. |
| Reset over held offload | Hold N with missing facts; bus reset N+1 while adapter busy | RESET retry retained; original typed bytes unchanged. Only exact N+1 retry is eligible, older N is stale, N+2 waits externally. On successful reset admission no grant/owner settlement/promise is invented. |
| Reset after grant | H already granted; actual reset N+1; retain C | C remains owned until explicit original settlement; no second grant and no ACK. SERVICE-only reset draining may proceed, but cannot grant a subsequent held event. Older N never resumes after the reset barrier. |
| Deferred SOFT_RESET overlap | Existing real class reset waiting promises; offer newer typed event without its facts | No old deferred ACK or finish/restart while capture held, even though adapter E is unchanged. Actual admitted newer event invalidates old reply linkage without pretending any recovery promise. |
| Sequence boundary | Last N=MAX-2; admissible MAX-1; offer MAX; then wrap0/old sequences | MAX observation retained as local terminal LIMIT; no adapter admission, grant, or wrap. Progress0; exact old-owner settlement remains possible. Local terminal state is not a claim that hardware was stopped. |
| Internal identity boundary | Seed control/transport/submission identity individually at the actual next-overflow boundary | No wrapped/zero identity, grant or leaked new owner. Existing owners remain until explicit settlement. Preserve existing adapter convention: allocating MAX once is allowed; trying to advance MAX exhausts. External MAX is separately reserved. |

Do not substitute broad counters for the ownership oracle. On every rejected
grant, compare output object sentinel, every owned byte, cookie history,
descriptor/staging tails, programmed-endpoint map, existing recovery promises
and exact prior output/document traces. Permit only the documented fence,
cancellation-request and diagnostic changes for recognized current faults.

For source-copy authority controls, retain notification N, mutate the caller
struct into a different supported SC/SI, and dispatch N: the original is
authoritative. A later genuinely new sequence with the changed values must be
treated as a new event. No oracle should repair a stale sequence or cookie using
current component state.

### Programming-cleanup identity corner

Capture a failure token from the original attempt before `fence()` can advance
or exhaust a transport identity. A nonwrapping control epoch can identify that
attempt if the implementation enforces at most one attempt for it; a dedicated
identity is also valid, but must have its own checked saturation. Do not compare
an old failure's cleanup against the adapter's *current* control or transport
identity: actual reset/new SETUP may occur while the dirty record remains.
Conversely, a new failure after explicit cleanup must get a distinct token.

Cleanup is a separate external settlement fact. Require no DCD or PENDING owner,
prepared receive reservation, live delivery, or retained class response before
acceptance. A pending capture may still block all forward progress even after
cleanup succeeds. Cleanup does not grant status, open endpoints, clear a document
fault, advance its generation, or discharge RECEIVE/OUTPUT/TRANSPORT promises.
An exhausted software identity must not be treated as permission to forget a
dirty hardware attempt; if cleanup is still accepted in terminal state it must
only settle that exact retained record, never resume the terminal lifetime.

The synthetic programmed-endpoint map needs two separate events: an actual
programming attempt can leave OUT installed before IN fails; an explicitly named
cleanup operation later changes that map and supplies its original token. A
replayed *notification* of an old cleanup must not execute another simulated
cleanup against a new failure. This prevents a circular test which clears the
map merely because production cleared its dirty flag.

## Provenance and remaining limits

The fixed primary TinyUSB pin is commit
`dae3f9a366bfcddbf9dcf1b48d7500286a849539` (0.21.0, MIT). This review uses the
repository's pinned originals plus its existing protocol patch, not a downloaded
latest version. Sources inspected:

| Relative path | SHA256 |
|---|---|
| open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.c | ed7195a2d007d909a177d5f5e3451257f4341e84898946a3b0eef5adaac0d72f |
| open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.h | 523f543409e0252c5462cff43c28e699ed52a8da70a5a23028a0358461a879d3 |
| open-firmware/udc-setup/hp1020_udc_setup.c | 23fe0cd38f092274d345cde59fb28414fa47ffc20fc2364e44830f1e3f4d282a |
| open-firmware/udc-setup/hp1020_udc_setup.h | 39222609106c6230d725faf74f25177e2b95c5f73884167767dd77cebc7e493b |
| vendor/tinyusb-0.21.0/src/device/usbd.c | 38de54351d81878e6543f2b022d0c39f45d28c8f0888491796398dec45e727be |
| vendor/tinyusb-0.21.0/src/device/dcd.h | baf785f2d5d8e3f74bd6d6a04559fc606d341983aad35aa08e168b452c2750db |
| open-firmware/tinyusb-device/patches/protocol-compatibility.patch | 62edce457c5f3a4d7be7db18a9aea36be0e59477985252df53d23a2d2261a5cb |

The new adapter header and partial source under
`/tmp/hp1020-offload-draft-20261002/draft/` were read while still being drafted;
they have no reviewed final hash yet. The findings above are independent of its
implementation oracle. Final execution must freeze the actual modified closure.

No test here establishes HP dynamic-CSR capability, inherited controller mode,
coherent status acquisition, actual CSR programming, hardware rejection, stall
clearing, physical status completion, USB ACK, interrupt order or DMA/cache
settlement. Those remain explicitly supplied facts or unimplemented operations.
The reconstructed path does not recover omitted malformed raw SETUP high bits.
Its status ownership model is conservative until a separately justified
controller completion contract exists.
