#!/usr/bin/env python3
"""UNEXECUTED draft: typed hardware-offload notifications in synthetic RAM.

No controller access or physical USB. Reconstructed requests, automatic status
permission and original-cookie cancellation are distinct from wire completion.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import runpy
import select
import shutil
import struct
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1] if Path(__file__).parent.name == 'scripts' else Path.cwd()
spec = importlib.util.spec_from_file_location('offload_composed', ROOT/'scripts/validate-hp1020-udc-composed.py')
comp = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = comp
spec.loader.exec_module(comp)
ep0, base, core = comp.ep0, comp.base, comp.core
bulk_reference = comp.bulk_reference
SRC = ROOT/'open-firmware/udc-offload-test'
OUT = ROOT/'analysis/usb-path/udc-offload'
OK, WAIT, STALE, INVALID, FAULT, ADAPTER_ERROR, LIMIT = range(7)
CAPTURE_FACTS, GRANT_FACTS = 0x01010101, 0x0101
MODE_EVIDENCE = ('analysis/usb-path/controller-reference/manuals/README.md',
    'analysis/usb-path/controller-reference/manuals/offload-mode-review.json',
    'analysis/usb-path/controller-reference/manuals/offload-mode-review.tar.gz')
CANONICAL = {('SC', 1): bytes.fromhex('0009010000000000'),
             ('SC', 0): bytes.fromhex('0009000000000000'),
             ('SI', 0): bytes.fromhex('010b000000000000')}


class Host(comp.Host):
    def __init__(self, executable, directory, fill, capacity, interface):
        self.offload_rows, self.offload_oracles = [], []
        self.auto_owners, self.typed_offers = {}, {}
        super().__init__(executable, directory, fill, capacity, interface)
        self.offload_initial = self.offload.copy()

    def read_row(self):
        if not select.select([self.process.stdout], [], [], 30)[0]:
            self.process.kill(); self.process.wait()
            raise AssertionError('offload fixture timed out: '+str(self.directory))
        raw = self.process.stdout.readline()
        with (self.directory/'raw-stdout').open('ab') as saved:
            saved.write(raw)
        assert raw, ('fixture ended early', self.directory)
        row = json.loads(raw)
        assert len(row) == 368, row
        self.ep0, self.udc, self.ingress = row[96:200], row[200:248], row[248:288]
        self.offload = row[288:368]
        return row[:96]

    def step(self, op, a=0, b=0, c=0, d=0, data=b'', result=OK, expect=None):
        row = super().step(op, a, b, c, d, data, result, expect)
        self.offload_rows.append(self.offload.copy())
        o = self.offload
        assert o[11:13] == [0,1], ('offload ownership/capture', op, o)
        if o[6] > len(self.auto_owners):
            assert o[6] == len(self.auto_owners)+1
            token = o[16]
            assert token and token not in self.auto_owners and o[13] == 1
            expected_cookie = [row[21], row[3], row[32], 0, 0x80]
            assert o[16:21] == expected_cookie and row[28:30] == [token,0]
            original = self.typed_offers[o[26]]
            assert o[26:31] == original and o[32:35] == [1,0,1]
            assert o[35] in (0,1), 'core BUSY can clear after a retained bind is rejected'
            expected_raw = CANONICAL[('SC',original[2])] if original[1] == 1 else CANONICAL[('SI',0)]
            assert struct.pack('>2I', *o[64:66]) == expected_raw
            assert row[77] == 0, 'automatic status cannot borrow a class response'
            assert self.slot(1)[0] == 0, 'automatic status has no packet descriptor'
            self.auto_owners[token] = dict(cookie=expected_cookie, original=original.copy())
            self.offload_oracles.append(dict(step=len(self.rows)-1, kind='auto_bind',
                canonical_hex=expected_raw.hex(), **self.auto_owners[token]))
        if o[13]:
            assert o[16:21] == self.auto_owners[o[16]]['cookie'], 'original cookie changed'
        with (self.directory/'host-offload-steps.jsonl').open('a') as saved:
            saved.write(json.dumps(self.offload)+'\n')
        return row

    def offer_offload(self, kind=1, cfg=1, interface=0, alt=0, *, sequence=None, result=OK):
        sequence = self.next_sequence() if sequence is None else sequence
        raw_capture = self.ingress[32:36].copy()
        before = self.row[2:96].copy()
        self.step(100, sequence, kind, (cfg<<16)|(interface<<8)|alt, result=result)
        assert self.row[2:96] == before, 'capture cannot dispatch a protocol request'
        assert self.ingress[32:36] == raw_capture, 'typed capture is not a raw SETUP record'
        if result == OK or (result == LIMIT and sequence == 0xffffffff):
            self.typed_offers[sequence] = [sequence,kind,cfg,interface,alt]
            assert self.offload[21:26] == self.typed_offers[sequence]
            self.offload_oracles.append(dict(step=len(self.rows)-1, kind='typed_capture',
                original=self.typed_offers[sequence].copy(), previous_raw_capture=raw_capture))
        return sequence

    def dispatch_offload(self, sequence, *, facts=CAPTURE_FACTS, busy=0, result=OK):
        self.step(101, sequence, facts, busy, result=result)

    def grant(self, sequence, token, *, facts=GRANT_FACTS, mutant=0, result=OK):
        before = self.offload[7]
        self.step(102, sequence, token, facts, mutant, result=result)
        if result == OK:
            original = self.auto_owners[token]
            assert self.offload[7] == before+1
            assert self.offload[37:42] == original['original']
            assert self.offload[42:47] == original['cookie']
            self.offload_oracles.append(dict(step=len(self.rows)-1, kind='auto_grant', **original))
        else:
            assert self.offload[7] == before

    def cancel_retained(self):
        for token in (self.row[26],self.row[28]):
            if token in self.auto_owners:
                self.cancel_auto(token)
            elif token:
                self.step(43,token,1)
        if self.row[30]:
            self.step(64,self.row[30],1)

    def cancel_auto(self, token, *, settled=1, mutant=0, result=OK):
        self.step(103, token, settled, 0, mutant, result=result)


def compile_host(temp, effective):
    ep0_src = ROOT/'open-firmware/udc-ep0'
    out = ROOT/'open-firmware/udc-out'
    setup = ROOT/'open-firmware/udc-setup'
    implementation = [SRC/'fixture.c', SRC/'host-check.c', ep0_src/'hp1020_udc_ep0.c',
        out/'hp1020_udc_out.c', setup/'hp1020_udc_setup.c',
        base.ADAPTER/'hp1020_tusb_adapter.c', base.PRINTER/'hp1020_usb_printer.c',
        base.RX/'hp1020_usb_receive.c', base.RX/'hp1020_usb_document.c']
    implementation += [base.IMG/name for name in ('hp1020_image.c', 'hp1020_image_page.c',
        'hp1020_image_stream.c', 'hp1020_image_ring.c', 'hp1020_image_output.c')]
    implementation += [base.SEM/'hp1020_semantic.c', base.SEM/'hp1020_page_plan.c',
        core.VENDOR/'libjbig/jbig85.c', core.VENDOR/'libjbig/jbig_ar.c']
    implementation += [effective/'src'/name for name in ('tusb.c', 'device/usbd.c', 'common/tusb_fifo.c')]
    flags = ['clang', '-std=c11', '-O1', '-g', '-fno-common', '-Wall', '-Wextra', '-Werror',
        '-fsanitize=address,undefined']
    include = ['-I'+str(p) for p in (SRC, ep0_src, out, setup, ROOT/'open-firmware',
        base.SRC, base.ADAPTER, base.PROTOCOL, base.PRINTER, base.RX, base.IMG, base.SEM,
        core.VENDOR/'libjbig', effective/'src')]
    core.command(flags+include+implementation+['-o', temp/'host'])
    full = ROOT/'vendor/foo2zjs-source'
    core.command(flags+['-I'+str(full), base.IMG/'reference.c', full/'jbig.c', full/'jbig_ar.c',
        '-o', temp/'reference'])


def sources(temp):
    tested = comp.sources(temp)
    selected = set(SRC.glob('*.[ch]')) | set(SRC.glob('*.ld'))
    selected.update(ROOT/'scripts'/name for name in (
        'validate-hp1020-udc-offload.py', 'build-hp1020-udc-offload-target.sh'))
    selected.update(ROOT/name for name in MODE_EVIDENCE)
    for path in sorted(selected):
        name = str(path.relative_to(ROOT)); tested[name] = core.sha(path.read_bytes())
        destination = temp/'source'/name; destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
    (temp/'source-sha256.json').write_text(json.dumps(tested, indent=2)+'\n')
    return tested


# Scenario oracles and main remain unfinished pending the frozen fixture ABI.
# This draft has not been imported, compiled, or executed.
