def usb_offload_consistency_gate(root):
    """Independent saved-transcript checks; never import the experiment."""
    import hashlib
    import json
    import re
    from pathlib import Path

    root = Path(root)
    path = root / 'analysis/usb-path/udc-offload/validation.json'
    bad = set()

    def need(value, reason):
        if not value:
            bad.add(reason)

    def packed(words):
        return b''.join(v.to_bytes(4, 'big') for v in words)

    try:
        report = json.loads(path.read_bytes())
        target = report['target']
        need(report['status'] == target['status'] == 'pass', 'paired status')
        sources = report['source_sha256']
        required = {
            'scripts/validate-hp1020-udc-offload.py',
            'scripts/build-hp1020-udc-offload-target.sh',
            'open-firmware/udc-offload-test/fixture.c',
            'open-firmware/udc-offload-test/host-check.c',
            'open-firmware/udc-offload-test/target-check.ld',
            'open-firmware/udc-composed-test/fixture.c',
            'open-firmware/udc-setup/hp1020_udc_setup.c',
            'open-firmware/udc-setup/hp1020_udc_setup.h',
            'open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.c',
            'open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.h',
            'open-firmware/tinyusb-device/patches/protocol-compatibility.patch',
            'vendor/tinyusb-0.21.0/src/device/usbd.c',
        }
        need(required <= sources.keys(), 'implementation and reusable stack source closure')
        for name, digest in {**sources, **report['fixture_sha256']}.items():
            relative = Path(name)
            need(not relative.is_absolute() and '..' not in relative.parts and
                 relative.as_posix() == name and re.fullmatch('[0-9a-f]{64}', digest),
                 'safe exact source paths')
            need(hashlib.sha256((root / relative).read_bytes()).hexdigest() == digest,
                 'current exact tested sources and fixtures')
        need(len(report['fixture_sha256']) == 6, 'six independent document fixtures')
        mode = report['offload_mode_evidence']
        need(set(mode) == {
            'analysis/usb-path/controller-reference/manuals/README.md',
            'analysis/usb-path/controller-reference/manuals/offload-mode-review.json',
            'analysis/usb-path/controller-reference/manuals/offload-mode-review.tar.gz'},
             'bounded original mode evidence')
        need(all(sources[n] == digest for n,digest in mode.items()), 'mode evidence captured')
        need(report['hp_dynamic_csr_capability_established'] is False and
             report['automatic_grants_are_acknowledgments'] is False and
             report['controller_quiescence_established'] is False and
             report['actual_peripheral_accesses'] == report['usb_transfers'] ==
             report['completed_native_page_lifecycles'] == 0, 'explicit supplied hardware scope')

        cases = report['cases']
        need(len(cases) == len(target['cases']) and bool(cases), 'complete paired matrix')
        # Final scenario names/count and measured target sizes are added only
        # after the first captured run; this draft is not yet an aggregate gate.
        seen = set()
        totals = dict(captures=0, binds=0, grants=0, cancellations=0)
        for case, native in zip(cases, target['cases']):
            key = (case['scenario'], case['fill'], case['interface'])
            need(key not in seen and case['fill'] in (0,204) and case['interface'] == 0
                 and case['capacity'] == 64, 'bounded unique profiles')
            seen.add(key)
            need(case['case'] == native['case'] and case['status'] == native['status'] == 'pass'
                 and native['all_steps_equal'] is True
                 and native['typed_captures_original_cookies_and_grants_equal'] is True
                 and native['all_pixels_wire_notifications_descriptors_and_storage_equal'] is True,
                 'paired execution and exact captures')
            need(case['capture_sha256'] == native['capture_sha256'] and
                 set(case['capture_sha256']) == {'pixels','wire','receive','output','documents',
                                               'ep0','bulk_descriptor','setup_record'},
                 'complete guarded storage and output captures')
            rows, erows, brows, srows, orows, events = (case[n] for n in
                ('steps','ep0_steps','bulk_steps','setup_steps','offload_steps','events'))
            need(bool(rows) and len({len(a) for a in (rows,erows,brows,srows,orows,events)}) == 1,
                 'complete 368-word transcript')
            prev, pe, pb, ps, po = (case[n] for n in
                ('initial','initial_ep0','initial_bulk','initial_setup','initial_offload'))
            typed, owners, granted = {}, {}, set()
            bind_steps, grant_steps, capture_steps = set(), set(), set()
            for i,(r,e,b,s,o,event) in enumerate(zip(rows,erows,brows,srows,orows,events)):
                need([len(a) for a in (r,e,b,s,o)] == [96,104,48,40,80] and
                     r[15:17] == [0,1] and e[2:5] == [0,1,1] and b[7:10] == [0,1,1]
                     and s[12:15] == [0,1,3] and o[11:13] == [0,1] and o[76:80] == [0]*4,
                     'row shapes, ownership and guards')
                op,a,arg_b,arg_c,arg_d = event['words']
                result = event['result']
                need(r[0] == result and op not in (0,2,3,4,5,13,19), 'ordered typed/component ingress')
                if 100 <= op <= 107:
                    need(event['data_hex'] == '', 'typed commands have no raw payload')
                if op == 100 and (result == 0 or (result == 6 and a == 0xffffffff)):
                    original = [a,arg_b,(arg_c >> 16)&255,(arg_c >> 8)&255,arg_c&255]
                    need(a not in typed and o[21:26] == original and r[2:] == prev[2:]
                         and s[32:36] == ps[32:36], 'typed copy is not raw capture or dispatch')
                    typed[a] = original
                    capture_steps.add(i)
                if o[6] != po[6]:
                    token = o[16]
                    original = typed[o[26]]
                    cookie = [r[21],r[3],r[32],0,128]
                    canonical = bytes.fromhex('0009010000000000' if original[1:3] == [1,1]
                                else '0009000000000000' if original[1:3] == [1,0]
                                else '010b000000000000')
                    need(o[6] == po[6]+1 and token not in owners and token > 0 and
                         o[16:21] == cookie and o[26:31] == original and
                         original[1] in (1,2) and original[2] in (0,1) and original[3:] == [0,0]
                         and (original[1] != 2 or original[2] == 1) and
                         packed(o[64:66]) == canonical and r[28:30] == [token,0]
                         and o[13] == 1 and o[32:35] == [1,0,1] and r[77] == 0,
                         'original no-buffer owner and literal canonical request')
                    need(e[56] == 0 and e[39:41] == pe[39:41] and e[87:89] == pe[87:89]
                         and r[24:26] == prev[24:26] and o[57] == po[57],
                         'auto bind creates no descriptor, wire or status callback')
                    owners[token] = (cookie,original)
                    bind_steps.add(i)
                if o[13]:
                    need(owners[o[16]][0] == o[16:21], 'held owner never retagged')
                if op == 102:
                    need(r[2:] == prev[2:] and e == pe and b == pb and o[57] == po[57],
                         'grant never completes, publishes or restarts anything')
                    if result == 0:
                        cookie,original = owners[arg_b]
                        need(arg_d == 0 and arg_c == 0x0101 and a == original[0] and
                             arg_b not in granted and o[7] == po[7]+1 and
                             o[37:42] == original and o[42:47] == cookie and
                             o[13] == o[15] == o[33] == 1,
                             'one current exact-original status proposal')
                        granted.add(arg_b)
                        grant_steps.add(i)
                    else:
                        need(o[7] == po[7] and o[37:47] == po[37:47], 'rejected grant retains output')
                if op in (103,104,105):
                    need(o[57] == po[57] and r[24:26] == prev[24:26] and e == pe,
                         'auto settlement/fault never emits a protocol ACK')
                if op == 105:
                    need(result != 0 and o[13] == po[13] and r[28:30] == prev[28:30],
                         'generic auto success cannot retire ownership')
                prev,pe,pb,ps,po = r,e,b,s,o
            need(po[2] == len(capture_steps) and po[6] == len(owners) and po[7] == len(granted),
                 'complete capture, bind and grant ledgers')
            for kind, indices in (('typed_capture',capture_steps),('auto_bind',bind_steps),('auto_grant',grant_steps)):
                need({item['step'] for item in case['offload_oracles'] if item['kind'] == kind} == indices,
                     'independent oracle coverage')
            guard = bytes([case['fill']])*16
            need(hashlib.sha256(guard+packed(brows[-1][24:28])+guard).hexdigest() ==
                 case['capture_sha256']['bulk_descriptor'] and
                 hashlib.sha256(guard+packed(srows[-1][28:32])+guard).hexdigest() ==
                 case['capture_sha256']['setup_record'], 'complete guarded live records')
            totals['captures'] += len(capture_steps)
            totals['binds'] += len(owners)
            totals['grants'] += len(granted)
            totals['cancellations'] += po[8]
        need(all(value > 0 for value in totals.values()), 'positive typed-path coverage')
    except (OSError, ValueError, KeyError, TypeError, IndexError, OverflowError) as error:
        return False, 'offload transcript incomplete: '+str(error)
    return not bad, '; '.join(sorted(bad)) if bad else 'paired typed offload owners, grants, original identities and guarded captures agree; no physical USB claim'
