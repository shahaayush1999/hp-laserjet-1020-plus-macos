# Unexecuted repeated-configuration protocol regression

Full script draft: `/tmp/hp1020-protocol-repeat-tests-v2-20261002.py`.
It is intended to replace `scripts/validate-hp1020-tinyusb-device.py` before the
lead's normal source capture and execution. Do not run it from its temporary
path: the existing script resolves the repository relative to `scripts/`.
No imports, builds, validators, host/QEMU execution or repository edits occurred.

Original script SHA256:
`7ae8bc400bda72533e301247529ce5c5491ac056ce5535b87df38b32e9e1bf5a`.
Inspected unchanged protocol fixture SHA256:
`73bdc2442f0f4ec877d60ee9bbb41bbe0ec81c5f81f520fe63580e6d967a7edd`.

Only the existing `configuration-reset-preserves-control-request` scenario is
extended. It still exercises deconfigure/reconfigure and checks the exact status
callback request fields, including the unchanged core's known erased context.
It then sets both bulk Halt features through ordinary requests, requires literal
stallmap12/openmap15, and repeats SC1. Patched execution must increment driver
reset count49 by exactly one, finish with openmap50=15 and stallmap10=0. The
unchanged core must retain the old reset count and stallmap12. The fixture reset
callback itself sets openmap3, so its return to15 requires actual open callbacks.
No clear-halt operation is injected between reselection and observation.

Two subsequent GET_STATUS requests independently query core IN/OUT halt state:
patched bytes0000; unchanged host bytes0100, with its already-understood target
BE bytes0001 recorded explicitly. Existing exact packet coverage, original token,
status-context and all host/target row comparisons remain unchanged. The fixture
does not expose a physical DATA0 toggle or real controller reset; these tests
only exercise the core reset/reopen path and its supplied DCD callbacks.

Expected consistency-gate changes after actual regeneration:

- Case totals stay52 upstream and160 patched, with the same four affected
  fill/interface combinations. Source count remains68; no ABI/source is added.
- Unchanged protocol limitations grow14→18: add kind
  `repeated_nonzero_configuration_preserves_endpoint_halt`, exactly once per
  affected scenario. The other four finding kinds remain unchanged.
- Unchanged target BE mismatches grow32→40: the two additional endpoint-status
  replies per affected scenario are each independently checked. Patched
  limitations/mismatches must remain empty.

These are source-derived expected counts, not executed results. The lead should
confirm them from raw host/QEMU captures before updating the existing aggregate
predicates. Do not alter saved report hashes manually.
