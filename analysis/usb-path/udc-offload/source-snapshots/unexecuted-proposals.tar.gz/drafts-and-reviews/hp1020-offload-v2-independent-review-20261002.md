# Typed offload revision 2: independent static review

Reviewed 2026-10-02 by the USB reference-contract agent. This is a source review,
not an execution result. No project module was imported, no build/validator or
QEMU was run, and no repository, USB, MMIO or installed-printing state changed.
Only this review note was written. The lead owns integration and all execution.

## Exact reviewed drafts

- V2 root: `/tmp/hp1020-offload-v2-20261002/`.
- Complete patch: `changes.patch`, SHA256
  `09eb45caec623051bfaf13c7c4528e947925bce97812451ad894a7600e827944`.
- Every entry in its `DRAFT.sha256` verified with `shasum -a 256 -c`, including
  production C/H, fixture, local protocol patch/manifest, preserved effective
  v1/v2 source, and integration/evidence notes. No patch was applied or executed.
- Compared to preserved v1 patch SHA256
  `d0fad8a921b3bd680127d6eb4375a923dfb67d020016fba782c9acc00c9cebf1`.
- Changed scenario cross-check:
  `/tmp/hp1020-offload-cases-v2-20261002.py`, SHA256
  `d36334f83735ff778e5a71da7ff98c95981d33181aeee68e25840318e370e87b`.
  Its 29 profiles across two fills are unexecuted plans, not passed cases.

## Bounded result

No new production blocker found in the focused v1-to-v2 review. The four
corrections are consistent with the prior ownership contract and the cached
official USB 2.0 specification sections 9.1.1.5 and 9.4.5 cited in `DELTA.md`:

1. `effective-v2/src/device/usbd.c:998-1039` re-enters close/reset/open for every
   nonzero configuration selection. Adapter `changes_endpoints()` now fences
   both raw and typed nonzero selections, plus deconfiguration from a nonzero
   selection. Existing service waits for the original EP0 and bulk owners before
   dispatching this destructive request. The normal successful open callback
   marks one new binding; accepted status ownership remains necessary before
   one recovery begins. Repeated zero and ordinary polls create no recovery.
2. The configuration-only reset at effective `usbd.c:1012-1021` preserves
   connected/addressed/speed/current control context. The separate actual
   bus-reset route remains unchanged. This closes the connected=false side
   effect that would otherwise suppress subsequent suspend/resume handling.
3. Adapter `take_auto_status():579-582` waits on either core bulk HALT for the
   configuration-1 profile, including SI. Its exact original-cookie/control/
   transport/provenance checks remain intact. A valid new BUSY bulk owner after
   independently completed recovery does not invalidate the retained control
   owner. Supplied CSR-programmed facts explicitly include affected endpoint
   defaults/DATA0/Halt restoration; software flags alone do not prove these.
4. Adapter `driver_open():199-205` saves the raw or typed failure tuple before
   fencing can advance transport identity. Raw sequence0 is not a fabricated
   external sequence: the original nonzero control epoch identifies the single
   attempt. `ack_programming_cleanup():600-618` requires an exact tuple match,
   no DCD/PENDING/prepared/delivering/response owners, stopped receive, no open
   or mounted binding, and an explicit completed-cleanup fact. Reset/new SETUP
   does not clear dirty state. Cleanup does not supply recovery promises or
   reopen endpoints. Terminal lifetime remains fail-closed.

The unchanged v1-reviewed protections still retain automatic owners without any
TinyUSB completion/ACK, suppress grants behind newly held ingress, preserve
exact reset retries, and keep original cookies across receive-generation change.

## Scenario cross-check and remaining verification

The v2 scenarios correct the full endpoint-map oracle to 3/15/7 and retry an
already-known newer event before older normal service/grant. Repeated raw/typed
SC1 now expects old-owner drainage, close/reopen and fresh recovery. SI tests
retain both bulk HALTs until explicit supplied clearing, and raw partial-open
failure tests preserve a sequence0 cleanup ticket. Result-domain expectations
match the reviewed code, including raw failure's existing OK-with-STALL outcome.
No additional mismatch was found in this focused static comparison.

The lead's separate base fixture word68=`tud_connected()` is a required test
dependency; it is not included in this frozen C patch and was not reviewed here.
A useful additional reachable control remains: dirty programming plus a later
ordinary GET_DESCRIPTOR DCD owner must reject cleanup, and its explicitly settled
but still adapter-PENDING owner must also reject cleanup before reset service.
The production owner guards are present; this is extra execution coverage.

One nonblocking documentation correction before integration: adapter header
line223 still says unqualified "Idempotent configuration" creates no recovery.
Qualify that as repeated configuration0 to avoid reviving the superseded SC1
claim. No frozen source was changed by this reviewer.

HP dynamic-CSR applicability, physical endpoint programming/defaults, stable
event acquisition, original-event chronology, cache/DMA settlement, hardware
status permission and host ACK remain separate unproved/supplied boundaries.
This review adds no physical USB or native-page lifecycle and does not establish
a working firmware replacement. Preserve old reports as historical exact-source
results and run the revised focused and aggregate checks sequentially.
