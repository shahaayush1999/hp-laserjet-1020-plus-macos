# Typed standard-request offload — unexecuted integration handoff

The files under `draft/` and `changes.patch` are a proposed source change only.
No build, project-code import, validator, host execution, QEMU run or hardware operation has
been performed for this draft. `SOURCES.sha256` records the original source
closure copied before editing; `DRAFT.sha256` records the frozen proposed files.
The original copies are retained under `original/`. No repository source was
changed by this agent. The lead owns application, execution, evidence capture,
report generation and any later source-hash changes.

## Change boundary

The four production C/H files are the existing TinyUSB printer adapter and the
single-event SETUP bridge. The existing local TinyUSB protocol patch now
reinitializes every nonzero configuration selection, including the same value.
Its upstream pins and prepare-script verification gates remain unchanged; the
patch and effective-result hashes are regenerated from actual proposed bytes.
There is no new production translation unit. The composed fixture gains an optional compile-time block;
without `HP1020_COMPOSED_OFFLOAD`, its 288-word ABI and operations are unchanged.
The new `udc-offload-test` fixture enables that block, reusing the established
EP0/OUT descriptor paths, guards, cancellation queue and borrowed-buffer ledger.
Its codec emits 368 words: existing 288 plus OFFLOAD80. All new commands and
word meanings are specified in `draft/open-firmware/udc-offload-test/README.md`.
The lead's saved builder uses the matching future repository path
`open-firmware/udc-offload-test` and needs no additional C dependency.

`hp1020_udc_setup_offer_offload` retains a typed sample in the same event slot
and original sequence domain as actual raw SETUP/reset. `dispatch_offload`
requires four independent exact-boolean controller facts. It invokes the typed
adapter entry, which supplies canonical bytes only to TinyUSB's normal event
boundary. The original raw record, DMA label and provenance are never forged.

`hp1020_tusb_adapter_bind_auto_status` is the sole synchronous DCD reentry for
the resulting IN0 NULL/0 status owner. `hp1020_udc_setup_take_auto_status` is the
grant entry; its adapter counterpart is bridge-exclusive. The bridge must be
fully permitted and the event must still be its latest admitted ingress.
Granting retains the original owner and only authorizes the caller's immediate
serialized CSR action. It does not write MMIO, emit a ZLP, allocate a descriptor,
assert host ACK or satisfy a recovery promise. A newer offered event blocks it
even before the adapter's control epoch advances. The grant cannot be queued
or reused after an intervening ingress.

Only an explicit settled ABORTED/0 event retires an automatic-status owner.
Generic SUCCESS is rejected with ownership retained. Delivery suppresses every
TinyUSB completion/status callback for that owner. The original receive
generation can differ after successful recovery; it is not retagged or confused
with the original control/ingress identities. A late prohibited completion for
a superseded control owner cannot fence a newer same-generation request.

A successful nonzero configuration uses the existing three-promise recovery,
including repeated selection of configuration1. Admission fences/drains original
owners before core close/reopen establishes a fresh binding. Repeated SC0 stays
idempotent and may grant while unmounted/stopped. Typed SI0
explicitly establishes one reselection recovery because TinyUSB's fallback does
not reopen endpoints. Unsupported values are deliberately held until actual
reset in this bounded draft. General reject/STALL-and-continue policy remains
unfinished and is not represented by a fabricated controller operation. The
supplied CSR-programmed fact includes completed affected-endpoint default,
toggle and halt reset. A retained core bulk halt makes configuration1 grant
wait; BUSY from a valid newly armed packet after recovery does not.

## Partial programming cleanup

An endpoint-open failure in raw or typed configuration records the original failed
`{sequence, control_epoch, transport_epoch}` before fencing can advance identity.
Sequence0 explicitly marks raw provenance; a nonzero original control epoch is
required, without allocating another identity. Typed requests retain their
external sequence. All ticket fields must match the retained failed attempt.
The saved dirty ticket survives newer request/reset observations. Dirty state
prevents another endpoint-open attempt, status grant or transport-ready reset
acknowledgement. It is separate from document recovery identities/promises.

`hp1020_tusb_adapter_pending_programming_cleanup` reads the retained ticket.
`hp1020_udc_setup_ack_programming_cleanup` forwards a separately supplied
completed-cleanup fact to the adapter. An exact ticket, no DCD/PENDING/prepared/
delivering/response owner, stopped receive state and no mounted/open binding are
required. A matching original ticket may clear the old dirty record after a
newer reset; replaying it after another failure cannot clear that later record.
Cleanup does not reopen, restart, grant or manufacture a recovery promise.

Fixture word67 is an independent programmed-endpoint map, initially literal3.
Reset notification alone does not clear it. Actual successful DCD open/close
callbacks and a supplied exact-attempt cleanup are the only mutation paths.
Words68..71 retain a second failed-attempt witness captured before adapter
fencing. Words72..75 expose actual programming callback order/count. This lets
the oracle distinguish an OUT success followed by IN failure from no binding,
without deriving physical cleanup from `!mounted` or adapter success.

## Evidence and integration obligations

The official family references support SC/SI reconstruction and a dynamic CSR
status gate, but original HP mode applicability remains unproved. The separate
static review found no identified direct stock write enabling CSR_PRG or granting
CSR_DONE; mode/gate/currentness are supplied facts, not conclusions from an IRQ
bit or startup. SET_ADDRESS remains outside this draft. A grant is not ACK, and
DMA completion/count evidence must not be promoted to successful wire transfer.

Before the first run, retain these drafts plus exact compiler/fixture/source
snapshots and all raw host/QEMU captures using the lead's established workflow.
Measure target structure sizes rather than carrying old values forward. The
new validator should compare all 368 words except the established host/target
size word59, preserve exact wire/pixels/documents/storage oracles, and prove
that automatic status adds neither descriptor publication nor wire bytes.
Capture canonical eight-byte internal notifications independently from typed
values, and retain the source-derived adversarial review separately from results.

The earlier 132 adapter, 34 continuous and 34 composed cases remain separate
scopes; rerun them and the full sequential suite after integration as directed
by the lead. Passing this new bounded profile would add zero physical USB/native
page lifecycles and would not establish a real DCD or a working replacement.
