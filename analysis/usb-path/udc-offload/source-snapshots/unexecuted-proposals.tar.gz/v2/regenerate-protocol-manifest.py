#!/usr/bin/env python3
"""Edit-only helper: regenerate proposed patch/hash metadata from saved bytes.

No project code is imported, compiled, executed or validated. The repository's
unchanged prepare script remains responsible for the normal full-source gates.
"""
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOCAL = Path('open-firmware/tinyusb-device/patches')
manifest = json.loads((ROOT/'original'/LOCAL/'manifest.json').read_text())
chunks = []
for name, record in manifest['files'].items():
    original = (ROOT/'original/vendor/tinyusb-0.21.0'/name).read_bytes()
    result = (ROOT/'effective-v2'/name).read_bytes()
    assert hashlib.sha256(original).hexdigest() == record['original_sha256']
    chunks.extend(difflib.unified_diff(original.decode().splitlines(keepends=True),
        result.decode().splitlines(keepends=True), fromfile='a/'+name, tofile='b/'+name))
    record['result_sha256'] = hashlib.sha256(result).hexdigest()
patch = ''.join(chunks).encode()
(ROOT/'draft'/LOCAL/'protocol-compatibility.patch').write_bytes(patch)
manifest['patch_sha256'] = hashlib.sha256(patch).hexdigest()
for rationale in manifest['rationale']:
    if rationale['change'] == 'Preserve in-flight SET_CONFIGURATION context':
        rationale['change'] = 'Preserve bus and in-flight SET_CONFIGURATION context'
        rationale['reason'] = (
            'configuration_reset clears the whole device object. Save and restore '
            'connected/addressed, speed and the current control context when '
            'reinitializing a nonzero configuration, so bus connection/address '
            'and the actual request/failure state survive. Actual bus reset '
            'continues to clear this state through its unchanged path.')
manifest['rationale'].append(dict(
    change='Reinitialize every nonzero SET_CONFIGURATION selection',
    boundaries=['src/device/usbd.c: process_std_device_request SET_CONFIGURATION'],
    reason=('USB 2.0 sections 9.1.1.5 and 9.4.5 require affected endpoint defaults, '
        'DATA0 toggle and halt reset even when selecting the current configuration. '
        'Reenter the existing close/reset/open path for every nonzero selection; '
        'repeated zero remains unchanged. DCD endpoint operations must truthfully '
        'supply physical programming/defaults and settlement; this core patch '
        'does not establish controller quiescence or wire acknowledgment.'),
    source=dict(title='Universal Serial Bus Specification Revision 2.0',
        revision_date='2000-04-27', sections=['9.1.1.5', '9.4.5'],
        printed_pages=[243, 256])))
manifest['adapter_obligations'].append(
    'Every nonzero configuration selection, including the current value, must '
    'fence and settle original endpoint owners before core close/reset/open. '
    'Automatic status permission requires supplied affected-endpoint defaults, '
    'toggle and halt reset; a retained software halt is not success.')
manifest['validation_scope'] = (
    'Proposed source bytes and patch/result hashes regenerated from preserved '
    'upstream and disposable edited bytes. Existing prepare-script provenance, '
    'fuzz-zero application and full effective-source gates are unchanged. '
    'No compilation, fixture execution, QEMU, USB transfer, controller port or '
    'hardware validation is claimed for this revision.')
(ROOT/'draft'/LOCAL/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
