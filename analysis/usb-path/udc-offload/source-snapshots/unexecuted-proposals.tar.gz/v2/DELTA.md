# Revision2: standards correction before first execution

This revision preserves `/tmp/hp1020-offload-draft-20261002/` unchanged. The old
draft's patch SHA256 remains
`d0fad8a921b3bd680127d6eb4375a923dfb67d020016fba782c9acc00c9cebf1`.
Neither draft has been built or exercised. The metadata helper only generated
patch text and hashes from copied source bytes; it did not import project code
or run a validator. The lead owns the first execution.

The primary reference is *Universal Serial Bus Specification Revision2.0*,
27April2000: section9.1.1.5, printed page243, requires affected endpoint defaults
and DATA0 on configuration/reselection; section9.4.5, printed page256, explicitly
requires halt reset even for the current configuration/interface. The lead's
official cached PDF/text are `/tmp/hp1020-usb2-spec-20261002.pdf` and `.txt`.
Their exact hashes are retained in `EVIDENCE.sha256`.

Changes from revision1:

- The existing local TinyUSB patch now enters its close/reset/open path for
  every nonzero SET_CONFIGURATION, including the same value. Repeated zero
  remains unchanged. The adapter fences/drains every matching raw or typed
  admission before any endpoint programming; the ordinary open callback then
  establishes a new binding recovery. Polls still create no recovery.
- Configuration-only reset preserves logical `connected` and `addressed`, along
  with the already-preserved speed/control context. The actual bus-reset path
  is unchanged and still clears its normal state. This prevents a routine
  reselection from accidentally making `tud_connected()` false and suppressing
  later suspend/resume handling. The lead owns a separate existing-fixture
  word68 observation of `tud_connected()`; it is not included in this patch.
- The supplied `csr_programmed` contract includes completed affected endpoint
  default/toggle/halt reset. Configuration1 grants wait while either bulk
  endpoint remains core-stalled. BUSY is not rejected: a new packet may already
  have been armed after recovery. The held original automatic-status cookie is
  still not retagged to a new document generation.
- Programming failures now retain a dirty ticket for raw and typed requests.
  Sequence0 explicitly denotes raw provenance; the original nonzero control
  epoch and transport epoch identify the attempt. Cleanup checks nonzero control
  epoch and exact equality of all ticket fields. No new identity is allocated.
  A newer request/reset cannot clear dirty state or replace the original ticket.
  The fixture's injected failure now applies to raw requests as well and captures
  `active_offload.sequence`, never a historical typed shadow. A raw failure may
  retain the pinned core's OK-with-STALL service result; tests must observe that
  behavior rather than impose the typed path's explicit ERROR result.

SI0 remains an explicit adapter reselection because the pinned TinyUSB fallback
does not reopen endpoints. Its supplied physical endpoint defaults/reset facts
remain necessary; this revision adds no physical halt-clear operation. Automatic
status remains one permission proposal, not a CSR write, packet completion or
host ACK. Unsupported typed values remain held until actual ordered reset.

`effective-v1/` retains the old patched C/H source and `effective-v2/` the edited
proposed source. `regenerate-protocol-manifest.py` derives the complete local
protocol patch and its result SHA256s from those actual bytes. It preserves all
upstream pins, license/provenance and original source hashes. The repository's
`prepare-hp1020-tinyusb.py` remains unchanged, including exact upstream-file
verification, fuzz-zero patch application and full effective-source equality.
The lead must run those normal gates before testing. No generated report is
altered here, and no earlier tested hash is presented as validating this revision.

The optional fixture remains OFFLOAD80/368 total; no operation or row layout was
added. Before first execution, update independent repeated-config1 expectations
to assert original-owner drainage, actual close/reopen order, new binding
recovery, preserved bus connection, and no automatic wire ZLP/ACK. Cover raw and
typed partial failures, exact cleanup across reset and stale cleanup after a
later failure. Existing raw and protocol suites require their normal sequential
reruns; this revision is not a claim that any of them already pass.
