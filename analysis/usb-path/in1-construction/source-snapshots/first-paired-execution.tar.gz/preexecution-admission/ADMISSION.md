# Source-only admission before first original IN1 execution

Reviewed 2026-10-05 after the135-check real-page checkpoint was pushed.
The preserved unexecuted draft supplies the literal byte/write oracle; the only
subsequent change records original nm/objdump executable hashes/versions and
rejects tool changes during execution. Neither expected arithmetic nor scope
changed. The full stock ELF and the exact150-instruction cut are pinned.

The admitted range contains only standard integer/memory/branch and memw
instructions. It omits ENTRY, source/cache/queue handling, descriptor publication
and interrupt completion. All reads are restricted to original literals and the
supplied cells/record/first descriptor; all mutable RAM/stack/arena bytes have an
independent final oracle. Status stores are checked in original byte order,
including the capped branch's first length write and later last-flag write.

Lengths around64 exercise both signed comparisons with nonnegative supplied
values;129 exercises the non-taken backwards branch. Two pointer shapes and
a wrap case retain only numeric arithmetic. The512 cap cases are a separate
supplied profile. No zero-length case is claimed as a stock ZLP transfer.
Four bad-address controls and ten excluded PCs must reject before access or
instruction execution. No backend or physical printer capability is present.

The ordinary capture helpers are inherited from the validated EP0 construction
probe; the original-byte/ordered-write oracle is separately transcribed from the
IN1 range. Final source and executable identities are checked again after all
engine runs. Unexpected results must retain a failure capture, not rewrite the
expectation from output. No target instruction has executed at this admission.
