"""Review regenerated metadata against HEAD without changing any report."""
from pathlib import Path
import copy,hashlib,json,re,subprocess
ROOT=Path.cwd();OUT=Path('/tmp/hp1020-in1-final-metadata-review-20261005')
assert not OUT.exists();OUT.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
logs=[Path('/private/var/folders/46/5hjsxnq13752lvrwdm2q1fk80000gn/T')/('hp1020-validation.'+n)/'validate-hp1020-offline-analysis.log' for n in ('OpzixW','GgqQzD')]
log_text=[p.read_text() for p in logs]
files=subprocess.check_output(['git','diff','--name-only','HEAD','--','analysis/usb-path'],text=True).splitlines()
intentional={f'analysis/usb-path/{stem}.{suffix}' for stem in ('usb-bulk-callbacks-model','usb-parser-shim-contract') for suffix in ('json','md')}
files=[n for n in files if n not in intentional]
rows=[]
def temporary_source(a,b):
    pattern=rb'hp1020-[a-z0-9-]*source\.[A-Za-z0-9]{6}'
    x=set(re.findall(pattern,a));y=set(re.findall(pattern,b));assert len(x)==len(y)==1
    x=x.pop();y=y.pop()
    assert x.split(b'.')[0]==y.split(b'.')[0] and a.replace(x,y)==b
    return dict(before=x.decode(),after=y.decode())
def save(name,a,b):
    for prefix,data in (('before',a),('after',b)):
        f=OUT/prefix/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
for name in files:
    a=subprocess.check_output(['git','show','HEAD:'+name]);b=(ROOT/name).read_bytes()
    if name.endswith('.su'):
        detail=dict(kind='sole temporary compiler-source prefix',**temporary_source(a,b))
    else:
        assert name.endswith('validation.json'),name
        old,new=json.loads(a),json.loads(b);normalized=copy.deepcopy(old)
        family='tinyusb-packet-fault' if name.endswith('packet-fault-validation.json') else Path(name).parent.name
        captures=[]
        for value in log_text:
            found=re.findall(r'captures: (/tmp/hp1020-'+re.escape(family)+r'-[^\s]+)',value)
            assert len(found)==1,(name,found);captures.append(Path(found[0]))
        if 'captures' in old:
            assert old['captures']==str(captures[0]) and new['captures']==str(captures[1])
            normalized['captures']=new['captures']
        before=old['target']['captured_artifact_sha256'];after=new['target']['captured_artifact_sha256']
        assert before.keys()==after.keys();changes=[]
        for leaf in before:
            x=(captures[0]/'target'/leaf).read_bytes();y=(captures[1]/'target'/leaf).read_bytes()
            assert sha(x)==before[leaf] and sha(y)==after[leaf],(name,leaf)
            if x==y:continue
            if leaf.endswith('.su'):
                proof=dict(kind='temporary compiler-source prefix',**temporary_source(x,y))
            else:
                assert leaf=='annotated-disassembly.txt',(name,leaf)
                left,right=(str(c).encode() for c in captures)
                left_header=left+b'/target/target-check.elf:     file format elf32-xtensa-be'
                right_header=right+b'/target/target-check.elf:     file format elf32-xtensa-be'
                headers=x.splitlines().count(left_header)
                assert headers>0 and x.count(left)==headers==y.count(right)==y.splitlines().count(right_header)
                assert x.replace(left_header,right_header)==y
                proof=dict(kind='repeated per-function objdump input-path headers only',headers=headers,before=left.decode(),after=right.decode())
            save('captured/'+family+'/'+leaf,x,y)
            changes.append(dict(file=leaf,before_sha256=sha(x),after_sha256=sha(y),proof=proof))
        normalized['target']['captured_artifact_sha256']=after
        assert normalized==new,name
        detail=dict(kind='exact report equal after actual captured metadata substitutions',captures=[str(c) for c in captures],changed_artifacts=changes,
                    target_elf_and_all_other_artifact_bytes_unchanged=True)
    save(name,a,b)
    rows.append(dict(file=name,before_sha256=sha(a),after_sha256=sha(b),detail=detail))
(OUT/'review.json').write_text(json.dumps(dict(status='pass',scope='Every changed older USB artifact is actual metadata only, including raw disassembly header and compiler-source paths. No expectation, code, object, case, source or report was edited.',files=rows),indent=2)+'\n')
print(len(rows),'changed older USB artifacts reviewed; original binary/object/case values stay unchanged.')
