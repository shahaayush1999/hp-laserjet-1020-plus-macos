"""Focused copied-report controls of the actual shared IN1 gate; no target run."""
import ast,copy,hashlib,json,runpy
from pathlib import Path
ROOT=Path.cwd();OUT=Path('/tmp/hp1020-in1-consistency-controls-v2-20261005')
OUT.mkdir(exist_ok=False)
source=ROOT/'scripts/check-hp1020-analysis-consistency.py'
report=ROOT/'analysis/usb-path/in1-construction.json'
raw=report.read_bytes();baseline=json.loads(raw)
sha=lambda b:hashlib.sha256(b).hexdigest()
ns=runpy.run_path(str(source))
tree=ast.parse(source.read_text());body=next(n.body for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='build_report')
helpers={'ep0_stock','ep0_stock_sha','ep0_sources','ep0_spans','ep0_original_bytes','ep0_memory_put','ep0_manifest'}
selected=[];active=False
for node in body:
 names={t.id for t in node.targets if isinstance(t,ast.Name)} if isinstance(node,ast.Assign) else ({node.name} if isinstance(node,ast.FunctionDef) else set())
 if names & helpers:selected.append(node)
 if 'in1' in names:active=True
 if active:selected.append(node)
 if active and isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='append':break
assert {n.name for n in selected if isinstance(n,ast.FunctionDef)} >= {'ep0_original_bytes','ep0_memory_put','ep0_manifest'}
assert len([n for n in selected if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='in1' for t in n.targets)])==1
code=compile(ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[])),str(source),'exec')
(OUT/'executed-gate-slice.py').write_text(ast.unparse(ast.Module(body=selected,type_ignores=[]))+'\n')
(OUT/'checker-source.py').write_bytes(source.read_bytes())
(OUT/'positive-report.json').write_bytes(raw)
rows=[]
def check(label,value,want):
 space=dict(ns);space['checks']=[]
 def read(name):
  assert name=='analysis/usb-path/in1-construction.json',name
  return copy.deepcopy(value)
 space['read_json']=read
 exec(code,space)
 assert len(space['checks'])==1
 outcome=space['checks'][0]
 assert outcome['severity']==('watch' if want=='pass' else 'fail'),(label,outcome)
 rows.append(dict(name=label,severity=outcome['severity'],gate=outcome['name']))
 if want=='fail':(OUT/(label+'.json')).write_text(json.dumps(value,indent=2)+'\n')
check('positive-before',baseline,'pass')
for name,length,field,new_hex in (
 ('zeroed-reserved-word',0,'descriptor',lambda x:x[:8]+'00000000'+x[16:]),
 ('capped-next-pointer-zero',65,'descriptor',lambda x:x[:24]+'00000000'),
 ('missing-last-flag',64,'descriptor',lambda x:'00000040'+x[8:]),
 ('capped-current-source-not-advanced',65,'record',lambda x:'01234567'+x[8:]),
):
 altered=copy.deepcopy(baseline)
 c=next(c for c in altered['cases'] if c['input']['length']==length and c['input']['pointer']==0x01234567 and c['input']['effect']=='descriptor')
 for engine in ('interpreter','qemu'):
  for key in (field+'_hex','expected_'+field+'_hex'):c[engine][key]=new_hex(c[engine][key])
 check(name,altered,'fail')
altered=copy.deepcopy(baseline);altered['completed_bulk_in_transfers']=1
check('claimed-completed-usb-transfer',altered,'fail')
check('positive-after',baseline,'pass')
assert report.read_bytes()==raw
result=dict(status='pass',scope='Execute the actual shared IN1 gate in isolation with its exact generic memory helpers. Copied JSON controls only; no target, source or report mutation and no extra USB lifecycles.',checker_sha256=sha(source.read_bytes()),baseline_sha256=sha(raw),controls=rows)
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print('Five false-evidence controls rejected; unchanged independent positives pass before/after.')
