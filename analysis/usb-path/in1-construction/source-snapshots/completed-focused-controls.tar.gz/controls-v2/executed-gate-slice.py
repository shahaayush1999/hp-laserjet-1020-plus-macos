ep0_stock = (ROOT_DIR / 'analysis/sihp1020.elf').read_bytes()
ep0_stock_sha = '2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d'
ep0_sources = {'analysis/sihp1020.elf', 'scripts/validate-hp1020-usb-ep0-construction.py', *('scripts/' + name + '.py' for name in ('hp1020_qemu_multitask', 'hp1020_qemu_ram', 'hp1020_qemu_stock_parser', 'hp1020_stock_parser_harness', 'hp1020_stock_stop', 'hp1020_xtensa_call0', 'hp1020_xtensa_properties', 'hp1020_xtensa_stock'))}

def ep0_original_bytes(address: int, size: int) -> bytes:
    if not 268459136 <= address <= address + size <= 268549007:
        return b''
    offset = 12768 + address - 268459136
    return ep0_stock[offset:offset + size]
ep0_spans = ((268436336, 268436636), (268549008, 268555840), (268555840, 268653024), (553648128, 553779200), (579862528, 579866624))

def ep0_memory_put(memory: dict, address: int, data: bytes) -> None:
    for (begin, end), raw in memory.items():
        if begin <= address and address + len(data) <= end:
            raw[address - begin:address - begin + len(data)] = data
            return
    raise ValueError('EP0 consistency oracle write outside its fixed RAM')

def ep0_manifest(memory: dict) -> list[dict]:
    return [dict(begin=hex(a), end=hex(b), bytes=b - a, sha256=hashlib.sha256(raw).hexdigest()) for (a, b), raw in sorted(memory.items())]
in1 = read_json('analysis/usb-path/in1-construction.json')
in1_begin, in1_end = (268470687, 268471105)
in1_code_sha = 'af1c30e9998c5abe000121111bebe7e4efc31d1543d361d5996056e0f47d8a34'
in1_sources = ep0_sources - {'scripts/validate-hp1020-usb-ep0-construction.py'} | {'scripts/validate-hp1020-usb-in1-construction.py'}
in1_literals = {268459600: 268572048, 268459644: 268549212, 268459572: 2147483648, 268459648: 134217728}
in1_excluded = {268470684, in1_end, 268471124, 268471139, 268471154, 268471160, 268471212, 268471244, 268530632, 268468744}
in1_inputs = []
for seed in (49, 204):
    for pointer in (19088743, 3003122688):
        for length in (0, 1, 63, 64, 65, 128, 129):
            in1_inputs.append(dict(name=f'in1-n{length}-q64-p{pointer:08x}-s{seed:02x}', seed=seed, length=length, pointer=pointer, cap=64, effect='descriptor'))
    in1_inputs.append(dict(name=f'in1-pointer-wrap-s{seed:02x}', seed=seed, length=65, pointer=4294967292, cap=64, effect='descriptor'))
    for length in (511, 512, 513):
        in1_inputs.append(dict(name=f'in1-n{length}-q512-s{seed:02x}', seed=seed, length=length, pointer=2444411856, cap=512, effect='descriptor'))
    for mode, stop in (('record', 268470690), ('descriptor', 268470891)):
        in1_inputs.append(dict(name=f'in1-mmio-{mode}-s{seed:02x}', seed=seed, length=1, pointer=19088743, cap=64, effect='none', reject_mmio=mode, stop=stop))
in1_audit = in1['original_byte_audit']
in1_original = ep0_original_bytes(in1_begin, in1_end - in1_begin)
in1_ok = in1_audit['ranges'] == [dict(begin=hex(in1_begin), end=hex(in1_end), bytes=in1_original.hex(), sha256=in1_code_sha)] and hashlib.sha256(in1_original).hexdigest() == in1_code_sha and (in1_audit['literals'] == {hex(a): hex(v) for a, v in in1_literals.items()}) and all((ep0_original_bytes(a, 4) == v.to_bytes(4, 'big') for a, v in in1_literals.items())) and (in1_audit['original_descriptor_pointer'] == '0x900216d0') and (in1_audit['entry_after_original_ENTRY'] is True)
in1_allowed = {'l32i', 'l8ui', 's32i', 's8i', 'l32r', 'movi', 'mov', 'add', 'addi', 'sub', 'or', 'slli', 'extui', 'memw', 'blt', 'bge', 'beqz', 'bnei', 'j'}
in1_pcs, pc = ([], in1_begin)
while pc < in1_end:
    instruction = in1_audit['instructions'][hex(pc)]
    raw = bytes.fromhex(instruction['bytes'])
    in1_ok &= len(raw) in (2, 3) and pc + len(raw) <= in1_end and (raw == ep0_original_bytes(pc, len(raw))) and (instruction['op'].removesuffix('.n') in in1_allowed)
    in1_pcs.append(pc)
    if not raw:
        break
    pc += len(raw)
in1_ok &= pc == in1_end and len(in1_pcs) == 150
in1_ok &= set(in1_audit['instructions']) == {hex(pc) for pc in in1_pcs}
in1_range = lambda a, b: [pc for pc in in1_pcs if a <= pc < b]
in1_spans = ep0_spans[:-1] + ((580911104, 580915200),)
in1_templates = {(seed, a, b): bytes((seed + (a >> 8) + i * 17 + (i >> 4) * 3 & 255 for i in range(b - a))) for seed in (49, 204) for a, b in in1_spans}
in1_ok &= [c['input'] for c in in1['cases']] == in1_inputs
for case, given in zip(in1['cases'], in1_inputs):
    n, q, p = (given['length'], given['cap'], given['pointer'])
    before = {(a, b): bytearray(in1_templates[given['seed'], a, b]) for a, b in in1_spans}
    desc = 3003121716 if given.get('reject_mmio') == 'descriptor' else 580911360
    for address, value in ((268549212, desc), (268572048, q), (580911872, p), (580911876, 1500757409), (580911880, n), (580911884, 776759945)):
        ep0_memory_put(before, address, value.to_bytes(4, 'big'))
    after = {span: raw.copy() for span, raw in before.items()}
    writes = []

    def in1_word(at, address, value):
        ep0_memory_put(after, address, value.to_bytes(4, 'big'))
        writes.append(dict(pc=hex(at), kind='write', address=hex(address), size=4, value=hex(value)))

    def in1_bytes(pcs, offset, value):
        data = value.to_bytes(4, 'big')
        ep0_memory_put(after, 580911360 + offset, data)
        for at, index in zip(pcs, range(4)):
            writes.append(dict(pc=hex(at), kind='write', address=hex(580911360 + offset + index), size=1, value=hex(data[index])))
    if given['effect'] == 'descriptor':
        if n <= q:
            in1_bytes((268470891, 268470897, 268470903, 268470906), 8, p + 2147483648 & 4294967295)
            in1_bytes((268470915, 268470918, 268470921, 268470924), 12, 0)
            in1_bytes((268470951, 268470966, 268470981, 268470996), 0, 134217728 | n)
            in1_word(268470999, 580911880, 0)
        else:
            in1_bytes((268470726, 268470732, 268470738, 268470741), 8, p + 2147483648 & 4294967295)
            in1_word(268470752, 580911872, p + q & 4294967295)
            in1_bytes((268470768, 268470783, 268470798, 268470813), 0, q)
            in1_bytes((268470827, 268470833, 268470839, 268470842), 12, 580911376)
            in1_word(268470856, 580911880, n - q)
            in1_bytes((268471057, 268471072, 268471087, 268471102), 0, 134217728 | q)
    if n <= q:
        retired = in1_range(in1_begin, 268470702) + [268470865] + in1_range(268470871, 268471004)
    else:
        retired = in1_range(in1_begin, 268470699) + in1_range(268470702, 268470862) + ([268470862] if n - q > q else []) + [268470865, 268470868] + in1_range(268471004, in1_end)
    stop = given.get('stop', in1_end)
    retired = [at for at in retired if at < stop]
    before_manifest, after_manifest = (ep0_manifest(before), ep0_manifest(after))
    in1_ok &= case['status'] == 'pass'
    for engine in ('interpreter', 'qemu'):
        record = case[engine]
        reason = 'MMIO forbidden' if given.get('reject_mmio') else ('execution outside selected stock routines: ' if engine == 'interpreter' else 'native tasks left selected code: ') + hex(stop)
        in1_ok &= record['status'] == 'pass' and record['engine'] == engine and (record['entry'] == hex(in1_begin)) and (record['stop_before'] == hex(stop)) and (record['failure'] == dict(type='ValueError', reason=reason, pc=hex(stop))) and (record['before_memory'] == before_manifest) and (record['expected_memory'] == record['actual_memory'] == after_manifest) and (record['descriptor_hex'] == record['expected_descriptor_hex'] == after[580911104, 580915200][256:272].hex()) and (record['record_hex'] == record['expected_record_hex'] == after[580911104, 580915200][768:784].hex()) and (record['expected_writes'] == [x for x in record['accesses'] if x['kind'] == 'write'] == writes) and (record['original_instructions_retired'] == [hex(at) for at in retired]) and (record['engine_steps'] == len(retired) + int(engine == 'interpreter' and bool(given.get('reject_mmio')))) and (record['registers'][:2] == ['0xfffffffc', '0x2101fef0']) and (len(record['registers']) == 16) and (record['literal_descriptor_checked'] is (given['effect'] == 'descriptor')) and all((record[k] is True for k in ('all_mutable_and_guard_ram_equal', 'ordered_write_trace_equal', 'source_never_dereferenced', 'original_code_unchanged'))) and (record['actual_peripheral_accesses'] == 0)
        memory = {span: raw.copy() for span, raw in before.items()}
        for event in record['accesses']:
            address, size, value = (int(event['address'], 16), event['size'], int(event['value'], 16))
            in1_ok &= int(event['pc'], 16) in retired
            if event['kind'] == 'write':
                ep0_memory_put(memory, address, value.to_bytes(size, 'big'))
            else:
                if address in in1_literals and size == 4:
                    expected_value = in1_literals[address]
                elif size == 4 and address in (268549212, 268572048, 580911872, 580911880) or (size == 1 and 580911360 <= address < 580911376):
                    raw = next((v[address - a:address - a + size] for (a, b), v in memory.items() if a <= address and address + size <= b))
                    expected_value = int.from_bytes(raw, 'big')
                else:
                    expected_value = None
                in1_ok &= event['kind'] == 'read' and value == expected_value
    in1_ok &= all((case['interpreter'][key] == case['qemu'][key] for key in ('registers', 'accesses', 'original_instructions_retired', 'before_memory', 'actual_memory', 'expected_writes')))
checks.append(check('original_in1_construction_preserves_single_descriptor_and_source_lifetime_fields', in1_ok and in1['status'] == 'pass' and (in1['counts'] == dict(construction=36, mmio_rejections=4)) and (in1['stock_elf_sha256'] == ep0_stock_sha) and (in1['actual_peripheral_accesses'] == in1['completed_bulk_in_transfers'] == 0) and (in1['controller_quiescence_established'] is False) and (in1['original_entry_executed'] is False) and (in1['private_literal_redirects'] == in1['supplied_services'] == []) and (len(in1['excluded_code_controls']) == len(in1_excluded)) and ({int(r['pc'], 16) for r in in1['excluded_code_controls']} == in1_excluded) and all((r['status'] == 'rejected before instruction execution in both engines' for r in in1['excluded_code_controls'])) and (set(in1['source_sha256']) == set(in1['source_origins']) == in1_sources) and all((hashlib.sha256((ROOT_DIR / n).read_bytes()).hexdigest() == h for n, h in in1['source_sha256'].items())), 'Original bulk-IN1 arithmetic must retain reserved/original/done bytes, exact ordered writes and the independently derived branch path with one last-marked descriptor. Numeric aliases and supplied64/512 caps establish no DMA mapping, cache publication, USB transfer, FIFO settlement or host receipt.', evidence='analysis/usb-path/in1-construction.json'))
