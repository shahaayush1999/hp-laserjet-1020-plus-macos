from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
BACKEND = Path('/tmp/hp1020-udc-publish-draft-20261002')
FIXTURE = Path('/tmp/hp1020-udc-publish-fixture-draft-20261002')
VALIDATOR = Path('/tmp/hp1020-udc-publish-validator-draft-20261002')
OUT = ROOT/'analysis/usb-path/udc-program/source-snapshots'
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def check_manifest(path, base, remap=None):
    checked = {}
    for line in path.read_text().splitlines():
        digest, name = line.split('  ', 1)
        actual = (remap or {}).get(name, name)
        assert sha((base/actual).read_bytes()) == digest, (name, actual)
        checked[name] = dict(actual_path=actual, sha256=digest)
    return checked

remap = {'AGENTS.md':'AGENTS.md/AGENTS.md',
         'CURRENT_STATUS.md':'CURRENT_STATUS.md/CURRENT_STATUS.md'}
backend_files = check_manifest(BACKEND/'DRAFT.sha256', BACKEND)
baseline_files = check_manifest(BACKEND/'SOURCES.sha256', BACKEND/'baseline', remap)
assert len(backend_files) == 13 and len(baseline_files) == 30
fixture = json.loads((FIXTURE/'manifest.json').read_text())
assert sha((FIXTURE/'fixture.patch').read_bytes()) == fixture['patch_sha256']
assert len(fixture['files']) == 8
for name, value in fixture['files'].items():
    assert sha((FIXTURE/'draft'/name).read_bytes()) == value['result_sha256'], name
    if value['original_sha256']:
        assert sha((FIXTURE/'original'/name).read_bytes()) == value['original_sha256']
fixture_originals = {}
for path in (FIXTURE/'original').rglob('*'):
    if path.is_file():
        name = path.relative_to(FIXTURE/'original').as_posix()
        saved, current = path.read_bytes(), (ROOT/name).read_bytes()
        fixture_originals[name] = dict(saved_sha256=sha(saved), current_sha256=sha(current), matches_current=saved == current)
        if saved != current:
            assert name == 'open-firmware/udc-program-test/README.md'
            assert sha(saved) == '4301565d0665c78c076e8d08f39b475acc54850b5e815649ba52b6d258f4633e'
            assert sha(current) == 'ced731a83e173d62c10110772075c58c99ec82d8dc1e55ecc6a26cc51c85b98b'
for name, digest in fixture['backend_reference_only'].items():
    assert sha((FIXTURE/'references/udc-publish'/name).read_bytes()) == digest
    assert sha((BACKEND/'open-firmware/udc-publish'/name).read_bytes()) == digest
check_manifest(VALIDATOR/'BASELINE.sha256', ROOT)

review_files = {
    'independent-static-review.md':Path('/tmp/hp1020-udc-publish-independent-review-20261002.md'),
    'trace-oracles.py':Path('/tmp/hp1020-udc-publish-trace-oracles-20261002.py'),
    'fixture-plan.md':Path('/tmp/hp1020-udc-publish-fixture-plan-20261002.md'),
}
assert sha(review_files['independent-static-review.md'].read_bytes()) == '9d0d435e58ee87974a1cb2065d769d881ca2493ecb2f704dde6e014e31851d7e'
assert sha(review_files['trace-oracles.py'].read_bytes()) == 'b677dc57ee631186585fc8759c7b05d5fba30d8b35fb0e5767a94a99e1fdc694'
assert sha(review_files['fixture-plan.md'].read_bytes()) == '9b985218b829ec12bd62d78ed840833c1af7216c2b7e85ecf2cf14236f8f655a'
files = {}
for label, directory in [('backend', BACKEND), ('fixture', FIXTURE), ('validator', VALIDATOR)]:
    for path in directory.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            files[label+'/'+path.relative_to(directory).as_posix()] = path
files.update({'review/'+name:path for name, path in review_files.items()})
files['RESUME.md'] = Path('/tmp/hp1020-udc-publish-resume-20261002.md')
files['archive-check.py'] = Path(__file__)
content = {name:path.read_bytes() for name,path in files.items()}
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w') as archive:
        for name, raw in sorted(content.items()):
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(raw), 0o644, 0
            archive.addfile(info, io.BytesIO(raw))
payload = buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
    assert len(archive.getnames()) == len(set(archive.getnames())) == len(content)
    assert set(archive.getnames()) == set(content)
    for name, raw in content.items():
        assert archive.extractfile(name).read() == raw
metadata = dict(
    status='Unexecuted frozen publication backend and fixture, completed static C/H review, incomplete runner fragments; stopped at owner request. No integrated candidate or new validation result.',
    validated_baseline_commit='18f5ff4994c265b8ded70217f45d3a8c24bac97c',
    archive_sha256=sha(payload), archive_bytes=len(payload), member_count=len(content),
    baseline_note='28 direct paths and two explicitly mapped nested paths verify; original frozen manifests and layout are unchanged.',
    backend_baseline_verified=baseline_files,
    backend_draft_verified=backend_files,
    fixture_manifest_sha256=sha((FIXTURE/'manifest.json').read_bytes()),
    fixture_originals_verified=fixture_originals,
    fixture_originals_note='Six originals match the validated repository; the README template was captured before its full-suite prose update. Its exact earlier bytes are preserved. The first archive-check attempt caught this difference and stopped before writing archives; no candidate or manifest was changed.',
    limits='No publication compilation/import/execution, USB/device contact, physical register binding, native page lifecycle or printing. This archive check only reads, hashes and packages bytes.',
    member_sha256={name:sha(raw) for name,raw in sorted(content.items())})
label = 'unexecuted-publication-drafts'
OUT.mkdir(parents=True, exist_ok=True)
for suffix, raw in [('.tar.gz', payload), ('.json', (json.dumps(metadata, indent=2)+'\n').encode())]:
    path = OUT/(label+suffix)
    assert not path.exists(), path
    path.write_bytes(raw)
print(json.dumps({key:metadata[key] for key in ('archive_sha256','archive_bytes','member_count')}, indent=2))
