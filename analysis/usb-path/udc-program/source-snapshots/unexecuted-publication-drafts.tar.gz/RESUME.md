# Publication draft handoff — stopped at owner request

No publication candidate has been integrated, built, imported or executed.
The last validated repository baseline is
`18f5ff4994c265b8ded70217f45d3a8c24bac97c`: 129 consistency checks and both suites.
This archive is preservation only; do not infer test coverage from its contents.

## Recovery and package boundaries

Extract the archive into a new scratch directory. `backend/` contains frozen C/H,
README, patch and 30 baseline sources. `fixture/` contains a separate patch,
codec/builder/496-word fixture and seven originals. `validator/` contains only
three unfinished Python fragments plus its parent-validator hash. `review/`
contains the completed independent static C/H review and frozen literal-oracle
matrix; it has not reviewed executable fixture/runner behavior.

The backend's `SOURCES.sha256` names two root files whose actual saved paths are
`baseline/AGENTS.md/AGENTS.md` and
`baseline/CURRENT_STATUS.md/CURRENT_STATUS.md`. Both hashes match. The outer
archive metadata records that mapping; the frozen package/manifests are unchanged.
The other 28 baseline paths and all 13 DRAFT entries verify normally. No blocking
C/H finding was identified within the supplied serialized lease contract.
Six fixture originals match the validated baseline; its README template retains
the earlier pending-full-suite prose. The first archive check caught that expected
historical difference and stopped before writing. Metadata identifies both hashes;
the original draft, patch and manifest remain unchanged.

Start by reading both INTEGRATION files, fixture README, independent review and
fixture plan. Lead still needs to inspect final C/fixture and finish the runner.
Apply patches only after review, make the builder executable, install the frozen
oracle under `open-firmware/udc-publish-test/trace-oracles.py`, and preserve this
untested archive before any corrections. Do not silently rewrite a failed draft.

## Fixed experiment contract

One synchronous full-speed OUT1 arm path; reuse program/OUT/adapter/receive
ownership. Readiness and a supplied stationary, globally safe, DMA-idle lease
precede reservation and HOST_READY stores. The only genuine DCD callback calls
prepare-and-publish once: RX64 cache, descriptor16 bidirectional cache, order,
local take, DESPTR/order, optional CNAK/order/readback, RDE/order. No proposal
escapes and no physical binding, inline cache instruction or live register exists.
The seven facts and exact masks/traces are in the independently frozen oracle.

Failure after binding must retain the original adapter cookie, packet/history,
borrow guard and descriptor expectation even when the helper returns failure.
The adapter fences after callback unwind. Failed-state ordinary operations stay
blocked; only the admitted inactive actual-reset service drain is permitted.
Cleanup uses original identity and supplied settlement, retains receive.count
and gives no reset promises. The later existing three-promise restart owns recovery.
Do not require receive.count0 for cleanup. Queue-full WAIT must precede all I/O.
Selection/grant add local publisher failure/busy/arming/servicing barriers;
complete_selection still needs the underlying program SERVICE-only exception.

The planned matrix has 20 named profiles x two fills (40 cases). It covers both
CNAK branches, all fact/register refusals, preflight read failures, direct-helper
authority, progress barriers, exact cleanup identity, cancellation/reuse, NAK
readback refusal and every post-bind hook failure. Cases end in one exact 32-byte
FF page and END_DOC; cancelled prefixes must never appear. All completion/cache/
mapping/global-SETUP facts remain supplied, never hardware evidence.

## Unfinished runner work

`header.py`, `compile.py` and `host.py` are unexecuted fragments, not a runnable
validator. They import the existing program runner after eventual installation;
do not run them directly from their archive location. Add scenario/recovery helpers
and main/target replay, then assemble the final script. Preserve literal traces
from the separately frozen oracle; do not derive expectations from production.

Inspect assumptions before use: Host.arm's saved cookie order/epoch must match
the inherited bulk ledger; success/cleanup unchanged row slices may contain other
legitimate diagnostics; inherited send's queue-full op6 must return WAIT without
hooks. The new cleanup helper is distinct from existing program-ticket cleanup.
After fault: query and reject wrong/unclean/owned cleanup, admit actual reset,
settle retained exact cookies, drain reset service, cleanup original failure,
configure/recover a new generation, then feed the fresh page. Do not fake a
mounted-only state if the real lifecycle cannot isolate it.

Diagnostics: keep the original 432 words, append publisher64 = 496. Exclude only
host/target size words 59,425,490; new stats symbol
`hp1020_publish_fixture_stats`, size getter
`hp1020_publish_fixture_component_bytes`. Relative publisher62 is the latest bound
slot, including a post-bind failure. Ops130..134 and all other field definitions
are in the fixture README. Keep all 11 old capture pairs and the complete guarded
27712-byte read/trace storage. Cache trace kinds4/5 do not increment old 1..3 counts.

Run focused host/target only after an independent target instruction audit and
source snapshot; preserve exact failure artifacts before fixes. Add an independently
frozen raw-capture gate and meaningful corruption controls, then integrate shared
validation. Run all suites sequentially, freeze captured sources during execution,
compare unchanged prior variants, archive exact captures and update existing notes.
No user action, printer connection or installed printing change is needed.
