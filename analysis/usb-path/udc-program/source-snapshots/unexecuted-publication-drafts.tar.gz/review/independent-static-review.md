# Frozen OUT1 publisher: independent static review, 2026-10-02

Reviewed the frozen proposal in `/tmp/hp1020-udc-publish-draft-20261002/` after
freezing the separate literal trace oracle. No source was compiled, imported or
executed, no test or validator was run, and no repository/proposal source was
edited. Manifest checking below hashes files only. This is a static review, not
an executed or physical-controller result.

## Result

No blocking C/H correctness finding within the declared serialized, stationary,
nonreentrant, supplied-lease contract. The implementation preserves the material
pre-prepare safety boundary, original-cookie failure ownership and narrow reset
drain exception. One packaging-path defect is recorded below; the corresponding
source bytes are present and have the correct hashes.

This conclusion does not validate the forthcoming fixture or runner, prove the
physical facts, or permit direct calls that bypass the documented integration.

## Exact reviewed identities

All SHA256 values:

| Frozen member | SHA256 |
| --- | --- |
| `open-firmware/udc-publish/hp1020_udc_publish.c` | `d294b122ad0321ead398995eaac7edb5333d78a166ddc52a521270c108055ab8` |
| `open-firmware/udc-publish/hp1020_udc_publish.h` | `4dad4d4e0b1b59e10bfbac77cb9be59a0243bf52b34233aa287601d3395b49fd` |
| `open-firmware/udc-publish/README.md` | `e756779cbbaae17c13b01994eedbb091ec98699572843cfc45bdfaebbf22789c` |
| `INTEGRATION.md` | `6efbdfbd02cf3e8cb1f637507a862c2b5fe8813fc37d2fae58079295d45cc0c2` |
| `backend.patch` | `f638aa1dd762d223df2d9050c1d49fa4aba5f08607a28190fbb940fb9cac5a83` |
| `DRAFT.sha256` | `e72e926146d7acae9399a8ed60279a5e4b7894066aaab86dda187939fbb27e5b` |
| `SOURCES.sha256` | `4a0e16146521d9fe89f64608a03735a5b398661dcdff2f907ad219fb79008faa` |

All 13 `DRAFT.sha256` member hashes verified. All 28 normally located baseline
members verified, including stock ELF, pinned Linux and adapter/descriptor/
program/SETUP C. The two remaining baseline files have the layout issue below.
The repository dependency C files read during this review matched the frozen
baseline hashes: program `a0dbe512...`, OUT `1a7f1f1a...`, SETUP `f70322d7...`,
adapter `a5bb1d28...`; their full identities are in `SOURCES.sha256`.

The original independent expectations remain unchanged:

- `/tmp/hp1020-udc-publish-trace-oracles-20261002.py`,
  `b677dc57ee631186585fc8759c7b05d5fba30d8b35fb0e5767a94a99e1fdc694`.
- `/tmp/hp1020-udc-publish-fixture-plan-20261002.md`,
  `9b985218b829ec12bd62d78ed840833c1af7216c2b7e85ecf2cf14236f8f655a`.
- Primary boundary review,
  `39a4f942b986e74b48668c1e49449c5fa04312c6833e574c007b1d781ff60ee9`;
  cache review,
  `7b68c1a19c5b7a8c1ccc123fa060600f955330dc76a2890509f3c52a0a3cdc2c`.

## Checks that support the result

1. **The lease starts before descriptor reconstruction.** C201-224 checks facts,
   full progress, actual adapter/TinyUSB readiness, OUT FREE and queue capacity,
   then reads DEVCTL/OUTCTL/MPS/DEVSTS before calling `adapter_arm_out` at231.
   The existing adapter reserves only at adapter C913-924. Existing OUT C122-137
   binds first and finally writes HOST_READY. Thus the supplied idle/mapping/
   stable-window lease actually spans those stores, rather than being asserted
   after they occurred. A preflight refusal manufactures no cookie and cannot
   release anything. Read-hook failure preserves no alleged observed value.

2. **Command masks and ordering match the frozen conservative profile.** C7-19
   and130-149 require MODE/BE (`220`), forbid `fcd7`, preserve `ffff0328`, accept
   only OUTCTL20/60, MPS low16=64 and RXFIFO_EMPTY8000. C272-320 orders RX64,
   descriptor16, order, one local take, DESPTR234/order, optional CNAK120/order/
   exact OUTCTL20 readback, then saved DEVCTL|4/order. It does not replay RO NAK,
   other command bits, flush, RRDY, status ACK or a guessed read-after-write state.
   NAK-still1 and unexpected readback stop before RDE. No RDE readback is required
   to remain1 after issuance.

3. **The callback is a single synchronous authority window.** C225-232 snapshots
   the original control/transport/generation/ingress identities and clears the
   window on return. C244-264 rejects outside/duplicate calls before prepare;
   an in-window attempt consumes the window, checks actual busy/stack/prepared
   state, exact reserved buffer, unchanged identities, ingress state and program
   readiness. The selected DMA span is looked up by the actual receive slot.
   C268-271 copies the newly bound original cookie immediately. No local queue,
   replacement identity or delayed proposal exists. A non-OK result before a
   successful bind correctly has no publisher packet-failure ticket.

4. **A failed prefix does not imply settlement.** C84-113 captures the first
   original cookie, only successful prefix bits, failing operation/attempted
   value or exact cache range, and prior EXPOSED phase. C272-320 never retries or
   clears the OUT phase on failure. Failure before take retains PREPARED; after
   take it retains EXPOSED even if DESPTR was not performed. A failed final RDE
   order is still sticky with a possibly live descriptor. Adapter C927-932 then
   fences after the callback returns and retains its reserved input/owner.
   The DCD ledger requirement on non-OK bound results is therefore essential,
   explicit, and compatible with the existing adapter.

5. **The reset-drain exception is sufficiently narrow.** C175-182 permits
   failed-state SERVICE only when the SETUP bridge itself returns SERVICE, not
   merely when the program lacks binding readiness. SETUP C252-265 gives that
   value only to the matching admitted but inactive actual reset. Program
   C248-269 preserves the same narrow drain; normal progress stays barred.
   `submission_allowed` intentionally remains callable during the genuine arm
   or service callback; the deeper bind/context checks establish its authority.
   A mere external boolean query cannot bind a packet. Ordinary pump, finish,
   `finish_reset`, EP0/manual publication and selection/grant must use the
   integration barriers specified in the header/README. Valid typed SI selection
   may need the existing program SERVICE-only path, so blanket full7 there would
   be wrong; the final header correctly names that exception.

6. **Cleanup preserves recovery provenance and accounting.** C332-347 matches
   all five fields of the original failure cookie, independent of newer epochs.
   It waits for supplied clean1, OUT FREE, no DCD/PENDING/prepared/delivering/
   response ownership, stopped/fenced receive and unmounted/unopened state.
   It clears only `failed`; it does not alter old receive count, descriptor,
   program failure/history, generation, reset promises or failure bytes. This
   permits the necessary nonzero fenced reservation while still requiring the
   ordinary later three-promise restart. A newer failure cannot be cleaned by
   the old original cookie.

## Evidence and remaining supplied facts

The masks/offsets above agree with pinned Linux `amd5536udc.h:106-138,212-229`.
`snps_udc_core.c:1135-1168,1200-1208` supplies the family-level ordering reference:
control other RDE writers, descriptor pointer, CNAK inspection, then RDE. The
stock literals and guarded-CNAK bytes are already recorded in the frozen primary
review at its lines158-185; no original experiment was repeated. Sony manual1.1.0
pp1138-1140,1152-1154,1162,1207-1209 remains a family reference, not HP revision or
device evidence. In particular manual RDE0 and software FREE are not DMA-stop
proofs, and SETUP bypasses NAK. The draft correctly keeps the global SETUP/other
OUT readiness, serialization of all RDE writers, cache/mapping/granule safety,
settlement and posted-I/O semantics supplied. It neither solves receive-event
acquisition nor proves physical USB success. No new manual quotation is used.

## Actionable packaging correction

`SOURCES.sha256` names root files `AGENTS.md` and `CURRENT_STATUS.md`, but their
frozen copies are directories containing the real bytes at:

- `baseline/AGENTS.md/AGENTS.md`:
  `c89f9c08807341364640c44eb2dbe9d565e02add4731bc8f6a51c848b8f04638`.
- `baseline/CURRENT_STATUS.md/CURRENT_STATUS.md`:
  `1a29495a55158a76244ef7e5f6a40c5b8742deb8ebbc8828c2f64dd9fd300139`.

Those hashes match the intended two manifest entries exactly. Therefore a direct
`shasum -a 256 -c ../SOURCES.sha256` from `baseline` fails on two directories,
while all other entries pass. Preserve the proposal unchanged and record the
actual archived-path mapping, or make a separately identified packaging revision.
Do not silently report all 30 conventional paths as directly verified. This
does not change the reviewed C/H result. Root and author were notified.

The independently frozen 40-case matrix remains the recommended first execution;
this review made no post-implementation changes to its literal oracles.
