# Bulk OUT publication: lead integration decisions (unexecuted)

2026-10-02. No repository changes, compilation, execution or physical contact is
claimed by this design. The endpoint-command full suite is still running.

Implement one narrow OUT1/full-speed64/BE path. Reuse the existing program gate,
OUT descriptor object, adapter receive queue and original cookies. No new owner,
queue, identity allocator, IN-completion interpretation or startup is required.
The independently reviewed register sequence and remaining facts belong to
hp1020-next-dcd-boundary-review-20261002.md. CPU/DMA/cache facts and hook contracts
belong to hp1020-dma-visibility-contract-review-20261002.md. Do not fill a missing
hardware premise by treating a recorded write as a device observation.

The lead selects a synchronous arm wrapper, not a deferred proposal operation.
Before existing adapter_arm_out reserves or modifies a descriptor, the wrapper
checks combined software readiness, exact supplied facts and non-mutating
register preflight. Missing facts/unsupported sampled state/read failure here
produce no reservation, write, descriptor mutation or invented cookie. Then the
wrapper admits only its synchronous actual DCD bulk callback. That callback
uses existing udc_out_prepare to bind the real original cookie, synchronizes
RX payload and descriptor ranges, orders publication, consumes take_submission,
and issues the independently reviewed commands immediately. No proposal escapes.
The window clears on every exit and direct calls outside it are rejected before
prepare. The stopped/settled/cache/mapping lease must span before prepare, whose
final store is already HOST_READY. A later RDE0 observation cannot make earlier
reconstruction safe retroactively.

All hooks are synchronous and nonreentrant. No callback invokes fault delivery,
settlement or stack service. Post-bind failure preserves the first exact cookie,
operation/outcome and uncertain prefix, then returns false to the existing DCD
caller. Existing adapter_arm_out fences on unwinding; queued cancellation is
drained later. Failure blocks ordinary service/arm/pump/submission/publication,
but permits admitted actual-reset service and original-cookie settlement.
Cleanup requires the exact retained cookie, separate physical-clean promise,
stopped/unmounted state and no retained adapter/descriptor/response/reservation.
It performs no I/O and grants no document-reset promises. Reset is not cleanup.

Fixture implication: a post-bind failure must still record the bound descriptor,
borrowed packet, original cookie and history BEFORE returning false to TinyUSB;
otherwise cancellation bookkeeping would lose the very ownership being tested.
The existing composed_bulk_xfer early-return-on-prepare-error cannot be used
unchanged for that path. Update allowed descriptor bytes independently from
input addresses, never by copying back the implementation output. Keep cache
hooks from invoking the whole composed guard while an intentional preparation
is in progress. After the helper returns, all protected storage must be checked.

Record exact CPU range identity as an allocation role/offset plus explicit DMA
address and length in portable captures, not architecture-dependent raw CPU
pointers. Hooks need separate RX-buffer-for-device-write and descriptor-for-device
operations. The pinned TinyUSB generic weak cache hooks are no-op success and
must not be used as visibility evidence. Whole line isolation or a separately
justified coherent/uncached mapping is still external; current16-byte alignment
alone cannot prove it.

The next matrix should prove both first/short/reused packets reach exact pixels
and END_DOC, readiness refusal precedes receive reservation, direct callback
misuse cannot prepare, each failed command/cache prefix retains its original
borrow and prevents replay, read-back NAK refusal prevents global RX enable,
reset cannot clear failure, and stale cleanup cannot clear a later attempt.
Synthetic completion and global RX/SETUP readiness remain supplied facts.
