# DMA mapping and visibility contract for the next publication boundary

2026-10-02; independent static review only. Repository sources were read, not
edited or imported. The bounded stock slices below were disassembled directly
from the pinned ELF, with no execution, validator, QEMU, MMIO or USB operation.

**Recommendation:** retain explicit external CPU/DMA mapping and synchronous
visibility hooks. Stock bytes justify clean and clean/invalidate *candidate
operations* and16-byte stepping; they do not justify a physical mapping formula,
a no-op cache backend, or a tested HP cache primitive. The next recording-I/O
publisher can independently verify which exact allocations are synchronized,
in what direction and order, and whether failure prevents publication. It
should not yet contain inline cache instructions or guessed aliases.

## Reused completed evidence and narrow original-byte findings

The completed original EP0 construction experiment already distinguishes active
pointer passthrough from initialization addition. Its66 paired profiles execute
no copy/cache helper and establish no CPU/DMA mapping. Do not repeat it:
`analysis/usb-path/ep0-construction.json`, and corrected static
`control-in-data-stage.json`. Active anchors are10008d02/10008f11; initialization
100092aa adds80000000 modulo32. File-backed descriptor pointer900226f0 therefore
becomes100226f0 during that initialization, while active publication preserves
900226f0. This disproves using the old OR model as universal translation.

Relevant stock bytes, from ELF SHA256
`2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`:

| Anchor | Direct observation | What it does not establish |
|---|---|---|
|100173c8..100173e5|Clean-range candidate: ENTRY; offset=address&15; iterations=(length+offset+15)>>4 using32-bit arithmetic; DHWB at100173db; address+=16; DSYNC at100173e1; RETW.|No validated physical cache geometry, privilege/context, aliases or interconnect visibility. No wrap check; zero length with an unaligned address can still touch a line. Do not copy its unchecked range arithmetic.|
|10017414..10017431|Same bounded arithmetic, DHWBI at10017427 and DSYNC at1001742d.|Not a standalone invalidate-only operation; not transfer settlement.|
|10008c24..10008c69|Sender loads a10/a11 from transfer-state+64/+60, calls100173c8 at10008c44, then copies from that original source into staging at10008c69.|The stock clean occurs before the staging copy, so it cannot prove a clean of our newly written staging bytes. Copy-helper and mapping assumptions remain separate.|
|100087b8..100087cc|Read callback preserves the original destination for the10017414 call, while its retained destination register adds literal80000000 first. Call arguments remain original destination/length.|Useful evidence of intentional two-address access, not proof that all such pairs are valid CPU aliases or DMA addresses.|
|10008bc4..10008bcc|Another USB callback calls100173c8 with its original pointer/length before later queue work.|No direction or completion claim based solely on the older callback label.|

Complete30-byte helper encodings are respectively:

```text
100173c8: 6c1002020443a433bf330343146d3908011102242700222c10030200d10f
10017414: 6c1002020443a433bf330343146d3908011102252700222c10030200d10f
```

The existing boot notes locate the entry bridge100167a8, pointer10006a14→
10006cd0 and CPU/TLB initialization; their older decompilation is truncated and
is not proof of a completed boot. Bounded direct-byte read-through adds only:

- Literal10005cd0 is22222222; literal10005c9c isff222244; step literal10005ca0
  is e0000000. The boot code uses successive low nibbles as WITLB/WDTLB operands,
  sweeping the second operand in20000000 steps. Final WDTLB is at10006e49,
  followed by DSYNC10006e4f. This supports different attribute operands for the
  low and high address regions; do not decode them into a physical alias map
  without the actual configured core/address-translation contract.
-10006dd6..10006dec issues32 iterations of DII at index offsets0/16/32/48,
  advances the index64 and ends in DSYNC. The exact25 bytes are
  `c220c0306d280e27370027370427370827370c233c40030200`.
  These are index operations at boot, not a reusable runtime DMA synchronization
  routine or a proven cache-capacity/ways measurement.
- File-backed pointer cells1001bc40/58/5c/60/64/68 contain respectively
  900216f0/900226f0/900216d0/90022bc0/90022bd0/90021360. They are actual stock
  numeric operands, not addresses for the new allocator to adopt.

Disassembly used recovered GNU objdump2.30.0.20180625 from the pinned manual
toolchain. Each helper was started at its actual ENTRY; linear disassembly
across intervening padding was not used as instruction authority. Nothing in
this review promotes MEMW, DSYNC or a passing RAM experiment into a physical
cache/posted-write guarantee.

## Minimal contract for the recording publisher

Keep the current supplied `{cpu,dma,bytes}` spans. A board layer must establish
that each entire span is stationary writable RAM, physically reachable by this
controller, has the stated one-to-one byte correspondence, and has no other
CPU aliases or allocations that violate cache ownership. Both numeric address
spaces must be nonzero/nonwrapping and independently disjoint where required.
Do not cast a CPU pointer to DMA, toggle80000000, or infer mapping from identical
descriptor bytes. The asymmetric synthetic DMA labels test exactly this
separation; they provide no physical mapping evidence.

The smallest visibility seam is a synchronous, serialized callback over the
existing span and original cookie, with explicit role/direction/phase:

```c
/* Shape only, not a proposed new ownership allocator. */
sync(ctx, original_cookie, role, existing_cpu_dma_span,
     direction /* TO_DEVICE, FROM_DEVICE, BIDIRECTIONAL */,
     phase     /* BEFORE_DEVICE, AFTER_DEVICE */);
```

Reuse the existing I/O result policy: OK reports the documented CPU operation
completed; NOT_PERFORMED and UNKNOWN refuse forward publication and retain
ownership. A partial cache operation must not be hidden behind a retryable
boolean success. Hooks neither allocate an identity, invoke TinyUSB, process a
new event, release a buffer nor claim USB acknowledgement or DMA settlement.
Recording hooks are external promises about the eventual implementation.

For the first normal OUT publisher, the relevant exact ranges are the current
reserved64-byte receive prefix, then its16-byte normal descriptor. Prepare the
payload for device writes, then synchronize the fully constructed descriptor
for device read/write, then the existing publication-order operation. Only
after all three succeed may the conservative take_submission/exposure and
register-publication path proceed. Whether noncacheable/coherent memory permits
a no-op must be a separately established board capability, never a generic
fallback or a flag inferred from these callbacks returning OK.

**The stopped/settled programming window must begin before arm_out/prepare.**
Existing prepare already writes HOST_READY bytes. A late publisher check cannot
retroactively make those CPU stores safe against a controller still reading an
old pointer. Root's proposed preflight wrapper before the real DCD callback is
the appropriate boundary. Preserve its window through synchronization and the
logical register sequence; another agent owns that sequence. Cache hooks alone
cannot supply this exclusion or later old-event settlement.

An after-bind failure follows the existing adapter's retained original-cookie
fault/cancellation path. It does not undo prepare, rearm the same descriptor,
mark receive/output/transport promises, or claim the hardware never observed
memory. Cancel work still drains outside the initiating callback.

## Exact existing allocations and direction

| Allocation | Current allocation and DMA range | Visibility obligation |
|---|---|---|
|Normal bulk OUT descriptor|One16-byte,16-aligned object; explicit DMA label.|CPU builds descriptor, device reads and updates status: bidirectional. Before publication preserve CPU fields and remove stale dirty copies; before CPU status acquisition synchronize for CPU under stable-observation conditions.|
|Bulk OUT payload|Four1024-byte receive slots,16-aligned. Current DCD binds only the64-byte prefix of one reserved slot, one in flight.|Device-write range is64 bytes, not automatically1024 or an unbounded count. Prepare before DMA; acquire that same range before parser access after separately established settlement.|
|Normal EP0 descriptors|Separate OUT0 and IN0 objects, each16 bytes and16-aligned.|Same bidirectional descriptor obligation; preserve separate original cookies.|
|EP0 IN staging|Dedicated64-byte allocation,16-aligned; copied requested0..64 bytes from the original TinyUSB pointer.|Device reads staging, so synchronize staging, not the original source. Full64 is owned until settlement. Requested0 still has a valid64-byte staging allocation; never turn the original NULL ZLP pointer into a cache range.|
|EP0 OUT status sink|Dedicated64-byte allocation,16-aligned; current requested length0 only.|Receive-buffer preparation/acquisition follows the allocation's policy; zero USB payload is not proof that its backing allocation can be reused early.|
|SETUP source record|Separate16-byte record,16-aligned DMA label; immutable copied record passed to bridge.|Dedicated bidirectional/reinitialized storage, outside the first normal-descriptor publisher. Stable CPU-visible acquisition is independent of ownership bits; SETUP can overwrite despite owner state in the pinned family reference.|

Current span validators enforce16-byte CPU and DMA alignment, minimum allocation
size, numeric wrap and overlap. They cannot discover physical aliases, cache
granule size or coherent memory. If the real maintenance granule exceeds16,
back-to-back EP0 descriptors can share a line with each other; other objects may
share adjacent lines too. Whole-line maintenance must stay within an exclusively
owned allocation/padding envelope. Either establish the stock16-byte granule and
mapping, use independently justified uncached/coherent memory, or strengthen
allocation alignment/padding first. Blindly rounding into neighbouring live
state is unacceptable. Reject range-addition/round-up overflow before any hook.

For a conventional cached backend: TO_DEVICE needs clean before device access;
FROM_DEVICE needs appropriate pre-DMA invalidation/preparation and post-DMA
invalidation before CPU consumption; BIDIRECTIONAL descriptors need their CPU
writes preserved before device access and updated bytes acquired afterward.
The hook provider owns precise architecture operations and line-safe rounding.
After-device synchronization never substitutes for transfer_settled or original
event identity. In particular an IRQ, DMA_DONE or cache invalidation by itself
cannot prove no more writes/callbacks will occur.

## Reuse boundaries and useful independent controls

Pinned TinyUSB0.21.0 commit `dae3f9a366bfcddbf9dcf1b48d7500286a849539`,
[device/dcd.h](https://github.com/hathach/tinyusb/blob/dae3f9a366bfcddbf9dcf1b48d7500286a849539/src/device/dcd.h#L90)
defines clean, invalidate and clean-invalidate APIs, with TX/RX/bidirectional
direction comments. These are suitable names/contracts to reuse. **Its generic
`usbd.c:100..113` weak implementations all return true without doing anything.**
The current synthetic tusb_config explicitly disables D-cache support; upstream
default alignment4 and cache-line-size1 are configuration defaults, not HP facts.
No MCU-specific cache port is present in the19-file vendored closure. MIT license.

Pinned Linuxv6.12 commit `adc218676eef25575469234709c2d87185ca223a`,
[snps_udc_core.c](https://github.com/torvalds/linux/blob/adc218676eef25575469234709c2d87185ca223a/drivers/usb/gadget/udc/snps_udc_core.c),
keeps CPU descriptor pointers separate from DMA handles (`dma_pool_alloc`,
lines535..551), obtains buffer DMA mapping through usb_gadget_map_request
(1075..1080), and unmaps on completion(970..972). Descriptor/setup pools are
created at3076..3109. Reuse that allocation/mapping separation; Linux's device
DMA infrastructure and its platform memory rules are not an HP bare-metal
translation or cache implementation. Do not copy its phys_to_virt descriptor
chain shortcuts into this explicit-mapping component. GPL-2.0 reference.

Useful bounded checks for the next publisher: wrong CPU/DMA pair and stale
original cookie refuse before hooks; OUT64 and descriptor16 hooks have literal
direction/order; IN uses staging rather than original pointer; zero-byte USB
status does not remove the backing allocation; hook failure prevents subsequent
register intent and retains the original owner; no hook reaches a neighbouring
object or unowned cache-line tail. Those verify composition, not physical
coherence. No new test/model is necessary merely to restate the mapping promise.

## Exact source identities read

Paths below are repository-relative. SHA256 identifies this review's inputs;
the ongoing full suite may subsequently replace generated report bytes.

```text
analysis/usb-path/ep0-construction.json 8e41f358f5d956d5cdab71b45c136d6216bfa302af30a658f06f56e99696b53d
analysis/usb-path/control-in-data-stage.json 7c18b09ce7fb6a051557d6100a9e2ab961b19706e82e0dc9469d2a156c60473a
analysis/boot-handoff/boot-handoff.json 5462ed07bf6193e8cc2608d1cc6a4f228fb5eea7117ca469c3d13aa576a5d719
analysis/startup-chain-report.md a575f5bbc1d5e9bae80dc756acc926de843b29050a9c31a35821f4c39cc02df7
analysis/boot-abi/boot-abi.md 7a7592019ac8d335460a2d1e5a6f8377a0ac2a9f9db359c12ab367fc3b140263
vendor/tinyusb-0.21.0/PROVENANCE.json 31ee172160e0c9e51cec7fa0e3e9348e4b20b92493743849fcba649542eae2e0
vendor/tinyusb-0.21.0/src/device/dcd.h baf785f2d5d8e3f74bd6d6a04559fc606d341983aad35aa08e168b452c2750db
vendor/tinyusb-0.21.0/src/device/usbd.c 38de54351d81878e6543f2b022d0c39f45d28c8f0888491796398dec45e727be
vendor/tinyusb-0.21.0/src/tusb_option.h 452216f8caa674e6987f7565186dc100d02a177f3a655c7cb6e506e68e0ee67f
open-firmware/tinyusb-device/tusb_config.h 895c6599700b09f84be46ce74ac75f3974ce3b277d98f233134a54aea637616a
analysis/usb-path/controller-reference/linux-v6.12/provenance.json 023d10e246e4852c1b9415cdc3d591006edcedeba467a56b95b22b994d4a08e4
analysis/usb-path/controller-reference/linux-v6.12/snps_udc_core.c c1b09e8f69d3340f2afd3a033d77a42775b52716d45b1aceb211dcaab89127bf
analysis/usb-path/controller-reference/linux-v6.12/amd5536udc.h 8dbf2ebffe7de042bdfea1c5e4e0d7e7ca334cb821fbfaa1cf9ccfeeae302648
analysis/usb-path/controller-reference/manuals/README.md 8607c61b2c1c2f7402ed6d7b49e549b37d64cb5024172eafceced37dd86990f4
open-firmware/udc-ep0/hp1020_udc_ep0.h e9e9abb620e6a7c81bb7c3bb1050a1fd47820e5d6c228a16834c1150996cad11
open-firmware/udc-ep0/hp1020_udc_ep0.c 397c99e7b25239ae4dfb59179ea401f1e9e7d5befeb92aed853681ab90bcf140
open-firmware/udc-out/hp1020_udc_out.h 824771c76157cfda6ca6681f7f37927a769c28c1eaecbf7f56c4edca003744f2
open-firmware/udc-out/hp1020_udc_out.c 1a7f1f1a4b422b3630291210f45c1824396b99c809ebbf2c55b36eec51996a1d
open-firmware/udc-setup/hp1020_udc_setup.h 99de73d617d79128a2c66b56c97eaa4ab3b6ef47f55510dad5087f457f651e12
open-firmware/usb-receive-core/hp1020_usb_receive.h 20853cc8f4504b216d9bb0c1732da5b79c97b05796e7ea4b2a17ecc296389367
open-firmware/udc-composed-test/fixture.c 8c2089d9ae14e5ca364ac727f546488829d6935f1daa0027d38e6858ab2378eb
open-firmware/udc-ep0-test/fixture.c efd2bf5325fca29eea41cd497d456e8d66f3065bb4f1a559cfa7ca37c09c6d6f
```

Disassembler binary `/tmp/hp1020-xtensa-manual-systemz/bin/xtensa-fsf-elf-objdump`
SHA256 `513d2034299fc5cd46d543b95d120d908e67eefced3acbac2b56634f8d76124a`.
No opaque engine/video instructions were run or proposed. Remaining physical
unknowns are precise: boot-established memory attributes and aliases, controller
address reachability, maintenance granule/isolation, cache/bridge completion
semantics, stable acquisition, and transfer settlement. Keep them external.
