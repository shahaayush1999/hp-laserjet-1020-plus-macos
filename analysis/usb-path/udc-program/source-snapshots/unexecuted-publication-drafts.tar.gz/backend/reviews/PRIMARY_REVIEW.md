# Next DCD boundary: one synchronous bulk-OUT publication

2026-10-02, independent static review. Repository root is
`/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos`.
No source execution/import, build, validator, target run, live register access,
USB contact or repository edit. Only existing source/manual/disassembly reads
and this `/tmp` note. The lead owns all integration and validation.

## Recommendation and useful scope

Implement **one serialized OUT1 arm-and-publish operation**, composing the actual
`hp1020_tusb_adapter_arm_out()` and existing `hp1020_udc_out` component with the
recording register hooks. This materially replaces the fixture's supplied
publication facts and free-standing proposal with real synchronous command
construction. Keep explicit mapping/cache hooks, externally established receive
conditions and original-cookie settlement. Do not add another input queue,
descriptor encoder, identity allocator, completion model or controller startup.

Use the lead's amended integration: perform readiness/fact/register checks BEFORE
calling `adapter_arm_out`; install one synchronous callback window; the real
bulk `dcd_edpt_xfer` consumes that window, calls existing `udc_out_prepare`, performs
cache/order hooks, takes the proposal and issues its register operations before
returning. No proposal or deferred command escapes the window. Clear the window
on every wrapper exit, including adapter WAIT/no callback. Hooks cannot reenter,
admit ingress, defer operations or invoke the adapter.

This amendment is necessary: `udc_out.c:129-137` writes the final HOST_READY
descriptor during prepare. A later RDE=0 read cannot retroactively protect those
stores from a still-reachable old descriptor. The external stopped/settled lease
must begin before preparation and span publication. A wrapper enforcing its
preflight before reservation makes that requirement concrete and testable.

## Minimum supplied facts

These are exact boolean facts, not conclusions inferred from a read word. Names
are recommendations for the C draft; the meanings are the contract.

| Field | Meaning |
| --- | --- |
| `io_profile` | Logical 32-bit register words/offsets, ordered immediate hooks and the bounded classic single-RxFIFO register semantics are established. HP-compatible BE descriptor DMA and the selected packet-mode capability are supplied, not proven by the numerical BE bit. No optional RRDY/close-descriptor/CNAK enhancement is assumed. |
| `receive_dma_idle` | Before wrapper entry, prior receive DMA/bus accesses have actually settled; the old OUT1 descriptor and payload cannot be accessed while rebuilt. This remains true until the final RDE request. Old queued observations retain old cookies. RDE0, NAK, a free software owner or a timeout cannot produce this fact. |
| `register_window_stable` | All RDE writers, including any idle/timer worker, and competing register writers are serialized. DEVCTL's sampled preserved fields and relevant endpoint type/stall state remain valid through their writes, including hardware-driven changes/reset. No new ingress is admitted inside the operation. Software serialization alone is insufficient. |
| `global_receive_ready` | Reopening GLOBAL RDE is allowed: SETUP SUBPTR storage is valid, visible and safe to overwrite; any earlier SETUP is already captured; every other OUT path is safely prepared or gated. Ordinary OUT0 storage and the SETUP record are distinct. This is not implied by OUT1 readiness or by the bridge having no pending software event. |
| `cnak_window_safe` | When CNAK is needed, the relevant RX FIFO is empty at that command, under the classic non-enhanced rule. The RXFIFO_EMPTY sample is checked too, but neither RDE0 nor software serialization establishes a stable empty-FIFO interval. The no-CNAK branch need not consume this fact. |

Mapping validity, cache-line isolation and the exact cache-hook guarantees are a
separate adjacent review owned by `printer_class_reuse`. Reuse its explicit
CPU/DMA span and role/direction/range contract. Do not use TinyUSB weak successful
no-op cache hooks as evidence. There is no need for another generic DMA framework.

Unknown required facts return WAIT before a reservation; nonboolean facts reject.
A cache capability fact, if needed by that contract, must also be checked before
reservation. Actual cache operations occur only after the callback has a genuine
bound buffer and complete descriptor. None of these facts is a receive/transport/
output recovery acknowledgement.

## Concrete operation sequence and masks

The first implementation should deliberately require **DU0, BF0, THE0**:
one terminal64-byte packet descriptor in PPBNDU mode, without thresholding.
Sony supports both packet modes, but expanding DU behavior is unnecessary for
this first publication operation. Stock startup OR0x320 preserves DU/BF; it does
not prove either bit was initially zero. The mode is a checked supplied profile.

1. Outside any stack callback, require existing program/SETUP full progress7,
   current binding readiness, no local publication failure, no retained OUT
   component owner and ordinary adapter readiness. Do not bypass a held newer
   capture, reset retry, pending recovery, bulk HALT or programming failure.
   Let `adapter_arm_out` remain authoritative about readiness and reservation.
2. Validate required facts and read logical registers BEFORE `adapter_arm_out`:

   | Offset | Bounded check |
   | --- | --- |
   | `0x404` DEVCTL | Require `(v & 0x220)==0x220` (MODE9/BE5). Require `(v & 0x0000fcd7)==0`: RDE2, DU4, BF6, THE7, RES0, reserved1/15, soft-disconnect10, simulation-scale11, DEVNAK12, CSR_DONE13 and RX-flush14 must be zero. Preserve only the remaining documented fields: mask `0xffff0328`, including BREN8/TDE3 and the two length fields. This avoids replaying unrelated commands. |
   | `0x220` OUT1 CTL | Require exactly `0x20` or `0x60`: bulk ET2, optional RO NAK6, all other bits zero. Thus no STALL, snoop, poll/flush, RRDY or unproved feature commands are echoed. This is stricter than the older programming backend's preservation policy. |
   | `0x22c` OUT1 MPS | Require low16==64. Do not write or interpret upper16 as an RX allocation in this single-FIFO profile. |
   | `0x408` DEVSTS | Require RXFIFO_EMPTY15 (`0x8000`) for this first bounded profile. No write or acknowledgement follows this read. Other state/capability promises are not inferred from it. |

   Read failures/refusals cause no reservation, cookie allocation, descriptor
   mutation or peripheral write. Record a preflight diagnostic if useful, but
   do not manufacture a packet cookie. Never clear RDE here and call it settled.
   The empty-FIFO restriction deliberately excludes the separate useful case of
   draining already queued FIFO data; do not silently claim that case supported.
3. Install the synchronous window with the checked register words/lease; invoke
   the EXISTING `adapter_arm_out`. The actual callback accepts only the expected
   rhport0/OUT1/64-byte binding during `adapter.busy && stack_active && prepared`.
   Consume the callback window once; direct or duplicate calls reject BEFORE
   prepare. Validate explicit spans, then call `udc_out_prepare` and retain its
   actual original cookie. No cookie is invented for a pre-bind failure.
4. Perform the explicit RX-buffer preparation hook on the exact64-byte binding,
   descriptor publication hook on its complete16 bytes, and ordering hook.
   Only successful documented hooks justify the corresponding visibility facts
   passed to `udc_out_take_submission`. Use the supplied/check-validated mode.
5. Consume `take_submission` once into a LOCAL proposal and immediately issue:

   ```text
   WRITE 0x234 = original proposal.descriptor_dma
   ORDER
   if initial OUT1 NAK was set:
       WRITE 0x220 = 0x00000120     # bulk ET + CNAK only
       ORDER
       READ  0x220                 # require exactly 0x20 now
   WRITE 0x404 = saved_stable_devctl | 0x00000004
   ORDER
   ```

   With initial NAK0 (`0x20`), omit the unnecessary CNAK/read-back branch.
   No SNAK, RRDY, POLL, STALL, flush, interrupt acknowledgement, CSR/table update
   or SETUP rearm is part of this operation. Do not emit 0x160, which writes the
   RO NAK sample back, or inherit pending command bits from arbitrary fill.
   The CNAK branch additionally requires `cnak_window_safe` before reservation.
6. Success means only the complete intended command prefix was issued by the
   documented hooks. Leave the OUT component EXPOSED and original adapter owner
   DCD-owned. Do not read RDE back and demand it remain1: a real arrival can
   legitimately auto-clear it. No completion, receive count, ACK, FIFO drain,
   source reuse or recovery promise follows publication success.

The ordering hooks need their documented CPU/bus ordering semantics; their OK
return must not be presented as proof that a posted write reached hardware.
The physical hook implementation and its posted-write behavior remain open.

## Failure and ownership

`adapter.c:913-934` reserves input then synchronously calls the genuine TinyUSB
submission. If its DCD callback binds an owner and later returns false, the
existing adapter fences and retains the reservation/original DCD owner. Reuse
that path. Do not call packet fault, cancelled, complete, service or any recovery
API reentrantly from the DCD callback. Drain queued cancellation requests only
after the arm wrapper returns.

After a binding exists, retain the first failing original cookie, operation,
offset/range, attempted value, hook outcome and whether take_submission exposed
the record. NOT_PERFORMED and UNKNOWN both stop the prefix; neither permits a
blind replay. A NAK1 or unexpected read-back after CNAK is a retained failure:
do not issue RDE, loop or queue a later CNAK. A failed final order or uncertain
RDE write is also a failure with an already exposed, possibly active record.

All normal arm/service/pump/publication/grant/finish operations must observe this
sticky failure barrier, just as they observe program/SETUP barriers. Permit only
original-cookie fault/cancellation settlement and the existing narrow service
exception needed to drain an already admitted bus reset. No descriptor-status
bit or register write authorizes retirement. Even a pre-exposure PREPARED owner
is not silently dropped. A pre-bind callback rejection has no normal packet
cookie; the adapter's already reserved input still follows its existing recovery.

Clear a failed publication only under an explicit settled/clean recovery contract
using its ORIGINAL failure identity after owners have retired. A newer reset or
generation must not relabel the failure or automatically clear it. Do not misuse
the endpoint-programming ticket API to manufacture a programming failure that
did not occur. Reuse the existing OUT cancellation and class recovery layers;
the small publisher needs only synchronous-window/first-failure diagnostics,
not another queue, cookie allocator or general reset machine.

## Exact supporting evidence

### Stock bytes and existing execution, not newly executed hardware

Original ELF literals, reread directly:

| Literal address | Bytes / meaning |
| --- | --- |
| `0x10005e60` | `b3000234`: OUT1 DESPTR |
| `0x10005e68` | `b3000408`: DEVSTS |
| `0x10005e6c` | `00008000`: RXFIFO_EMPTY mask |
| `0x10005e70` | `b3000220`: OUT1 CTL |
| `0x10005ea8` | `b3000404`: DEVCTL |
| `0x10005f08` | `b300022c`: OUT1 MPS, not an IRQ acknowledgement |

`0x10008752` bytes `16f5c3` load the DESPTR literal; `0x1000875f..8763`
bytes `0c0200 9460` are MEMW then store the supplied descriptor pointer.
This comes BEFORE final next/status stores (`0x10008766..87a6`). The existing
replacement correctly builds all bytes before exposure; do not copy stock's
partial-construction order as a DMA-safety proof.

Original rearm call `0x10008951` bytes `5bff68` targets `0x100086f4`.
Immediately afterward `0x10008954..895f` loads DEVSTS, reads it and branches around
CNAK unless mask0x8000 is set. `0x10008962..8974` loads OUT1 CTL, reads it, ORs
0x100 and writes it: key bytes at896a `291a00`,896d `098802`,8973 `98f0`.
The earlier wait path `0x1000886c..888d` performs the same guarded CNAK request.
These are direct control-flow/byte anchors, not successful controller commands.

The already executed idle-receive experiment separately shows another writer
can OR RDE4 after a supplied delay (`0x10008f93..8fa3`), without a cancellation
generation check. Reuse `analysis/usb-path/idle-receive.md`; do not rerun it.
It explains the global receive-writer serialization prerequisite, not quiescence.

### Pinned family reference

Linux v6.12, commit `adc218676eef25575469234709c2d87185ca223a`, local directory
`analysis/usb-path/controller-reference/linux-v6.12/`:

- `snps_udc_core.c:1135-1168`: stop RDE timer, clear RDE, optional BNA dummy
  handling, publish DESPTR, request CNAK and inspect whether NAK cleared.
- `:1200-1208`: queue the original request and enable RDE; helper`:1029-1044`
  explicitly stops the separate RDE timer before read/OR4/write.
- `:303-314`: CNAK failure is observable through RO NAK; Linux queues retry.
  The proposed bounded operation instead fails closed without a retry queue.
- `amd5536udc.h:106-138`: DEVCTL/RX-empty fields;`:215-229`: endpoint commands
  and type;`:275-289`: MPS units/profile. Linux platform-specific dequeue and
  dummy descriptors are not copied or treated as settlement proof.

Sony CXD5602 User Manual1.1.0,2022-10-24, printed and one-based PDF pages:

- p1140 TableUSB-55: BF/BE/DU/TDE/RDE; p1138 TableUSB-53 and p1139 TableUSB-54
  distinguish CSR_DONE/RX flush/DEVNAK/scale/disconnect from normal mode fields.
- pp1152-1154 TablesUSB-68/69/70: RRDY requires multiple RX FIFO; CNAK needs
  empty relevant FIFO unless an optional enhancement exists; NAK is RO and
  SETUP bypasses NAK. This supports the conservative first profile and limits.
- p1162 TableUSB-81: DESPTR is the normal descriptor pointer, separate from
  SETUP SUBPTR. p1207 section3.18.11.2.1: complete a descriptor chain before
  returning it HOST_READY. p1208 section3.18.11.2.2: PPBNDU interrupts/updates
  the terminal chain descriptor; BFILL and DU1 have different timing.
- p1190 section3.18.8.6 and p1209 section3.18.11.2.3: normal OUT completion
  disables RX DMA; processing/capture precedes reconstruction and re-enable.
  None makes manually clearing RDE a bus-settlement guarantee.

Official URL:
https://www.sony-semicon.com/files/62/pdf/p-28_CXD5602_user_manual.pdf
Cached PDF remains under `/tmp/hp1020-udc-manual-review-20260929/`.
No verbatim manual quotations are reproduced. This is family evidence, not
identification of HP silicon/revision or authorization for physical writes.

## Independent next experiment

Use the existing actual TinyUSB/descriptor/program fixture composition, adding
recorded cache/order/register hooks and independently scripted reads, not a
register emulator in which recorded writes magically cause readiness.

- Preflight missing/nonboolean facts, RDE1, DU1/BF1/THE1, missing MODE/BE,
  command bits, wrong MPS/type/stall/snoop, nonempty FIFO and held SETUP/program
  barrier: no reservation/identity change, descriptor mutation or write.
- Both NAK branches and asymmetric descriptor CPU/DMA addresses: exact literal
  ordered trace, actual prepared bytes and original callback identity. Verify
  cache role/range independently. No CPU-pointer cast or new queue.
- Every post-bind cache/order/read/write failure boundary, including false/unknown
  DESPTR/CNAK/RDE and NAK-still1: trace ends at the precise prefix, original
  storage retained, no automatic retry, no END_DOC/ACK/recovery side effect.
- Out-of-window/double callback and later call with an old cookie after reset
  or descriptor-address reuse: no extra I/O. Old failure cleanup uses old
  identity. Explicit settled cancellation remains reachable.
- Successful arm plus the EXISTING externally supplied completion path feeds
  a known page to exact pixels; distinguish that composed progress from a
  hardware receive. Capture all guarded descriptor/payload bytes and both
  engines, including unchanged tails and retained old output.

This closes a real code boundary: the replacement, rather than the test caller,
decides and orders OUT1 publication from an actual stack request. It still proves
no physical cache/mapping, safe global lease, DMA stop/reset, SETUP acquisition,
interrupt/event identity producer, actual FIFO/CNAK behavior or successful USB
transfer. Startup has larger unresolved HP mode/PHY/reset assumptions; IN
completion has separate FIFO-versus-wire semantics. Neither is needed here.

## Read source identities

All following SHA256 values were rechecked during this review:

| Source | SHA256 |
| --- | --- |
| `analysis/sihp1020.elf` | `2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d` |
| Linux `amd5536udc.h` | `8dbf2ebffe7de042bdfea1c5e4e0d7e7ca334cb821fbfaa1cf9ccfeeae302648` |
| Linux `snps_udc_core.c` | `c1b09e8f69d3340f2afd3a033d77a42775b52716d45b1aceb211dcaab89127bf` |
| `open-firmware/udc-out/hp1020_udc_out.c` | `1a7f1f1a4b422b3630291210f45c1824396b99c809ebbf2c55b36eec51996a1d` |
| `open-firmware/udc-out/hp1020_udc_out.h` | `824771c76157cfda6ca6681f7f37927a769c28c1eaecbf7f56c4edca003744f2` |
| `open-firmware/udc-program/hp1020_udc_program.c` | `a0dbe512b4b4f7d045960800637f858165a3757f1e5c17096532616133f33cce` |
| `open-firmware/udc-program/hp1020_udc_program.h` | `e84cf4a8ff293d6dc3e36f502bf1029041367c0c697585f7d7f76cd2fd896f2b` |
| `open-firmware/udc-setup/hp1020_udc_setup.h` | `99de73d617d79128a2c66b56c97eaa4ab3b6ef47f55510dad5087f457f651e12` |
| `open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.c` | `a5bb1d281dd7226f9346e0dce3b13a475ac25320cf6b276f39d539d78584c3d7` |
| Sony `CXD5602-user-manual-1.1.0.pdf` | `c21b1d93018421d7c283ab377a7dabec3339badd4809652885a8a1b76e522802` |
| AMD `33238G_cs5536_db.pdf` (cross-reference only) | `a829ae505ed96a180856c84291ab26e838453ff19a589c9af7624c1e7bfcd929` |
