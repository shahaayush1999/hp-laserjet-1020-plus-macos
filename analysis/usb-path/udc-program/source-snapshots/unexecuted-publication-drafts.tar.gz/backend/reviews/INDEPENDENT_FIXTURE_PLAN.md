# Independent first OUT1 publication matrix

2026-10-02. Unexecuted `/tmp` design and literal oracles only. No imports, builds,
validators or source execution. The forthcoming publication C and runner results
were deliberately not read. Existing baseline fixture/adapter contracts and the
new frozen public header were read for API/ABI integration only.

Companion: `/tmp/hp1020-udc-publish-trace-oracles-20261002.py`.
Authority: `/tmp/hp1020-next-dcd-boundary-review-20261002.md`, SHA256
`39a4f942b986e74b48668c1e49449c5fa04312c6833e574c007b1d781ff60ee9`.
That note pins original-byte and primary-document evidence. Public header read
at SHA256 `044c5c6f1113680d51c2a52dcb830d8ea073cf0345b7b686cd98bd72b0b65bdc`.
The C author later clarified its SERVICE-only selection wording, with no ABI
change: existing program selection rules remain authoritative; local publication
failure/busy/window barriers must not erase the legitimate program reselection
service path. Neither this note nor the oracle imports the implementation.

## API and literal operations

`publication_profiles()` returns20 names × fills0/204 = **40 cases**, interface0,
capacity64. Each case is a fresh host/target instance. These are paired software
profiles, not40 physical transfers or native page lifecycles. Both fills use the
same logical register inputs; canary fill is never treated as a register state.

`publication_trace(slot, cnak)` supplies a complete literal block. Existing queue
slot0..3 has explicit DMA labels24681340/24682340/24683340/24684340; descriptor
DMA579bdf10. Determine expected slot from the known existing queue's prior
issued count modulo4, before reservation; compare to independent actual buffer
identity. Do not select an expected DMA solely from the new publisher's result.
No CPU pointer is converted to a DMA label.

All four preflight reads precede reservation. The CNAK branch has14 hook rows:
R404,R220,R22c,R408,RX-prep4,descriptor-bidir5,order,DESPTR-write,order,
CNAK-write,order,NAK-read,RDE-write,order. No-CNAK has11 rows. The successful
prefix masks are4095 and3199 respectively. `take_submission` is the silent
one-shot exposure between initial order and DESPTR write, never a fake trace row.

The positive base word34120320 becomes34120324; alternatea55a0228 becomes
a55a022c. Base OUTCTL60 emits CNAK120 and independently supplied read20; alternate
OUTCTL20 emits no CNAK. MPS uppera55a on the latter is opaque and survives only as
a read observation. No mode/default/ACK change is inferred from these words.

Read script rows are `(offset, independently supplied logical word, outcome)`.
Trace rows are `(event, absolute ordinal, kind, offset-or-DMA, value, outcome)`.
Kinds1..3 retain the existing program fixture ABI;4 is64-byte DEVICE-WRITE RX
preparation,5 is16-byte bidirectional descriptor publication. Order usesffffffff/0.
Failed reads record0 without writing the caller output; the oracle supplies
poisonwordd3a569c7 in those failed-read inputs. Writes/orders/cache hooks never
feed the read script or alter a modeled register. A missing or wrong read-script
offset is a harness violation, not a controller outcome.

`post_bind_failure(name, slot)` supplies a literal stopped trace, supplied reads,
expected last-successful prefix, component phase and failure-field expectations.
Its optional outcome override exposes an alternative vector but does NOT add it
to the claimed40-case coverage. Cache failure diagnostics have offsetffffffff,
value0, actual DMA/size; orders haveffffffff/0 with zero range; register failures
retain their offset/attempted word (failed reads0) and zero range. Original cookie
is deliberately absent from the literal data: copy it independently from the real
DCD/adapter owner before the first cache hook, then compare every diagnostic.

## Fixture reuse and event ABI

Reuse the current program fixture's one adapter, document, queues, component
owners and ledger. Append64 words after432 (total496), preserving the old block.
No second transport queue, automatic register-state simulation or cookie exists.

Agreed events (24-byte BE header plus payload remains unchanged):

| Op | Encoding |
| --- | --- |
|130|Replace exactly7 fact bytes: io_profile,idle,stable,global_receive_ready,cnak_safe,mapping_lease,cache_range_safe.|
|131|a=cache kind4/5,b=absolute future all-hook ordinal,c=IO outcome1/2,d=0. Existing121 remains write/order injection.|
|132|All words0; query pending failure into retained poisoned output.|
|133|a=original saved history id,b=full-cookie mutation0..5,c=physical-clean byte,d=0. Resolve the ORIGINAL recorded cookie, not current generation.|
|134|Direct helper probe a=rhport,b=endpoint,c=allocated receive slot0..3,d=16-bit length. No fabricated invalid CPU pointer.|

Existing op6 routes through the new arm wrapper. Ops60/61 (old direct bulk
publication policy/proposal) and14 (old generic submission-failure injection)
must be refused in this fixture build; do not leave a bypass. Normal completion
and cancellation still use the existing immutable observations/original cookies.
Public publisher results0..5 are OK/WAIT/STALE/INVALID/FAULT/ADAPTER_ERROR;
PREFLIGHT_ERROR6 is specifically a failed pre-reservation read, with no sticky
packet failure or invented cookie. Do not conflate base adapter result domains.

New diagnostics agreed by the fixture author: failure words22..35 are original
cookie5,prefix,offset,value,dma,size,operation,IO,exposed,OUT-result. Facts36..42;
query result43/hash44; independent actual cache-owner cookie45..49; cache attempt
counts50/51; exact span/cookie check52; violations53; genuine callbacks54;
cleanup count55; RX count before/after cleanup56/57; measured size58; direct
probes59; unchanged direct output60; helper result61; slot62; reserved63=0.
The remaining0..21 layout belongs to the fixture README, not an assumption here.

Every hook must check actual CPU buffer and descriptor identities in addition to
numeric DMA labels, length, role and full original cookie. Keep existing
pre/post-operation storage checks; original borrowed storage must be checked
BEFORE clearing its ledger's live flag on settlement. Used raw script/trace,
guards and unused tails must be captured and compared independently on host and
target. The existing program-storage envelope expands only as explicitly
documented by the fixture; do not discard cache rows from its oracle.

## 20 profiles, with combined preflight controls

| Profile | Required observations; final generation |
| --- | --- |
| `cnak-and-page` | Configure/recover normally, arm actual OUT chunks through the full14-row trace. Verify exact prepared16 bytes and actual64-byte mapping for every used slot, one original owner, no wire/control completion from arm. Feed one small document through externally supplied existing completion, exact32FF pixels and one END_DOC; G2. |
| `no-cnak-and-page` | Alternate11-row trace, CNAK-safe fact0 is accepted. Exercise TDE/BREN/opaque-MPS preservation; zero CNAK attempts. Same exact fresh document; G2. |
| `preflight-facts` |21 controls from `fact_refusals`: each0/2/255. Missing CNAK0 with NAK1 consumes only the first two reads; all other missing required facts and all malformed bytes cause zero I/O. No reservation/identity/buffer change. Restore facts and print once; G2. |
| `preflight-registers` |33 controls: every forbidden DEVCTL bit and missing required bit, every selected OUTCTL wrong field/command, MPS0/63/65/512, two nonempty samples. Stop at first refused read, WAIT/no reservation. Restore valid reads and print once; G2. |
| `preflight-read-failures` |8 controls, each preflight read×IO1/2; supplied poison is not reported as read value. PREFLIGHT_ERROR6, no sticky failure/cookie. Next valid arm remains usable; G2. |
| `progress-barriers` | Before initial configuration and during its pending three-promise recovery, op6 does zero publication I/O/reservations. After normal recovery hold a known newer SETUP before dispatch; arm still blocked with no I/O. Dispatch/service/settle that ordinary control through existing EP0 machinery, then print once; G2. No new programming-failure scenario is necessary. |
| `callback-authority` | Direct probes outside the window, then again with a real retained bulk owner, reject before prepare/cache/I/O and preserve poisoned cookie output. Same buffer/otherwise valid args do not authorize a second callback. Legacy bypass ops refuse. Complete the valid original owner and exact document; G2. |
| `cleanup-original-cookie` | Inject uncertain DESPTR write. Query exact independent original cookie/prefix. Cleanup with missing/nonboolean fact, wrong full-cookie fields, retained DCD owner, and stopped-but-still-mounted state fails. Admit actual reset, settle original owner, drain reset, then cleanup with original identity succeeds while receive.count remains NONZERO, G/reset promises/output unchanged. Duplicate cleanup stale; ordinary reconnect/three promises then one fresh page; G3. |
| `cancel-and-descriptor-reuse` | Successful G2 arm retains one original cookie; actual reset requests cancellation without settlement. Settle old cookie, reconnect/recover, arm G3 slot0 at same descriptor address. Late old observation/cleanup/direct probe cannot alter or retire new binding or issue any command. Finish fresh document only; G3. |
| `nak-still-set` | Literal readback60 after successful CNAK is a readback failure, IO_OK0/op7/prefix511. No RDE or retry. Retain exact exposed owner and perform explicit cleanup/recovery before fresh page; G3. |
| Ten `*-failure` profiles | Every post-bind hook boundary below; first failure retains exact prefix/cookie. No normal-progress or implicit retry after fault. Explicit original-cookie cleanup/recovery then one fresh page; G3. |

Post-bind boundaries and defaults:

| Ordinal / hook | IO | Prefix / OUT phase |
| --- | --- | --- |
|5 RX prep|UNKNOWN2|1 / PREPARED1|
|6 descriptor bidir|NOT_PERFORMED1|3 / PREPARED1|
|7 initial order|UNKNOWN2|7 / PREPARED1|
|8 DESPTR write|UNKNOWN2|31 / EXPOSED2|
|9 DESPTR order|NOT_PERFORMED1|63 / EXPOSED2|
|10 CNAK write|UNKNOWN2|127 / EXPOSED2|
|11 CNAK order|NOT_PERFORMED1|255 / EXPOSED2|
|12 CNAK readback read|UNKNOWN2|511 / EXPOSED2|
|13 RDE write|UNKNOWN2|1023 / EXPOSED2|
|14 final order|UNKNOWN2|2047 / EXPOSED2|

## Independent ownership assertions

Before each rejected preflight save real base row[2:96], receive/output/descriptor
bytes and existing proposal history; ordinary owner/receive/forward state must
be unchanged. New diagnostic/read-count changes are allowed. In particular
base issued33/count35/submissions17/last-id21 must not advance. Prefix preflight
reads are supplied observations, not bus-side effects.

For each bound failure, snapshot prior generation/issued/count and forward
counters; expect exactly one new actual cookie/reservation. Independently saved
owner has generation equal to the pre-arm receive generation, sequence prior
issued+1 and endpoint1; its transport epoch is the ORIGINAL pre-fence epoch.
The adapter may advance/fence its current epoch AFTER false callback return.
Never derive expected original identity from the resulting failure struct.
Expect DCD owner enum1 (not PENDING2); PREPARED/EXPOSED are separate component
enums. Publication success or failure creates no received payload, control ACK,
page or END_DOC.

Repeated arm, ordinary service/pump/finish/reset-finish, manual publication and
status grant cannot issue a new prefix or forward traffic during sticky failure.
Explicit settlement and actual-reset ingress remain reachable. SERVICE-only is
allowed only to drain an already admitted inactive actual bus reset; merely
being program-binding-unready is not permission to bypass publication failure.
Without publication failure, retain the program's own selection/service rules.

Cleanup success must leave receive issued/consumed/count/generation, reset active/
parts, descriptor bytes, accepted output and wire/document counters unchanged.
Specifically assert `before_count == after_count > 0` and no new recovery promise.
Do not require count0: that fenced accounting is cleared only by the later normal
three-promise generation restart. No active prepared/delivering/response or
DCD/PENDING owner may survive cleanup. Wrong/old failure identity remains stale
after a new failure, even if the same descriptor/receive address is reused.

Each case ends with one32x8 black page: exactly32 bytesff, one page and document
notification, and no page from interrupted input. Existing independent JBIG
reference decoding is retained. G2/G3 are explicitly conditional software
generations, never printer lifecycles. Captured raw events, literal script,
full trace, all source hashes and host/target rows must suffice for a later
independent consistency gate; report labels and its saved expected trace are
not independent truth.
