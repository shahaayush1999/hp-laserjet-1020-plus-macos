# Integration proposal — unexecuted, no repository edits

This directory contains new reusable C/H/README only. `backend.patch` adds those
three files under `open-firmware/udc-publish/`; it changes no existing source.
Root owns application, source capture, validation and claims. The separate
fixture agent owns optional seams/codec/build drafts. Do not execute this draft
while the current full suite is running.

## Required fixture/application seams

- Initialize after the existing OUT descriptor, program and bridge, before any
  activity. Reuse the existing asymmetric descriptor/receive DMA labels. Supply
  four fixed mappings and two real synchronous range hooks; no new C unit apart
  from `hp1020_udc_publish.c` is needed by the production path.
- Replace normal op6 adapter arm with publisher `arm_out`. Replace ordinary
  program service/progress/final-DCD-submission checks with the publisher
  equivalents. The final submission gate must cover direct SET_ADDRESS too.
- The actual bulk DCD callback invokes `prepare_and_publish`; use a zeroed local
  output cookie. A nonzero returned cookie means binding occurred even when the
  result is non-OK. Capture packet/history/borrowed bytes and independent allowed
  descriptor bytes before returning false. Preparation writes HOST_READY before
  the first cache hook, so the old whole-fixture shadow check cannot run inside
  that intentional construction interval. Cache callbacks validate their own
  exact ranges/cookies, then check all protected storage after the helper returns.
- Do not call standalone `composed_publish`, including its old automatic path,
  after the helper; it already consumed the proposal. Count actual exposure from
  the OUT component phase plus original cookie, not the helper's final success.
  A failed DESPTR/CNAK/RDE prefix still has an exposed owner. Preserve every
  cancellation request and settle it only through the existing exact-cookie API.
- Independent EP0 publication and normal pump/finish/restart require combined7.
  Program selection/grant need a local publication failed/busy/arming/servicing
  refusal, then their existing admission rules. Do not blanket require7 for
  typed SI complete_selection: it creates the missing program readiness.
  Program cleanup is not publisher cleanup; neither may clear the other's flag.
- Reuse the explicit read FIFO and ordered hook trace. Cache trace kinds4/5
  represent RX-before-device64 and descriptor-before-device16; encode exact CPU
  identity as role/slot/offset and record explicit DMA/length, not host-pointer
  integers. Reads remain independent supplied observations, never previous-write
  values or an invented register-state simulator.
- Preserve all previous432 words/ops/default builds. The fixture agent proposes
  appended64 words and ops130 facts,131 cache failure injection,132 failure query,
  133 exact-cookie cleanup and134 direct-helper refusal. Root and fixture author
  own the definitive ABI, not these prose placeholders.

## Independent controls that matter

Literal sequence obligations come from the independently frozen primary/cache
notes, not production constants. Preflight reads404/220/22c/408 must all precede
receive reservation/cookie allocation and descriptor stores. Test each missing
or nonboolean fact, conditional CNAK-safe0 with NAK0/1, each preflight read
failure, forbidden DEVCTL/type/halt state, bad MPS and nonempty FIFO. Compare
all receive counters/storage before/after, not merely result values.

For successful CNAK1 the complete hooked trace has14 operations, including the
four preflight reads; no-CNAK has11. Use independent valid observations such as
DEVCTL34120320→34120324 and a55a0228→a55a022c to exercise preserved fields. Literal
prefixes before failing post-bind ordinals5..14 are1,3,7,31,63,127,255,511,1023,
2047; success4095 (CNAK) or3199 (no CNAK). These bits mean completed software
steps only. Readback refusal NAK1 has operation READBACK, IO_OK, observed60,
prefix511, exposed1 and no RDE command. Check both NOT_PERFORMED and UNKNOWN
effects at cache/write/order boundaries without relabeling either as settlement.

Check exact CPU/DMA pair, RX64 then descriptor16 direction/order, immutable
original cookie and unchanged unowned tails. Direct or duplicate helper calls
must not prepare, hook, allocate or replace the cookie output. A pending held
raw capture must block before preflight. A later reset cannot relabel/clear a
failure. Preserve first failure on repeated blocked calls. Cleanup must wait
through controller-owned and adapter-PENDING stages; after permitted actual
reset drainage it may succeed with nonzero fenced receive.count and must leave
that count intact. Replay old cleanup after a new failure must be stale.

Finally feed known bytes through successful publications and existing supplied
settled descriptor observations to exact pixels and END_DOC. This is composed
software progress only. Do not turn those supplied observations into physical
cache, FIFO, USB, settlement or printer evidence.

## Draft history and closure

The first header was shared early so fixture/oracle work could proceed
independently. `reviews/initial-api-header.h` preserves those exact bytes
(SHA256044c5c6f1113680d51c2a52dcb830d8ea073cf0345b7b686cd98bd72b0b65bdc).
The final header only clarifies the valid SERVICE-only selection exception; its
function signatures, fact byte order, result values and diagnostic layout are
unchanged. The fixture reviewer identified that wording before any execution.

`baseline/` plus `SOURCES.sha256` preserves the inspected repository bytes;
`reviews/` preserves independent read-only inputs. `DRAFT.sha256` identifies this
unexecuted proposal and patch. No compiler, validator, Python import or target
execution was used to create it. Object size and executable behavior remain
unmeasured until root's separately controlled integration run.
