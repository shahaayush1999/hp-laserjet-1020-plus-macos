def compile_host(temp, effective):
    ep0_src = ROOT/'open-firmware/udc-ep0'
    out = ROOT/'open-firmware/udc-out'
    setup = ROOT/'open-firmware/udc-setup'
    implementation = [SRC/'fixture.c', SRC/'host-check.c', ep0_src/'hp1020_udc_ep0.c',
        out/'hp1020_udc_out.c', setup/'hp1020_udc_setup.c', PROGRAM/'hp1020_udc_program.c', PUBLISH/'hp1020_udc_publish.c',
        base.ADAPTER/'hp1020_tusb_adapter.c', base.PRINTER/'hp1020_usb_printer.c',
        base.RX/'hp1020_usb_receive.c', base.RX/'hp1020_usb_document.c']
    implementation += [base.IMG/name for name in ('hp1020_image.c', 'hp1020_image_page.c',
        'hp1020_image_stream.c', 'hp1020_image_ring.c', 'hp1020_image_output.c')]
    implementation += [base.SEM/'hp1020_semantic.c', base.SEM/'hp1020_page_plan.c',
        core.VENDOR/'libjbig/jbig85.c', core.VENDOR/'libjbig/jbig_ar.c']
    implementation += [effective/'src'/name for name in ('tusb.c', 'device/usbd.c', 'common/tusb_fifo.c')]
    flags = ['clang', '-std=c11', '-O1', '-g', '-fno-common', '-Wall', '-Wextra', '-Werror',
        '-fsanitize=address,undefined']
    include = ['-I'+str(p) for p in (SRC, PUBLISH, PROGRAM, ep0_src, out, setup, ROOT/'open-firmware',
        base.SRC, base.ADAPTER, base.PROTOCOL, base.PRINTER, base.RX, base.IMG, base.SEM,
        core.VENDOR/'libjbig', effective/'src')]
    core.command(flags+include+implementation+['-o', temp/'host'])
    full = ROOT/'vendor/foo2zjs-source'
    core.command(flags+['-I'+str(full), base.IMG/'reference.c', full/'jbig.c', full/'jbig_ar.c',
        '-o', temp/'reference'])

