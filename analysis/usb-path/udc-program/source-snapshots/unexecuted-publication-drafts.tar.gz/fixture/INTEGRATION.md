# Unexecuted publication fixture package

The lead owns integration and all execution. Nothing in this package has been
compiled, imported as executable source, run under a validator or used with a
device. Only copied sources, static edits/read-through, unified-diff generation
and file hashes were performed. The repository was not modified by this task.

`fixture.patch` modifies three optional existing fixture seams and adds five
files: publication fixture, host codec, linker wrapper, README and builder.
`manifest.json` pins every original/result hash. `original/` contains seven
exact baseline files, including the codec/linker/README/builder templates.
`draft/` contains the intended integration files. The backend author's frozen
C/H and adjacent design notes are copied under `references/` for provenance;
they are **not** part of this patch. Apply the author's production package
separately. The builder needs executable mode when created by plain patch.

No public production API was changed by this fixture draft. The final header's
selection exception is preserved: program `complete_selection` must be allowed
to establish readiness under its own SERVICE-only rules, with an additional
local publication failure/busy/arming/servicing barrier. Ordinary scheduling
and all actual DCD submissions use the combined wrappers.

The fixture README is the exact op/stats/trace contract. Append
`hp1020_publish_fixture_stats[64]` to the unchanged432 diagnostics. Exclude only
its relative58 size field from host/target equality in addition to prior size
exclusions. The component-size getter is
`hp1020_publish_fixture_component_bytes`. Program read/trace storage and getters
retain the exact public symbols, lengths, guards and unused-tail preservation.
Cache kinds4/5 increase total trace length but not old read/write/order counters.

The latest bound slot (relative62) includes a post-bind helper failure, because
that failure still owns the real buffer. Relative45..49 witness the actual
adapter owner at the last cache hook, independently of returned cookie/failure
fields. Query digest is over14 canonical BE words; rejected query calls preserve
the entire output object byte-for-byte. The README specifies its poison values.

The host codec retains all existing output arguments and captures. It only adds
64 diagnostic words and validates seven-byte op130/no-payload131..134. Target
event replay must enforce the same envelopes. The builder adds the production
publication C unit and include path while retaining pinned compiler, TinyUSB
materializer, undefined-symbol and disassembly gates. The lead must still run
the independent target instruction audit before QEMU.

No first run is claimed. The independent scenario/oracle author owns expected
literal register/cache traces and fault prefixes. The lead owns actual compiler
and target execution, complete source closure/raw capture preservation, aggregate
integration, and any later corrections. Existing variants require regression
because the patch introduces optional seams in shared fixture sources.
