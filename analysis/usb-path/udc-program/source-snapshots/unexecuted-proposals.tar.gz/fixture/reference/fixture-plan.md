# First register-programming fixture and validation plan

2026-10-02. **Unexecuted design and literal oracle data only.** No project script
was imported or run, no build or validator ran, and no repository source changed.
The proposed component remains an injected logical-register implementation;
there is no physical register backend, peripheral access or USB contact.

Companion literal data: `/tmp/hp1020-udc-program-trace-oracles-20261002.py`.
No producer function/constants are imported by those oracles. The register field
arithmetic comes from the pinned primary references below. The ordered sequence
is a reviewed candidate contract, not a replay of Linux or stock initialization.

## Reuse the current single DCD

Use a new optional `HP1020_COMPOSED_PROGRAM` build on the existing
`HP1020_COMPOSED_OFFLOAD` fixture. Keep the one `adapter`, `printer`, `document`,
`packets`, `history`, EP0 bridge, bulk bridge and SETUP bridge already present.
Do not add a controller simulator, another event queue for USB traffic or a
second owner/generation allocator. The only extra queued objects are explicit
I/O read observations; they carry no USB ownership.

The API confirmed with the implementation agent is:

- `hp1020_udc_program_init(program, ingress, io, layout, init_facts)`.
- `service(program)`, `progress(program)`, `submission_allowed(program)`.
- `open(program, rhport, seven_raw_descriptor_bytes, length, program_facts)`.
- `close_all(program, rhport, program_facts)`.
- `complete_selection(program, program_facts)` for typed SI or SC0 when core
  close was skipped. This is a separate explicit operation, never an invented
  `driver_open` callback.
- `grant(program, original_sequence, original_cookie, grant_facts)`.
- `pending_cleanup(program, failure)` and
  `ack_cleanup(program, original_programming_ticket, controller_clean)`.

Result domains must remain explicit: backend OK0/WAIT1/STALE2/INVALID3/FAULT4/
ADAPTER_ERROR5; I/O OK0/NOT_PERFORMED1/UNKNOWN2. Do not infer adapter semantics
from numeric equality when an operation now reports the backend result.

Small conditional seams are sufficient:

1. Invoke `program_open` from the *actual* offload `dcd_edpt_open` wrapper,
   before its base-success bookkeeping. Pass the unchanged seven endpoint
   descriptor bytes. On failure return false without manufacturing a completed
   endpoint-open mask. The write trace retains partial programming independently.
2. Invoke `program_close_all` from the *actual* void close-all callback. On
   failure preserve the backend's first failure and skip successful close-mask
   bookkeeping. Subsequent open or auto-status attempts must be rejected before
   I/O/binding. The service wrapper observes the sticky failure after TinyUSB
   unwinds; the void callback must not convert it into success.
3. Add a default-preserving adapter-service hook in the underlying fixture's
   op1 call. The program build uses the backend wrapper. Retain all existing
   protected-memory/shadow/guard checks around that call, rather than bypassing
   the underlying fixture step and losing its storage checks.
4. Route composed ordinary service/ARM/PUMP/finish/reset-finish/manual
   publication scheduling through `program_progress`. Keep exact-cookie
   completion/cancellation and actual reset admission reachable while failed.
   Explicit `complete_selection` must be callable when backend progress grants
   service only; requiring all three progress bits there would deadlock SI's
   unfinished programming.
5. Check `submission_allowed` before the final actual `dcd_edpt_xfer` dispatch,
   covering EP0, bulk and no-buffer auto status. Also guard the separate direct
   `dcd_set_address` route, which otherwise calls the composed EP0 constructor
   without passing through that final xfer wrapper. The first matrix need not
   add a SET_ADDRESS experiment, but it must not leave this bypass open.
6. Under the new build only, refuse old op102 (direct bridge grant), op107
   (adapter-only cleanup) and op106 (fixture-only open-failure injection).
   They bypass the new backend or can create unrelated adapter-only dirtiness.
   All existing builds keep their old behavior and 288/368-word ABI unchanged.

Use new opcodes or one small operation dispatcher for read-script loading,
fact snapshots, one I/O-failure schedule, complete-selection, backend grant,
failure query and exact cleanup. Normal op1 remains the real service entry.
The new grant operation resolves the original saved cookie from `history` and
passes it by value, including its *original* receive generation. It must not
rebuild a cookie from current state or call the old direct-grant helper.

Add a separate diagnostics array/capture for the program build. Do not reuse
the four zero-reserved offload words or change old fields. A compact new array
should expose backend failure/ticket/masks, last adapter/bridge result, current
permissions, read queue indices, trace length, I/O counts, violation/guard words
and the supplied fact bytes. A new host codec can append this array after the
existing 368 words; the old host codecs stay unchanged. Serialize trace words
explicitly, never by dumping C structs with padding or native endianness.

## Recording I/O, without automatic hardware behavior

Supply one fixed read FIFO containing `(offset, logical_value, outcome)` copied
from input events. `read32` consumes exactly the next item and verifies its
offset, or records a harness violation and fails. Successful reads set one
complete output word. Failed reads do not overwrite the caller's output; record
no claimed returned value (zero in the trace) even if a scripted value existed.
That queued outcome is the sole source of a read failure; do not add a second
competing read-result injector.

Record every hook attempt in order as six unsigned words:
`(input_event, call_ordinal, kind, offset, value, outcome)`. `kind` is R1/W2/
order3; an order event uses offset `ffffffff` and value zero. Write values are
the *attempted* values on failure too. An independent one-shot hook failure
schedule identifies a particular write/order attempt and outcome; it must
not call production failure APIs or change controller/adapter state directly.
A strict overflow or unscripted read is a failed harness, never silent truncation.

Write and order hooks log intent only. They do not update the read FIFO, clear
RDE, acknowledge NAK, clear commands, set DATA0, signal status, settle a DMA
owner or invoke TinyUSB. An optional last-successful-write ledger is a command
ledger, explicitly not a register-state simulator; uncertain writes must remain
distinct. Every later read is an independently supplied observation, even when
its value happens to match a preceding write's intended persistent bits.

Reads for the positive trace are independent of memory fill0/204. Both fills
exercise every positive/failure scenario with the same logical observations and
different guards/canaries. Asymmetric words exercise wrong bank/bit/endian
choices. Do not use fill bytes as plausible register values.

Snapshot each programming callback's original `(sequence, control_epoch,
transport_epoch)` at callback entry, before calling the backend. These values
are already allocated by the actual ingress/adapter. Use them to check later
failure tickets after the adapter's failure fence advances transport. Do not
derive expected failure provenance from the backend's resulting ticket.

For a grant, snapshot the saved typed offer and original no-buffer cookie before
the call. A backend FAULT can occur *after* the adapter consumes permission.
When `auto_granted` changes0→1, record one consumed permission with those saved
original identities even if the public return is FAULT. This is not a status
packet, completion or ACK. Never increment that witness solely on return OK,
and never undo it after UNKNOWN/NOT_PERFORMED or a failed final order hook.

## Independent register contract

The supplied first layout is OUT1 CSR slot508, IN1 slot50c, IN FIFO64 words
(256 bytes). Its size is checked, never dynamically allocated. These CSR slots
are distinct from AHB endpoint banks OUT1=220 and IN1=020. EP0 slot504 and the
stock alternate OUT1 slot510 must remain untouched; full-table coherence is
still supplied separately.

| Quantity | Literal expectation |
| --- | --- |
| Endpoint USB descriptors | OUT `07050102400000`; IN `07058102400000` |
| Endpoint type | mask30, bulk20 |
| SNAK command |80; read-only NAK40 is never replayed |
| Suppressed old command/enable bits |3ca (RRDY/CNAK/SNAK/NAK/P/F) |
| Open control write | clear type30, stall1 and3ca; then bulk20 plus SNAK80 |
| Close control write | suppress3ca, add80, preserve type and stall |
| MPS | lower16 becomes0040 at OUT22c / IN02c; preserve upper16 |
| IN allocation | read/check028 lower16=0040; **no write** |
| Logical NE fields | mask3fffffff; OUT64/config1/itf0/alt0/bulk=020000c1; IN=020000d1 |
| Bulk interrupt mask | OUT bit17=00020000; IN bit1=00000002 |
| Close pointer intent | write zero at234 and034 only after supplied quiescence |
| CSR_DONE | DEVCTL404 bit13=00002000 |
| Grant RDE refusal | DEVCTL bit2=4 must read zero |
| Unsupported DEVCTL command sample | mask6001 (flush/CSR_DONE/resume) cannot be replayed |

Companion data gives complete literal traces. Initial OUT is nine operations,
initial IN ten, close nine, successful grant four. A positive DEVCTL sample
34120320 yields write34122320; sample34120324 yields one read then WAIT. The
other fields in those words are retained, with no RDE enable. The supplied
profile still owns logical bus word semantics independently of BE DMA records.
SI has its own literal trace with the previously unmasked IRQ word00a500a5;
repeated SC1 uses the independently supplied masked word after its actual close.
Do not invent a close or automatic IRQ-mask transition to reuse one trace.

No read/write should occur outside the narrowly listed offsets. In particular
there are no accesses to OUT228 (frame-number, not a FIFO allocation), EP0 banks,
DEVCFG400, DEVSTS408, IRQ status40c/414, CSR table504/510, or descriptor-pointer
publication of a nonzero DMA address. There is no CNAK, POLL, flush, RX enable,
IRQ acknowledgement or hidden mode initialization. A barrier is an ordered CPU
I/O operation, not proof of posted-write arrival.

The companion's initial endpoint control sample51 uses read-only NAK plus old
type/stall; its intended write is a0. Later sample61 preserves stall in a close
writea1, while a reselect open emitsa0. Subsequent DATA0/halt defaults are still
an explicit fact, never inferred from either write. The primary positive words
leave reserved fields zero. Preservation of nonzero unowned reserved bits is
not claimed from these vectors; a later separately justified profile can test
such words. The IRQ mask00a700a7 supplies unowned nonzero bits which must survive.

## First matrix:12 profiles ×2 fills =24 cases

Interface0 and capacity64 only. Preserve existing actual descriptor, cookie,
guard, exact pixel/document and wire checks. The table below defines a coherent
first boundary; it is not a claim of exhaustive register fault coverage.

| Profile | Required evidence |
| --- | --- |
| `sc1-grant-and-page` | Actual OUT then IN callbacks give the literal initial traces and one retained no-buffer owner. Missing `devctl_stable` and each other missing grant fact yield WAIT with zero I/O; malformed byte2 yields INVALID. RDE=1 gives read-only WAIT. With supplied facts, one read/order/CSR_DONE/order may grant **before** document recovery; it does not advance G or fill promises. Duplicate grant is STALE before I/O. All three separate promises then restart toG2 while the original status cookie remainsG1; one exact black page and END_DOC follows. |
| `repeated-sc1-owned` | Start configured/recovered, consume only a31-byte page prefix and retain another original31-byte bulk owner. Repeated SC1 admission stops input; neither old auto status nor bulk ownership is settled by receipt. Service before each explicit original settlement gives no programming I/O. Then actual close followed by OUT/IN reopen gives full literal traces. Complete the new three-promise recovery toG3, grant using the new status owner's originalG2 cookie and print one fresh exact page; partial old data emits no page. |
| `si-explicit-programming` | Establish both bulk core HALTs through real ordinary endpoint SET_FEATURE requests, each with its normal zero-length IN status. Admit the first raw request before supplying cancellation of the retained previous typed owner, then service that raw request. Actual typed SI service has no open callbacks and no register programming yet. Backend scheduling blocks ARM/PUMP/reset finish. `complete_selection` with missing quiescence, safe-IN-SNAK or table fact waits without I/O; byte2 is invalid. Valid selection executes OUT/IN once. Duplicate selection is stale/no-I/O. Core HALTs still contradict a grant even if `affected_defaults=1` is claimed: WAIT with zero I/O. Explicit supplied default clearing and all three normal promises then permit grant/recovery and one exact page atG3. The only wire packets are the two ordinary SET_FEATURE statuses, never an automatic SI status packet. |
| `sc0-and-reset-history` | From cfg1, SC0 calls close intent, has no recovery and grants once. Repeated SC0 with completed masks already zero has no repeated close I/O. Re-enable cfg1, then supply an actual bus reset: backend command history must not magically disappear. A following SC0 while core is alreadycfg0 has no core close; explicit `complete_selection` must still execute close intent before grant. End stopped/unconfigured with zero image/document output. No NE slot is invented as disabled. |
| `stale-held-grant` | Initial typed configuration is recovered toG2 but its originalG1 status owner remains ungranted. Mutated original sequence/cookie identity and current-cookie mismatches refuse before I/O. A newer raw SETUP held with missing capture facts blocks the old grant before adapter dispatch. Admit it, settle original auto owner, and verify ordinary GET_DESCRIPTOR gives the literal18 bytes and real OUT status via existing EP0 bridge. Old grant remains stale. End atG2 with no pixels/documents; do not introduce a replacement grant or retag the old owner. Duplicate-grant coverage belongs to the successful SC1 profile. |
| `fifo-mismatch-cleanup` | OUT completes, then IN allocation read20 disagrees with fixed layout40. Exact prefix is OUT's nine operations plus that read; no IN control/write/status owner follows. Preserve original failed ticket across actual reset. Missing cleanup fact waits; wrong ticket is stale; exact cleanup occurs only with stopped/unmounted/no-owned-or-PENDING state and generates no I/O/recovery. A retry with supplied fixed40 can configure, recover toG2 and produce an exact page. |
| `read-then-partial-write-failure` | First OUT read returns NOT_PERFORMED: zero writes and original failureF1. Reset/explicit cleanup preserves G. New SC1 gets complete OUT plus IN read/check/control/MPS-read, then MPS write UNKNOWN: exact new prefix and distinct failureF2. Old F1 cannot clear F2 even after newer reset. No suffix executes; exact cleanup ofF2 is independent of all document promises. A final good configuration supplies a fresh recovery toG2 and one exact page, never a replay of either failed attempt. |
| `void-close-failure` | With old owners genuinely settled, typed SC0 close reaches mask and OUT-control writes, then OUT DESPTR zero write returns UNKNOWN. Preserve that attempted prefix. Void callback return must not erase failure; service reports backend fault and automatic status bind is refused. No IN-close suffix or CSR_DONE occurs. New reset admits/drains through the allowed service-only path but does not clean programming; original cleanup fact/ticket is still required. |
| `si-write-failure` | Typed SI has its actual no-buffer owner; explicit selection completes OUT and reaches IN interrupt-mask write which returns NOT_PERFORMED. Sticky failure keeps that original auto owner, creates no grant and blocks forward work. Cleanup waits while DCD owner exists and after explicit settlement leaves adapterPENDING; only service of an admitted actual reset then exact cleanup can release the failure. |
| `grant-pre-order-failure` | Current fully programmed selection: DEVCTL read succeeds, first order returns NOT_PERFORMED. Failure ticket is original, `grant_consumed=0`, owner auto_granted0. No CSR_DONE write or retry I/O. Its auto owner still requires explicit reset/cancellation before cleanup. |
| `grant-write-uncertain` | Read/order succeeds, permission is consumed once, CSR_DONE write returns UNKNOWN. Exact prefix ends at the attempted write; `grant_consumed=1`, original owner auto_granted1 and still live. No final barrier, rollback, wire status, completion or ACK. Repeating the call cannot issue CSR_DONE again. |
| `grant-post-order-failure` | Read/order/write succeeds, final order returns UNKNOWN. Exactly one issued CSR_DONE command remains in the trace and permission remains consumed. API fault is not permission to replay; owner/failure survive newer reset until original settlement and cleanup. |

For plain source-level positive coverage, missing grant facts may be looped in
one profile because each refusal is nonmutating. Sticky failures need fresh
selection/reset/cleanup epochs; do not silently reset the component or clone a
new ownership model inside a case. The deliberate two-attempt failure profile
exists specifically to test old-cleanup rejection against a later failure.

Every intended old-owner cancellation follows actual newer control/reset
admission which requested that cancellation. Do not retire a current healthy
auto owner by an unsolicited ABORTED completion merely to simplify setup; that
is a different transport fault and would confound the recovery oracle.

All grant success/failure controls compare wire length/hash, both EP0 descriptor
ledgers/staging, status-callback count and original no-buffer owner. CSR_DONE
creates no raw SETUP16-byte record, EP0 descriptor, zero-length wire packet,
TinyUSB success callback or ACK. Existing owner settlement stays separate.

For image-bearing cases, use the existing stock-generated small fixture and
independent32-byte all-ff pixel oracle, with exactly one5-word BE notification
for the expected receive generation. For a partial aborted document, no pixels
or successful notification may precede the fresh complete document. Repeated
service/PUMP after END_DOC changes neither bytes nor notifications; no input EOF.

Precisely, `sc1-grant-and-page`, `fifo-mismatch-cleanup` and
`read-then-partial-write-failure` produce notification `(2,1,0,1,0)`;
`repeated-sc1-owned` and `si-explicit-programming` produce `(3,1,0,1,0)`.
Each of those five cases produces32 all-ff bytes; all other first-matrix cases
produce empty pixel/document captures. Failure profiles end after exact cleanup
without an extra demonstration page unless the table explicitly requires one.
Ordinary wire is empty except the two separately counted SET_FEATURE ZLPs in
the SI profile and the literal GET_DESCRIPTOR18-byte reply (plus OUT status
owner) in the stale-held profile. An empty wire byte capture must not hide an
unexpected extra ZLP: retain the existing publication/original-cookie ledger.

## Evidence capture and review before execution

Save immutable read scripts, all actual I/O attempts/outcomes, backend invocation
identities, complete old368-word and new diagnostic rows, raw input events,
actual wire/pixels/notifications/storage/descriptor captures and source closure.
Compare host/QEMU full traces and old state, excluding only measured host/target
footprint differences already handled by the existing harness. Record the new
component size separately. Save the target ELF and effective patched TinyUSB
source map; preserve first failures before corrections. Never rewrite report
hashes or make old source snapshots appear to test this new backend.

The independent report gate should compare complete trace order and failed-call
prefixes, not merely final register words or a backend `completed_mask`. It must
detect extra reads/writes/barriers, missing queued observations, any consumed
read for a pre-I/O stale/fact refusal, or any successful suffix after failure.
Unused queued reads after intentional early refusal/failure are expected and
must be preserved with exact cursor; they must not be discarded to make the
trace look complete.

Source review still needs to confirm the final hooks and result boundaries
before constructing the executable runner. No initial case count/result is
claimed here. Unsupported command-bit read controls, every possible individual
I/O failure offset, malformed endpoint descriptors in genuine callback context,
other FIFO geometries, raw SC failure sequence0, other interfaces/speeds and
live posted-write semantics are outside this first24-case plan. Existing old
raw/composed/offload regression remains mandatory after any optional-hook edit.

## Provenance and physical limits

Primary pinned files already in the repository: Linux v6.12
`analysis/usb-path/controller-reference/linux-v6.12/amd5536udc.h` (NE fields59–81,
device control103–128, endpoint fields208–259, layouts388–444) SHA256
`8dbf2ebffe7de042bdfea1c5e4e0d7e7ca334cb821fbfaa1cf9ccfeeae302648`, and
`snps_udc_core.c` SHA256
`c1b09e8f69d3340f2afd3a033d77a42775b52716d45b1aceb211dcaab89127bf`.
HP slot literals/byte anchors and exact cached AMD/Sony manual provenance are
in `/tmp/hp1020-next-controller-backend-independent-review-20261002.md` and the
existing manual README. They were read, not executed or downloaded again.

Dynamic CSR, full table coherence, FIFO geometry, safe IN SNAK timing, endpoint
defaults, stable DEVCTL, logical bus ordering and quiescence remain independently
supplied. A successful trace proves constructed commands and software ownership
gates only. It does not prove HP register revision compatibility, DMA/cache
behavior, actual IRQ chronology, mode/startup, status handshake, enumeration,
physical printing or power-cycle recovery.
