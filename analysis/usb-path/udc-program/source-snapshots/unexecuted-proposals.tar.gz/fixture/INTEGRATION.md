# Unexecuted optional program-fixture proposal

2026-10-02. All writes stayed under this `/tmp` package. No repository file was
changed; no source imported, compiled or executed, and no tests/builds/validators,
QEMU, USB or physical register operations ran. Metadata hashing and text diffs
are archival operations only.

`original/` preserves exact six repository baselines. `draft/` contains two
optional shared-fixture edits and five proposed new files: program fixture,
host codec, linker file, README and builder. `fixture.patch` applies only those
paths. It does not contain production backend edits, scenarios, Python runner,
manual/provenance edits or report changes. The lead owns all those integrations.

`reference/backend-v1/` preserves the untouched initial frozen backend C/H;
`reference/backend-v2/` separately preserves the reviewed correction's C/H.
Neither is included in this fixture patch. V2 is needed for root's four added
raw-config guard profiles; V1 remains an unexecuted original proposal. The
public function call shape remains compatible with V1/V2; the latter makes
submission permission explicitly mutating. This fixture calls it only from
real final DCD submission/direct-address entry, never for diagnostics.

The copied target builder assumes the proposed files and separately selected
backend are integrated into a complete repository/captured source tree. This
small package deliberately is not a separate, incomplete build environment.
Preserve executable mode for `scripts/build-hp1020-udc-program-target.sh`.
The builder is adapted from the exact offload baseline and preserves its gates.

Root already has the432-word ABI and exact global capture layout; the new
README is the durable definition. The first24 matrix and literal traces are
saved in `reference/` without execution. Root's separate V2 raw configuration
profiles expand the intended first matrix to28; this fixture adds no cases or
oracle conclusions. Read queue capacity256, trace capacity1024, per-event
payload1024 and event sequence ordinal are intentionally bounded.

Review priorities before execution:

- Confirm every actual DCD submission reaches the backend permission gate,
  including the void direct-address route, and service stays inside the old
  protected-memory checks. Existing builds must preserve their old ABI/behavior.
- Confirm program operations cannot call old102/106/107 bypasses, infer hardware
  state from writes or forge settlement/default promises. Cleanup bookkeeping
  follows successful API validation of a separately supplied clean fact.
- Confirm exact failed-I/O prefixes, original pre-fence identities, consumed
  grant on later FAULT, immutable read tails and full guarded capture equality
  are independently checked by root's scenarios/gate.
- The old map is a successful actual DCD callback/cleanup ledger. Explicit
  complete_selection has its own trace/masks and never fabricates a callback.
- The first-failure witness copies allocated active request/control/transport
  identity before the call. Nested actual callback/permission failure wins over
  the older enclosing service entry. Later reset/cleanup cannot retag it.

No execution claim is made. If the first compilation or experiment fails,
preserve this exact patch, metadata and captured source closure before fixes.
