from pathlib import Path
import hashlib, gzip, io, json, tarfile
ROOT=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
OUT=ROOT/'analysis/usb-path/udc-program/source-snapshots'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
content={}
for label,directory in (
    ('backend-v1','/tmp/hp1020-udc-program-draft-20261002'),
    ('backend-v2','/tmp/hp1020-udc-program-v2-20261002'),
    ('fixture','/tmp/hp1020-udc-program-fixture-draft-20261002'),
    ('runner','/tmp/hp1020-udc-program-validator-draft-20261002')):
    root=Path(directory)
    for path in sorted(root.rglob('*')):
        if path.is_file():
            name=label+'/'+path.relative_to(root).as_posix()
            assert '__pycache__' not in name and not path.is_symlink(),name
            content[name]=path.read_bytes()
for path in (
    '/tmp/hp1020-next-controller-backend-20261002.md',
    '/tmp/hp1020-next-controller-backend-independent-review-20261002.md',
    '/tmp/hp1020-udc-program-v1-independent-review-20261002.md',
    '/tmp/hp1020-udc-program-v2-independent-review-20261002.md',
    '/tmp/hp1020-udc-program-lifecycle-addendum-20261002.md',
    '/tmp/hp1020-udc-program-scenarios-static-review-20261002.md',
    '/tmp/hp1020-udc-program-raw-scenarios-static-review-20261002.md',
    '/tmp/hp1020-udc-program-fixture-plan-20261002.md',
    '/tmp/hp1020-udc-program-root-integration-review-20261002.md',
    '/tmp/hp1020-udc-program-fixture-draft-20261002.sha256',
    '/tmp/hp1020-udc-program-trace-oracles-20261002.py'):
    path=Path(path);content['reviews/'+path.name]=path.read_bytes()
content['archive-check.py']=Path(__file__).read_bytes()
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as gz:
    with tarfile.open(fileobj=gz,mode='w') as archive:
        for name,raw in sorted(content.items()):
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0
            archive.addfile(info,io.BytesIO(raw))
payload=buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as archive:
    assert set(archive.getnames())==set(content)
    for name,raw in content.items():
        assert archive.extractfile(name).read()==raw
OUT.mkdir(parents=True,exist_ok=True)
label='unexecuted-proposals'
assert not (OUT/(label+'.tar.gz')).exists(),'immutable prior archive exists'
(OUT/(label+'.tar.gz')).write_bytes(payload)
(OUT/(label+'.json')).write_text(json.dumps(dict(
    status='Unexecuted proposals, original baselines and static reviews before integration/build/host or QEMU execution',
    archive_sha256=sha(payload),archive_bytes=len(payload),member_count=len(content),
    member_sha256={n:sha(raw) for n,raw in sorted(content.items())},
    limits='Static source review and draft syntax parsing only. No fixture execution, USB/MMIO or physical evidence.'),indent=2)+'\n')
print(label,len(content),len(payload),sha(payload))
