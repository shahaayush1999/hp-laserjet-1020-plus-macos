# Next offline controller implementation: endpoint programming and status grant

2026-10-02. **Recommendation only; unimplemented and unexecuted.** Read-only
review while the lead's full suite runs. No project imports, builds, validators,
original-code execution, downloads, USB access or repository edits.

After the ordinary raw SET_INTERFACE fix, implement a small production
register-I/O backend used by the existing TinyUSB DCD callbacks. Start with
configuration of the two bulk endpoints and immediate publication of the
already-authorized CSR_DONE permission. Exercise those same functions through
a recording RAM bus. This closes a real implementation boundary: the current
offload fixture changes open masks/counters but never programs an endpoint.
Do not add a second event queue, transfer ledger or recovery identity.

## Exact existing boundary and evidence

- `open-firmware/udc-composed-test/fixture.c:96–128` implements endpoint open/
  close as fixture bookkeeping. `:218–233` records a grant without a register
  write. `open-firmware/udc-setup/hp1020_udc_setup.c:217–239` already supplies the
  correct shared-ingress, original-sequence and immediate-consumption gate.
  `tinyusb-printer-adapter/hp1020_tusb_adapter.c:558–628` owns the one-shot
  no-buffer status owner and exact failed-programming cleanup ticket. Reuse all
  of these identities; do not reconstruct them from the register image.
- `udc-out/hp1020_udc_out.h:31–50` and `udc-ep0/hp1020_udc_ep0.h:108–125`
  deliberately stop at descriptor proposals and supplied completion facts.
  Leave these interfaces unchanged in this first programming slice. Descriptor
  publication, global RDE arbitration and completion ingress are later backend
  operations, not prerequisites for testing endpoint programming.
- Pinned Linux v6.12 `analysis/usb-path/controller-reference/linux-v6.12/`
  `amd5536udc.h:59–81` gives the NE fields; `:208–259` the endpoint control,
  bank and type fields; `:388–444` the register layouts. `snps_udc_core.c:318–432`
  programs type, maximum packet size, FIFO allocation and logical mapping.
  `:447–485` distinguishes disabling/clearing pointers from opening;
  `:2751–2858` programs configuration/interface fields and clears halt;
  `:1103–1107` writes CSR_DONE. These are reference sequences, not proof of HP
  side effects or safe cancellation. Do not copy Linux's queue freeing.
- Existing byte-reviewed stock anchors: stores at `0x100090bd` (`98a0`),
  `0x100090ce` (`9890`), `0x100090d9` (`99b0`) and `0x100090de` (`98a0`), with
  their literal loads, write `+0x504=0x02000000`, `+0x508=0x100000c1`,
  `+0x510=0x100080c1`, `+0x50c=0x100000d1` relative to `0xb3000000`.
  Anchors/provenance are in `controller-reference/manuals/README.md`,
  `static-review.tar.gz`, and `offload-mode-review.tar.gz`; the cached annotated
  rows are `/tmp/hp1020-pio-annotated-20260930.{json,txt}`. The first value is
  EP0/64; the others initially encode 512-byte bulk endpoints. The bounded
  full-speed candidate therefore needs independently expected NE words
  **0x020000c1 for OUT1 and 0x020000d1 for IN1**, not those startup words.
- **CSR slots are not endpoint-bank indices.** Stock uses the explicit slots
  above, including another OUT1 alternate. Linux's `UDC_CSR_EP_OUT_IX_OFS=12`
  belongs to its own endpoint arrangement. Use a reviewed supplied HP slot map;
  do not transplant that arithmetic or silently leave an inherited alternate
  entry enabled. A coherent complete table/unused-slot policy remains a startup
  precondition until separately implemented.
- Official cached Sony revision1.1.0 pp1134/1138, p1211 §3.18.12.1.2 and p1212
  separate dynamic CSR capability, endpoint programming, CSR_DONE permission,
  hardware status and host ACK. AMD33238G pp321/323 corroborate CSR_PRG and the
  read-zero CSR_DONE bit. The current manual README and provenance pin both
  documents. Original DEVCFG stores preserve CSR_PRG; inspected DEVCTL stores
  never explicitly grant CSR_DONE. Dynamic mode remains a supplied candidate,
  not a recovered HP fact.

## Smallest useful production slice

Use a freestanding C unit with injected `read32(offset)`, `write32(offset,value)`
and ordered-I/O barrier hooks. Its first build must have **only** a recording
RAM-bus implementation: no volatile peripheral pointers or physical backend.
Hooks return logical register words; bus byte order is a separate supplied
platform contract, not automatically inherited from BE descriptor encoding.

Route actual `dcd_edpt_open`/`dcd_edpt_close_all` calls from the existing composed
fixture through this unit. Accept only full-speed bulk OUT1/IN1, MPS64, config1,
interface0/alt0. Validate the entire requested descriptor before its first write.
Program reviewed type/MPS/NE fields using the explicit slot map and bounded
read/modify/write masks. FIFO allocation/geometry must be supplied and checked;
Linux's double-buffer dimensions must not become an undocumented HP default.
Opening does not publish a DMA descriptor or clear OUT NAK to accept input.

For typed SI, explicitly run the affected endpoint programming operation: the
TinyUSB fallback does not call `driver_open`. For config0, disable only the
affected non-control binding. Preserve the existing admission rule that old
packet owners settle before destructive programming. A close/disable command
must never itself acknowledge that settlement.

Wrap `hp1020_udc_setup_take_auto_status` and the one CSR_DONE write in a single
serialized, nonreentrant operation. Check all facts before consuming permission;
no deferred grant object can cross a newer ingress. The only DEVCTL change is
the intended bit13 command under the documented read-zero semantics. No status
descriptor, wire ZLP, TinyUSB completion or ACK callback is generated.

Successful register writes establish **programming intent**, not every part of
the current `csr_programmed` promise. Keep endpoint-default/DATA0/halt completion,
dynamic mode, current physical gate, visibility and controller settlement as
separate supplied facts. If I/O fails or a write's outcome is uncertain, retain
the partial trace and stop; do not roll back ownership or repeat CSR_DONE.
Reuse the original failed-attempt cleanup identity. TinyUSB close callbacks are
void, so the backend must retain a failure that blocks later open/grant; merely
returning from `close_all` cannot certify success. No new identity allocator is
needed for that condition.

## Bounded experiment and independent oracles

Extend the existing offload/composed fixture with the recording bus rather than
building a separate protocol simulator. Six focused scenarios, each at fills0
and204, are enough for the first checkpoint:

1. SC1: actual OUT then IN callbacks produce literal full-speed NE/MPS/type
   values; no CSR_DONE until all required facts and the current grant exist.
2. Repeated SC1 with held bulk ownership and halt: no destructive write before
   explicit settlement; then disable/reprogram in order and recover through the
   unchanged three promises. Register commands do not themselves supply them.
3. SI0: the backend actually reprograms the affected binding despite no core
   open callback; no accidental second status mechanism.
4. SC0: disable the non-control mapping, preserve EP0/global unrelated fields,
   permit one current status grant and create no document recovery.
5. A failure before programming versus midway through OUT/IN programming:
   retain the exact successful write prefix and original dirty ticket; newer
   SETUP/reset alone cannot clean it or authorize grant/retry.
6. Newer offered raw/typed ingress before grant, plus duplicate/stale attempts:
   zero CSR_DONE writes. An already issued permission remains merely a command;
   its no-buffer owner still needs explicit original-cookie settlement.

Assert exact ordered offset/value/barrier traces from an independent table,
unowned register bits/storage unchanged, and existing complete wire/pixel/
document equality. The RAM bus must not manufacture hardware side effects such
as self-clearing commands, DATA0, NAK acknowledgement or successful USB status.
Observe current register state and separately supplied acknowledgements without
pretending one caused the other. Preserve exact sources, traces and failed runs
before any future host/QEMU execution; the lead owns execution sequencing.

This adds real code needed by a DCD without repeating stock IRQ/SETUP cuts.
It cannot establish HP dynamic-CSR support, startup/reset state, complete CSR
table policy, FIFO geometry, PHY/wrapper behavior, posted-write completion,
DMA/cache visibility, event chronology, cancellation quiescence, wire ACK,
physical enumeration or printing. No part of this recommendation authorizes
binding the hooks to live peripheral addresses.

## Reviewed source identities

These identify the frozen implementation read during the recommendation, not
newly tested sources:

| File | SHA256 |
|---|---|
| `open-firmware/udc-composed-test/fixture.c` | `8bc01825129e958f3f8d4c4da52384a28d60692adb77b6c14a2930225379ec18` |
| `open-firmware/udc-setup/hp1020_udc_setup.c` | `f70322d734a8a2d26ed31befb275f61c5256e807389ca399a70707ce089508f3` |
| `open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.c` | `0fb30500dd4580d238d2f0648b935e825a427dda7af742d7bc3ddb20bdafb0bb` |
| pinned `amd5536udc.h` | `8dbf2ebffe7de042bdfea1c5e4e0d7e7ca334cb821fbfaa1cf9ccfeeae302648` |
| pinned `snps_udc_core.c` | `c1b09e8f69d3340f2afd3a033d77a42775b52716d45b1aceb211dcaab89127bf` |

