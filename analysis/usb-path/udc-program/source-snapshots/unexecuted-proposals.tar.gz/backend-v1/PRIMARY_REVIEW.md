# Controller programming recommendation: bounded static review

2026-10-02. Reviewed `/tmp/hp1020-next-controller-backend-20261002.md`, SHA256
`111868b0177f28ce95819179d7ac02212d26f409d01bdbdf21e40546e4cf3ad8`.
No firmware instruction execution, imports, build/tests, downloads, repository
edits or hardware contact. Existing annotated instructions and direct original
ELF byte/literal dumps were read; manuals were read from the existing cache.

The proposed recording-bus boundary is useful, provided the constraints below
are explicit. Its result is programming intent conditional on supplied controller
state, not a demonstrated physical backend. Findings were sent to adapter_review
while its draft remained editable.

## Concrete constraints

1. **CSR_DONE requires stable DEVCTL, not merely serialized software.**
   AMD33238G p323 makes bit13 read as zero; Sony1.1.0 p1138 identifies its
   status-permission meaning. The Linux sequence at snps_udc_core.c1103-1107 is
   read/OR/write. Family RX completion may independently clear RDE (Sony p1190),
   so replaying a saved read with RDE=1 after hardware clears it can reopen RX.
   A one-context C routine does not exclude that hardware change. Require a
   separately supplied stable/idle DEVCTL interval spanning read, ordering,
   permission consumption and write; preserve the distinction from current gate
   identity. Reject unsupported command/read state. Do not derive that stability
   from descriptor settlement or a barrier. Other DEVCTL semantics vary: Sony
   bit14 can be an active receive-flush operation; AMD calls it reserved.
2. **Endpoint control is not an ordinary persistent RAM word.** Pinned header
   214-229: NAK6 is status, SNAK7/CNAK8 are commands, ET[5:4] bulk=2, P3 starts
   demand, F1 is TX flush, S0 is stall. AMD pp313/317 and Sony pp1153-1155 give
   direction-specific RO/reserved/command semantics. Masking only ET in a generic
   RMW can replay unrelated demand/flush/NAK commands. Emit reviewed writable
   bits and deliberately selected commands; never treat a NAK write as setting
   its RO status. Positive recording reads need valid scripted register values,
   independent of storage fill0/204. The write log must not manufacture NAK or
   FIFO acknowledgements. Linux's own CNAK helper checks NAK again (303-314).
3. **IN SNAK needs more than memory settlement.** Sony p1153 requires an IN-token
   indication of empty TxFIFO before application SNAK for IN. Previously proved
   DMA-to-FIFO completion is a different fact. Keep a separate supplied
   in_snak_safe/empty-transaction condition. No speculative flush should replace
   it. Sony p1155 also says clearing the S bit cannot undo a HALT already observed
   by the host; required defaults/DATA0/halt semantics stay separately supplied.
4. **No defined NE enable bit establishes slot disable.** Header59-81 defines
   endpoint/type/config/interface/alternate/MPS fields, not an enable bit.
   Zeroing an inherited entry resembles endpoint0/config0 rather than a proven
   disabled entry. Keep the complete table/unused-slot policy supplied. A bounded
   close can record NAK/IRQ-mask/DESPTR-clear intent only after truthful external
   quiescence; none establishes logical mapping disable or ownership settlement.
5. **FIFO geometry is fixed and implementation-specific.** Sony pp1160-1161
   expresses allocation in32-bit words and prohibits changing it dynamically
   during operation. Upper16 of OUT +0x0c is a FIFO allocation only when the
   multiple-RX option exists; AMD pp319 marks the corresponding area reserved.
   IN +0x08 and OUT +0x08 are not interchangeable: OUT is a frame-number read.
   Preserve/read-check a supplied fixed allocation; do not resize on every SC/SI
   or copy Linux's double-buffer policy. Complete capacity and other endpoint
   allocations still require external establishment.
6. **Failure provenance must cover more than driver_open.** Existing adapter
   driver_open records programming_failure on endpoint-open failure. Void close,
   explicit SI programming and CSR_DONE write failures do not automatically
   populate that ticket. The backend must retain their original operation
   identity and block later programming/grants without forging successful
   adapter cleanup. An uncertain CSR_DONE write must consume permission once;
   no retry/rollback may imply that the command did not reach hardware.

## Confirmed byte/field anchors

Stock ELF contains these literal words; bytes were reread directly:

| Literal address | Word / role |
| --- | --- |
| 0x10005c84 | 0x02000000, EP0 CSR value |
| 0x10005ebc | 0xb3000504, EP0 CSR slot |
| 0x10005ec0 / ec4 | 0xb3000508 / 0x100000c1, OUT1 config1 alt0 |
| 0x10005ec8 / ecc | 0xb3000510 / 0x100080c1, OUT1 config1 alt1 |
| 0x10005ed0 / ed4 | 0xb300050c / 0x100000d1, IN1 config1 alt0 |
| 0x10005ed8 / edc | 0xb3000008 / 0xb3000028, IN0/IN1 allocation registers |

The first four stores are at0x100090bd (`98a0`),0x100090ce (`9890`),
0x100090d9 (`99b0`) and0x100090de (`98a0`). Associated literal loads retain the
exact table order above. These CSR slots are distinct from logical AHB banks
IN1 +0x020 and OUT1 +0x220. Linux's OUT CSR subtraction12 is its own layout
(header362; core386-392), not an HP slot formula.

Pinned NE masks low-to-high are0x0f,0x10,0x60,0x780,0x7800,0x78000,
0x3ff80000 (header61-81). Therefore the supplied FS64/config1/itf0/alt0/bulk2
candidate is precisely OUT1=0x020000c1 and IN1=0x020000d1. This validates arithmetic,
not HP dynamic-CSR behavior. Bank ET must become0x20 under mask0x30; MPS is64
under mask0xffff at IN1 +0x02c / OUT1 +0x22c. No OUT +0x228 write is justified.

Stock additionally writes16 to IN0 allocation at0x100090e8 and64 to IN1 allocation
at0x100090f2; the alternate startup branch repeats these at0x10009112/0x1000911c.
Under family units these are64B and256B. Linux's FS IN default32 words is different
(header256-270; core365-376). Neither observation proves total HP FIFO capacity.
The source register-word bytes and associated cached disassembly were inspected;
these writes were not executed.

Do not conflate full-speed encodings: TinyUSB TUSB_SPEED_FULL=0, family
DEVSTS.ENUMSPD FS=1, and Sony p1137 DEVCFG.SPD FS can be1 or3 depending on PHY
clock. No DEVCFG speed/mode write belongs in this first slice. Logical CSR bus
word order must remain supplied independently from BE descriptors; AMD p324 marks
DEVCTL.BE read-only while Sony p1140 marks it read/write. Existing HP CSR_PRG and
wrapper/reset unknowns are unchanged; this review does not repeat that research.

## Source identity and manual provenance

- Stock `analysis/sihp1020.elf`: `2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`.
- Pinned Linux v6.12 `amd5536udc.h`: `8dbf2ebffe7de042bdfea1c5e4e0d7e7ca334cb821fbfaa1cf9ccfeeae302648`; `snps_udc_core.c`: `c1b09e8f69d3340f2afd3a033d77a42775b52716d45b1aceb211dcaab89127bf`.
- Existing `/tmp/hp1020-pio-annotated-20260930.json`: `58b8d91665187865f88cc45bc5d4d7cebac49fc8a1b420eced6d0fb38059956d`; accompanying TXT: `f7c7e66d4fc6017c013e6a4ea25d4fae140b5c62d8cd7a09e14b7845abe8413f`.
- [Sony CXD5602 manual](https://www.sony-semicon.com/files/62/pdf/p-28_CXD5602_user_manual.pdf), rev1.1.0,2022-10-24: cached PDF SHA256 `c21b1d93018421d7c283ab377a7dabec3339badd4809652885a8a1b76e522802`.
- [AMD CS5536 Data Book](https://www.amd.com/content/dam/amd/en/documents/archived-tech-docs/datasheets/33238G_cs5536_db.pdf),33238G,May2007: cached PDF SHA256 `a829ae505ed96a180856c84291ab26e838453ff19a589c9af7624c1e7bfcd929`.

All hashes above were rechecked. Cached manuals are under
`/tmp/hp1020-udc-manual-review-20260929/`; printed pages equal one-based PDF pages.
No verbatim manual quotation is reproduced. They describe family implementations,
not established HP silicon/revision semantics. Barrier/posted-write behavior,
physical chronology, reset, unused slots and FIFO/default state remain unresolved.
