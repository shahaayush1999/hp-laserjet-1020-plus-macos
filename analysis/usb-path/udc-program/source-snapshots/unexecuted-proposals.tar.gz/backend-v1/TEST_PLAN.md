# Narrow independent controls — design only, not executed tests

Reuse the existing composed/offload Host and owners. Keep ordinary raw-SI tests
and descriptor fault matrices in their existing suites. Build expected register
values from primary field definitions and the literal table, not by calling the
new C helper or copying its computed fields. Run selected scenarios at fills0
and204; command-register observations are separate valid scripted values.

Minimum useful positive sequences:

- Typed SC1: actual OUT-open then IN-open, exact FS64/config1/itf0/alt0 NE words,
  MPS64, fixed IN FIFO equality, preservation of unrelated fields, and no CSR_DONE
  before explicit grant. Exercise raw SC1 through the same real callback path.
- Repeated SC1 with held bulk: no programming before old exact-cookie settlement;
  then close/open, ordinary three-promise recovery and an exact fresh document.
  Register writes do not count as any promise or USB ACK.
- SI0: service creates its existing held auto owner/recovery, but finish-reset
  and arm are blocked until explicit `complete_selection`. Verify actual pair
  reprogramming even though core open counters do not increment. Duplicate SI
  completion performs zero I/O. A newer raw request cannot restore old readiness.
- SC0: close affects bulk only; EP0 and unowned NE +504/+510 remain untouched.
  Repeated zero with no completed-open command history uses no register access.
  After SC1→actual reset→SC0, software reset must not erase old history; explicit
  completion emits the same bounded NAK/IRQ-mask/DESPTR-clear sequence before
  grant, without claiming logical/NE disable or physical settlement.
- Held status through document recovery: grant uses its original old-generation
  cookie, with RDE read0, and creates no additional descriptor/wire ZLP/ACK. A
  legitimate new software bulk owner is not an automatic reason to reject this
  idle-RX grant. Exact eventual cancellation remains separately supplied.

Programming guards:

- Each program fact0/2/255; known facts do not bypass old-owner checks. In DCD
  open/void-close, non-OK leaves sticky failure and prevents the following status
  bind. In post-service complete-selection, unknown facts return WAIT without
  new programming and leave recovery blocked. Invalid boolean shape rejects.
- Fixed FIFO observed mismatch versus match; **zero FIFO-size writes** in either
  case. Changing supplied layout after initialization is prohibited caller
  mutation, not a supported runtime resize test. Never write OUT+228/frame or
  claim an upper16 receive-buffer allocation change.
- Safe IN-SNAK fact absent despite source DMA being settled; no endpoint command
  is allowed. Read-only NAK is not emitted as a writable flag; previous P/F/
  CNAK/SNAK/RRDY values must not be replayed as new start/flush/ready commands.
- Failed read, definite rejected write, unknown write and failed ordering hook
  at representative OUT, IN and close positions. Assert the exact prefix and
  original ticket; known completed-command masks are not physical state after
  failure. In particular OUT success/IN failure preserves the real OUT write
  prefix without calling the whole binding complete.
- Void close failure during cfg0 and repeated cfg1: no new status bind, no grant,
  no normal progress. This must work when adapter.driver_open was never called
  and hence no adapter programming-failure record was created.

Grant controls:

- All five original cookie fields, original sequence, cancel/fault/granted state,
  held newer raw/typed/reset event and core halt: stale or blocked requests issue
  **zero bus accesses**, not just zero successful CSR_DONE writes. Keep bridge
  one-shot mutation authoritative after the read-only prechecks.
- Each grant fact0/2/255; unknown stable-DEVCTL is not supplied by software lock.
  With otherwise valid facts, read RDE1: exactly one read, no order/write, owner
  unconsumed, WAIT. Later explicitly supplied RDE0 can retry. Never test a changing
  hardware word while simultaneously claiming the spanning stability fact true.
- DEVCTL resume/flush/CSR_DONE command bits observed set: reject before permission
  consumption; no command replay. On a valid word, preserve every unrelated bit
  and add only CSR_DONE, with RDE remaining0.
- Correct grant then duplicate call: no second read/order/write or new I/O failure.
  Wrong cookie with an injected failing next-read must not consume that read or
  latch a fault. A held newer raw event before grant has the same zero-I/O rule.
- Before permission, failed DEVCTL read/order leaves grant unconsumed but retains
  the backend failure. After permission, NOT_PERFORMED/UNKNOWN CSR write and
  failed final order all leave grant consumed, owner retained and progress
  blocked. No retry may issue CSR_DONE, even after another supplied clean word.

Cleanup and replay:

- Exact failure survives newer actual reset with the original sequence/control/
  transport fields unchanged. Explicit owner cancellation can settle controller
  ownership; adapter PENDING still requires allowed reset-service drainage.
- Reject cleanup before that drainage, with clean fact0/2/255, wrong/old ticket,
  opened/mounted state or retained response/reservation. A matching later cleanup
  writes no register, starts no recovery and issues no permission.
- For failed raw open, sequence0 is valid and original control epoch is nonzero.
  When an adapter dirty ticket exists it must match; otherwise backend-only
  close/SI/grant cleanup still works without fabricating one.
- Cause a fresh later failure and replay the previous cleanup; it cannot clear
  the newer record. Replaying a consumed grant after cleanup/reset is stale.

No control above establishes the truth of supplied hardware facts. These are
command-construction and software-composition cases, not USB enumeration, IRQ
ordering, DMA settlement, peripheral side effects or printing tests.
