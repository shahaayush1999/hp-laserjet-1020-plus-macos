# UNEXECUTED scenario draft. Helpers/ABI are supplied by the final validator.

def activate(h, sequence, trace, kind=1, cfg=1):
    return h.io(trace, lambda: off._offload_activate(h, sequence, kind, cfg))


def configure(h, *, recover=False, grant=False, trace=None):
    n = off._offload_offer_dispatch(h)
    token = activate(h, n, trace if trace is not None else INITIAL)
    assert h.program_ready() and h.row[44:46] == [1, 0]
    if grant:
        h.io(GRANT, lambda: h.grant(n, token))
    if recover:
        off._offload_recovery(h, token)
    return n, token


def reset_and_cleanup(h, ticket, *, test_pending=False):
    generation = h.row[32]
    h.step(5)
    assert h.failure_ticket() == ticket and h.program_failed()
    if any(h.row[i] for i in (26, 28, 30)):
        h.service(WAIT)
        h.cleanup(ticket, result=WAIT)
        h.cancel_retained()
        if test_pending:
            h.cleanup(ticket, result=WAIT)
    h.service()
    assert h.row[8] == h.row[10] == 0 and h.row[36] == 1
    assert h.row[32] == generation and h.failure_ticket() == ticket
    h.cleanup(ticket, fact=0, result=WAIT)
    h.cleanup([ticket[0], ticket[1]+1, ticket[2]], result=STALE)
    h.cleanup(ticket)
    assert not h.program_failed() and not h.program_ready()
    assert h.row[32] == generation and h.row[44] == 0
    h.cleanup(ticket, result=STALE)


def failed_configuration(h, trace):
    n = off._offload_offer_dispatch(h)
    ticket = [n, h.row[2], h.row[4]]
    h.io(trace, lambda: h.service(FAULT))
    assert h.failure_ticket() == ticket and h.program_failed()
    assert h.row[28] == h.offload[13] == 0
    assert h.row[8] == h.row[10] == h.row[44] == 0
    assert h.offload[59:63] == [1]+ticket
    assert h.row[4] > ticket[2]
    h.step(6, result=WAIT)
    h.service(WAIT)
    return ticket


def scenario(h, name, document, images):
    h.facts([1]*7)
    h.grant_facts([1]*5)
    off._offload_reset(h)
    # Direct old fixture routes must not bypass the command backend.
    for op in (102, 106, 107):
        h.step(op, result=INVALID)
    name = name.removeprefix('program/')

    if name == 'raw-configuration-field-guards':
        # Canonical fresh cfg0 needs no invented close callback; direction is
        # ignored when wLength is zero. Both use genuine ordinary IN status.
        for direction in (0, 0x80):
            h.setup(base.packet(direction, 9))
            h.control_status('fresh-clean-raw-SC0')
        h.io(INITIAL, lambda: h.setup(base.packet(0, 9, value=1)))
        h.control_status('ordinary-raw-SC1')
        h.step(10)
        h.finish_reset(ack=False)
        assert h.row[32] == 2
        h.io(CLOSE, lambda: h.setup(base.packet(0, 9)))
        h.control_status('ordinary-raw-SC0-after-close')
        assert h.completed_mask() == 0 and h.row[44] == 0
        for value, index in ((0, 1), (0x100, 0), (1, 1), (0x101, 0)):
            _, owner = configure(h)
            raw = h.capture(base.packet(0, 9, value=value, index=index))
            h.dispatch(raw)
            ticket = [0, h.row[2], h.row[4]]
            h.service(WAIT)
            off._offload_settle_auto(h, owner, service=False)
            h.service(FAULT)
            assert h.program_failed() and h.failure_ticket() == ticket
            assert not h.offload[13] and h.row[26] == h.row[28] == 0
            reset_and_cleanup(h, ticket)
        # Also cover the cfg0 aliases for which the core emits no close call.
        for value, index in ((0, 1), (0x100, 0)):
            raw = h.capture(base.packet(0, 9, value=value, index=index))
            h.dispatch(raw)
            ticket = [0, h.row[2], h.row[4]]
            h.service(FAULT)
            assert h.failure_ticket() == ticket and h.completed_mask() == 0
            assert h.row[26] == h.row[28] == 0
            reset_and_cleanup(h, ticket)
        assert h.row[32] == 2 and not h.row[50] and not h.row[90]
        return

    if name == 'fifo-mismatch-cleanup':
        ticket = failed_configuration(h, O['PROGRAM_FIFO_MISMATCH'])
        reset_and_cleanup(h, ticket)
        _, token = configure(h, recover=True, grant=True)
        h.fresh_page(document, images)
        return

    if name == 'read-then-partial-write-failure':
        first = failed_configuration(h, O['PROGRAM_FIRST_READ_FAILURE'])
        reset_and_cleanup(h, first)
        second = failed_configuration(h, O['PROGRAM_IN_MPS_UNCERTAIN'])
        assert first != second
        h.cleanup(first, result=STALE)
        reset_and_cleanup(h, second)
        configure(h, recover=True, grant=True)
        h.fresh_page(document, images)
        return

    n, token = configure(h)
    if name == 'sc1-grant-and-page':
        before = h.row[32:48].copy()
        for i in range(5):
            facts = [1]*5; facts[i] = 0
            h.grant_facts(facts)
            h.grant(n, token, result=WAIT)
            facts[i] = 2
            h.grant_facts(facts)
            h.grant(n, token, result=INVALID)
        h.grant_facts([1]*5)
        h.io(O['PROGRAM_GRANT_RDE_WAIT'], lambda: h.grant(n, token, result=WAIT))
        assert h.offload[33] == 0 and not h.program_failed()
        h.io(GRANT, lambda: h.grant(n, token))
        assert h.row[32:48] == before, 'permission is not a recovery promise'
        h.grant(n, token, result=STALE)
        off._offload_recovery(h, token)
        assert h.offload[16:21] == h.auto_owners[token]['cookie']
        assert h.offload[18] == 1 and h.row[32] == 2
        h.fresh_page(document, images)
        return

    if name.startswith('grant-'):
        traces = {'grant-pre-order-failure':'PROGRAM_GRANT_PRE_ORDER_FAILURE',
                  'grant-write-uncertain':'PROGRAM_GRANT_WRITE_UNCERTAIN',
                  'grant-post-order-failure':'PROGRAM_GRANT_POST_ORDER_FAILURE'}
        ticket = [n, h.row[3], h.row[4]]
        h.io(O[traces[name]], lambda: h.grant(n, token, result=FAULT))
        consumed = int(name != 'grant-pre-order-failure')
        assert h.failure_ticket() == ticket and h.program_failed()
        assert h.offload[33] == consumed and h.failure_consumed() == consumed
        h.grant(n, token, result=FAULT)
        h.step(6, result=WAIT)
        reset_and_cleanup(h, ticket, test_pending=True)
        return

    off._offload_recovery(h, token)
    if name == 'stale-held-grant':
        h.grant(n+1, token, result=STALE)
        for mutant in range(1, 6):
            h.grant(n, token, mutant=mutant, result=STALE)
        pending = h.capture(base.packet(0x80, 6, value=0x0100, length=18))
        h.dispatch(pending, facts=0x010001, result=WAIT)
        h.grant(n, token, result=WAIT)
        h.dispatch(pending, service=True, service_result=WAIT)
        h.grant(n, token, result=STALE)
        off._offload_settle_auto(h, token, service=False)
        h.service()
        h.requested = 18
        h.control_in(base.DEVICE, 'device-after-held-original-auto-owner')
        h.grant(n, token, result=STALE)
        assert h.row[32] == 2
        return

    h.io(GRANT, lambda: h.grant(n, token))
    if name == 'raw-sc0-after-reset':
        off._offload_reset(h)
        assert h.completed_mask() == 3 and not h.program_ready()
        raw = h.capture(base.packet(0, 9))
        h.dispatch(raw)
        ticket = [0, h.row[2], h.row[4]]
        h.service(FAULT)
        assert h.failure_ticket() == ticket and h.completed_mask() == 3
        assert h.row[26] == h.row[28] == 0 and not h.offload[13]
        h.step(125)
        assert h.program[48:51] == ticket and h.program[56] == OK
        reset_and_cleanup(h, ticket)
        h.setup(base.packet(0, 9))
        h.control_status('new-raw-SC0-after-explicit-cleanup')
        assert h.row[32] == 2 and h.completed_mask() == 0
        return
    if name == 'repeated-sc1-owned':
        data = document(['small'])
        h.send(data[:31], 31, zlp=False)
        bulk = h.arm_write(data[31:62])
        cookie = h.bulk[bulk]['cookie'].copy()
        repeat = off._offload_offer_dispatch(h)
        h.service(WAIT)
        off._offload_settle_auto(h, token, service=False)
        h.service(WAIT)
        h.step(64, bulk, 0, result=WAIT)
        assert h.udc[16:21] == cookie and h.row[50] == h.row[90] == 0
        h.step(64, bulk, 1)
        current = activate(h, repeat, CLOSE+RESELECT)
        off._offload_recovery(h, current)
        h.io(GRANT, lambda: h.grant(repeat, current))
        assert h.auto_owners[current]['cookie'][2] == 2 and h.row[32] == 3
        h.fresh_page(document, images)
        return

    if name in ('si-explicit-programming', 'si-write-failure'):
        halt = name == 'si-explicit-programming'
        if halt:
            h.setup(base.packet(2, 3, index=1), service_result=WAIT)
            off._offload_settle_auto(h, token, service=False)
            h.service()
            h.control_status('ordinary-OUT-HALT')
            h.request(base.packet(2, 3, index=0x81), label='ordinary-IN-HALT')
            assert h.row[81:85] == [1, 1, 1, 1]
        selected = off._offload_offer_dispatch(h, kind=2)
        if not halt:
            h.service(WAIT)
            off._offload_settle_auto(h, token, service=False)
        current = activate(h, selected, (), kind=2)
        assert not h.program_ready()
        h.step(6, result=WAIT)
        h.step(7, result=WAIT)
        h.step(10)
        h.step(12, result=WAIT)
        if not halt:
            ticket = [selected, h.row[3], h.row[4]]
            h.io(O['PROGRAM_SI_IN_MASK_NOT_PERFORMED'], lambda: h.complete_selection(result=FAULT))
            assert h.failure_ticket() == ticket and h.offload[33] == 0
            reset_and_cleanup(h, ticket, test_pending=True)
            return
        for i in (3, 4, 6):
            facts = [1]*7; facts[i] = 0
            h.facts(facts); h.complete_selection(result=WAIT)
            facts[i] = 2
            h.facts(facts); h.complete_selection(result=INVALID)
        h.facts([1]*7)
        h.io(SI, lambda: h.complete_selection())
        h.complete_selection(result=STALE)
        h.grant(selected, current, result=WAIT)
        assert h.row[81:85] == [1, 1, 1, 1]
        h.step(15)
        h.io(GRANT, lambda: h.grant(selected, current))
        off._offload_recovery(h, current)
        assert h.row[32] == 3
        h.fresh_page(document, images)
        return

    if name == 'void-close-failure':
        off_seq = off._offload_offer_dispatch(h, cfg=0)
        h.service(WAIT)
        off._offload_settle_auto(h, token, service=False)
        ticket = [off_seq, h.row[2], h.row[4]]
        h.io(O['PROGRAM_CLOSE_POINTER_UNCERTAIN'], lambda: h.service(FAULT))
        assert h.program_failed() and h.failure_ticket() == ticket
        assert h.offload[13] == 0 and h.row[28] == 0
        reset_and_cleanup(h, ticket)
        return

    if name == 'sc0-and-reset-history':
        off_seq = off._offload_offer_dispatch(h, cfg=0)
        h.service(WAIT)
        off._offload_settle_auto(h, token, service=False)
        zero = activate(h, off_seq, CLOSE, cfg=0)
        h.complete_selection()
        h.io(GRANT, lambda: h.grant(off_seq, zero))
        again = off._offload_offer_dispatch(h, cfg=0)
        h.service(WAIT)
        off._offload_settle_auto(h, zero, service=False)
        zero = activate(h, again, (), cfg=0)
        h.complete_selection()
        h.io(GRANT, lambda: h.grant(again, zero))
        on = off._offload_offer_dispatch(h)
        h.service(WAIT)
        off._offload_settle_auto(h, zero, service=False)
        current = activate(h, on, RESELECT)
        off._offload_recovery(h, current)
        off._offload_reset(h)
        assert h.completed_mask() == 3 and not h.program_ready()
        off_seq = off._offload_offer_dispatch(h, cfg=0)
        zero = activate(h, off_seq, (), cfg=0)
        h.grant(off_seq, zero, result=WAIT)
        h.io(CLOSE, lambda: h.complete_selection())
        h.io(GRANT, lambda: h.grant(off_seq, zero))
        assert h.completed_mask() == 0 and h.row[8] == h.row[10] == h.row[44] == 0
        return
    raise AssertionError('unknown program profile: '+name)
