# Recording-I/O integration experiment

This draft has not executed. It adds endpoint-register command construction to
the existing single composed/offload DCD, using the same real TinyUSB callbacks,
owners, source buffers, ingress order and document recovery. The injected bus
records CPU intentions in RAM. It is not a physical controller implementation.

`scripts/validate-hp1020-udc-program.py --target` is intended to compare a
sanitized host build and the audited big-endian Xtensa/call0 QEMU build. The
first matrix has14 profiles at fills0/204 (28 cases), interface0 and packet64.
It covers SC1/repeat/SI/SC0, delayed/stale status permission, fixed FIFO mismatch,
partial programming and ordering failures, original cleanup identities, and
raw malformed-configuration/retained-history barriers. Five profiles produce
one independently checked32-byte black page and one exact END_DOC notification.
The remaining profiles intentionally produce no pixels/documents.

The optional `HP1020_COMPOSED_PROGRAM` build extends the existing offload
variant. Old default fixtures retain their288/368-word ABIs. The new432-word
row appends64 diagnostics. Legacy direct grant102, failure injection106 and
adapter-only cleanup107 are rejected only in this new variant; failures instead
enter through the actual recording hooks and cleanup uses the backend API.

## Supplied I/O and exact captures

Read observations are immutable triples `(offset, logical word, I/O result)`.
Writes never change that queue or simulate hardware effects. Each attempted
hook adds six words `(input event, absolute call ordinal, kind, offset, value,
result)`. Kind is read1/write2/order3. Order uses offsetffffffff/value0. A failed
read records value0 without modifying its output; failed writes retain their
attempted value. Every scripted prefix is consumed exactly once in this matrix.

The read object has16-byte guards around256 triples (3104 bytes total); the
trace object has16-byte guards around1024 six-word records (24608 bytes). All
guards and unused tails retain the independent allocation fill. Host captures
serialize words explicitly in big-endian order; QEMU compares both used regions
and the full27712-byte combined storage. No C-struct padding is an oracle.

New operations retain the existing five-word command plus payload-length codec:

| Op | Arguments and payload |
|---|---|
|120|a=count, other words0; exactly12×count BE bytes of read triples (at most85 per event)|
|121|a=write2/order3, b=absolute one-based all-hook ordinal, c=NOT_PERFORMED1/UNKNOWN2, d=0; no payload|
|122|all words0; seven exact program-fact bytes|
|123|complete selection; all words0, no payload|
|124|a=original ingress sequence, b=saved original token, c=cookie mutant0..5, d=0; five grant-fact bytes|
|125|query retained cleanup; all words0, no payload|
|126|a/b/c=original sequence/control/transport ticket, d=physical-clean fact; no payload|

The backend result domain is OK0/WAIT1/STALE2/INVALID3/FAULT4/ADAPTER_ERROR5.
It is distinct from adapter identity-limit semantics. Program facts are I/O
profile, packet64/BE mode, dynamic CSR, affected quiescence, table coherence,
FIFO geometry and safe IN SNAK. Grant facts are I/O profile, dynamic CSR,
completed defaults, current physical status gate and stable DEVCTL. Unknown or
invalid facts are passed as exact bytes, not converted to C truth values.

Relative new diagnostic words:

| Words | Meaning |
|---|---|
|0..9|last result, initialized, busy, servicing, failed, completed commands, selection commands, binding ready, progress, last actual submission permission|
|10..15|selection S/E/T, service epoch, last adapter/bridge results|
|16..23|original failure S/E/T, operation, offset, attempted value, I/O result, grant consumed|
|24..31|queued/consumed reads, trace count, read/write/order attempts, guards, violations|
|32..35|failure injection kind, absolute ordinal, outcome, armed|
|36..47|seven program facts, five last grant facts|
|48..56|last cleanup query output S/E/T/offset/value/operation/result/consumed, query result|
|57|measured backend sizeof (host/target difference is compared separately)|
|58..63|independently captured first-failure entry S/E/T, entry kind, witness count, actual submission checks|

The independent entry kind is service1/OUT-open2/IN-open3/close4/selection5/
grant6/submission7. It is sampled before calling the backend. A status permission
consumed before an uncertain write stays consumed even when the API returns
FAULT; the fixture observes the actual original owner's transition, not just
the return value. Cleanup and software reset do not manufacture new promises.

## Evidence boundaries

The source/fixture closure is frozen before compilation. Each event, complete
row, original storage capture, explicit I/O input, attempted trace, target ELF
and effective pinned TinyUSB source map is preserved. `trace-oracles.py` owns
independent literal expectations; it does not import production constants or
feed writes back as simulated register values. The shared checker must also
audit the result independently before a completed research checkpoint.

Mode, FIFO geometry, coherent unused table entries, safe SNAK timing, endpoint
defaults, stable DEVCTL, posted-write visibility, IRQ chronology and physical
settlement remain supplied. No physical backend, peripheral access, USB ACK,
enumeration, native page lifecycle, printing or power-cycle recovery is proven.
First coverage is deliberately bounded: it does not exercise every I/O position,
every impossible internal state, alternative geometry/speed/interface, startup,
descriptor publication to hardware, or real asynchronous controller behavior.
