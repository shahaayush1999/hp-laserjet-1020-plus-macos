# UNEXECUTED wrapper for the independent recording-I/O fixture ABI.
PROGRAM_WORDS = 64


class Host(off.Host):
    def __init__(self, executable, directory, fill, capacity, interface):
        self.program_rows = []
        self.expected_trace, self.expected_reads = [], []
        self.program_oracles = []
        self.current_grant_facts = bytes([1]*5)
        super().__init__(executable, directory, fill, capacity, interface)
        self.program_initial = self.program.copy()
        assert self.program[1:8] == [1, 0, 0, 0, 0, 0, 0]
        assert self.program[24:32] == [0, 0, 0, 0, 0, 0, 1, 0]

    def read_row(self):
        if not select.select([self.process.stdout], [], [], 30)[0]:
            self.process.kill(); self.process.wait()
            raise AssertionError('program fixture timed out: '+str(self.directory))
        raw = self.process.stdout.readline()
        with (self.directory/'raw-stdout').open('ab') as saved:
            saved.write(raw)
        assert raw, ('fixture ended early', self.directory)
        row = json.loads(raw)
        assert len(row) == 432, row
        self.ep0, self.udc, self.ingress = row[96:200], row[200:248], row[248:288]
        self.offload, self.program = row[288:368], row[368:432]
        return row[:96]

    def step(self, op, a=0, b=0, c=0, d=0, data=b'', result=OK, expect=None):
        row = super().step(op, a, b, c, d, data, result, expect)
        self.program_rows.append(self.program.copy())
        p = self.program
        assert p[2:4] == [0, 0] and p[30:32] == [1, 0], ('program guards', op, p)
        assert p[26] == len(self.expected_trace), ('unexpected hook access', op, p, self.expected_trace)
        assert p[24] == len(self.expected_reads)
        assert p[27:30] == [sum(row[2] == k for row in self.expected_trace) for k in (1, 2, 3)]
        with (self.directory/'host-program-steps.jsonl').open('a') as saved:
            saved.write(json.dumps(p)+'\n')
        return row

    def facts(self, values):
        assert len(values) == 7
        self.step(122, data=bytes(values))
        assert self.program[36:43] == values

    def grant_facts(self, values):
        assert len(values) == 5
        self.current_grant_facts = bytes(values)

    def program_ready(self):
        return self.program[7] == 1

    def program_failed(self):
        return self.program[4] == 1

    def completed_mask(self):
        return self.program[5]

    def failure_ticket(self):
        return self.program[16:19].copy()

    def failure_consumed(self):
        return self.program[23]

    def complete_selection(self, result=OK):
        return self.step(123, result=result)

    def grant(self, sequence, token, *, mutant=0, result=OK):
        before_wire = off._offload_wire_state(self)
        grants = self.offload[7]
        was_granted = self.offload[33]
        self.step(124, sequence, token, mutant, data=self.current_grant_facts, result=result)
        off._offload_no_wire(self, before_wire)
        consumed = int(not was_granted and self.offload[33] == 1)
        assert self.offload[7] == grants+consumed
        if consumed:
            original = self.auto_owners[token]
            assert self.offload[37:42] == original['original']
            assert self.offload[42:47] == original['cookie']
        if result == OK:
            assert consumed == 1 and self.offload[13] == 1
        if result == FAULT:
            assert self.program_failed()

    def cleanup(self, ticket, *, fact=1, result=OK):
        before = self.row[32:48].copy()
        self.step(126, *ticket, fact, result=result)
        assert self.row[32:48] == before, 'programming cleanup cannot recover a document'
        if result == OK:
            assert self.program[4:8] == [0, 0, 0, 0]
            assert self.program[10:13] == [0, 0, 0]
            assert self.offload[59] == 0 and self.row[8] == self.row[10] == 0

    def io(self, expected, invoke):
        """Supply literal observations, then compare the complete attempted trace."""
        expected = tuple(expected)
        trace_start, read_start = len(self.expected_trace), len(self.expected_reads)
        reads = [tuple(entry[1:]) for entry in expected if entry[0] == 1]
        assert len(reads) <= 85
        if reads:
            self.expected_reads.extend(reads)
            self.step(120, len(reads), data=b''.join(struct.pack('>3I', *row) for row in reads))
        failures = [(i, row) for i, row in enumerate(expected) if row[0] != 1 and row[3]]
        assert len(failures) <= 1
        if failures:
            index, row = failures[0]
            self.step(121, row[0], trace_start+index+1, row[3])
        event_index = len(self.events)+1
        self.expected_trace.extend((event_index, trace_start+i+1, kind, offset,
                                    value if kind != 1 or outcome == 0 else 0, outcome)
                                   for i, (kind, offset, value, outcome) in enumerate(expected))
        value = invoke()
        assert len(self.events) == event_index, 'a trace belongs to one actual API event'
        assert self.program[25] == len(self.expected_reads), 'every supplied prefix read is consumed once'
        assert self.program[35] == 0, 'write/order failure injection must be consumed'
        self.program_oracles.append(dict(event=event_index, trace_begin=trace_start,
            trace_end=len(self.expected_trace), read_begin=read_start,
            read_end=len(self.expected_reads), literal_trace=[list(r) for r in expected]))
        return value

    def finish(self):
        captures = super().finish()
        for name, suffix, rows, width in (
                ('program_reads', '.program-read-script', self.expected_reads, 3),
                ('program_trace', '.program-trace', self.expected_trace, 6)):
            raw = (self.directory/('output'+suffix)).read_bytes()
            expected = b''.join(struct.pack('>'+str(width)+'I', *row) for row in rows)
            assert raw == expected, (self.directory, name, len(raw), len(expected))
            captures[name] = raw
        assert self.program[24:26] == [len(self.expected_reads)]*2
        assert self.program[26] == len(self.expected_trace)
        return captures
