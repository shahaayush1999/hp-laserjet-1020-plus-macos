#!/usr/bin/env python3
"""Endpoint-register command construction through recording I/O in RAM only.

UNEXECUTED draft. Every register observation is supplied, never computed from
writes. No physical controller, USB, DMA, ACK or printing evidence is claimed.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import runpy
import select
import shutil
import struct
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('program_offload', ROOT/'scripts/validate-hp1020-udc-offload.py')
off = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = off
spec.loader.exec_module(off)
comp, ep0, base, core = off.comp, off.ep0, off.base, off.core
bulk_reference = off.bulk_reference
SRC = ROOT/'open-firmware/udc-program-test'
OUT = ROOT/'analysis/usb-path/udc-program'
PROGRAM = ROOT/'open-firmware/udc-program'
MODE_EVIDENCE = off.MODE_EVIDENCE
OK, WAIT, STALE, INVALID, FAULT, ADAPTER_ERROR = range(6)
ORACLES = ROOT/'open-firmware/udc-program-test/trace-oracles.py'

def compile_host(temp, effective):
    ep0_src = ROOT/'open-firmware/udc-ep0'
    out = ROOT/'open-firmware/udc-out'
    setup = ROOT/'open-firmware/udc-setup'
    implementation = [SRC/'fixture.c', SRC/'host-check.c', ep0_src/'hp1020_udc_ep0.c',
        out/'hp1020_udc_out.c', setup/'hp1020_udc_setup.c', PROGRAM/'hp1020_udc_program.c',
        base.ADAPTER/'hp1020_tusb_adapter.c', base.PRINTER/'hp1020_usb_printer.c',
        base.RX/'hp1020_usb_receive.c', base.RX/'hp1020_usb_document.c']
    implementation += [base.IMG/name for name in ('hp1020_image.c', 'hp1020_image_page.c',
        'hp1020_image_stream.c', 'hp1020_image_ring.c', 'hp1020_image_output.c')]
    implementation += [base.SEM/'hp1020_semantic.c', base.SEM/'hp1020_page_plan.c',
        core.VENDOR/'libjbig/jbig85.c', core.VENDOR/'libjbig/jbig_ar.c']
    implementation += [effective/'src'/name for name in ('tusb.c', 'device/usbd.c', 'common/tusb_fifo.c')]
    flags = ['clang', '-std=c11', '-O1', '-g', '-fno-common', '-Wall', '-Wextra', '-Werror',
        '-fsanitize=address,undefined']
    include = ['-I'+str(p) for p in (SRC, PROGRAM, ep0_src, out, setup, ROOT/'open-firmware',
        base.SRC, base.ADAPTER, base.PROTOCOL, base.PRINTER, base.RX, base.IMG, base.SEM,
        core.VENDOR/'libjbig', effective/'src')]
    core.command(flags+include+implementation+['-o', temp/'host'])
    full = ROOT/'vendor/foo2zjs-source'
    core.command(flags+['-I'+str(full), base.IMG/'reference.c', full/'jbig.c', full/'jbig_ar.c',
        '-o', temp/'reference'])


def sources(temp):
    tested = off.sources(temp)
    selected = set(SRC.glob('*')) | set(PROGRAM.glob('*.[ch]'))
    selected.update(ROOT/'scripts'/name for name in (
        'validate-hp1020-udc-program.py', 'build-hp1020-udc-program-target.sh'))
    for path in sorted(selected):
        if not path.is_file():
            continue
        name = str(path.relative_to(ROOT)); tested[name] = core.sha(path.read_bytes())
        destination = temp/'source'/name; destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
    (temp/'source-sha256.json').write_text(json.dumps(tested, indent=2)+'\n')
    return tested


