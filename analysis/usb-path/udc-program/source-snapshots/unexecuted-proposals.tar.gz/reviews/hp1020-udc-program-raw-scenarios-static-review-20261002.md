# Two raw configuration scenarios — static review addendum

2026-10-02. Scope is only `raw-configuration-field-guards` and
`raw-sc0-after-reset` in the root-owned unexecuted scenario draft. No imports,
execution, builds, validators, source edits or hardware operations were used.

Inspected initial scenario SHA256:
`2a80ad935a4811b0f76560743f6f262f6a0cfdedf22a01818b4d36ff76ce5b9e`.
After the lead's orchestration correction, inspected scenario SHA256:
`d57c395fa53cd16bfc38dd4d26a2d6aeb4b0aef497aed2585474e8e6c6965d7c`.
Path: `/tmp/hp1020-udc-program-validator-draft-20261002/scripts/program-scenarios.py`.
The lead preserved the initial file and its then-current Host/joined validator
under `before-raw-scenario-review/`. This reviewer did not retain a byte copy of
the earlier `bef1b781...` pre-raw scenario version from the previous review;
no version was reconstructed from chat text.

## Finding fixed before execution: multi-event trace interval

The initial raw-positive calls wrapped `h.setup(...)` inside `h.io(INITIAL,...)`
and `h.io(CLOSE,...)`. `setup` performs live-record write, capture offer, dispatch
and service. `Host.io` preloads the expected complete trace for exactly one API
event, and each intermediate step checks the expected trace count. Thus the
first capture step would fail the oracle before the actual callback ran.

The lead split capture/dispatch outside the trace and now wraps only
`lambda: h.service()` for both positives. The corrected lines were reread; this
resolves the source-level orchestration issue. No execution failure is claimed.

## Remaining coverage distinction: malformed first open is not isolated yet

In the corrected inspected version, every malformed `(value,index)` case first
calls `configure(h)`, including low value1 aliases `(1,1)` and `(0x101,0)`.
Every nonzero SET_CONFIGURATION now resets endpoint defaults, so TinyUSB invokes
the genuine close callback first when the old configuration is1. That close
already latches the malformed REQUEST failure. A later open sees `p->failed`
and exits at `enter()`; it does not independently test the new active-open
request-validation branch.

The current expected FAULT and exact ticket are still correct; this is a
coverage/claim issue, not another implementation defect. To cover all three V2
paths, run low-byte1 malformed aliases from clean core cfg0 after explicit
cleanup, without first configuring1 or retaining an auto owner. Save the raw
ticket immediately after dispatch, expect service FAULT, and assert matching
local plus adapter dirty ticket. Keep configured low-byte0 aliases for void
close, and cfg0 low-byte0 aliases for skipped-close status. This recommendation
was sent to the lead; no tests were edited by this reviewer.

## Confirmed source-derived expectations

- Fresh clean SC0 has no close callback and permits one ordinary IN status ZLP.
  Both zero-length direction values are supported by the patched status-stage
  rule. The initial two requests therefore produce two status packets, not
  automatic-status owners or fabricated CSR grants.
- Positive raw SC1 reaches the actual OUT/IN callbacks, then binds its ordinary
  status owner. Completing that status does not finish the configuration's
  document recovery. The added op10 correctly captures the existing recovery
  ticket before `finish_reset(ack=False)` supplies its three parts. This creates
  generation2 and no extra class-reset ACK.
- Positive configured raw SC0 emits bounded close intent and one ordinary status
  ZLP. Together with the prior positives, the guard profile expects four ordinary
  ZLP publications. Malformed configured/skipped-close attempts bind no status
  owner and add no status packet. A zero-length byte capture alone cannot count
  those packets; existing publication/owner diagnostics and packet records do.
- For malformed configured requests, raw dispatch first fences and requests
  cancellation of the old typed auto owner. Saving `{0,current control,current
  transport}` after dispatch and before callback execution is correct. The
  first service waits for that original owner; cancellation marks it PENDING;
  the next service drains it and reaches the real malformed callback. The local
  failure is captured before any subsequent adapter open-failure fence can
  advance transport. No old owner is retagged or retired implicitly.
- A void-close failure can leave no adapter dirty ticket; its backend ticket
  is sufficient for the common explicit cleanup API. A malformed first-open
  failure additionally creates the adapter dirty record with the same saved
  ticket. Actual reset/service leaves both original tickets unchanged, clears
  software binding only, and permits cleanup only after owners are gone and the
  completed controller-clean fact is explicitly supplied.
- Fresh cfg0 malformed low-value0 aliases have no actual close callback. V2's
  mutable final submission guard recognizes the trusted current stack request
  and records REQUEST failure before any descriptor/owner is created. Service
  returns backend FAULT4 even if the core swallowed the rejected submission.
- In `raw-sc0-after-reset`, initial typed configuration/recovery yields
  generation2. Actual reset cancels and drains the old auto owner, clears
  readiness but leaves completed command mask3. The following raw SC0 reaches
  skipped-close status and must fail before bind. Its ticket is raw sequence0,
  the new active control epoch and the existing post-reset transport epoch;
  raw cfg0 itself adds no destructive fence.
- That post-reset failure's pending-cleanup query should return the same ticket.
  Another actual reset does not erase it; exact explicit cleanup clears only
  the software failure/history, with no status, I/O or generation increment.
  A genuinely new canonical raw SC0 then permits the profile's only ordinary
  status ZLP. Final generation remains2 and completed command mask becomes0.

No additional wrong expected service result, owner state, generation or ticket
timing was found in the two reviewed paths. The stated outcomes remain
source-derived expectations until the independent fixture and target run.
