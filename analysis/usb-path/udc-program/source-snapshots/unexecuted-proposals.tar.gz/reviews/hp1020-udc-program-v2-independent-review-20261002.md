# Endpoint-program V2: narrow static rereview

2026-10-02. Reviewed the frozen `/tmp/hp1020-udc-program-v2-20261002/` delta
against V1 and its saved adapter/effective TinyUSB sources. No source execution,
imports, builds, validators, QEMU, repository edits or hardware contact. Both
proposal directories remain unchanged.

- V2 C: `11b88880c7b6b4eb9124b09d33fff4a9cced1ee3a99691f2aee87e1f74e8bb1b`.
- V2 H: `fbeb2f6b29b40df3a0a81d0fdd20a3a1e5317d1880e7bb8d03787e92858d2eab`.
- `v1-to-v2.patch`: `3d936c38a28210dc432c2cb7e1a21d4b1df770334564a41dcee818c4387bc1c8`.
- Prior independent V1 review: `/tmp/hp1020-udc-program-v1-independent-review-20261002.md`,
  SHA256 `79c48d45f09096f95d01d17c2dfc7ce24b55f68489213879b207b86d2b2aca3a`.

All fifteen V2 `DRAFT.sha256` and all nineteen `SOURCES.sha256` entries matched.
The latter now also preserves both pinned and effective TinyUSB core bytes.

**No additional actionable correctness finding in this bounded delta.** The two
identified V1 failure-barrier gaps are closed by source flow, subject to the
integration contract that every genuine DCD submission calls the mutable gate
before binding an owner. This is a static result, not a passed execution claim.

## Malformed real configuration callbacks now retain failure

V2 C176–186 establishes current real callback identity without folding in
request validity or stopped state. It still requires the service wrapper,
actual adapter/stack activity, rhport match, current control identity, matching
bridge epoch, and no held/terminal ingress. The open path C275–284 and close
path C302–308 then separately validate request/support/fence/stop conditions
and latch REQUEST failure before I/O when a genuine callback rejects them.

For configured raw low0 with wIndex1 or high wValue1, pinned core still enters
void close; that close now retains original sequence0/control/transport identity,
sets failed and clears binding readiness. Its ensuing status call is rejected
at C230, before a new owner. Service notices the new failure at C265 even if
TinyUSB ignores the void-close/failed-status result. No successful close command
history is invented.

For malformed low1 on either fresh cfg0 or existing cfg1, the open false path
has already retained the same pre-fence transport identity as the adapter's
programming_failure. The adapter records its ticket before its later fence
advances transport (saved adapter C199–205). Existing callback-time reset does
not add another fence when already fenced and owner-free (C161–175). Hence the
local cleanup API can use one exact original ticket for both records. Neither
record is relabelled to a later reset or request.

Inactive/late/wrong-rhport calls remain INVALID before any failure mutation.
This matters because an obsolete active_setup buffer alone cannot supply valid
new failure provenance. The ordinary callback window is unchanged for valid
configuration open/close; program facts and no-owner checks still precede I/O.

## Skipped raw SC0 close now has an actual-submission barrier

C229–246 is explicitly mutable. In the trusted callback window it matches raw
standard-device SET_CONFIGURATION by low value0, not strict canonical fields
alone. If fields are unsupported, retained completed/selection history remains,
or stopped/fenced state is absent, it latches the original REQUEST failure and
returns false before descriptor/auto-owner binding or bus operations.

This catches the lead's SC1 → actual reset service → raw SC0 schedule: reset
clears binding_ready but not completed/selection history; cfg0 causes core to
omit close; the status gate now rejects that silent-cleanup assumption. It also
catches fresh malformed high/index/IN-length aliases reaching the same skipped
close, even when history is empty. OUT requests with nonzero length are rejected
by the existing adapter before core dispatch and need not manufacture a backend
failure merely to reject them.

Valid exceptions remain usable by source flow:

- Fresh canonical raw SC0: adapter init explicitly fenced/stopped the document
  (saved adapter C393–404), and backend command masks are zero. The gate returns
  true without inventing a close callback.
- Raw SC0 after a successful ordinary close: disable_endpoints cleared both
  masks at V2 C197; the request remains fenced/stopped, so normal status survives.
- Typed SC0: nonzero active_offload.sequence excludes this raw guard. It retains
  its original no-buffer status owner and explicit completion/grant path.
- Ordinary GET_DESCRIPTOR, printer-class traffic, SET_ADDRESS and valid raw SC1
  do not match the raw-low0 guard. Normal bulk arming occurs outside service and
  remains subject to the existing adapter/component ownership checks. The new
  predicate does not replace those checks.

No live owner is cancelled/released by the new guard, no permission is consumed,
and no register is touched. The cleanup ticket identifies the rejected current
attempt, not a claimed write. Existing cleanup still requires exact original
identity, externally supplied controller-clean fact, stopped/unmounted state
and no retained adapter owners. Reset/ordinary ingress alone does not clear it.

## Integration and execution checks to retain

Use the actual mutable predicate in every submission callback, including direct
SET_ADDRESS and typed auto-status binding. A cached result or precheck before
entering the core would miss this intentionally callback-scoped barrier. Keep
register trace, ownership ledger and wire output independent.

The focused controls proposed with V1 remain sufficient: genuine malformed
SC0/SC1 callbacks and matching cleanup; post-reset retained-history raw SC0;
fresh canonical SC0; normal configured raw close; typed SC0 explicit completion;
and an out-of-callback predicate/open/close query with stale active bytes. Check
that the query creates no failure while the real malformed callback does.
For the ordinary positive path, exact pages/documents and a real EP0 descriptor
response demonstrate that the new predicate did not merely block all traffic.

Register offsets, masks, command sequences, RDE/stability restrictions, one-shot
grant consumption, original-cookie checks and cleanup implementation did not
change in V2. The primary-manual/stock-byte review and all supplied hardware
limits from the frozen V1 review therefore still apply. These software guards
establish neither HP controller behavior nor physical cancellation/defaults.
