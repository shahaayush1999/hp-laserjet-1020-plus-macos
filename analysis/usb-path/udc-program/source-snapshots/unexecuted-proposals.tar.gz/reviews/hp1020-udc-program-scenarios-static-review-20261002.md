# Program scenario/Host review — static, before execution

2026-10-02. Read-only review of these root-owned unexecuted drafts:

- `/tmp/hp1020-udc-program-validator-draft-20261002/scripts/program-host.py`,
  SHA256 `778bcd61045e75f7d0f7704a79ea971354b24429b72654dcb6746591d36ed484`.
- `/tmp/hp1020-udc-program-validator-draft-20261002/scripts/program-scenarios.py`,
  SHA256 `bef1b78112061e59062b988e4c38d88000fb1487edab12a0828ba56633691f82`.

No imports, compilation, tests, validator, target execution, repository changes
or device contact occurred. The scenario and Host sources were not edited.
This review excludes the separately added malformed raw configuration and
post-reset raw-SC0 profiles. It does not review the in-progress fixture codec as
if that partial file were its final ABI.

**No actionable expected-state or lifecycle error was found in this pair.**
The fixture author independently confirmed the intended64-word map used by
Host:1–7 initialization/busy/servicing/failure/completed/selection/readiness;
24–25 scripted-read count/cursor;26 trace count;27–29 read/write/order attempts;
30–31 guards/violations;35 armed failure outcome. Combined rows therefore have
the existing368 words followed by64 new words. Final fixture integration and
execution are still required to establish that it emits this agreed ABI.

## Source-derived checks which support that conclusion

- `reset_and_cleanup` correctly distinguishes actual controller settlement from
  adapter drainage. Before settlement the exact original auto/bulk owner is
  retained; afterward it can be PENDING even though the fixture's live token
  row has cleared. Cleanup's second WAIT assertion is correct because backend
  `no_owners()` checks adapter owner state, prepared/delivering and response
  retention. Actual reset service must drain those pending records and reset
  software binding before cleanup can succeed. The helper's successful cleanup
  creates no new generation or recovery promise.
- Failed first configuration saves the ticket before service. Actual DCD open
  failure creates the adapter dirty record with the same sequence/control/
  transport fields, then fences/advances transport. Consequently the expected
  exact old ticket and later larger current transport epoch are consistent.
  Backend service returns PROGRAM_FAULT4 for a newly latched callback failure,
  even if the underlying adapter returns ERROR5 or swallows a raw rejection.
- The three grant-failure cases correctly distinguish failure before permission
  from uncertain write/failed order after it. Host compares the actual owner's
  `auto_granted`0→1 transition, not merely successful API returns, and retains
  the original grant/cookie witness even on FAULT. It expects the next grant to
  fail without another read/order/write. No failure is presented as a status ACK.
- The stale-grant scenario's WAIT versus STALE distinction is correct. A held
  unadmitted raw capture blocks the bridge before identity checks, so WAIT is
  expected. Once the new capture is admitted, the original sequence/control
  owner is stale even while the old auto-status borrow awaits cancellation.
  The later ordinary descriptor response follows only after explicit old-cookie
  settlement and service.
- SI service makes the transport reselection/recovery record but performs no
  TinyUSB open callback. The scenario expects an empty register trace then,
  blocks finish/reset/arm/pump while backend binding readiness is false, and
  explicitly invokes complete_selection. Missing facts leave it pending;
  malformed facts reject; duplicate completed selection is STALE without I/O.
  With existing core HALT still set, grant correctly waits despite successful
  register commands. The separately supplied op15 clears those software states;
  only then is the independent defaults/current-gate grant permitted. The later
  three document promises remain separately exercised.
- Typed SC0 from configured state reaches the actual close callback. Repeated
  SC0 in core cfg0 has no callback/I/O when command history is already empty.
  SC1 followed by an actual reset notification preserves completed command
  history while clearing readiness, so the final typed SC0 grant must WAIT
  until explicit complete_selection emits the bounded close sequence. None of
  those expectations treats software reset as controller-programming cleanup.
- Initial generation1→configuration recovery2, then repeated SC1/SI recovery3,
  matches the explicit reset/recovery calls. The held automatic status owner
  keeps its original earlier generation rather than being restamped.
- Existing base/component/bridge success, WAIT, STALE and INVALID values match
  their use here. New backend service/grant/selection/cleanup failures use its
  own FAULT4/ADAPTER_ERROR5 domain; the examined scenarios do not interpret a
  base identity-limit result4 as a backend fault or vice versa.
- `Host.io()` queues only the expected prefix's independent read observations,
  records attempted failed writes/order separately, and requires all scripted
  reads and one-shot injection to be consumed. The expected trace event number
  is calculated after script/injection configuration, immediately before the
  single API event. `activate()` calls only one service step inside that trace
  interval; helper assertions add no hidden fixture events.
- Every step rejects unexpected hook counts; final capture equality compares
  the full read script and six-word attempted trace. It does not feed writes
  back as later register observations or infer any command side effect. Storage
  fill and supplied register words remain separate.

## Deliberate limits of this review

The literal trace tables are independently owned by the fixture/oracle author;
this review checks their call placement and expected lifecycle, not an absent
final table's arithmetic. Host/QEMU orchestration, source/artifact closure and
full replay main are separate integration checks. Successful future execution
would establish command construction and software composition under supplied
facts, never physical reset, FIFO state, posted-write arrival, USB ACK or printing.

The reset-SERVICE safety argument relies on the existing adapter's common
admit_control guard refusing PENDING_BUS_RESET before incrementing control_epoch.
The separate lifecycle addendum includes the newer-raw-capture negative schedule;
the examined scenarios do not yet claim to execute that additional control.
