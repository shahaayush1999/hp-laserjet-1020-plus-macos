# Integration plan — unapplied, unexecuted

Add `open-firmware/udc-program/hp1020_udc_program.{c,h}` from `backend.patch`.
There are no required production adapter/bridge/TinyUSB patch edits and no
callback-signature dependency on the raw-SI fix. `baseline/` contains the exact
files read; `BASE_REVISION` records the repository HEAD at capture. Sources may
include the lead's then-uncommitted raw-SI work; the hashes, not HEAD alone,
identify the snapshot. Do not overwrite existing report hashes on integration.

The lead/fixture agent owns an optional extension of the existing composed/
offload fixture and its independent oracle. Preserve all old default ABIs and
targets. Add one translation unit/include directory to a new target builder;
retain pinned compiler, effective TinyUSB and ISA-audit gates. No new library,
runtime, allocator, interrupt handler or physical register mapping is required.

The integration wrapper must do all of the following together:

1. Initialize this backend after the existing SETUP bridge and before any
   control ingress, with explicit slots +508/+50c and a supplied fixed IN1 FIFO
   allocation (stock candidate64 words). Initialize only a recording bus.
2. Replace adapter-service entry with `hp1020_udc_program_service()`. Replace the
   outer scheduling predicate with `hp1020_udc_program_progress()`, preserving
   the existing exact-cookie settlement/reset exception. Gate base finish-reset
   as well as arm/pump/close/finish/manual descriptor publication.
3. Actual DCD open calls `hp1020_udc_program_open()` before the fixture's normal
   successful-open bookkeeping. Return true only on OK. Actual configuration
   close_all calls the backend first; update successful-close fixture state only
   on OK. Its void return must not erase the backend's sticky failure.
4. Every DCD submission entry, including direct `dcd_set_address`, checks
   `submission_allowed()` before binding any descriptor or auto-status owner.
   Its backend pointer is mutable in V2: a genuine current raw SC0 status can
   latch REQUEST failure for unsupported fields or retained open-command history.
   Do not replace it with a cached bool or an idle precheck outside the callback.
   Do not recursively call the outer progress
   predicate inside a busy TinyUSB callback. This check ensures a close failure
   rejects the core's ensuing status submission before ownership is acquired.
5. After typed SI0, or SC0 when core close was skipped, call
   `complete_selection()` explicitly with supplied facts. Do not auto-complete
   the three recovery promises or erase old programming history on bus reset.
6. Replace the fixture's simulated grant counter operation with backend
   `grant()`. Record the actual CSR_DONE write separately from permission
   consumption. Ordinary raw control traffic still uses existing EP0 descriptors.
7. Add an exact failure-query/cleanup operation; preserve raw and typed ticket
   provenance. A backend failure can exist without adapter.programming_dirty.
   Cleanup uses the backend API, which calls existing adapter cleanup only when
   an adapter dirty record exists. Do not write component-owned fields directly.

The new fixture variant must reject the old standalone grant/adapter-cleanup
operations102/107 so neither can bypass the backend. The default composed and
offload builds keep their existing behavior. A grant failure after one-shot
consumption must be observed as `auto_granted=1` with the original owner retained,
even though the API returns FAULT; counting only successful-return grants loses
that necessary failure evidence.

V2 additionally closes the two static review findings preserved in
`V1_INDEPENDENT_REVIEW.md` and `LIFECYCLE_REVIEW.md`. See `V2_DELTA.md` for exact
scope; V1 remains unchanged in its original directory. No source was executed
between the two revisions. The existing failure-only SERVICE exception remains
unchanged: the adapter refuses any raw/typed request admission while an actual
reset is pending, before advancing its control epoch.

The initial recording bus should queue individual `{operation,offset,value,
result}` expectations for reads and hook failures and retain a separate actual
trace. The implementation never reads from its own write log. Record attempted
write values even for NOT_PERFORMED/UNKNOWN results and assert all intended
input observations were consumed. Ordinary guard fills remain independent.

Suggested fixture-only command numbers start at120, beyond existing offload107;
the fixture agent owns the final ABI. Expose program/grant facts as separate
bytes (not booleans reduced by C truthiness), original failure/selection tickets,
completed-command masks, busy/failure/grant-consumed diagnostics, read cursor and
trace length. Preserve the original368 words and append a compact new block;
save the full read script and actual trace separately rather than expanding
every trace event into permanent stats. Measure target state size after build.

Before the first execution, freeze source/fixture hashes and byte snapshots.
Compile and run the focused host/QEMU fixture sequentially only after the lead's
current suite finishes. Compare old wire/pixels/documents/storage exactly, plus
the new independent trace and full new diagnostic rows. Preserve any failure
archive before source edits. Later shared-suite validation remains the lead's
decision. No execution or integration has been done by this drafting task.
