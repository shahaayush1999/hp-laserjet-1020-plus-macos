# Frozen endpoint-program backend V1: static review

2026-10-02. Read-only review; no source import/execution, build, validator,
QEMU, download, repository edit, device contact or peripheral access. The
proposal bytes were left unchanged. This note is frozen against V1; later
corrections need a separate addendum.

Reviewed package: `/tmp/hp1020-udc-program-draft-20261002/`.

- `backend.patch`: `c4556bd41c1b4d87c1f2b3cd09dcb975abc884ff4599319ab7cfe1e5ba93a3d0`.
- `hp1020_udc_program.c`: `f730acfc44a3dc83f63f0cdb8d8b36585c26c7485c005710ce4753c1c59d0e9a`.
- `hp1020_udc_program.h`: `2a3eaab8da7b7c98183a246a8e691989e7e70395641ba6c402c63763c3e1abbd`.
- README: `22428b13708f25ab6116c50c5117d56c370948da8326c80431b2f9075ac5104d`.

All ten `DRAFT.sha256` and all seventeen `SOURCES.sha256` members were checked
against their saved bytes and matched. The saved baseline identifies the
then-current source bytes independently of its recorded Git revision. In
particular, adapter C is `a5bb1d281dd7226f9346e0dce3b13a475ac25320cf6b276f39d539d78584c3d7`.
The effective TinyUSB core read for its dispatch behavior is
`/tmp/hp1020-offload-v2-20261002/effective-v2/src/device/usbd.c`, SHA256
`8bf699c1522d65301a4c63e2bfa529d302d3955b8cd18dd1602d7ace441a62dc`;
it is the effective core represented by the saved protocol patch.

## Actionable finding: unsupported raw configuration can escape the failure barrier

**Fix before integration/testing.** `configuration_request()` (C59–63) requires
full wValue <=1, wIndex=0 and wLength=0. `callback_context()` folds that request
policy into its otherwise genuine callback-context check (C176–184).
`open()` C257 and `close_all()` C283 return INVALID when the combined check
fails, without latching a local failure. `submission_allowed()` C227–229 thus
continues returning true.

A concrete source-derived schedule is:

1. Successfully configure1 and settle its existing owners before new service.
2. Admit a raw device SET_CONFIGURATION with low value0 and either wIndex=1
   (`00 09 00 00 01 00 00 00`) or high value1
   (`00 09 00 01 00 00 00 00`). The adapter's admission recognizes the
   destructive operation and fences/drains it (saved adapter C426–465).
3. Pinned effective TinyUSB C998–1040 uses only `(uint8_t)wValue`. Because its
   old configuration was1, it invokes the real void close callback, resets its
   software configuration and then calls `tud_control_status()`.
4. Backend `close_all()` rejects the unsupported fields before any I/O but
   leaves `failed=0`. TinyUSB cannot observe that return, and the required DCD
   submission predicate remains true. Ordinary status can therefore be bound
   even though no backend close commands were issued and old command history
   remains present.

The parallel low-value1/high-or-index alias reaches `open()` and returns false;
then adapter `driver_open()` C199–205 can create `programming_dirty` while the
backend has no local failure. The backend's `pending_cleanup()` returns STALE,
so its advertised single cleanup route cannot clear that adapter-only record.
This is not an unsupported caller invocation: the pinned core itself generates
these callbacks from admitted raw bytes. It also contradicts the README's
statement that malformed prerequisites inside actual callbacks latch failure.

Separate trusted active-callback identity from supported-request validation.
A genuine active callback with an unsupported request should retain a REQUEST
failure with its original raw sequence0/control/transport ticket before
returning, while an unrelated out-of-context external call can remain a
mutation-free INVALID. Alternatively, reject the malformed request before core
dispatch while preserving original admission/ownership; do not let a void close
rejection disappear.

A small focused matrix suffices: configured low0/wIndex1, low0/high-value1 and
low1 alias. Verify no backend I/O for rejected fields, no new status owner/wire
packet, sticky original provenance, blocked normal progress, and exact cleanup
across actual reset. Keep one valid raw SC0/SC1 control to establish that valid
callbacks still perform the expected command sequences.

The lead separately identified canonical raw SC0 after SC1→actual reset: core
cfg0 skips close_all while old backend open-command history remains, allowing
ordinary status in V1. That lifecycle issue is tracked by the lead/author for
V2 and is not represented here as an independently discovered register flaw.

## Register and one-shot review: no additional finding within supplied profile

The literal layout and field formulas are internally consistent with the pinned
family reference and previously reread original stock anchors:

- IN1 control/FIFO/MPS/DESPTR +020/+028/+02c/+034 and OUT1
  control/MPS/DESPTR +220/+22c/+234 match their distinct logical banks.
  +418 is the endpoint interrupt mask; bulk bits are IN1 bit1 and OUT1 bit17.
- Explicit HP NE slots +508 OUT1 and +50c IN1 are supported by stock literals
  0x10005ec0/0x10005ed0 and corresponding stores 0x100090ce/0x100090de.
  No Linux OUT-bank index formula is substituted. EP0 +504 and inherited
  OUT1-alt1 +510 are not written.
- Header field masks union to low30 bits. Independent MPS64/config1/itf0/
  alt0/bulk2 arithmetic gives OUT `0x020000c1` and IN `0x020000d1`.
  These are supplied-profile values, not stock boot's MPS512 values.
- `EP_SUPPRESS=0x3ca` removes F1, P3, RO NAK6, SNAK7, CNAK8 and RRDY9 from
  the sampled word; open additionally replaces ET[5:4] with bulk and clears S0.
  The only asserted endpoint command is SNAK. Close preserves type/S but clears
  the other sampled command intent. Reserved/SN preservation remains conditional
  on `io_profile`; arbitrary poisoned register words are not a valid positive
  hardware profile. A write log must not be recycled into synthetic reads.
- IN FIFO +028 is read/check only against fixed supplied allocation. Neither
  OUT frame-number +228 nor allocation resizing is emitted. MPS writes replace
  low16 only; this does not prove optional OUT FIFO allocation semantics.
- CSR_DONE grant C333–398 checks original retained cookie/control/transport,
  core halt, current ingress and completed command history before any bus read.
  DEVCTL read RDE1 returns WAIT before consumption. Commands RES0, CSR_DONE13
  and SRX_FLUSH14 must read zero. The stable-DEVCTL supplied fact spans the
  read/order/grant/write interval, including hardware changes, not just CPU
  serialization. These are necessary restrictions of this narrow proposal.
- Bridge permission is consumed immediately before the CSR_DONE write, with no
  escaped grant or intervening stack callback. Failed/unknown write or final
  ordering after consumption retains `grant_consumed=1`, the original owner
  and first failure; no retry can reuse that permission. CPU hook success does
  not prove posted-write arrival or host ACK.
- Close is conditional on externally supplied DMA/FIFO/event quiescence and
  safe IN SNAK timing. It does not derive settlement from IRQ masking, SNAK,
  pointer zeroing or software reset. It retains NE entries and emits no flush,
  RDE/TDE mode change, FIFO resize, descriptor start or physical reset.

Preserve independent negative checks for RDE1, command bits in DEVCTL, missing
stable interval, wrong original cookie, FIFO mismatch and each late grant
failure. Test successful and uncertain prefixes against an independent trace,
not a bus model that fabricates self-clearing commands or defaults. These are
bounded conditional tests, not physical-controller proof.

## Evidence and remaining supplied facts

The exact stock/manual anchors and provenance are preserved in
`PRIMARY_REVIEW.md` (SHA256
`9315587950faae4c40791e441b77883876202b2eaf22eaa84713af2f8fa61997`).
Pinned Linux header lines59–81,107–127,174–229,250–282 support the masks;
its OUT CSR index12 at362 is not the HP slot map. Linux core303–314 itself
separates CNAK issuance from checking NAK acknowledgement.

Sony CXD5602 user manual rev1.1.0, 2022-10-24, printed/PDF pp1153–1155
supports command/RO fields and separate safe IN SNAK timing; pp1160–1162
supports fixed FIFO units and MPS; pp1138/1190 supports the RDE read-modify-write
hazard and pp1211–1212 separates CSR_DONE permission from status/ACK.
Official source: https://www.sony-semicon.com/files/62/pdf/p-28_CXD5602_user_manual.pdf
PDF SHA256 `c21b1d93018421d7c283ab377a7dabec3339badd4809652885a8a1b76e522802`.
AMD CS5536 Data Book33238G, May2007, printed/PDF pp313/317/319/323–324
provides older-family comparisons, including command/reserved differences.
Official source: https://www.amd.com/content/dam/amd/en/documents/archived-tech-docs/datasheets/33238G_cs5536_db.pdf
PDF SHA256 `a829ae505ed96a180856c84291ab26e838453ff19a589c9af7624c1e7bfcd929`.
No verbatim manual quotation is reproduced.

These manuals describe related implementations, not established HP revision
behavior. The frozen header/README appropriately leave HP mode, full table and
FIFO geometry, logical register endian, stable bus state, defaults/DATA0/halt,
physical gate currentness, posted ordering, cache visibility, settlement and
real enumeration externally supplied. Passing recording-bus execution cannot
convert any of those facts into a device observation or a working replacement.
