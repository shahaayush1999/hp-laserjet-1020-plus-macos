# Endpoint program V2 — narrow static corrections, unexecuted

V1 is preserved unchanged at `/tmp/hp1020-udc-program-draft-20261002/`.
`V1_DRAFT.sha256` records its manifest. This new directory retains the original
seventeen baseline snapshots and adds the pinned/effective TinyUSB core used to
review real callback dispatch. Effective snapshot source:
`/tmp/hp1020-offload-v2-20261002/effective-v2/src/device/usbd.c`.
All exact hashes are in the new `SOURCES.sha256` and `DRAFT.sha256`.
No compile, import, build, test, validator or firmware instruction was executed.

The C/H changes are limited to two missing failure barriers:

1. `callback_context()` now establishes only real current callback provenance.
   Canonical request fields and stopped/fenced state are checked afterward in
   open/close. A genuine unsupported raw request latches REQUEST with its
   original raw sequence0/control/transport ticket before returning INVALID.
   An inactive/external call still returns INVALID without such a mutation.
   This prevents a void close rejection from disappearing and ensures an actual
   false open has local failure provenance before the adapter records/fences it.
2. `submission_allowed()` now takes a mutable backend pointer. In a trusted
   actual callback, raw low-byte SC0 status is rejected before ownership if the
   request shape is unsupported or completed/selection open history remains.
   Matching uses the core's standard-device request and low configuration byte,
   not canonical fields alone. Direction is ignored when wLength0. Unsupported
   high bytes/index/length cannot bypass the skipped-close guard. The original
   REQUEST ticket is retained with no bus I/O, new owner or recovery identity.
   Service reports the new failure even if the core swallowed submission false.

There is no synthetic close callback, reset, status, ACK or automatic cleanup.
Known-clean canonical SC0 still works; typed SC0 retains its no-buffer owner and
explicit complete-selection/grant path. Existing cleanup requires the original
failure ticket, no owners and a separately supplied completed controller-clean
fact. A later new request may proceed after that cleanup; reset notification
alone is not cleanup. No new register sequence, mask, layout or grant change was
introduced.

The failed-backend SERVICE exception is unchanged. The saved adapter rejects
raw/typed admission while PENDING_BUS_RESET before advancing control_epoch.
A held newer capture can therefore coexist with reset drainage but cannot run
through it; after reset activation, failed-backend progress becomes0. The
separate lifecycle review records the exact source-derived proof and controls.

The SI wording is also narrowed: service invalidates binding readiness when the
typed SI enters service. An SI superseded before its first service did not yet
commit a programming/recovery operation. Neither schedule is represented as an
executed test in these drafts.
