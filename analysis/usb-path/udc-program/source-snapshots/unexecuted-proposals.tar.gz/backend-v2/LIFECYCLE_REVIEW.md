# Frozen backend lifecycle review — static addendum

2026-10-02. Read-only review of the unexecuted V1 package at
`/tmp/hp1020-udc-program-draft-20261002/`. Its bytes are unchanged:

- `backend.patch`: `c4556bd41c1b4d87c1f2b3cd09dcb975abc884ff4599319ab7cfe1e5ba93a3d0`.
- C: `f730acfc44a3dc83f63f0cdb8d8b36585c26c7485c005710ce4753c1c59d0e9a`.
- H: `2a3eaab8da7b7c98183a246a8e691989e7e70395641ba6c402c63763c3e1abbd`.
- Additional pinned `vendor/tinyusb-0.21.0/src/device/usbd.c` read:
  `38de54351d81878e6543f2b022d0c39f45d28c8f0888491796398dec45e727be`.

No import, compile, test, validator, firmware execution, download or device
contact occurred. Source anchors below refer to the exact frozen baseline copies
unless a pinned vendor path is explicit. These are source-derived outcomes,
not observed execution results.

## 1. Raw SC0 after software reset: a missing submission precondition

**Recommendation: reject the ordinary status submission when retained completed-
open command history remains.** V1 documents this as a limitation, but merely
documenting it is weaker than its enforced typed status-permission contract. The
status must not silently use software reset as evidence of controller cleanup.

Minimal sequence:

1. A successful raw or typed SC1 executes both real open callbacks. V1 records
   `completed_mask=3`, `selection_mask=3`, and `binding_ready=1`.
2. Admit a real bus-reset notification. Settle retained original cookies and
   service that reset. V1 C237–239 clears only `binding_ready`. Adapter
   `driver_reset`, C160–176, clears `opened` and `configuration_value`, and
   TinyUSB clears its configuration. The completed command history remains3.
3. Admit canonical raw SC0. Adapter `changes_endpoints`, C426–431, sees both the
   low configuration byte and software `configuration_value` as0, so this adds
   no endpoint-change fence (the earlier actual reset already left it fenced).
4. Pinned `usbd.c`983–1017, with the frozen protocol patch77–107 applied, skips
   close_all when cfg0 remains0, then calls `tud_control_status` anyway.
5. V1 `submission_allowed`, C227–229, tests only valid/not-busy/not-failed.
   There is no failure in this sequence, so an ordinary EP0 status owner can be
   bound and published without any new programming facts or cleanup promise.

No new bulk receive can start merely because of this response: the adapter is
still unopened/fenced. Thus this is not a demonstrated use-after-free, DMA
restart or physical hardware failure. It is nevertheless a concrete missing
precondition if this backend is to cover accepted raw SC0 as well as typed SC0.
The typed path retains a no-buffer owner, and `grant()` waits while
`completed_mask` remains set; `complete_selection()` can issue the bounded close
intent under fresh supplied facts. The ordinary raw status has no such barrier.

The existing bus-reset API accepts an original event sequence and speed only.
It reports a host bus-reset observation and establishes software cancellation/
ordering; it does not acknowledge controller-programming cleanup. Settled DMA
cookies establish those specific borrow lifetimes, not endpoint mapping,
TxFIFO, unused NE table state or the completion of controller reset. Conversely,
a future controller port may establish those facts from a documented real reset
and cache/interconnect protocol; this backend currently has no identity-bound
API recording that completed cleanup. It must not infer it from the notification.

### Narrow correction for the next revision

Keep V1 frozen. In a new revision, make the mandatory DCD submission gate detect
current **raw** SC0 while `completed_mask || selection_mask` is nonzero, before
binding any owner or publishing any packet. Repeated typed SC0 remains on its
existing no-buffer/grant path. Initially clean raw SC0, and raw SC0 following an
actually completed configuration-close command sequence, remain unaffected.

Prefer a sticky REQUEST failure carrying the exact current existing programming
ticket `{sequence=0, active_control_epoch, transport_epoch}`, then return false.
This requires making the gate explicitly mutating (or adding an equally narrow
mutating admission function); a const predicate must not hide mutation. There
is no bus I/O, new identity, synthetic close callback or fabricated owner. The
service wrapper then observes the newly latched failure and reports FAULT even
though TinyUSB may swallow the false initial status submission.

The existing cleanup path can then require the explicit completed controller-
programming-clean promise, stopped/unmounted state and no retained owners, using
that same original ticket. It clears only the recorded software barrier/history;
it issues no register write and creates no document-recovery promise. A later
new raw SC0 can be admitted normally. This is a fail-closed limitation, not an
automatic physical reset implementation or a promise of seamless recovery.

Do not key this guard solely to high-level request validity. The pinned core
narrows `wValue` to its low byte; any malformed raw aliases which it still routes
to cfg0 must not obtain the missing status through a strict-canonical-only gate.
Match its device-standard dispatch, low configuration byte0 and no-data status
path, including ignored direction at wLength0. Keep already rejected requests
and unrelated EP0 traffic out of the guard. No endpoint operation is inferred
from clearing a software mask.

Independent controls for that revision:

- SC1 → real-reset notification → original-cookie settlement/reset service →
  raw SC0: zero new register operations, no EP0 owner/packet/status ACK, exact
  raw ticket retained, completed command history unchanged, service FAULT.
- Same sequence with typed SC0: owner retained but no extra wire ZLP; grant
  waits, explicit completion emits the bounded close intent, then supplied
  defaults/current-gate facts permit the one-shot grant.
- Fresh initial raw SC0 and SC1 → ordinary successful raw SC0 close: ordinary
  status remains possible, with no invented close callback on fresh cfg0.
- Both allowed zero-length directions and ignored-field aliases reaching
  TinyUSB cfg0 obey the same history barrier; normal GET_DESCRIPTOR is unchanged.
- Exact cleanup does not emit I/O/status or satisfy a recovery promise. Old
  cleanup after a later failure is stale. Actual reset alone never clears it.

## 2. Failed-backend SERVICE exception: no raw supersession bypass

**No correction is required for this concern in the frozen sources.** The
existing adapter admission guard is essential to the proof; inspecting only the
bridge's saved epoch would miss it.

V1 C219–225 returns SERVICE for `p->failed` only when the bridge itself returns
exactly SERVICE. Bridge C252–265 returns that value only while an admitted reset
has the current control epoch but has not become active. Basic invalid/busy/
exhausted/mismatched-epoch and bridge-pending-reset states return0 first.

There are four relevant ordered states:

| State | New raw offer/dispatch | Failed-backend progress |
|---|---|---|
| Reset admission itself returned WAIT | Bridge retains RESET; later offer and dispatch wait; no control epoch replacement | 0 |
| Reset admitted, adapter has not serviced it | A later raw offer may retain one capture; dispatch calls adapter admission, which returns WAIT before changing anything | SERVICE only, to drain that actual reset |
| Reset has become active, later capture still held | Capture remains immutable and can later retry; ordinary progress is blocked by held ingress | 0 |
| Later raw capture admitted after reset is active | Its new epoch no longer equals the saved reset epoch; bridge permission can be7 | 0 because the backend is still failed |

Exact anchors: bridge `bus_reset`, C130–157, records the reset epoch only after
adapter admission succeeds; bridge `offer`/`dispatch`, C67–126, retains the newer
capture on WAIT; adapter `admit_control`, C444–465, checks
`pending_kind == PENDING_BUS_RESET` at C448 **before** advancing the control epoch
at C449 or changing pending request state. That common function handles both
ordinary raw requests and typed offload requests.

Backend SERVICE cannot convert into a general permission for raw work. Once the
reset has been delivered, bridge permission is0 for held capture or7 after its
admission; failed-backend C222 reduces both to0. The separate DCD submission
predicate is also false for every failed backend. Exact-cookie settlement and
external actual-reset admission do not clear failure; only the explicit matching
cleanup API can do that. No old failure is retagged to the later request.

Useful independent control: inject a backend failure with retained owners;
admit reset R; offer raw R+1; attempt dispatch before and after owner settlement
but before reset service. It must WAIT without changing the adapter's current
reset epoch. Service only drains old ownership and activates R; the held capture
then blocks progress. Admit R+1 after that service and confirm backend progress0,
no new open/close/submission/read/write/order, and the original failure ticket
unchanged until exact cleanup. This is a source-derived test design, unexecuted.

This proof assumes the documented serialized application uses the combined
backend gate and wrapper for all ordinary service/publication/finish operations,
and does not invoke direct adapter APIs as a bypass. It proves the specified
software barrier, not that every conceivable controller failure is recoverable.
