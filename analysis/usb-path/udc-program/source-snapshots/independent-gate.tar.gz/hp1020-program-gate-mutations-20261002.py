from pathlib import Path
import copy,hashlib,json,runpy,struct
ROOT=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
path=ROOT/'analysis/usb-path/udc-program/validation.json'; original=path.read_bytes(); report=json.loads(original)
gate=runpy.run_path('/tmp/hp1020-udc-program-consistency-gate-20261002.py')['check_program_report']
assert gate(report)[0]
sha=lambda raw:hashlib.sha256(raw).hexdigest()

def pick(r,name):
 for i,c in enumerate(r['cases']):
  if c['scenario']=='program/'+name and c['fill']==0:
   return c,r['target']['cases'][i]
 raise AssertionError(name)

def both_hash(c,n,name,raw):
 c['capture_sha256'][name]=n['capture_sha256'][name]=sha(raw)

def wrong_trace(r,kind):
 c,n=pick(r,'sc1-grant-and-page'); trace=c['expected_program_trace']
 if kind=='bank':
  t=next(t for t in trace if t[2:4]==[2,0x508]);t[3]=0x510
 elif kind=='rde':
  t=next(t for t in trace if t[2:4]==[2,0x404]);t[4]|=4
 else:
  assert trace[-1][2]==3;trace.pop()
 raw=b''.join(struct.pack('>6I',*t) for t in trace)
 both_hash(c,n,'program_trace',raw)
 # Host and target now agree on the same wrong stream; no original file changes.

def pixels(r):
 c,n=pick(r,'sc1-grant-and-page');raw=b'\x00'*32
 c['expected_pixels_sha256']=sha(raw);both_hash(c,n,'pixels',raw)

def documents(r):
 c,n=pick(r,'sc1-grant-and-page');c['expected_documents']=[[3,1,0,1,0]]
 both_hash(c,n,'documents',struct.pack('>5I',3,1,0,1,0))

def consumed(r):
 c,n=pick(r,'grant-write-uncertain')
 i=next(i for i,(e,p) in enumerate(zip(c['events'],c['program_steps'])) if e['words'][0]==124 and e['result']==4 and p[23]==1)
 c['program_steps'][i][23]=0
 c['offload_steps'][i][7]-=1;c['offload_steps'][i][15]=c['offload_steps'][i][33]=0

def identity(r):
 c,n=pick(r,'fifo-mismatch-cleanup')
 i=next(i for i,p in enumerate(c['program_steps']) if p[4])
 c['program_steps'][i][17]+=1;c['program_steps'][i][59]+=1
 c['offload_steps'][i][61]+=1;c['offload_steps'][i][70]+=1

def zlp(r):
 c,n=pick(r,'sc1-grant-and-page')
 i=next(i for i,(e,p) in enumerate(zip(c['events'],c['program_steps'])) if e['words'][0]==124 and e['result']==0)
 c['ep0_steps'][i][56+32]+=1

def tail(r):
 c,n=pick(r,'sc1-grant-and-page');raw=bytearray(27712)
 reads=b''.join(struct.pack('>3I',*t) for t in c['supplied_reads'])
 trace=b''.join(struct.pack('>6I',*t) for t in c['expected_program_trace'])
 raw[16:16+len(reads)]=reads;raw[3104+16:3104+16+len(trace)]=trace
 raw[-17]=0x5a
 both_hash(c,n,'program_storage',raw)

controls=[('wrong-CSR-bank',lambda r:wrong_trace(r,'bank'),'trace/read summaries'),
 ('replayed-RDE',lambda r:wrong_trace(r,'rde'),'trace/read summaries'),
 ('missing-final-barrier',lambda r:wrong_trace(r,'barrier'),'trace/read summaries'),
 ('agreed-wrong-pixels',pixels,'independent exact image/document oracle'),('retagged-document-generation',documents,'independent exact image/document oracle'),
 ('rolled-back-consumed-grant',consumed,'consumption'),('retagged-original-failure',identity,'original entry'),
 ('hidden-status-ZLP',zlp,'ordinary publication'),('corrupted-unused-trace-tail',tail,'program_storage')]
results=[]
for name,mutate,expected in controls:
 changed=copy.deepcopy(report);mutate(changed);passed,detail=gate(changed)
 results.append(dict(control=name,rejected=not passed,detail=detail))
 assert not passed and expected in detail,(name,expected,detail)
 print(name+': '+detail)
assert path.read_bytes()==original
Path('/tmp/hp1020-program-gate-mutations-20261002.json').write_text(json.dumps(dict(
 original_report_sha256=sha(original),original_unchanged=True,controls=results),indent=2)+'\n')
