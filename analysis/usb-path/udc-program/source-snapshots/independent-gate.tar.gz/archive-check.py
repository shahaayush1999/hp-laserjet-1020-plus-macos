from pathlib import Path
import gzip,hashlib,io,json,tarfile
ROOT=Path.cwd()
OUT=ROOT/"analysis/usb-path/udc-program/source-snapshots"
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def save(label, files, note):
    OUT.mkdir(parents=True, exist_ok=True)
    content = {name: path.read_bytes() for name, path in files.items()}
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as archive:
            for name, raw in sorted(content.items()):
                assert not Path(name).is_absolute() and '..' not in Path(name).parts
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                archive.addfile(info, io.BytesIO(raw))
    payload = buffer.getvalue()
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r:gz') as archive:
        assert set(archive.getnames()) == set(content)
        for name, raw in content.items():
            assert archive.extractfile(name).read() == raw
    (OUT/(label+'.tar.gz')).write_bytes(payload)
    metadata = dict(note, archive_sha256=sha(payload), archive_bytes=len(payload),
                    member_count=len(content), member_sha256={n:sha(raw) for n, raw in sorted(content.items())})
    (OUT/(label+'.json')).write_text(json.dumps(metadata, indent=2)+'\n')
    print(label, len(content), len(payload), sha(payload))

root=Path('/tmp/hp1020-udc-program-gate-draft-20261002')
files={'proposal/'+p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file()}
for name in ('hp1020-udc-program-gate-first-20261002.log',
             'hp1020-program-gate-mutations-20261002.py',
             'hp1020-program-gate-mutations-20261002.json',
             'hp1020-program-gate-mutations-20261002.log',
             'hp1020-program-gate-mutations-first-draft-20261002.py',
             'hp1020-program-gate-mutations-first-draft-20261002.log',
             'hp1020-program-gate-mutation-correction-20261002.md'):
    files[name]=Path('/tmp')/name
files['archive-check.py']=Path(__file__)
save('independent-gate',files,dict(status='Frozen independent gate passed28 paired captured cases unchanged; nine deliberately corrupted controls rejected after one negative-control index correction',
    gate_sha256=sha((root/'frozen-before-report/independent-gate.py').read_bytes()),
    report_sha256=sha((ROOT/'analysis/usb-path/udc-program/validation.json').read_bytes()),
    limits='Offline evidence auditing only; no new firmware execution or physical evidence. First mistaken mutation addressed an unused pointer field rather than the publication count; original attempt preserved.'))
