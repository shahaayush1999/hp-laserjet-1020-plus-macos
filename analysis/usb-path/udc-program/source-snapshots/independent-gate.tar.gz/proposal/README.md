# Independent program-report gate draft

2026-10-02. No execution, imports, builds or validator runs were performed by
this drafting agent. No captured program report or execution rows were read.
The lead owns the first execution of this checker and any later correction.

`first-unexecuted/independent-gate.py` preserves the initial implementation before
static adaptation to the lead's corrected raw-field scenario. That adaptation
uses two configured malformed low0 close failures, two fresh malformed low1
open failures, then two malformed skipped-close status failures. No case count,
ordinary four-ZLP contract or generation changed. The final pre-report draft
also binds exact raw request bytes and original ingress/failure identities.

`frozen-before-report/independent-gate.py` is the review/first-run candidate.
The convenient top-level working copy remains at
`/tmp/hp1020-udc-program-consistency-gate-20261002.py` with identical bytes.
Do not rewrite either frozen proposal after an execution finding.

Public helper:
`check_program_report(report, capture_root=None, source_root=None)` returns a
boolean and precise first-failure detail. It imports only standard-library
modules and never imports producer validators/oracles, executes firmware or
starts a subprocess. The optional CLI accepts a JSON report plus
`--capture-root` and `--source-root`.

The checker owns literal ordered read/write/barrier contracts and failed
prefixes for all14 profiles with fills0/204. It reconstructs event/attempt
ordinals, read queue/cursor and exact failure injection from input events and
checks source-visible result/owner/recovery witnesses independently. It does
not treat report program_oracles labels or expected_program_trace as authority.
The latter and supplied_reads are cross-checked only after reconstruction.

It additionally checks the known32 all-FF pixel bytes, G2/G3 notifications,
ordinary individual ZLP and18-byte reply publications, retained original typed
cookies, no grant-generated wire/ACK/recovery, genuine failure entry kinds and
cleanup identities, blocked progress and measured component sizes. Supplied
hardware facts stay explicit and reported hardware proof remains false/zero.

With capture_root, it seals raw events.bin, initial/event stdout, all target
rows (excluding only measured ABI size fields),11 paired captures, full27712-byte
recording storage including guards/unused tails, source/fixture snapshots and
captured target artifacts. Without raw files, it checks report rows and digest
bindings to its independent expected bytes, which is a narrower evidence check.

This draft is not itself validated. The lead should preserve the untouched
first attempt and diagnose any schema/oracle disagreement before changing it.
Negative controls should independently alter a command offset/order/result,
queued observation, original failure ticket, consumed-grant flag, extra ZLP,
page generation, guard/tail or target row; each should reject explicitly.
