# Integrated endpoint-program boundary — focused static review

2026-10-02. Read-only review while the lead owns the full sequential validation
run. No imports, validators, tests, builds, firmware execution, repository edits,
downloads, USB enumeration, peripheral contact or installed-printing changes.
The lead reports the first28 host/28 target profiles passed; this review does not
rerun or independently claim those execution results.

**No additional actionable lifecycle counterexample was found within the
documented serialized, nonalias, recording-I/O profile.** The production C/H
match frozen V2 semantically; their only differences from the draft are the
introductory experimental-status comments. This review checked actual integration
points rather than treating the earlier isolated C review as sufficient.

## Initialization and publication

- Backend init requires the supported adapter profile, no prior control epoch,
  submission ID or ingress sequence, and three explicit initial facts. Fixture
  init runs it after constructing the adapter, EP0/OUT components and ingress
  bridge, before accepting any event. This fresh-process fixture cannot use init
  as recovery from outstanding ownership. No register callback occurs at init.
- The program variant replaces the base normal-service entry with
  `program_fixture_service()` and the composed scheduling macro with
  `program_fixture_progress()`. Uninitialized, busy or failed state cannot
  acquire ordinary publication permission. Default variants retain their old
  macros/ABI; the new state is not silently injected into unrelated fixtures.
- Actual final `dcd_edpt_xfer` and direct `dcd_set_address` both call the mutable
  submission gate before either descriptor preparation or automatic-status
  binding (`udc-composed-test/fixture.c`487–500). This is not merely an outer
  precheck that can be bypassed by a nested real stack callback.
- Delayed manual EP0 publication op41 and bulk publication op61 require the
  combined full permission. Ordinary service, arm, pump, close/finish and
  finish-reset also pass the combined gate (`fixture.c`613–641). Automatic
  preparation/publication remains inside an already admitted serialized DCD
  callback, after the final submission gate; no hook may admit newer ingress
  or defer its write. Prepared storage is not implicitly freed by rejection.
- Exact-cookie observations/cancellation remain independently callable while
  forward work is stopped. They can settle a borrow or leave an adapter PENDING
  record; their availability does not grant a new descriptor, packet or restart.

## Reset, held ingress and callback identity

- The backend failure exception returns only the ingress bridge's SERVICE-only
  permission for an admitted but inactive real reset. The adapter's common
  `admit_control()` still refuses `PENDING_BUS_RESET` before incrementing the
  control epoch. A later raw capture may be retained, but cannot replace the
  admitted reset. After reset service, held capture blocks progress; after its
  later admission, bridge permission7 still becomes backend permission0 while
  failure is retained. No raw-service bypass was found.
- Reset clears binding readiness, not completed command history or the failure
  ticket. Typed SC0 with retained history must explicitly complete its bounded
  close intent before grant. The V2 raw-SC0 submission barrier is present and
  matches low-byte core routing, so a skipped close cannot silently create an
  ordinary status packet. Canonical clean SC0 remains supported.
- Genuine current open/close callbacks establish trusted service/control
  provenance before request-shape validation. Unsupported raw fields latch the
  existing original REQUEST ticket; out-of-context invalid calls do not invent
  failure provenance. The first nested callback witness wins over enclosing
  service and is saved before adapter fencing. These are the resolved V1 paths,
  verified here without reopening that investigation.
- SI entering service clears binding readiness and requires explicit selection
  programming before restart/grant. If a held newer capture prevents service,
  the bridge blocks it. An SI superseded before its first service has not yet
  committed that programming/recovery operation; this is distinct from an
  already serviced but unprogrammed SI. Neither schedule authorizes an old grant.

## Endpoint state, grants and failures

- Real open and configuration-close callbacks invoke the backend before
  successful fixture bookkeeping. A void close's ignored return cannot erase
  its sticky failure; the final submission gate prevents its ensuing status
  owner, and service reports the newly latched backend fault.
- Existing core bulk HALT prevents a configuration1 grant. The recording command
  sequence clearing an EPCTL S bit is not treated as clearing that core state or
  establishing DATA0/defaults. Fixture op15 remains an independently supplied
  cleanup fact; it does not clear backend failure, consume a grant or satisfy
  the other document recovery promises.
- Grant verifies the exact original sequence/cookie/control/transport, no newer
  ingress, owner cancellation/fault/granted fields, core EP0 state and current
  completed selection before any I/O. It deliberately preserves an old receive
  generation when that same held control owner outlives document recovery.
  A valid new software bulk reservation is not confused with physical RDE.
- DEVCTL read with RDE set returns WAIT before consumption. Other rejected read
  command bits/failures retain failure before any grant. With supplied stable
  state, the authoritative bridge mutation occurs immediately before one write
  and ordering hook. Post-consumption NOT_PERFORMED/UNKNOWN/write-order failure
  cannot retry; the original no-buffer owner remains retained.
- The program fixture observes `auto_granted`0→1 even when the API returns FAULT
  and preserves the original cookie/request witness. It creates neither a normal
  EP0 descriptor nor a status completion/ACK. Old direct grant, unrelated open-
  fault and adapter-only cleanup operations102/106/107 are disabled in this
  variant, so they cannot bypass the backend protocol.
- Cleanup compares the original retained failure ticket, then requires explicit
  completed controller cleanup, unmounted/stopped/fenced state and no DCD,
  PENDING, prepared, delivering or response owner. If an adapter dirty record
  exists, it must match through the public cleanup API before local state clears.
  The fixture's bookkeeping cleanup occurs only on that successful result and
  separately checks original provenance/ownership. Reset, later ingress and
  mere controller-cookie settlement cannot substitute for this cleanup.
- A backend failure after a healthy bulk reservation can leave that reservation
  owned until explicit settlement/reset. Normal service and pump are blocked;
  the allowed reset admission fences the document before pending completion
  drainage. The software barrier is not presented as a physical DMA abort.

## Remaining explicit assumptions

This is a recorded command backend, not a physical DCD. The underlying ordinary
stall/clear-stall callbacks remain synthetic state, and op15 supplies controller
cleanup; neither establishes physical HALT/default transitions. Initialization,
fixed FIFO geometry, complete unused-NE policy, HP mode capability, logical bus
word semantics, safe IN-SNAK timing, spanning DEVCTL stability, gate currentness,
cache/posted-write effects, actual event chronology and physical settlement are
still supplied. A write log is never fed back as manufactured controller state.

Direct application calls around the combined gate, reinitializing live objects,
reentrant hooks or changing component fields are outside the documented profile;
no finding here relies on those prohibited caller actions. No physical endpoint
disable, acknowledgement, USB enumeration or printing result follows from this
static review or the reported recording-bus tests.

## Exact inspected source identities

All paths below are repository-relative; the review preserved these hashes rather
than modifying any generated report or its historical source closure.

| Source | SHA256 |
|---|---|
| `open-firmware/udc-program/hp1020_udc_program.c` | `a0dbe512b4b4f7d045960800637f858165a3757f1e5c17096532616133f33cce` |
| `open-firmware/udc-program/hp1020_udc_program.h` | `e84cf4a8ff293d6dc3e36f502bf1029041367c0c697585f7d7f76cd2fd896f2b` |
| `open-firmware/udc-program-test/fixture.c` | `94ed7e6893085a253c41e08f01d397100a0f60f1eaa27cc78c1666977a677dbc` |
| `open-firmware/udc-composed-test/fixture.c` | `8c2089d9ae14e5ca364ac727f546488829d6935f1daa0027d38e6858ab2378eb` |
| `open-firmware/udc-ep0-test/fixture.c` | `efd2bf5325fca29eea41cd497d456e8d66f3065bb4f1a559cfa7ca37c09c6d6f` |
| `open-firmware/tinyusb-printer-test/fixture.c` | `e8f98e821f468e6dbb0788bdaa5dcd1b53d273be4e660728fd7c34d9ec622463` |
| `open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.c` | `a5bb1d281dd7226f9346e0dce3b13a475ac25320cf6b276f39d539d78584c3d7` |
| `open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.h` | `0f809b1ac03f5fb96d8524cab2e5cf18d5ad8d9fe6348e50ae4b2d6d2509e5bf` |
| `open-firmware/udc-setup/hp1020_udc_setup.c` | `f70322d734a8a2d26ed31befb275f61c5256e807389ca399a70707ce089508f3` |
| `open-firmware/udc-setup/hp1020_udc_setup.h` | `99de73d617d79128a2c66b56c97eaa4ab3b6ef47f55510dad5087f457f651e12` |
