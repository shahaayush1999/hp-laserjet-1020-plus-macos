from pathlib import Path
import copy,hashlib,json,runpy
ROOT=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
GATE=Path('/tmp/hp1020-raw-si-consistency-gate-20261002.py')
namespace=runpy.run_path(str(GATE),init_globals={'hashlib':hashlib})
check=namespace['raw_si_composed_consistency']
report_path=ROOT/'analysis/usb-path/udc-composed/validation.json'
original=report_path.read_bytes();baseline=json.loads(original)
assert check(baseline)==(True,'')

def selected(report,name):
    return next(c for c in report['cases'] if c['scenario']=='raw-si/'+name and c['fill']==0 and c['interface']==0)

def si_index(case):
    for i,event in enumerate(case['events']):
        if event['words'][0]==82:
            raw=b''.join(w.to_bytes(4,'big') for w in case['setup_steps'][i-1][32:36])[8:]
            if (raw[0]&0x7f)==1 and raw[1]==11:return i
    raise AssertionError('no raw SI')

def bad_pixels(report):
    c=selected(report,'live-partial');h=hashlib.sha256(bytes(32)).hexdigest()
    c['expected_pixels_sha256']=c['capture_sha256']['pixels']=h
    next(t for t in report['target']['cases'] if t['case']==c['case'])['capture_sha256']['pixels']=h

def retag_document(report):
    c=selected(report,'live-partial');c['expected_documents'][0][0]=3;c['steps'][-1][32]=3
    raw=b''.join(x.to_bytes(4,'big') for x in c['expected_documents'][0]);h=hashlib.sha256(raw).hexdigest()
    c['capture_sha256']['documents']=h
    next(t for t in report['target']['cases'] if t['case']==c['case'])['capture_sha256']['documents']=h

def lose_zlp(report):
    c=selected(report,'live-partial');index=next(i for i,o in enumerate(c['packet_oracles']) if o['expected_hex']=='')
    del c['packet_oracles'][index]

def early_ep0_release(report):
    c=selected(report,'retained-ep0');start=si_index(c)
    i=next(i for i in range(start+1,len(c['events'])) if c['events'][i]['words'][0]==1)
    c['steps'][i][28]=c['steps'][i][77]=0;c['ep0_steps'][i][56]=0

def retag_bulk(report):
    c=selected(report,'live-partial');i=si_index(c)
    c['steps'][i][30]+=100;c['bulk_steps'][i][16]+=100

def retag_reset(report):
    c=selected(report,'pending-reset');c['steps'][si_index(c)][42]+=1

def lose_promise(report):
    c=selected(report,'pending-reset');c['steps'][si_index(c)][45]=6

def wrong_interface_reply(report):
    c=selected(report,'live-partial')
    o=next(o for o in c['packet_oracles'] if o['expected_hex']=='00');o['expected_hex']='01'
    wire=b''.join(bytes.fromhex(o['expected_hex']) for o in c['packet_oracles']);h=hashlib.sha256(wire).hexdigest()
    c['capture_sha256']['wire']=h
    next(t for t in report['target']['cases'] if t['case']==c['case'])['capture_sha256']['wire']=h

matrix=[('agreed-wrong-pixels',bad_pixels,'literal pixels'),
 ('retagged-document-generation',retag_document,'literal pixels'),
 ('omitted-status-ZLP',lose_zlp,'literal complete wire bytes'),
 ('early-old-EP0-release',early_ep0_release,'protocol dispatch waits'),
 ('retagged-healthy-bulk',retag_bulk,'SI preserves bulk identity'),
 ('retagged-old-recovery',retag_reset,'exact reset ticket/promises'),
 ('lost-old-promise',lose_promise,'exact reset ticket/promises'),
 ('wrong-GET_INTERFACE-byte',wrong_interface_reply,'literal complete wire bytes')]
results=[]
for name,mutate,reason in matrix:
    changed=copy.deepcopy(baseline);mutate(changed);ok,detail=check(changed)
    assert not ok and reason in detail,(name,ok,detail)
    results.append(dict(name=name,rejected=True,required_reason=reason,detail=detail))
    print(name+': rejected for expected reason',flush=True)
assert report_path.read_bytes()==original and check(baseline)==(True,'')
out=Path('/tmp/hp1020-raw-si-gate-mutations-20261002.json')
out.write_text(json.dumps(dict(status='pass',gate_sha256=hashlib.sha256(GATE.read_bytes()).hexdigest(),
 report_sha256=hashlib.sha256(original).hexdigest(),negative_controls=results,
 limits='In-memory negative controls of independent report predicates only; original report/captures and source hashes unchanged.'),indent=2)+'\n')
