# Raw SET_INTERFACE consistency proposal — unexecuted

Owned proposal: `/tmp/hp1020-raw-si-consistency-gate-20261002.py`.
It has not been imported, compiled or executed. No repository file changed and
no validator, emulator, device or installed printing operation ran.

This is a supplemental gate for the planned 28 positive raw-SI profiles in the
existing composed experiment. It does not validate the separate four pre-policy
observations, which remain a conditional software finding with a separately
requested later SOFT_RESET. The planned composed positive matrix becomes 62.

## Minimal integration

Keep the existing composed checker in
`scripts/check-hp1020-analysis-consistency.py` intact, including its host/target
capture equality, guards, full descriptor/publication ledger, immutable SETUP
record comparison, supplied-fact refusal matrix, original references, source
and fixture closure, effective sources, target artifacts and physical exclusions.
The current relevant block starts at the `uc = read_json(...)` assignment.

1. Add the two helper definitions at module scope. They use the checker's
   existing `hashlib`; they do not import a generator or read current producer
   output to derive expected behavior.
2. Extend the existing 34-profile set, after its construction:

   ```python
   uc_profiles |= raw_si_composed_profiles()
   ```

3. Immediately after `uc_need` is defined, before the existing all-case loop:

   ```python
   uc_raw_si_ok, uc_raw_si_detail = raw_si_composed_consistency(uc)
   uc_need(uc_raw_si_ok, "raw-SI rejection contracts: " + uc_raw_si_detail)
   ```

4. Change only the existing composed total-count predicate from 34 to 62.
   Do not add a second report or a separate passing check merely for the count.
   Do not change the old scenario-specific predicates or generic packet and
   document checks. The new helper additionally pins document generation to 2
   or 3 independently instead of accepting the final row as its expected value.
5. If the case definitions are pasted into the existing composed generator,
   the current source set remains the same set of paths (117 in the draft
   baseline). Preserve the existing closure calculation and hash checks. If
   integration instead adds a source file, deliberately include that file and
   update the closure expectation; do not waive source equality.

## Independent expectations

The helper decodes admitted requests from the *retained pre-dispatch* 16-byte
record in `setup_steps`. It checks the exact literal eight-byte request sequence
for each profile, including the nonzero printer interface and all seven field
controls. `packet_oracles` labels and any scenario-return metadata are ignored.

Replies are independently specified by request: ordinary configuration and
endpoint-HALT status are zero-length IN packets; GET_INTERFACE/configuration is
one zero byte; explicitly unknown printer status is `18`; halted endpoint
GET_STATUS is `01 00`; the device descriptor is the fixture's literal 18 bytes;
the cancelled ID is its first literal 64 bytes. Every permitted IN proposal and
OUT status owner is paired with the original control epoch and exactly one
explicit completion, except the cancelled ID. Rejected SI has neither direction
of EP0 packet ownership. The older deferred class reset in `pending-reset` has
no status proposal even when its original recovery later finishes.

All 28 profiles end with exactly 32 bytes of black 32-by-8 pixels, and one literal
five-word BE notification `(generation, 1, 0, 1, 0)`. Healthy partial page cases
and the initially unconfigured case use generation 2; the fault, pending-reset
and retained-HALT cases use generation 3. No explicit input close/EOF is allowed.

Rejection windows compare bulk ownership, current and active transport identity,
receive generation/counters/storage, output activity/storage, endpoint state and
original reset ticket/promises independently of changing control identity.
The healthy second 31-byte reservation must retain its original cookie and later
complete normally; none of these cases may replace it through cancellation.
The retained ID must stay in controller ownership until an explicit failed then
successful original-cookie settlement; adapter PENDING remains visible until
the following service call actually dispatches the rejection.

The fault and HALT controls remain stopped until a separately admitted class
SOFT_RESET. Pending-reset preserves the exact older ticket and all three already
acknowledged promises, blocks finish while SI is merely held, then suppresses
the old reply while finishing that same recovery. All successful restarts are
tied to captured current tickets plus separately supplied receive, output and
transport promises. Fresh ordinary queries are checked independently and cannot
serve as a recovery shortcut.

## Limits and first-execution review

- This proposal is statically derived from the current 288-word schema and
  frozen scenario draft; there is no executed 62-case report yet. The lead must
  inspect its first execution before treating any added predicate as validated.
- Five command words are serialized in report `events[*].words`; raw
  `events.bin` also has a sixth payload-length word. This helper uses JSON and
  does not reconstruct or silently redefine the binary event framing.
- Source/input/target artifacts and host/target equality remain the existing
  composed gate's responsibility. This supplemental function does not duplicate
  that gate, decode ZjStream or emulate TinyUSB.
- The snapshot has no separate CONTROL_STAGE_ACK counter. The bounded no-ACK
  evidence is exact absence of an SI packet/owner/completion, explicit EP0 STALL,
  unchanged response-progress counters, and suppression of the old deferred
  status. It must not be described as an observed physical handshake or a trace
  of an otherwise invisible callback.
- Raw bridge *admission* intentionally precedes settlement. The ownership check
  concerns actual later TinyUSB request service/dispatch; it must not forbid
  the earlier control-identity supersession and original EP0 cancellation.
- The fixture's `stalls_cleared` input can clear its low two DCD stall-mask bits
  before dispatch even on WAIT. Only bulk mask bits enter the stable transport
  comparison. Cancellation counters are separate from normal completions.
- Zero-length direction is ignored by the USB request contract; the 0x81 SI
  control uses the same permitted sole-default rejection. Nonzero-length SI
  is conservative local rejection, not a claim of specified USB behavior.
- The `18` status remains an explicit unknown fallback. All DMA visibility,
  controller cancellation, stall clearing and reset-default facts remain
  supplied; these checks establish no physical USB, mechanical printing,
  controller quiescence or completed replacement firmware.

Useful first gate-negative controls are a changed SI reply/ZLP, an extra or
retagged healthy bulk owner, early old-EP0 release, a changed preserved recovery
ticket/part, a pending-reset ACK, a flipped fixed generation/document byte and
a changed GET_INTERFACE or HALT status byte. Keep any generator correction
separate from saved observations and never edit report hashes to fit.
