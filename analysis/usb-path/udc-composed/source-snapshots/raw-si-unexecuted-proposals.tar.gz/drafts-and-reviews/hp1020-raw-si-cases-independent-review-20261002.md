# Raw SET_INTERFACE cases: independent static review

Reviewed 2026-10-02. No imports, scenario execution, build, validator, emulator,
repository edit or hardware operation. The lead owns all sequential execution.

Reviewed scenario draft `/tmp/hp1020-raw-si-cases-20261002.py`, SHA256
`9cf3066778623d0a37c629f1a7f4e024cfb2138cc8c45940ae3b933aaf302474`.
Reviewed against raw-SI revision2 complete patch SHA256
`e577a84a26a51af6c5c23e7500dc2d1129bc6444b8b252cc68e2b84831387b73`,
whose adapter C is
`a5bb1d281dd7226f9346e0dce3b13a475ac25320cf6b276f39d539d78584c3d7`.

## Result

No blocking false expectation, circular outcome oracle or sequencing error
found. Seven positive profile names times two fills and two interface numbers
produce28 cases; the single pre-policy observation times those same axes
produces four separate conditional findings. Counts are draft scope, not passes.

- Lines92-150 isolate the old behavior meaningfully: start a partial real input
  stream and retain the original second bulk owner; raw SI advances the stop
  fence; missing settlement leaves the owner retained; explicitly supplied
  original-cookie cancellation permits genuine core fallback STATUS; after its
  supplied completion, pending-reset and ARM still return WAIT and generation
  stays unchanged. A new SOFT_RESET is then separately recorded before fresh
  exact pixels/document completion. Thus the finding is success status without
  an SI recovery, not irreversible failure or a physical ACK claim. The lead
  must run these observers against the preserved pre-policy adapter, never mix
  them into the corrected positive pass count.
- Lines44-79 snapshot independent prior transport facts and reply activity.
  The transport comparison includes original bulk cookie/descriptor/publication,
  receive state, existing reset ticket/parts, memory hashes and bulk halt/busy.
  Reply activity correctly excludes cancellation counters: fixture cancellation
  increments state.cancellations and slot.cancellations, whereas its actual
  completion path increments the compared completion counters. Therefore the
  retained-EP0 expected equality is not falsely assuming no retirement occurred.
- Lines235-261 correctly exercise all-promises reset ordering. The supplied
  three promises precede capture; the bridge blocks finish_reset while the
  newer request is held; raw SI dispatch preserves the exact old recovery and
  parts but invalidates deferred ACK permission. The same saved reset ticket
  then finishes before any unrelated new request can explain ACK suppression.
- Lines180-212 retain a partly consumed document and an already exposed bulk
  descriptor throughout SI rejection and independent GET_INTERFACE/status
  traffic. Completing that same original bulk token and remainder, followed by
  exact image/notification checks, would expose loss of input or accidental
  destructive admission; success is not inferred merely from API returns.
- Field controls cover wrong low interface (including fixture interface0 when
  printer interface is3), high-index alias, invalid alternate/high alternate,
  zero-length direction alias and conservative nonzero-length rejection. The
  latter two are accurately distinguished from mandatory USB Request Error.
  The separate unconfigured, existing fault and existing HALT profiles do not
  confuse rejection with recovery. HALT reset is explicitly supplied later by
  op15, not inferred from SI.

The inherited Host finalization checks captured wire bytes against independent
packet expectations, exact decoded pixels and ordered document records. New
no-reply assertions include submission counts and EP0 preparation/publication
counts, so an unwanted zero-byte STATUS cannot hide in a byte-only wire oracle.
The C fixture also retains independent original-buffer shadows and full guarded
allocation checks; descriptor cookies are saved from their original submissions.
No physical controller settlement, USB status ACK or printing is established.

## Nonblocking coverage limits

1. New `raw-si/retained-ep0` covers an IN DATA packet retired by explicit
   cancellation only. It does not directly cover a retained status packet or
   a genuinely settled late SUCCESS after cancellation was requested. Existing
   EP0/composed regressions cover related supersession paths, so this is a limit
   on raw-SI-specific coverage rather than a false result. If extended, compare
   no new submission/wire separately from the expected one completion-counter
   increase; do not reuse unconditional reply-activity equality for SUCCESS.
2. These new profiles do not supersede an admitted-but-unserviced destructive
   SET_CONFIGURATION with raw SI. Existing fault and active-recovery retention
   are useful different states. A narrow extra control would retain the prior
   stop/cancel request, reject SI without inventing a binding/recovery, then use
   a separately named real reset or configuration to recover. The code review's
   same-state guarantee is still source-derived until that schedule executes.
3. These snippets use the ordinary composed fixture, so they do not add a new
   raw-SI-versus-typed-offload supersession case. Keep the separate offload
   regressions when integrating; do not claim typed interaction from28 alone.

## Exact reviewed dependency hashes

Repository paths relative to `/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos`:

- `scripts/validate-hp1020-udc-composed.py`: `982f4680fe409521b982b1d25eb77daead763672a5977e19fef7f45d65dcd720`
- `scripts/validate-hp1020-udc-ep0.py`: `b6fa90e24c14c1a38d443c5bec0e48fe0e453b97c9c13fc67ec24ae8afa850bf`
- `scripts/validate-hp1020-continuous-printer.py`: `3e9a27fac60c29b423ae458a7e2116b668e03355af3ffd07021689c2e457e1ed`
- `scripts/validate-hp1020-tinyusb-printer.py`: `1b7030af58f3a855fa5f58e8996eaf354a6f0a0007db60e474c321f124e92afa`
- `open-firmware/udc-composed-test/fixture.c`: `8bc01825129e958f3f8d4c4da52384a28d60692adb77b6c14a2930225379ec18`
- `open-firmware/udc-ep0-test/fixture.c`: `efd2bf5325fca29eea41cd497d456e8d66f3065bb4f1a559cfa7ca37c09c6d6f`
- `open-firmware/tinyusb-printer-test/fixture.c`: `e6a912421957e86453a355fb3575d1c8fe812e8c3229cd4e66d9500ae293f93c`
- Frozen `/tmp/hp1020-offload-v2-20261002/effective-v2/src/device/usbd.c`: `8bf699c1522d65301a4c63e2bfa529d302d3955b8cd18dd1602d7ace441a62dc`

The scenario SHA was checked again after reading and remained unchanged.
