# Ordinary raw SET_INTERFACE: bounded source review

2026-10-02. Static inspection only during the lead's independent validation.
No project imports, builds, validators, emulation, USB or MMIO operations were
performed. No repository source was edited. This note records source-derived
behavior, not a newly executed finding.

## Finding and recommended policy

An ordinary valid raw SET_INTERFACE(interface0, alternate0, length0) currently
stops the document, then receives an ordinary TinyUSB status submission without
creating a restart ticket. Input remains fenced until a separate valid printer
SOFT_RESET or successful nonzero SET_CONFIGURATION begins recovery. It is not a
permanent inability to recover, but SI0 itself has acknowledged success without
providing the adapter's restart path.

For this sole-default raw interface, use the USB-specification-permitted STALL
policy and do not treat that rejected request as a destructive bulk change.
Still admit its original control identity, invalidate old EP0 reply permission,
and settle old EP0 ownership before dispatching the rejection. Preserve any
pre-existing document fault/recovery rather than clearing it. Typed hardware
offload SI remains separately supported with its supplied controller facts and
explicit reselection recovery. A software STALL cannot undo an already handled
controller offload event.

This is the smallest standards-compliant software policy. Host interoperability
on the physical printer remains untested. Accepting raw SI0 is possible, but
merely copying typed SI's post-status recovery is insufficient: ordinary EP0
status can already be published before affected defaults/toggles/Halt have been
reset. Acceptance needs a truthful endpoint-default operation before status, or
a separately deferred status mechanism. The current typed CSR permission gate
does not exist for an ordinary raw status packet.

## Exact inspected flow

Paths below are relative to the repository unless stated otherwise.

- `open-firmware/tinyusb-printer-test/fixture.c:269-280` constructs one printer
  alternate0 with two bulk endpoints. Preceding empty test interfaces support
  interface3 tests; they do not add printer alternate settings.
- `hp1020_tusb_adapter.c:399-428` considers standard interface request11
  destructive when the low wIndex byte matches the printer interface. Admission
  advances the control identity and calls `fence()`.
- `hp1020_tusb_adapter.c:96-108` sets fenced/input-closed, clears binding/reset
  transport linkage, faults/stops the document, advances transport identity and
  requests original-cookie bulk cancellation. Service at `:795-819` waits for
  original EP0 and destructive bulk ownership, then dispatches the actual raw
  request to TinyUSB.
- `hp1020_tusb_adapter.c:271-275` rejects all non-CLASS requests from its class
  callback. That false result does **not** mean final rejection for SI: effective
  TinyUSB `usbd.c:1188-1213` routes by the low wIndex byte, clears the callback,
  and calls `tud_control_status()` for SET_INTERFACE without validating wValue.
- `hp1020_tusb_adapter.c:833-852` establishes SI reselection only for typed
  PENDING_OFFLOAD. Raw SI never marks a binding. `begin_binding_recovery()` at
  `:216-244` returns immediately with no binding marker and explicitly recognizes
  typed SI only. `finish_reset()` at `:972-1000` requires an existing matching
  recovery; ordinary status completion cannot create one.

Consequently raw alt1 and alt0x0100 can reach the success fallback even though no
such alternate exists. A high wIndex alias such as0x0100 routes to interface0
because the core uses only its low byte; a different nonexistent low interface
fails mapping and stalls. All these conclusions are source flow, not execution.

Do not misclassify the direction-bit alias: USB2.0 section9.3.1 says direction is
ignored when wLength is zero. Thus bmRequestType0x81/SET_INTERFACE/length0 is not
by itself a malformed-direction error. The sole-default STALL option still
applies. Nonzero wLength has unspecified behavior under9.4.10; a safe rejection
is a bounded policy, not proof that the specification requires this exact path.

## Minimal implementation seam after the current checkpoint

1. Recognize ordinary standard/interface SET_INTERFACE separately from typed
   provenance before selecting destructive admission. Rejection alone must not
   cancel a healthy bulk owner, advance transport generation, erase recovery
   promises, or silently un-fence already stopped work.
2. Deliver the actual raw SETUP through TinyUSB's normal request-state path.
   Handle this standard request explicitly in the application's class callback,
   outside its CLASS-only early return: verify current control/request identity,
   stall EP0 and report the request as handled so the generic success fallback
   cannot run. Returning false alone is insufficient. A core fallback-policy
   change is an alternative, but is broader than this one-interface policy.
3. Keep typed SI outside that rejection branch. Keep original-cookie ownership,
   new-SETUP physical stall-clear requirements and normal GET_INTERFACE unchanged.
   STALL is an error response, not cancellation settlement or an ACK.

No implementation is included in this note; the lead will choose exact code and
freeze new sources after preserving the current execution checkpoint.

## Smallest useful next experiment

Use the existing composed EP0/OUT/SETUP harness; no new DCD or original-binary
execution is needed. Before fixing code, one focused host/BE-target reproduction
can retain current exact source and captures: start configured/recovered,
partially feed a document, retain a bulk OUT owner, admit raw SI0, observe the
fence/cancellation request, supply explicit original settlement, complete its
ordinary status, then observe no new recovery ticket and ARM still waiting.
Demonstrate a separate explicit recovery can restore input; do not call this a
completed SI recovery or physical lifecycle.

For the corrected policy, the most valuable paired controls are:

- Raw SI0 during partial document/live bulk: no status descriptor or ACK,
  EP0 STALL after any old EP0 owner settles, unchanged transport/recovery and
  bulk cookie/storage; complete that same bulk owner and finish exact pixels and
  END_DOC in the same generation. Repeat with a retained old EP0 DATA packet to
  prove rejection cannot pretend its cancellation is settled.
- Unsupported alt1/alt0x0100, invalid interface/high-index alias, zero-length
  direction alias, and nonzero-length controls: no generic fallback success or
  accidental bulk fence. An unconfigured request must not be accepted. Separate
  required Request Errors from conservatively rejected unspecified encodings.
- Follow rejection with a properly supplied fresh SETUP and normal
  GET_INTERFACE=0/class status to prove control recovery. Check that existing
  bulk Halt/default state was not falsely declared reset by a rejected SI.
- Already fault-fenced or pending printer recovery: rejection does not restart
  input, replace the recovery ticket, erase promises, or release an old deferred
  ACK. Superseded reply permission remains invalid.
- Keep the existing typed SI reselection/Halt/grant cases as regressions: their
  explicit recovery and conditional CSR status permission must remain distinct.

No claim is made that these proposed cases have run. All validation stays
sequential under the lead.

## Provenance and locator correction

Inspected current hashes:

- Adapter C: `0fb30500dd4580d238d2f0648b935e825a427dda7af742d7bc3ddb20bdafb0bb`.
- Adapter H: `8b15d4edb9d77a599be58e2f7d66a9c94b24b0989af4a7520175106d38f4524b`.
- Local protocol patch: `9f334e5cff0086e4d87de7cc9393cf2e204ae601112efefa9a6fd3c96293919d`.
- Effective TinyUSB source inspected at
  `/tmp/hp1020-offload-v2-20261002/effective-v2/src/device/usbd.c`:
  `8bf699c1522d65301a4c63e2bfa529d302d3955b8cd18dd1602d7ace441a62dc`.
- Pinned upstream `vendor/tinyusb-0.21.0/src/device/usbd.c`:
  `38de54351d81878e6543f2b022d0c39f45d28c8f0888491796398dec45e727be`.

Primary document: Universal Serial Bus Specification Revision2.0,27April2000,
from <https://www.usb.org/sites/default/files/usb_20_20250603.zip>, archive SHA256
`5fe9c53c04033818af396e8852b3acbca5c3a76ba92fab549fd81cd0ea7b3692`.
Cached PDF `/tmp/hp1020-usb2-spec-20261002.pdf`, SHA256
`d39698a33486c399124af92bd02e4f978fd9a836b5cf4e52e6e4633eb1d89f61`.
Section9.4.10 is printed259/PDF287 (one-based);9.2.7 is printed247/PDF275;
9.3.1 is printed248/PDF276;9.3.4 is printed249/PDF277. Text form-feed counting
and direct `pdftotext -f287 -l287` agree on SI's location.

The existing `usb2-spec-provenance.json` currently labels zero-based offsets as
one-based: its printed243/256/259 locators270/283/286 should be271/284/287.
Direct page extraction independently verified these. The lead was notified;
this reviewer left the frozen repository/provenance/report hashes untouched.

This protocol review establishes no HP controller mode, dynamic-CSR support,
physical STALL/default/toggle operation, event chronology or cancellation proof.
