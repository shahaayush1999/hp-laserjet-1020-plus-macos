# Raw SET_INTERFACE draft: independent static review

Reviewed 2026-10-02. No build, import, validator, emulator, hardware operation or
repository edit was performed. This is a bounded source review, not execution
proof. The lead owns sequential integration and validation.

## Frozen inputs

Draft directory: `/tmp/hp1020-raw-si-draft-20261002/`.

- `changes.patch`: `1dcda8d976c3fd7d71dfc76f7610eeb09348ebe2455aa50671bd4fd17536546d`
- Draft adapter C: `83d1fb06c69cc25f36a52f448a0bfbb25d975b5a30b53a55ed0cd91d8f002b5d`
- Draft adapter H: `0f809b1ac03f5fb96d8524cab2e5cf18d5ad8d9fe6348e50ae4b2d6d2509e5bf`
- Original adapter C: `0fb30500dd4580d238d2f0648b935e825a427dda7af742d7bc3ddb20bdafb0bb`
- Original adapter H: `8b15d4edb9d77a599be58e2f7d66a9c94b24b0989af4a7520175106d38f4524b`
- Unchanged local TinyUSB patch: `9f334e5cff0086e4d87de7cc9393cf2e204ae601112efefa9a6fd3c96293919d`

All five `DRAFT.sha256` entries passed SHA256 verification. The copied original
C/H and repository local protocol patch also match `SOURCES.sha256`. Effective
TinyUSB was read from the frozen offload-v2 effective source, not rebuilt.

## Result

No blocking ownership, provenance or normal-path semantics issue found in this
patch. This conclusion is limited to the documented single-context adapter and
sole-alternate printer profile. Every real SETUP and completion must use the
existing ingress/original-cookie contract. Physical STALL, controller settlement,
cache visibility and hardware offload support remain supplied facts.

1. Draft C271-303 recognizes only standard/interface request11, ignoring the
   direction bit as appropriate for a zero-length request. A raw active event
   uses the validated current request identity and explicitly stalls both EP0
   directions, returning handled=true. The pinned effective core's
   `invoke_class_control`/interface fallback (usbd.c975-979,1188-1217) therefore
   cannot submit the generic success status. No printer-class SETUP, owner,
   status packet or class recovery is created by this branch.
2. Draft C442-463 exempts only raw SI from destructive admission. A real new
   control epoch still invalidates deferred reply permission and requests EP0
   cancellation. It does not call `fence`, advance transport identity, cancel a
   healthy bulk owner, or invalidate existing reset promises. A fence already
   caused by an earlier destructive admission is retained; it is not rolled
   back when that pending request is superseded by SI.
3. Draft C810-843 waits for every old EP0 owner, including adapter PENDING
   retirement, and releases the original class response before early STALL.
   Full 16-bit wIndex comparison prevents both a wrong low interface (including
   fixture dummy interfaces) and high-byte alias from reaching another driver's
   generic success fallback. For the actual printer interface the unchanged
   request reaches genuine core dispatch and the handled STALL callback.
4. Draft C647-670,736-786 preserve original-cookie retirement. Admission changes
   control_epoch, so a later valid SUCCESS or expected cancellation for the
   superseded EP0 owner cannot invoke the old status callback or submit a
   follow-on packet. A physically settled packet is still retired through the
   existing service path; receipt of SI or STALL is never treated as settlement.
5. Raw/typed distinction is retained twice: the admission argument `offload`
   (C448) and copied nonzero `active_offload.sequence` at dispatch (C281,838).
   Typed SI still passes the standard callback as unhandled, reaches the
   existing conditional automatic-status owner and one reselection recovery
   (C869-895). A newly admitted raw SI invalidates old grant eligibility via
   control epoch/pending/cancel checks (C590-597), even before service replaces
   active_offload metadata.
6. Existing pending recovery can still finish under the same ticket/transport
   checks (C975-1032). Raw admission clears only deferred wire-reply permission;
   it does not erase reset_parts/reset_transport_epoch. A superseded SOFT_RESET
   may therefore finish its document recovery without sending its old ACK.
   Unexpected callback identity/stage/ownership takes the existing fail-closed
   fault/cancellation path and remains handled, preventing generic SI success.

The early wrong-index guard leaves TinyUSB's old control fields untouched, just
as the existing malformed control-OUT guard does. This is safe under the actual
adapter contract because old owners are settled, old control completions are
suppressed, and the next admitted ordinary SETUP resets the core's EP0/control
state. It is not permission to inject independent DCD events around the adapter.

## Execution controls worth retaining

These are recommendations, not completed cases:

- Healthy live bulk owner: raw SI0, alternate1/high alternate, wrong/high wIndex,
  both zero-length direction encodings, and conservative nonzero-length forms.
  Check STALL with no new submission/ACK/class request, unchanged original bulk
  cookie/bytes/transport/generation/cancellation count, followed by exact page
  and document completion from that same stream.
- Interface3 plus wrong dummy-interface0 and high-index0x0103: neither may route
  a fallback status, and a subsequent correct status request must still work.
- Hold an old EP0 DATA packet and, separately, a status packet: SI admission
  requests original cancellation; service waits, with no early STALL or reuse;
  exact late SUCCESS/cancellation retires it without old callback/continuation.
- Active SOFT_RESET with partial and all three promises: SI rejection preserves
  the existing recovery ticket/parts; finishing it sends no superseded reset ACK.
- Destructive configuration admission superseded before service: SI must preserve
  the existing stop/cancel effects rather than invent a binding or recovery.
- Typed SI after raw rejection must still produce only its existing automatic
  status owner/reselection, with no ordinary DMA status. Raw SI superseding a
  held typed owner must invalidate its old grant and await exact settlement.
- The subsequent fresh SETUP must clear protocol stall through the existing
  supplied stall-clear boundary and normal core reset, never via a fake status
  completion. Retain the broader adapter/composed/offload regressions identified
  in the draft INTEGRATION.md.

## Standards scope

The source-derived policy is supported by USB2.0 revision 27-Apr-2000 section
9.4.10 (printed259, PDF287 one-based): a sole-default interface may reject
SET_INTERFACE with a status STALL. Section9.3.1 (printed248, PDF276) ignores the
direction bit when wLength is zero; nonzero SI length is unspecified, so the
conservative rejection is a bounded policy rather than a claimed mandatory
response. Prior investigation/provenance is retained in
`/tmp/hp1020-raw-set-interface-review-20261002.md` and the frozen draft's review.md.
No hardware behavior or installed-driver change is established here.

## Nonblocking defensive-branch wording caveat

Draft C296-299 returns true for an unexpected CONTROL_STAGE_DATA as well as an
unexpected SETUP. The effective core usbd.c950-956 interprets true from a DATA
callback as permission to submit STATUS. The raw-SI path creates no owner and
suppresses old-cookie delivery, so this stage is not reachable through the
supported adapter flow reviewed above. It is nevertheless narrower than
INTEGRATION.md's claim that every unexpected stage cannot fall through to status
submission. Narrow that claim to the SETUP fallback, or distinguish unexpected
DATA (return false) from unexpected SETUP (handled=true). This is not execution
evidence or a finding of a supported-path regression.
