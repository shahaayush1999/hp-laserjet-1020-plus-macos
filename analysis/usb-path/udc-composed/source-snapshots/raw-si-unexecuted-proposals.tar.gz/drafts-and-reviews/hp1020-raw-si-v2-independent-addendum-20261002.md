# Raw SET_INTERFACE revision2: independent static addendum

Reviewed 2026-10-02. This supplements
`/tmp/hp1020-raw-si-independent-review-20261002.md` (SHA256
`dd024796ecfd3d481c9ab2d21b0d4cbb5f92ee9fb6651c8e9b804ccb08a739b6`).
No repository/source edit, build, import, validator, emulator or hardware
operation was performed. Only this review addendum was written.

Reviewed complete revision2 patch:
`/tmp/hp1020-raw-si-v2-20261002/changes.patch`, SHA256
`e577a84a26a51af6c5c23e7500dc2d1129bc6444b8b252cc68e2b84831387b73`.
All seven DRAFT.sha256 entries passed verification. Revision2 adapter C hashes to
`a5bb1d281dd7226f9346e0dce3b13a475ac25320cf6b276f39d539d78584c3d7`;
its header remains byte-identical to revision1. The actual C delta is limited to
the two defensive callback returns and their comment.

The caveat is resolved. At draft C284-301, both raw-SI identity-failure and
unexpected-stage/ownership branches now return true only for
CONTROL_STAGE_SETUP. That suppresses the pinned core's generic SI success
fallback (effective usbd.c1196-1217). Unexpected DATA returns false, so the
pinned core follows its STALL branch instead of STATUS submission
(effective usbd.c950-960). The ordinary matching SETUP still explicitly stalls
both directions and returns handled=true (draft C303-305). No admission,
retirement, raw/typed discrimination, bulk state, reset promise or ordinary
class handling changed.

DELTA.md and INTEGRATION.md accurately limit the ACK claim: the pinned core
invokes the DCD status-complete hook before the class ACK callback and ignores
that callback's return (effective usbd.c918-925). False cannot undo such an
already-delivered event. Correct original-cookie/control-epoch ownership,
including the absence of a raw-SI packet owner, remains the actual barrier.

No new actionable finding in this narrow v1-to-v2 review. The prior independent
execution recommendations remain applicable; no execution result is inferred.
