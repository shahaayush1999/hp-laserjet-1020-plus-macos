#!/usr/bin/env python3
"""UNEXECUTED draft: preserve the pre-fix ordinary SI software observation.

Reuses the current validated composed ELF and exact source/fixture closure.
No physical USB, peripheral access, native page lifecycle or printing.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import runpy
import shutil
import struct
import sys
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path.cwd())
    parser.add_argument('--cases', type=Path, default=Path('/tmp/hp1020-raw-si-cases-20261002.py'))
    args = parser.parse_args()
    root = args.root.resolve()
    sha = lambda raw: hashlib.sha256(raw).hexdigest()
    sys.path.insert(0, str(root/'scripts'))
    spec = importlib.util.spec_from_file_location('raw_si_composed', root/'scripts/validate-hp1020-udc-composed.py')
    comp = importlib.util.module_from_spec(spec);sys.modules[spec.name] = comp
    spec.loader.exec_module(comp)
    base,core = comp.base,comp.core
    report_path = root/'analysis/usb-path/udc-composed/validation.json'
    baseline_raw = report_path.read_bytes();baseline = json.loads(baseline_raw)
    assert baseline['status'] == baseline['target']['status'] == 'pass'
    temp = Path(tempfile.mkdtemp(prefix='hp1020-raw-si-baseline-',dir='/tmp'))
    print('Conditional raw-SI observation: '+str(temp),flush=True)
    tested = comp.sources(temp)
    assert tested == baseline['source_sha256'], 'current composed source must already be validated'
    own = {'observer.py':Path(__file__).read_bytes(),'scenario.py':args.cases.read_bytes()}
    for name,raw in own.items():(temp/name).write_bytes(raw)
    (temp/'baseline-validation.json').write_bytes(baseline_raw)
    fixture_bytes = {n:(root/n).read_bytes() for n in baseline['fixture_sha256']}
    for name,raw in fixture_bytes.items():
        assert sha(raw) == baseline['fixture_sha256'][name]
        path = temp/'tested-fixtures'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)

    def unchanged():
        assert all(sha((root/n).read_bytes()) == digest for n,digest in tested.items())
        assert all((root/n).read_bytes() == raw for n,raw in fixture_bytes.items())
        assert Path(__file__).read_bytes() == own['observer.py'] and args.cases.read_bytes() == own['scenario.py']
        assert report_path.read_bytes() == baseline_raw

    effective = runpy.run_path(str(root/'scripts/prepare-hp1020-tinyusb.py'))['prepare'](temp/'effective-source',True)
    assert effective == baseline['effective_source']
    comp.compile_host(temp,temp/'effective-source')
    document,images,used = base.image_documents(temp)
    assert {str(p.relative_to(root)) for p in used} == set(fixture_bytes)
    scenarios = runpy.run_path(str(temp/'scenario.py'),init_globals=dict(
        comp=comp,base=base,core=core,ep0=comp.ep0,struct=struct,
        OK=0,WAIT=1,STALE=2,INVALID=3,FAULT=4,ADAPTER_ERROR=5,LIMIT=6))
    matrix = scenarios['raw_si_observer_profiles']()
    assert len(matrix) == 4 and {(f,itf) for n,f,itf in matrix} == {(f,itf) for f in (0,204) for itf in (0,3)}
    cases,replays = [],[]
    for index,(name,fill,interface) in enumerate(matrix):
        directory = temp/f'case-{index:03}';directory.mkdir()
        title = f'{name}/fill={fill}/capacity=64/interface={interface}'
        (directory/'case-name').write_text(title+'\n')
        h = comp.Host(temp/'host',directory,fill,64,interface)
        try:
            finding = scenarios['raw_si_observer'](h,name,document,images)
            assert isinstance(finding,dict) and finding
            captures = h.finish()
        finally:
            h.abort()
        assert len(h.events) == len(h.rows) == len(h.ep0_rows) == len(h.out_rows) == len(h.setup_rows)
        cases.append(dict(case=title,scenario=name,fill=fill,capacity=64,interface=interface,
            status='observed_software_gap',finding=finding,initial=h.initial,
            initial_ep0=h.ep0_initial,initial_bulk=h.out_initial,initial_setup=h.setup_initial,
            steps=h.rows,ep0_steps=h.ep0_rows,bulk_steps=h.out_rows,setup_steps=h.setup_rows,
            events=h.events,packet_oracles=h.packets,descriptor_oracles=h.descriptor_oracles,
            bulk_descriptor_oracles=h.bulk_oracles,setup_oracles=h.ingress_oracles,
            expected_documents=h.expected_documents,expected_pixels_sha256=sha(h.expected_pixels),
            capture_sha256={n:sha(raw) for n,raw in captures.items()}))
        replays.append((h,captures,directory))
        print(f'Raw SI baseline: {len(cases)}/4 host observations captured',flush=True)
    unchanged()

    built = root/'analysis/usb-path/udc-composed/target'
    target_dir = temp/'target';target_dir.mkdir()
    for name,digest in baseline['target']['captured_artifact_sha256'].items():
        if name == 'annotated-disassembly.txt':continue
        raw = (built/name).read_bytes();assert sha(raw) == digest
        (target_dir/name).write_bytes(raw)
    elf = target_dir/'target-check.elf'
    assert sha(elf.read_bytes()) == baseline['target']['elf_sha256']
    program,audit = core.audit_target(elf)
    artifacts = {p.name:sha(p.read_bytes()) for p in target_dir.iterdir() if p.is_file()}
    from hp1020_qemu_ram import QemuRAM

    def rows(q):
        result=[]
        for symbol,length in (('hp1020_bulk_fixture_stats',96),('hp1020_ep0_fixture_stats',104),
                              ('hp1020_composed_out_stats',48),('hp1020_composed_setup_stats',40)):
            result.append(list(struct.unpack('>'+str(length)+'I',q.read(program.symbols[symbol],length*4))))
        return result

    assert len(cases) == len(replays) == 4
    native=[]
    with QemuRAM() as q:
        version=q.version
        for case,(h,captures,directory) in zip(cases,replays):
            q.load(elf)
            assert q.call0(program.symbols['hp1020_bulk_fixture_reset'],[case['fill'],64,case['interface'],0xffffffff])==0
            row,e,b,s=rows(q)
            assert row[:59]+row[60:]==h.initial[:59]+h.initial[60:]
            assert (e,b,s)==(h.ep0_initial,h.out_initial,h.setup_initial)
            for index,(event,r0,e0,b0,s0) in enumerate(zip(h.events,h.rows,h.ep0_rows,h.out_rows,h.setup_rows)):
                data=bytes.fromhex(event['data_hex'])
                if data:q.put(program.symbols['hp1020_bulk_fixture_input'],data)
                result=q.call0(program.symbols['hp1020_bulk_fixture_step'],event['words'])
                row,e,b,s=rows(q)
                with (directory/'target-steps.jsonl').open('a') as output:output.write(json.dumps(row+e+b+s)+'\n')
                assert result==row[0]==event['result'] and row[:59]+row[60:]==r0[:59]+r0[60:]
                assert (e,b,s)==(e0,b0,s0),(case['case'],index)
            observed={}
            for name,symbol in (('pixels','hp1020_bulk_fixture_pixels'),('wire','hp1020_bulk_fixture_wire'),
                                ('documents','hp1020_bulk_fixture_documents')):
                observed[name]=q.read(program.symbols[symbol],len(captures[name]))
            for name,symbol in (('receive','hp1020_bulk_fixture_receive_storage'),
                    ('output','hp1020_bulk_fixture_output_storage'),('ep0','hp1020_ep0_fixture_storage'),
                    ('bulk_descriptor','hp1020_composed_fixture_out_storage'),
                    ('setup_record','hp1020_composed_fixture_setup_storage')):
                observed[name]=q.read(q.call0(program.symbols[symbol],[]),len(captures[name]))
            for name,raw in observed.items():
                (directory/('target-'+name)).write_bytes(raw)
                assert raw==captures[name],(case['case'],name)
            native.append(dict(case=case['case'],status='observed_software_gap',
                all_steps_and_captures_equal=True,adapter_state_and_memory_bytes=row[59],
                capture_sha256={n:sha(raw) for n,raw in observed.items()}))
            print(f'Raw SI baseline: {len(native)}/4 target observations captured',flush=True)
    unchanged()
    assert all(sha((target_dir/n).read_bytes())==digest for n,digest in artifacts.items())
    report=dict(status='observed_software_gap',source_sha256=tested,
        observer_sha256={n:sha(raw) for n,raw in own.items()},
        fixture_sha256=baseline['fixture_sha256'],baseline_report_sha256=sha(baseline_raw),
        effective_source=effective,cases=cases,target=dict(cases=native,qemu_version=version,
            reused_validated_elf_sha256=sha(elf.read_bytes()),audit=audit,captured_artifact_sha256=artifacts),
        completed_native_page_lifecycles=0,usb_transfers=0,actual_peripheral_accesses=0,
        scope='Conditional ordinary raw SI software finding with explicit old-owner settlement and a separately requested later class recovery.',
        limits='No claim of successful SI recovery, physical DCD, host interoperability, MMIO, USB traffic, printing or power-cycle recovery.')
    (temp/'observation.json').write_text(json.dumps(report,sort_keys=True,separators=(',',':'))+'\n')
    print('Preserved conditional observation; no shared report or target modified.',flush=True)


if __name__=='__main__':main()
