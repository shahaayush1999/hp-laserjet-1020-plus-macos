# Raw SET_INTERFACE rejection — unexecuted code-only draft

Only the copied adapter C/H files change. `changes.patch` applies against the
current repository bytes recorded in `SOURCES.sha256`; it is not a patch against
the earlier offload draft. The lead owns integration after the current full
checkpoint. No repository source, tests, generators, reports or patch manifest
was edited. No imports, builds, validators, emulator or hardware operation ran.
The source review is copied unchanged to `review.md`.

The bounded sole-alternate raw printer profile uses USB2.0 section9.4.10's
permitted STALL policy. The predicate recognizes standard/interface request11
without treating zero-length direction as an error. Unsupported alternates and
nonzero-length forms are conservatively rejected as well, without claiming that
the latter has specified USB behavior.

Admission still allocates the actual new control identity, suppresses old EP0
reply permission and requests original-cookie EP0 cancellation. Raw SI alone
does not call the destructive bulk fence, advance transport identity, cancel a
healthy bulk owner, create a recovery or erase existing promises. A superseded
destructive admission keeps its existing stop fence and outstanding cancellation
requests; rejecting a later SI is not permission to undo those effects. The
normal pending-request replacement/service rules remain in place.

For the actual printer interface, normal service waits for original EP0 owners,
releases any already-settled response and passes the unchanged raw request into
TinyUSB. The class callback validates its current identity, explicitly stalls
both EP0 directions and reports the request handled. Returning false would have
invited the pinned core's generic success fallback. No class request, status
packet, ACK, new pointer or owner retirement is manufactured. Unexpected callback
identity/stage/ownership uses the existing contract-fault/cancellation mechanism.
Its SETUP return is handled=true to suppress generic fallback, while DATA returns
false so the core cannot authorize a following status submission. ACK and unknown
stages also return false. The pinned core ignores the ACK callback's return and
has already invoked its DCD status hook before that callback; the return cannot
undo such an event. The supported raw-SI path creates no packet owner and
suppresses superseded-owner delivery, so it supplies no DATA or ACK completion.

A narrow service guard rejects a wrong full wIndex before core dispatch, after
the same EP0-settlement checks. This prevents low-byte routing to another
interface's fallback, including the empty interfaces used by the nonzero-interface
fixture. High-index aliases are not silently accepted. The pre-existing malformed
OUT-data guard also remains unchanged. Later fresh SETUP processing retains its
normal stall-clear fact and control-state reset. GET_INTERFACE is unchanged.

Typed SI never enters this rejection branch. It retains destructive admission,
its explicit reselection/recovery and current-only conditional hardware status
grant. The local TinyUSB protocol patch is unchanged.

## Existing validation impact

Static searches found no existing ordinary raw SET_INTERFACE invocation in the
reusable adapter, composed, EP0/OUT, packet-fault or continuous validators. The
new behavior is therefore a coverage gap, not an already-validated fix. This task
does not add or draft tests. No existing expectation is intentionally revised.

Existing paths sharing the edited admission/callback/service boundaries need
their normal sequential regression after integration, particularly:

- Adapter `status-and-id-during-owned-out`, `reset-retains-bulk-and-ep0`,
  `superseded-deconfiguration-keeps-fence`, `automatic/superseded-deconfiguration`,
  `malformed-control-out/interface` (GET_INTERFACE request10, not SI), and
  `malformed-out-waits-for-old-ep0`.
- Composed `protocol`, `held-capture-blocks-reset-ack`, `superseded-control` and
  `soft-reset-held`; packet-fault `pending-recovery` and `superseded-setup`.
- Offload `interface-reselection`, `interface-halt-reselection`,
  `new-raw-held-blocks-grant` and `held-offload-blocks-deferred-reset` must retain
  their existing typed semantics.

All validators that capture the adapter source will require fresh source
closures/reports after the lead's execution. Counts and finding sets are not
changed by this draft. The generic TinyUSB-device fixture does not use this
adapter and its protocol expectations are unchanged. No USB/controller, toggle,
physical STALL, cancellation settlement or printing result is established.
