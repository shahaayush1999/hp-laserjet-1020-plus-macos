# Revision2 defensive callback result

The first draft remains unchanged at `/tmp/hp1020-raw-si-draft-20261002/`;
its full patch SHA256 is
`1dcda8d976c3fd7d71dfc76f7610eeb09348ebe2455aa50671bd4fd17536546d`.
This revision is a complete patch against the same preserved repository baseline,
not a delta to apply on top of revision1. No repository edits, tests, builds,
imports or execution occurred.

Only two defensive raw-SI callback returns change: return handled=true for
CONTROL_STAGE_SETUP, false for DATA/ACK/unknown stages. Normal matching SETUP
still explicitly stalls both EP0 directions and returns true. Existing ownership
retention, contract fault, cancellation request and raw/typed policy are unchanged.

The exact effective TinyUSB callback behavior was read from
`/tmp/hp1020-offload-v2-20261002/effective-v2/src/device/usbd.c`:

- Interface SETUP uses a false class result to enter its generic SET_INTERFACE
  success fallback. Returning true prevents that fallback, including a defensive
  identity/ownership failure where no status may be submitted.
- DATA uses the callback boolean to choose a new status submission versus STALL.
  Returning false prevents the unintended permission that revision1's defensive
  unconditional true would have granted. The normal raw-SI path has no DATA owner.
- ACK has already invoked the optional DCD status-complete hook before calling
  the class callback; the callback return is ignored. False does not undo an ACK
  or previously executed hook. The supported adapter ownership/epoch gate, not
  this return value, excludes unsolicited and superseded ACK delivery.
- No unknown stage is emitted by the inspected core call sites. It returns false
  here and triggers the same contract fault/cancellation path, with no claimed
  rollback of an external caller's behavior.

`INTEGRATION.md` now states those limits explicitly. No test or ABI change is
included; the lead owns later independent validation and all source captures.
