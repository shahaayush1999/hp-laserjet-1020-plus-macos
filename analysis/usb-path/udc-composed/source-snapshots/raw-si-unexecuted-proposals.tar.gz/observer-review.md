# Static observer review

The reviewer found no wrong target reuse or shared-output writes. Before first
execution, root preserved observer V1 and changed the current draft to execute
the saved scenario snapshot and assert equal lengths for all event/row arrays
before zip. The observer, scenarios and V1/V2 C proposals in this archive are
unexecuted; no behavioral finding is claimed. The future observer must use a
completed, current full composed baseline, then capture host/QEMU agreement in a
separate conditional report. The later SOFT_RESET is a separate recovery action.
