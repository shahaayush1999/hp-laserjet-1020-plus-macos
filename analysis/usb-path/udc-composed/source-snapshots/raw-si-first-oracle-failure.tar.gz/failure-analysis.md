# First raw-SI corrected matrix attempt

The run completed46 host cases and stopped in case046 raw-si/existing-fault,
fill0/interface0, event57. No QEMU replay or shared report regeneration occurred.
The scenario expected service WAIT for a separately requested class SOFT_RESET.
The actual result OK begins a new class recovery while preserving the original
bulk owner, stop/cancel fence and deferred status. This matches the existing
adapter: pending_destructive is set only by changes_endpoints; a valid class
reset fences input but can establish recovery before bulk settlement. Its final
status/restart still requires original owner settlement and three promises.
Correct only that scenario assumption, add pre-settlement finish WAIT and exact
owner/deferred assertions, then rerun. The reviewed V2 production code is unchanged.
