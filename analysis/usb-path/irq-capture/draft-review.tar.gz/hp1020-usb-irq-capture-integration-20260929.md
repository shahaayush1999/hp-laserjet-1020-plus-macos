# USB IRQ capture draft: integration note

Status: **unexecuted and unimported**. No repository edits, builds, validators,
QEMU, stock execution or hardware access were performed while drafting.

Draft `/tmp/hp1020-usb-irq-capture-draft-20260929.py` is intended for
`scripts/validate-hp1020-usb-irq-capture.py`, producing
`analysis/usb-path/irq-capture.json/.md`. It uses only existing guarded
interpreter/QEMU support. It has no target compilation or new runtime component.
The parent owns review, execution sequencing, reports, consistency gates and
integration. Do not execute while the full126 source closure is frozen.

## Independent phases

1. `samples`: original ENTRY at `0x10008208` runs from explicitly seeded SP,
   CPU window and registers. DEVINT/EPINT are sampled in order; all saved EPINT
   bits are written at original incoming SP-48. No reset bit stops before
   `0x1000833c`. Reset plus supplied wrapper bit0x10 clear stops before the
   configuration call at `0x10008240`, after the literal8 device-word write.
   The timer branch is excluded. This is not actual interrupt entry/return.
2. `lanes`: independent entry at `0x1000837e`, no ENTRY. `[SP]` is a separately
   supplied saved EPINT, while the live EPINT RAM image has a different value.
   IN0/OUT0/OUT1 only, stop before the first helper/event/IRQ-clear call. It does
   not claim that the prefix returned or that its frame reaches this cut.
3. `out0_common_wake`: independent entry at `0x100084c8` with
   `a2=1,a3=1,a4=16,a5=0`; stop before `0x100086c0`. One event-object literal read,
   no record read or write. The preceding OUT helper is omitted, not simulated.

The proposed matrix has44 conditional phase profiles (8 samples,34 lanes,
2 common-wake),14 removed-redirect guards and24 standalone MMIO-instruction
guards:82 paired cases if execution succeeds. Seventy-five separate excluded-PC
checks are expected (25 for each phase), without executing those instructions.
These are planned counts, not measured results.

## Independent expectations

All mutable RAM includes the original writable regions, private control images,
two guarded record canaries, stack, and the phase's redirected literal words.
The oracle specifies exact ordered reads/writes and all16 logical registers plus
SAR, including partial legitimate effects before MMIO rejection. It does not
consume decoded instruction operands, engine output or observed transfer state.

A separate literal profile table checks lane selection and first-call stops.
It includes masked OUT0 serviced because higher OUT1 is enabled (with and without
TDC), the converse skipped OUT1 above the last enabled OUT0, IN0 then OUT0 when
IN0 has no TDC, and co-pending IN0 stopping before OUT0 when IN0 has TDC. The
all-status-bits case independently requires ordered writes
`200,80,40,30,400` and final plain RAM status `00000400`.

Each of the12 actually selected peripheral access PCs has a standalone
pre-access rejection case under both fills. Seven literal redirects are each
removed under both fills. Calls at `100083d4/10008428/10008470/100084b4/
100084c5/100086ad/100086c0/100086ed`, configuration/timer callees, SETUP admission
and retirement all remain outside every execution range. No supplied service
or function stub exists. No selected cut may read the SETUP record-pointer global,
the private/raw original SETUP record, or the bulk record/global.

Full stock ELF SHA pins the byte authority. Each complete selected instruction
range is audited against original bytes, captured with a digest before execution
and checked unchanged afterward. Exact source closure is copied before either
engine starts; original byte audit, supplied inputs, before/expected/after memory,
complete accesses and failed captures are retained. Linux references remain at
the existing pinned commit/hashes; no newly fetched manual is a runtime input.

The independent static review is
`/tmp/hp1020-irq-capture-independent-review-20260929.md`; its author inspected the
stock bytes before reading this oracle. Its reset/frame/mask/status invariants
were checked against the draft by reading only. In particular, incoming wrapper
bit0x10 clear is a condition, not a fabricated result of a helper.

## Review before first execution

The original ENTRY phase deliberately uses fresh PS.WOE=1, CALLINC=0,
WB0/WS1 directly, without an artificial CALL8 caller; the expected logical
effect is SP-48, with no window rotation. PS.WOE=1 follows the existing windowed
QEMU scaffolding's ENTRY prerequisite; later cuts and standalone access guards
use PS0 and no ENTRY. Root should inspect this initial-state choice when
reviewing the QEMU setup. The unused IN1 flag prelude is excluded starting at
`0x1000841a`, before its RAM flag load; no IN1 instructions are needed.
The input capture explicitly records PS/WB/WS/SAR. The QEMU outcome additionally
requires unchanged supplied PS, WB0, WS1, zero loop registers and the independently
predicted SAR. Native special-register captures remain separate from the abstract
interpreter, which is not credited with modeling physical window registers.

No syntax check, imports, dry run, checker or execution has occurred. Fixes after
first execution must preserve failed captures and source snapshots rather than
relabeling them. Only a successful later run can establish the draft's measured
counts or claim agreement between engines.

## Meaning and remaining boundary

At most this establishes software sample order, literal acknowledgement intent,
pre-call lane/event proposals, and absence of record acquisition/return in three
separate cuts. A RAM image is not W1C hardware. Co-pending bits have neither
physical chronology nor a packet's reset generation. Suffix-mask behavior is a
conditional software predicate, not proof of a reachable lost interrupt.

The future controller ingress barrier still needs coherent immutable SETUP
acquisition and a justified relationship to reset. Descriptor DONE/HOST_BUSY is
not treated as overwrite exclusion. A conservative port may fence/discard an
ambiguous reset-overlap observation rather than reproduce stock scan order.
No physical transfer, controller settlement, hardware rearm, printing or native
page lifecycle is added by these experiments.
