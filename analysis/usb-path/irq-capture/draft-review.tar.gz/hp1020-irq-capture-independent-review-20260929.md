# Original USB IRQ capture: independent static review

2026-09-29. Read-only review; no experiment, validator, import of experiment code,
QEMU, USB access or repository change. The drafting agent's oracle was not read.

**Material finding:** the endpoint scan does not apply the current endpoint's
mask bit to its pending bit. It continues while *any remaining higher-or-current
endpoint is enabled*, then tests only the current pending bit. Consequently a
masked OUT0 can be selected while OUT1 is enabled. This is original software
behavior to record, not a requirement for the replacement DCD.

## Byte authority

Original `analysis/sihp1020.elf` SHA256:
`2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`.
Direct disassembly used the pinned local Xtensa objdump; bytes also read directly
from the ELF `.text` mapping (VMA `0x10005c80`, file offset `0x31e0`).

The following are **static audit ranges**, including some boundary/helper code
that must not execute. They are not a proposed execution allowlist.

| Range, end exclusive | Bytes | SHA256 |
|---|---:|---|
| `0x10008208..0x10008240` | 56 | `59b74f05f1cc9cf8b955897419da788fdcf79c796a8e4b1ed2965e52d1ab1894` |
| `0x1000837e..0x100084c8` | 330 | `1d47d19c53d6609ddc743b551981583a5aadfdb395a37f4d49e42a7eb13ff0e5` |
| `0x100084c8..0x100084ce` | 6 | `2c04324fcfd412844d1900c7c084cffc753fb0e6c6b6f02e1abd345fb280a0da` |
| `0x100086b0..0x100086f0` | 64 | `e4c3c4ae64a42158e2ade360261c76a30df51947ae712dbcf39fcc6952c29316` |
| Literal block `0x10005de4..0x10005e20` | 60 | `6866992cece33a3d6e2cd7d56e716e58875f2d40438d3efac4d2d125e381e707` |

Original literals relevant to these cuts:

| Literal address | Original value | Role used in this review |
|---|---|---|
| `0x10005de4` | `0xb300040c` | DEVINT word |
| `0x10005de8` | `0xb3000414` | EPINT word |
| `0x10005dec` | `0xb3010004` | wrapper word, unknown physical semantics |
| `0x10005e00` | `0xb3000418` | EPINT mask word |
| `0x10005e04` | `0xb3000004` | IN0 endpoint-status base |
| `0x10005e08` | `0xb3000204` | OUT0 endpoint-status base; OUT1 is +32 |
| `0x10005e18` | `0x10021318` | event object address, not dereferenced here |
| `0x10005e1c` | `0x100212d4` | RAM cell whose value is supplied to the OUT helper |

Named peripheral-word reads/writes below are allowed only through explicit
private ordinary-RAM redirects. A RAM write is not a hardware acknowledgement.

## 1. Prefix at `0x10008208`

Let original incoming SP be `S`, supplied DEVINT be `D`, supplied EPINT be `P`,
and supplied wrapper word be `W`. ENTRY adjusts SP to `S-48`. In addition to the
literal reads, the exact nonliteral access order is:

1. `0x10008214`: read DEVINT once into `a5`.
2. `0x10008219`: read EPINT once into `a8`.
3. `0x1000821d`: store **all of P** at `[S-48]`.
4. Only if `D & 8`: `0x1000822b` writes literal **8**, not D and not `D & ~8`,
   to the DEVINT image; then `0x10008230` reads W once.

The literal access order is `5de4`, `5de8`, then (only on reset-bit presence)
`5dec`. The final conditional uses **mask `0x10`**, not bit index 10.

- If `D & 8 == 0`, the jump at `0x10008222` stops before `0x1000833c`. No wrapper
  read or device-word write occurs. Final `a5=D`, `a8=P`, `a9=8`, `a10=DEVINT-image`;
  `a7` is unchanged. The saved EPINT word and SP adjustment are the only RAM/SP effects.
- If `D & 8` and `W & 0x10 == 0`, stop before call `0x10008240` (`5823cd`) to
  `0x10011178`. Final `a5=D`, `a7=0`, `a8=16`, `a9=W`, `a10=21`.
  Do not claim what the omitted call does, returns or settles.
- `W & 0x10 != 0` branches at `0x10008238` to `0x10008264`; that is a distinct
  excluded continuation, not a permissible rewrite into the clear-wrapper path.

The prefix saves endpoint pending bits **before** the reset-related helper
boundary, but neither acknowledges EPINT nor reads its mask. This establishes
software snapshot order, not chronology or atomicity of physical arrivals.

## 2. Endpoint scan at `0x1000837e`

This separate cut receives an already-owned frame with `[SP]=P`; it does not
execute ENTRY or prove that a real reset prefix returned to this scan. Let mask
word be M and `E=(~M)&0xffffffff`.

The exact common nonliteral accesses are:

1. `0x1000838d`: read M once.
2. `0x1000838f`: read saved P from `[SP]`.
3. `0x10008396`: store E at `[SP+4]`.
4. `0x1000839b`: write **all saved P** to EPINT image, before any endpoint status.

There is no live EPINT read in this cut. Varying the initial EPINT-image value
independently of saved P should leave selection unchanged; the RAM image's final
value is P, not a simulated W1C result. Do not normalize masked bits away.

Each direction initializes scratch words in this order: read `[SP+4]` at `839d`,
read `[SP]` at `83aa`, write `(E >> shift)&0xffff` to `[SP+8]` at `83ac`, write
`(P >> shift)&0xffff` to `[SP+12]` at `83b7`. IN uses shift 0 (`a3=0,a4=0`),
then OUT uses shift 16 (`a3=1,a4=16`); `a5=0` at each direction's start.

At each endpoint index:

- `0x100083b9` reads remaining enabled bits; `0x100083bb` (`64e31c`) skips the
  direction if that whole word is zero.
- Otherwise `0x100083be` reads remaining pending bits; `0x100083c1` (`7fef02`)
  tests the **low numerical bit**. Xtensa BE `bbsi ... ,31` uses MSB-indexed bit
  numbering; it is not a test of numerical bit 31.
- There is no `pending & enabled` operation. If pending bit 0 is set, endpoint
  status is read even when enabled bit 0 is clear, provided some higher enabled
  bit kept the loop alive.
- For an endpoint that proceeds to the next index: `86c3` reads `[SP+8]`, `86ca`
  writes it right-shifted by one, `86cc` reads `[SP+12]`, and `86d3` writes that
  right-shifted by one; index increments once. Other frame bytes must remain
  unchanged. `[SP]` and `[SP+4]` remain the original complete P and E.

### Endpoint status and first-call boundaries

`0x100083eb` reads one endpoint-status snapshot T from
`IN0-status + 32*index` or `OUT0-status + 32*index`. All following write decisions
use saved `a6=T`, even when earlier plain RAM writes have replaced the image.
The optional writes occur in exactly this order:

| Predicate on T | Write PC | Value |
|---|---|---|
| `T & 0x200` | `0x100083f6` | `0x200` |
| `T & 0x80` | `0x10008401` | `0x80` |
| `T & 0x40` | `0x1000840c` | `0x40` |
| `T & 0x30` | `0x10008443` | `T & 0x30` |
| `T & 0x400` | `0x1000844f` | `0x400` |

Thus `T=0x6f0` yields `[0x200,0x80,0x40,0x30,0x400]`, and the final RAM image
is `0x400`. It is incorrect to clear bits in T after each write or combine them.

For the permitted IN0/OUT0/OUT1 profiles:

- With `T & 0x400`, stop before `0x100084b4` (`583e3d`) calling `0x10017dac`.
  `a10=0x10021318`, `a11=1 << (direction_shift+index)`, `a12=0`;
  `a7` also holds that event mask, **not** the status address anymore.
  No OUT helper or later endpoint executes before this boundary.
- Without `0x400`, IN0 goes to loop advance. Status `0x40` alone is acknowledged
  but does not take the special IN1 list-handling path.
- Without `0x400`, either OUT0 or OUT1 reaches `0x100084c5` (`5bfde5`) calling
  `0x10007c5c`, even when T is zero or contains only error/OUT-type flags.
  Its `a10` is the **value read from cell `0x100212d4` at `0x100084c0`**, not the
  cell address or event object. Stop before the helper executes.
- A scan with no endpoint that triggers either omitted call reaches stop-before
  `0x100086ed` (`583abc`), the separate call with `a10=4` to `0x100171e0`.
  This includes an empty selection and an IN0-only selection without TDC.
  That call/IRQ-return behavior is excluded.

The special IN1-only helpers at `0x10008428`, `0x10008470` and `0x100083d4`
are outside the three permitted endpoint profiles and should remain guarded.

### Small decisive selection controls

All mask bits not shown enabled below are disabled. These literal words avoid
turning the expected selection into a copy of the scan algorithm.

| Saved P | M | Expected selection before any omitted call |
|---|---|---|
| `0x00010000` | `0xfffdffff` | **OUT0**, although masked; OUT1 is the enabled higher bit |
| `0x00020000` | `0xfffeffff` | None; OUT1 is beyond the last enabled OUT0 bit |
| `0x00010000` | `0xffffffff` | None, but common EPINT-image write still equals P |
| `0x00010000` | `0xfffffffe` | None; only IN0 enabled, OUT half skipped |
| `0x00020000` | `0xfffdffff` | OUT1; no-TDC helper boundary has `a5=1` |
| `0x00010001` | `0xfffefffe` | IN0 first; with TDC it stops before reading OUT0 |

For the last row, give IN0 no TDC and OUT0 a different asymmetric status: IN0's
permitted writes must precede OUT0's read and helper/event boundary. For the first
row, exercise both TDC and no-TDC so the unexpected mask selection cannot be
hidden by only checking the final endpoint. Vary live EPINT image independently
of P and use two asymmetric RAM fills.

## 3. Supplied post-helper OUT0 continuation

At `0x100084c8`, supply exactly `a2=1,a3=1,a4=16,a5=0`. The failed `a5==1` test
(`685102`) takes the jump at `0x100084cb` (`6001e1`) directly to `0x100086b0`.
Stop before `0x100086c0` (`583dba`) calling `0x10017dac`.

The only memory access is `l32r` at `0x100086b0` reading literal `0x10005e18`
as `0x10021318`. No RAM writes, endpoint-status read, descriptor access, bulk
flag, physical command or helper result is involved. Final `a10=0x10021318`,
`a11=0x10000`, `a12=0`; other logical registers stay supplied and SAR becomes16.
This is a conditional wake-intent continuation with no TDC predicate in the cut,
not a completed OUT0 transfer or proof that the omitted helper returned.

## Inference boundaries and recommendation

- Preserve three distinct experiments. The reset prefix stops before a helper;
  the endpoint scan starts from supplied stack state; the last cut supplies a
  post-helper continuation. They cannot be stitched into an observed reset,
  cancellation, capture or endpoint lifecycle.
- A pending bitset carries neither occurrence counts nor physical order. A saved
  reset bit plus endpoint bits does not reveal which arrived first, whether a
  SETUP record was overwritten, or which generation a packet belongs to.
- A write of saved EPINT or endpoint-status masks demonstrates command intent
  only. Ordinary RAM does not establish W1C behavior, concurrent-arrival survival,
  interrupt reassertion, rearm, DMA visibility, stall clearing or quiescence.
- Keep reset ingress order/immutable SETUP ownership externally supplied in the
  reusable adapter until a real capture/acknowledgement contract is established.
  Do not assign fresh transfer generations or reset sequence identities using
  original scan order. Do not interpret an event mask as successful completion.
- The pinned Linux v6.12 reference is a useful counterexample to mandatory stock
  scheduling: `udc_irq` handles endpoint bits before device bits, whereas the
  original prefix checks the reset-related bit before its endpoint scan. Its
  order is not proof that either order is safe for this board's concurrent events.

Primary comparison: Linux commit `adc218676eef25575469234709c2d87185ca223a`,
[IRQ selection](https://github.com/torvalds/linux/blob/adc218676eef25575469234709c2d87185ca223a/drivers/usb/gadget/udc/snps_udc_core.c#L2968-L3021),
[bit definitions](https://github.com/torvalds/linux/blob/adc218676eef25575469234709c2d87185ca223a/drivers/usb/gadget/udc/amd5536udc.h#L158-L201).
Local reference hashes remain `c1b09e8f69d3340f2afd3a033d77a42775b52716d45b1aceb211dcaab89127bf`
for `snps_udc_core.c` and `8dbf2ebffe7de042bdfea1c5e4e0d7e7ca334cb821fbfaa1cf9ccfeeae302648`
for `amd5536udc.h`. No physical interrupt or USB transfer is proven.
