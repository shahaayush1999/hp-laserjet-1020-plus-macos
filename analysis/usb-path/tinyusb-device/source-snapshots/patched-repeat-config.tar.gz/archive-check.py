from pathlib import Path
import gzip,hashlib,io,json,tarfile

ROOT=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
profiles=[
    ('upstream-repeat-config',Path('/tmp/hp1020-tinyusb-wmn1ckvh'),'upstream-baseline.json','tinyusb-device','/tmp/hp1020-protocol-repeat-upstream-20261002.log'),
    ('patched-repeat-config',Path('/tmp/hp1020-tinyusb-qx0t8lss'),'patched-validation.json','tinyusb-device','/tmp/hp1020-protocol-repeat-patched-20261002.log'),
    ('adapter-repeat-config',Path('/tmp/hp1020-tinyusb-printer-r4wyqvnm'),'validation.json','tinyusb-printer','/tmp/hp1020-adapter-repeat-config-20261002.log')]
for label,capture,report_name,destination,log in profiles:
    raw=(capture/report_name).read_bytes();r=json.loads(raw)
    assert raw==(ROOT/'analysis/usb-path'/destination/report_name).read_bytes()
    for name,digest in r['source_sha256'].items():
        assert sha((capture/'source'/name).read_bytes())==digest
        assert sha((ROOT/name).read_bytes())==digest
    for index,(case,target) in enumerate(zip(r['cases'],r['target']['cases'])):
        directory=capture/(f'case-{index:03}' if destination=='tinyusb-printer' else f'case-{index:02}')
        assert (directory/'case-name').read_text().strip()==case['case']==target['case']
        mapping={'capture':'capture'} if destination=='tinyusb-device' else {n:n for n in ('pixels','wire','receive','output')}
        for name,file in mapping.items():
            host_hash=case['capture_sha256'] if destination=='tinyusb-device' else case['capture_sha256'][name]
            target_hash=target['capture_sha256'] if destination=='tinyusb-device' else target['capture_sha256'][name]
            assert sha((directory/file).read_bytes())==host_hash
            assert sha((directory/('target-'+file)).read_bytes())==target_hash
    files={p.relative_to(capture).as_posix():p.read_bytes() for p in capture.rglob('*') if p.is_file()}
    files['run.log']=Path(log).read_bytes();files['archive-check.py']=Path(__file__).read_bytes()
    output=io.BytesIO()
    with gzip.GzipFile(fileobj=output,mode='wb',mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as archive:
            for name,data in sorted(files.items()):
                assert not Path(name).is_absolute() and '..' not in Path(name).parts
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                archive.addfile(info,io.BytesIO(data))
    payload=output.getvalue()
    with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as archive:
        assert set(archive.getnames())==set(files)
        for name,data in files.items():assert archive.extractfile(name).read()==data
    out=ROOT/'analysis/usb-path'/destination/'source-snapshots';out.mkdir(exist_ok=True)
    (out/(label+'.tar.gz')).write_bytes(payload)
    metadata={'status':r['status'],'report_sha256':sha(raw),'source_files':len(r['source_sha256']),'host_cases':len(r['cases']),'target_cases':len(r['target']['cases']),'archive_sha256':sha(payload),'archive_bytes':len(payload),'member_count':len(files),'member_sha256':{n:sha(data) for n,data in sorted(files.items())},'limits':'Offline synthetic DCD execution only. Unchanged upstream intentionally retains independently observed limitations; no physical USB or printing.'}
    (out/(label+'.json')).write_text(json.dumps(metadata,indent=2)+'\n')
    print(label,len(files),len(payload),sha(payload),flush=True)
