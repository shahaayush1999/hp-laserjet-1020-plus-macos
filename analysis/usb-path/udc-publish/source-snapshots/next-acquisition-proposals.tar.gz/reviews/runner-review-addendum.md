# Acquisition runner static review addendum

2026-10-03; static delta review only. Original review is preserved unchanged at
`/tmp/hp1020-acquisition-runner-review-20261003.md`.
No code edits, imports, parsing, builds, tests, QEMU or device operations.

The retained pre-review Host is byte-identical to the original reviewed source:
`host-before-static-review.py` SHA256
`f667cbfce4ac2d72652b46a17bb1fdc411d6e7dfc4b636d4b49245f7580be0d5`.
The updated `/tmp/hp1020-acquisition-integration-20261003/host.py` is SHA256
`c2374e9af2cf501a42a040e51ca46205606dd12466c9718eae472639b882ee8f`.

The delta closes all three reported assertion gaps for the frozen matrix:

- Refused image inputs now preserve source descriptor words and both image FNV
  witnesses immediately, in addition to existing cookie/slot/context checks.
- No-hook WAIT/INVALID/STALE compares all base and OUT state apart from result
  and the two documented stale counters. Their exact increments match known
  historical-cookie calls made by this Host; its `self.bulk[token]` requirement
  excludes the fixture's separate unknown-history shortcut from this assertion.
  Original ownership, transport, receive generation, reset tickets/parts and
  source-image witnesses therefore cannot change silently on these refusals.
- Successful acquisition preserves the entire pre-service `row[32:48]`, covering
  receive generation, stop/quiescence/error and reset state. Calls without a new
  injected hook failure also preserve the existing first_failure record exactly.

No new static defect was found in this delta. The previously documented
expected_visibility assumption remains bounded as agreed: each frozen retry
installs new op140 image/poison first. This addendum does not approve unfinished
scenario code or claim execution, acquisition C correctness or physical cache/DMA
behavior.
