# Acquisition V2 wording addendum

2026-10-03. Static-only follow-up to
`/tmp/hp1020-udc-acquire-independent-review-20261003.md`
(SHA256 `8b33a67d00fc595903ff2fc277d61c58263f5d9c81a1bbab86b1cab28d806d4a`).
V1 proposal and that review remain unchanged. No imports, source execution,
builds, tests, validators, hardware access or repository edits.

Reviewed `/tmp/hp1020-udc-acquire-v2-20261003/`:

```text
63361d26de832654eeb75f3a87248d1badb08d074419ff870880127e6d7ba91c  draft/open-firmware/udc-out/hp1020_udc_out.c
e073d84e4f0223e07997a3cce5125a420591317681f80c7b80a5b2adc0bfc653  draft/open-firmware/udc-out/hp1020_udc_acquire.h
3c3b5b6cda89f98f373294879f9ec0bd59a07c58b9df1d0179ccbfbb6765a4ae  acquire.patch
ecb159332ce04232cdd0cb3d92d7e5ee4d0d8a73523a1d62edeeec8fa9c2ba80  README.md
a9faf25bcf1542a45de28cda6cc59ebb9f92b68c51907bf67a679b51e156ff4f  V2_DELTA.md
```

The C is byte-identical to V1. The header's only difference is its initialization
comment; the README makes the corresponding clarification. They now distinguish
checked adapter in-flight preparation/owner/response state from the document's
retained receive accounting, which is untouched and governed by caller lifetime
preconditions. This resolves the V1 wording observation without adding a
receive.count==0 or new recovery requirement. No additional correctness finding.

All ownership, no-hook refusal, fault retry, shared-observer and fenced
settlement conclusions and execution obligations in the original review remain
applicable. This is static approval within explicit supplied preconditions,
not a claim of successful execution or physical reception.
