# Acquisition runner fragment review

Static review only, 2026-10-03. No imports, parsing/compilation, builds, validators,
QEMU, device operations or repository edits. The new acquisition C was not read.
Unfinished scenario bodies are excluded from this review.

Reviewed root fragments under `/tmp/hp1020-acquisition-integration-20261003/`:

- header.py SHA256 `24dd9b14fa9670879f960709b8dda7f56af92c3b613dfbf84fff1824dbb0d052`.
- host.py SHA256 `f667cbfce4ac2d72652b46a17bb1fdc411d6e7dfc4b636d4b49245f7580be0d5`.
- main.py SHA256 `f59ed46cbe26fee1248f1860635bafed092f0a460093d64005201915c5dd0bef`.

Fixture authority: frozen package
`/tmp/hp1020-udc-acquire-fixture-draft-20261003/changes.patch`, SHA256
`5dd19ee515a4a070b035a6bdcd9a3eb7057a1896b96b50beae518a509f3b082f`.
Independent plan/helper and public-header snapshot are retained in that package.

## Concrete assertion gaps to strengthen before execution

1. **device_image refusal: source-image bytes are not covered immediately.**
   The refusal branch checks `acquire[9:61]`, but omits the literal source
   descriptor words69..72 and both source FNV values77..78. The input can later
   be overwritten by a successful op140, hiding a transient refused-input change
   from the final144-byte equality. Compare these unchanged on every refusal,
   along with retained image-cookie/slot metadata already covered. The fixture
   itself also has an independent source shadow, but its admitted/refused write
   policy should not be the only immediate assertion of that contract.

2. **No-hook stale/invalid/missing-fact refusals should preserve ownership and
   recovery, not merely context diagnostics.** `acquire_packet` currently checks
   only hook counters and last/first diagnostics in its no-work refusal branch.
   Add unchanged original owner/control/transport/fence/receive/reset metadata,
   permitting only the documented fixture result and stale counters. An old
   cookie is specifically forbidden to stop/retag today's packet or advance a
   recovery. This must be an immediate per-event assertion, independent of later
   document success or the separate aggregate gate.

3. **Accepted acquisition must preserve the whole pre-service recovery state.**
   The success branch verifies issued/consumed/count33..35 and READY slots, but
   omits generation32, stopped/quiescent/error and reset-ticket/parts36..47.
   Compare `row[32:48]` unchanged. Only OUT ownership retirement plus the same
   original adapter owner's DCD->PENDING transition is permitted before service.
   Also require an already-valid first_failure diagnostic42..58 to survive every
   later call without a new hook failure; successful visibility cannot erase it.

These are bounded assertion improvements, not demonstrated production defects.
The independent aggregate gate may duplicate some checks deliberately, but the
focused Host should still fail at the offending event and preserve its capture.

## Integration paths found consistent

- Alias chain and reused compilation inputs preserve the actual publisher,
  program/OUT/adapter and document stack. The new public header is explicitly
  included in source capture; the changed OUT C is in the inherited closure.
- Host and target enforce the same new payload envelope140=80,141=3,142/143=0,
  in addition to the previous1024-byte and old-operation checks. The fixture
  codec matches those lengths exactly.
- Row partitions are96/104/48/40/80/64/64/80 =576. Only global sizes59/425/490/555
  are excluded. Per-stream row counts are checked against events before replay;
  native rows are saved before assertions. The acquisition getter agrees with
  its measured size and does not substitute a guessed platform size.
- Independent original DCD history selects cookie and slot; op140 data and
  literal poison supply expected bytes. Each acquisition trace is descriptor16,
  payload64,order with original-cookie witness. Partial visibility uses the
  frozen independent helper and preserves whole4096-byte receive accounting.
  Failure fields come from input cookie and literal expected prefix, not the
  production failure object. Generic bulk completion is overridden to acquire.
- All twelve raw capture pairs are present, including144-byte acquire_device,
  4096 receive bytes, guarded OUT descriptor and27,712-byte complete program
  read/trace storage. Host source-image equality is literal, not digest-only;
  target uses the matching device_storage and size accessors. Source image,
  receive and descriptor expected bytes are checked before successful reporting.
- Six external fixtures are copied and hashed; recursive source hashes are
  checked across compilation/execution. Exact effective TinyUSB source metadata
  must match the built target. Immutable target artifacts are copied without a
  stale annotated listing, audited before QEMU, then rehashed after execution.
  Source capture skips an absent new checker as in its parents, so install/freeze
  the intended checker first if it belongs to this run's closure.
- Report schema retains per-event original inputs/rows/oracles, source/fixture/
  effective-source identities, expected pixel/document fields and raw hashes.
  Physical cache/DMA/settlement/USB/printing and speculative-load claims remain
  explicitly excluded. There is no success report before final closure checks.

## Bounded helper assumption

`expected_visibility()` starts from the poison installed by the latest op140.
The frozen not-DONE retry plan installs a fresh image/poison before retry, so it
fits. If a later scenario retries acquisition without another op140, apply hook
partial effects to the CURRENT independent CPU shadow instead of automatically
resetting it to initial poison (or explicitly enforce the fresh-op140 precondition).
The API permits whole-acquisition retry with a fresh physical lease; that does
not itself re-poison CPU bytes. This is a future/helper assumption, not approval
of an unfinished scenario sequence.
