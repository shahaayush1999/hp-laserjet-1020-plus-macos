# Independent static review: retained OUT1 acquisition

2026-10-03. Read-only review of the explicitly frozen V1 proposal. No source
import, execution, compilation, validator, QEMU, hardware access or repository
edit was performed. The proposal was read only after its author confirmed its
freeze. This review does not establish physical cache or transfer behavior.

## Result

No blocking correctness issue found within the stated single-context,
stationary-memory, nonaliasing and nonreentrant hook contract. One initialization
wording claim should be narrowed; it does not require a new runtime receive-count
restriction. Preserve V1 unchanged and record any wording revision separately.

Exact reviewed proposal:

```text
63361d26de832654eeb75f3a87248d1badb08d074419ff870880127e6d7ba91c  draft/open-firmware/udc-out/hp1020_udc_out.c
f2baab1c349d99c00005f3a761222f1bd80d9e355b35abaf5eb1fa83eedea3d6  draft/open-firmware/udc-out/hp1020_udc_acquire.h
824771c76157cfda6ca6681f7f37927a769c28c1eaecbf7f56c4edca003744f2  draft/open-firmware/udc-out/hp1020_udc_out.h
664c979efbba8b8694206ac073d3fc18f7961dfdc3cbc57a2962d3a980fdce3a  README.md
f8e805e3b616e7e03c911b9fb522f980d8683db690ec81ba51448ae3b993fd75  acquire.patch
53a9ba65b4c51ac095b8254590da40d28dcc5a4bc4abf041a9461cb6a4ec77cf  DRAFT.sha256
```

These paths are relative to `/tmp/hp1020-udc-acquire-draft-20261003/`.

## Initialization clarification

V1 README lines28–34 say init rejects any adapter reservation; the new header
lines91–96 describe empty owner/reservation/response state. C lines258–265 check
the adapter's `prepared`, delivering, owner and response fields, plus
`control_epoch` and `last_submission_id`. They do not check the underlying
receive queue's `count`, `issued` or `consumed`.

This closes the intended first-use adapter path: an adapter-driven reservation
requires actual configured input and therefore cannot precede its first control
epoch. It is not a general proof that the attached document is fresh. The
existing adapter initializer at `hp1020_tusb_adapter.c:403` stops its document's
receive queue without clearing prior accounting; printer init at
`hp1020_usb_printer.c:94–107` accepts an initialized document without requiring
an empty queue. Direct prior receive use is therefore not excluded solely by
this new initializer.

Recommended wording: “adapter in-flight preparation, owner and response state”;
state that receive accounting is untouched and document lifetime/freshness is a
caller precondition. Do not introduce a receive.count==0 condition into later
failure cleanup or recovery. Acquisition init modifies only its new context;
the observed wording gap does not erase a reservation or authorize completion.

## Ownership, refusal and failure review

- C303–340 takes the existing OUT lock, checks the entire original retained
  cookie, then the adapter's actual bulk DCD owner and original CPU pointer and
  length before any hook or descriptor/payload load. No caller-selected buffer,
  descriptor snapshot or current-generation identity replaces that owner.
  FREE/PENDING/old-cookie calls cannot acquire current reused storage. Checking
  endpoint1 before using its meaning also avoids an endpoint mutation being
  interpreted as another owner slot.
- C321–322 rejects active adapter/stack/preparation/delivery contexts. The lock
  remains held through every hook and the common observer. Reentry through OUT
  acquire/observe/prepare/cancel returns WAIT. This guard does not protect an
  illegal hook that directly calls the adapter or mutates component memory;
  the header correctly leaves such calls outside its explicit contract.
- C328–340 separates malformed facts, known faults and missing normal
  prerequisites. Nonboolean facts are INVALID even on the fault-only path.
  Known/local faults with valid but missing facts need no cache work or physical
  settlement, including an owned PREPARED record after callback unwind. Normal
  PREPARED is INVALID, and normal missing facts WAIT without changing context
  diagnostics. This matches the declared profile.
- C342–379 uses the retained descriptor16 and payload64, with exact original
  cookie, then acquire-order, then the actual retained descriptor copy. The
  count is not decoded to select an earlier payload range. All normal results,
  including zero-length and not-DONE, use the same acquisition sequence; zero
  never becomes parser EOF. A successful hook is a supplied CPU-operation
  guarantee, not evidence of DMA stop or physical visibility on the HP chip.
- C288–300 latches the distinct I/O reason after a hook returns, then invokes
  existing fault delivery. A hook's nonzero or malformed result stops the
  sequence. Subsequent calls hit C332–335, with no hook replay or snapshot.
  Original owner and storage remain retained. The first-failure record survives
  cancellation and later success and can be replaced only after another exact
  retained cookie reaches a genuine hook failure. A returned WAIT/error from
  fault delivery still needs the existing retry-before-forward-work discipline.
- C168–214 is a mechanical extraction of the historical observer: the external
  API keeps enter/leave at the same boundary; the private helper keeps the
  original checks, ordering, reasons, adapter call and retirement. It introduces
  no duplicated descriptor policy. On successful acquisition the adapter is
  PENDING while OUT is FREE; receive parsing and TinyUSB dispatch remain separate.
- Cancellation at C216–239 is unchanged. A clean late successful packet may
  settle after an ordinary cancellation request, as the historical contract
  allows. A latched acquisition/status/body fault remains on the fault path;
  a later clean descriptor cannot erase it. Exact settled cancellation remains
  available without acquisition hooks.
- No mounted/current-epoch/progress7 check was added to acquisition, so exact
  old ownership can settle while a held event, actual reset or publisher fault
  blocks forward work. The old adapter fault API still checks transport identity
  and receive generation before fencing. Acquisition does not clear publisher
  failure prefixes, supply reset promises, service pending events or publish a
  replacement. The surrounding integration must retain the existing ordinary
  progress barrier and actual-reset drain exception.

## Focused execution obligations

These are recommendations for the lead's later sequential experiment, not
executed findings: preserve old observer regressions; confirm hook order/ranges
against separate poisoned CPU and device images; cover all three hook failure
positions and malformed results; prove no hooks or diagnostic reset on stale,
PENDING, normal PREPARED, busy and missing-fact refusal; invoke a known fault
with all prerequisite facts0; probe reentry from an actual hook; keep old
failure history over settled cancellation and a later successful packet; and
settle exact owners while publication failure blocks forward progress, retaining
its original cleanup identity and nonzero receive accounting.

No new physical guarantee is inferred. Event identity, transfer settlement,
mapping/alias ownership, cache-line safety and real acquire primitives remain
externally supplied. Hooks must implement compiler/architecture ordering as well
as the declared memory operation; ordinary RAM fixtures cannot prove all hardware
or speculative-load effects.

## Existing source identities used for the cross-check

Relative to the repository root, read without mutation:

```text
a5bb1d281dd7226f9346e0dce3b13a475ac25320cf6b276f39d539d78584c3d7  open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.c
0f809b1ac03f5fb96d8524cab2e5cf18d5ad8d9fe6348e50ae4b2d6d2509e5bf  open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.h
1a7f1f1a4b422b3630291210f45c1824396b99c809ebbf2c55b36eec51996a1d  open-firmware/udc-out/hp1020_udc_out.c
4492d8387bffd6156c8df9513c2eb86cd2c0435a97afb73f4f8ee7de5467a5b3  open-firmware/udc-out/README.md
f3608666e58b4b1e328d0166d3dbdce68d7bdebef7beca766d464c81a56f5f7a  open-firmware/udc-publish/hp1020_udc_publish.c
352413d1c3d5cd8dbe1aa1788ab27383d1c45bfc344842d3b9b08c7e64827a8e  open-firmware/usb-receive-core/hp1020_usb_receive.c
c9daf663ae7eea5b9df6a6a68fffd86ec0d6c4b860ce17559250e65cf02361b9  open-firmware/usb-printer-class/hp1020_usb_printer.c
```

The proposal's frozen primary/cache reviews were reused for scope only; no
original-byte or manual investigation was repeated in this review.
