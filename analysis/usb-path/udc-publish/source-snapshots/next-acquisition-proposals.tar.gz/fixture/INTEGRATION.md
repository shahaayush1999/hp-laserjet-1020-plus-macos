# Unexecuted acquisition fixture integration

Owned files: optional seams in two existing fixture C files; new acquisition
fixture C, host codec, target linker script, README and builder. No repository
files were edited. No new acquisition C implementation was read, copied or
executed. Public header snapshot and independently frozen plan/oracles are under
references/. The lead owns production integration, Python Host/scenarios/checker,
source closure, compilation, target audit, all execution and reporting.

Apply the production acquisition package separately first. It adds the public
header beside udc-out and implements it in the existing OUT translation unit.
Then apply changes.patch from repository root after checking both original fixture
hashes against baseline. Historical variants see no changes without the new
HP1020_COMPOSED_ACQUIRE macro. There is no production or installed-printing change
in this fixture package.

Python Host changes: parse576 words; keep first496 partitions; append80 acquire
words and exclude only acquire59 from target equality. Validate new payloads
140=80,141=3,142/143=0 before both host and target entry. Schedule kinds6/7/8 with
op143 rather than old program/publication injectors. Read new raw suffix
output.acquire-device and compare144 bytes via target device_storage getter;
retain all eleven old capture pairs. Snapshot original owner cookie/slot at bind,
use independent input bytes and trace outcomes to update exactly descriptor16
and selected prefix64 in the external oracle, and require every other receive
byte unchanged. Program trace format/storage stays identical; read/write/order
counters exclude new kinds. Private recursive probes add no trace records or
external events and are counted only in acquisition60/61.

After a failure, do not accidentally call inherited arbitrary completion62 or
synthetic CPU-write65: those are intentionally blocked. Normal completion must
use real acquisition142. Original cancellation63/64 remains unchanged. op140
makes explicit device images plus CPU poison; it is not a physical DMA command.
The explicit CPU copies in hooks model a chosen visibility outcome only.

Header source is f2baab1c349d99c00005f3a761222f1bd80d9e355b35abaf5eb1fa83eedea3d6.
The frozen32-case independent plan is retained under references; no producer
scenario or production result was consulted. No unsupported report-WAIT or
reinitialization coverage is claimed. Hardware/cache/order correctness remains
external. Freeze and preserve these unexecuted bytes before first execution.
