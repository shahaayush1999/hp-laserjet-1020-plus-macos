# Independent acquisition fixture and event plan

Unexecuted, 2026-10-03. The new acquisition C has not been read. This plan uses the
lead's boundary review, the existing OUT/adapter/composed/publication contracts,
and only the public acquisition header. No imports, builds, validators, QEMU,
stock execution, repository edits or device operations were performed.

## Fixed authority and literal operations

Use the actual composed TinyUSB/DCD, publisher, OUT object and existing four-slot
receive/document pipeline. Do not add an owner allocator or a second completion
simulator. The new acquisition object is configuration/diagnostics, not an owner.
The independently captured original DCD cookie is five fields: id, transport
epoch, receive generation, receive sequence, endpoint1. The selected slot comes
from the actual bound buffer address compared with each existing queue slot;
never select it from acquisition/failure diagnostics or a current endpoint event.

An ordinary attempt must record exactly this ordered prefix, with the original
cookie checked independently on EACH call:

1. kind6, descriptor DMA579bdf10, actual retained descriptor CPU address, length16;
2. kind7, receive DMA24681340/24682340/24683340/24684340, actual original selected
   receive slot CPU address, length64;
3. kind8, dedicated acquire-order, original cookie, diagnostic offset/length0.

Reuse the existing six-word trace `(event, absolute ordinal, kind, DMA, length,
result)`. No new register read/write is part of acquisition. Program counters for
kinds1..3 and publication counters4/5 retain their old meanings. Full guarded
read/trace storage and unused tails remain independently checked. Success prefix
bits are1/2/4/8 (descriptor/payload/order/snapshot), giving15 after the actual
snapshot. A failure at6/7/8 has literal successful prefix0/1/3 respectively, no
valid snapshot, and reason80000103. NOT_PERFORMED1 and UNKNOWN2 are both faults.
These public diagnostic numbers describe software evidence, not settlement.

`trace-oracles.py` contains standalone literal bytes/ranges/prefixes, partial
visibility effects, fact probes, original-cookie mutations and a proposed
16-profile × two-fill matrix (32 total). It does not import or inspect production.
The reusable small image is the existing pinned32x8 black JBIG fixture; the final
pixel oracle is exactly32 bytes of FF, independently of decoder output. Each
case ends with one BE document record `(G,1,0,1,0)` and exactly one completed
page. First normal generation is2. Reset/fault cases finish a fresh document in3;
old partial inputs must produce no page or END_DOC. Every current packet,
including all later stream fragments, must go through real acquisition.

## Synthetic device image and CPU poison

Retain ONE fixture-only device descriptor16 and payload64, surrounded separately
by16-byte guards, initialized to the profile fill. They are input witnesses, not
production ownership. Save their exact input bytes and original cookie by value.
Keep separate independent CPU shadows. Capture the entire48+96=144-byte device
image storage, in addition to every existing capture pair. Source images never
change as an automatic consequence of reads, hooks, status bits or commands.

A valid image/poison input must first match the original current EXPOSED OUT
cookie, actual adapter DCD owner, actual fake-DCD packet, fixed descriptor CPU
allocation and selected queue slot. Unknown history, old cookie, FREE, PREPARED,
PENDING or a mismatched retained owner must refuse BEFORE any mutation of either
device images or CPU bytes. There is no permission inferred from current DMA
addresses. Replay the same original image input against PENDING/FREE/reused
storage and require full byte/metadata preservation.

Once admitted, the input stores exactly80 independently supplied device bytes
and deliberately poisons exactly the actual descriptor16 and selected prefix64.
Update the permitted shadow from the INPUT poison constants at that point. Do
not update a shadow from whatever the component writes. Every other receive
slot, selected slot bytes64..1023, descriptor guard, receive allocation guard,
output slot, EP0 storage and source-image guard/tail remains unchanged. The whole
existing storage oracle must survive every hook and before retirement clears
any fixture live flag. All these are explicitly synthetic fixture writes,
not DMA operations or proof of physical cache behavior.

Normal poison has owner3 plus a deliberately wrong body; a second mode has a
plausible DONE/count64 descriptor with the correct body. Payload poison and the
unused device-prefix tail are distinct nonuniform bytes specified in the helper.
The latter false-DONE mode is useful with a device owner1/count31 observation:
correct acquisition must return WAIT despite the CPU's initially valid-looking
DONE descriptor. A later attempt must freshly acquire actual DONE/count31 bytes.

Successful range hooks copy exactly their witnessed range. NOT_PERFORMED copies
nothing. UNKNOWN copies the first8 descriptor bytes or first32 payload bytes,
respectively. The order hook has no byte effect. This deliberately preserves
visible partial effects on failure. At payload failure the descriptor may be
fully valid; at order failure both ranges are fully copied. Neither may permit
completion, service, parsing or reset promises. Hooks independently check that
OUT and the original adapter owner are still retained, no completion/fault was
reported by the normal path yet, and previous trace ordering is exact.

This proves byte authority, bounded range selection and observable ordering of
admission/effects. Ordinary C/RAM captures cannot prove absence of every unused
or speculative early load; do not claim otherwise. The source review must still
check that the actual descriptor copy is after all three operations.

## Provisional input seams

The lead accepted the following as a suitable *provisional* allocation. Existing
variants and old ABI positions must be untouched. Extra stats/raw fields should
serialize named words/bytes only, never pointer values or C padding.

- op140: `a=original history id,b=CPU poison mode0/1,c=d=0`, payload exactly80
  bytes (literal device descriptor16 + payload64). Strict original-owner and
  EXPOSED validation precedes every synthetic image/CPU write. Successful hook
  effects retain source images; this op alone changes their contents.
- op141: zero arguments, payload exactly3 raw prerequisite bytes, unnormalized.
- op142: `a=original history id,b=cookie mutation0..5,c=endpoint_fault,d=0`, no
  payload. Call the actual acquisition API; there is no descriptor argument or
  supplied visibility boolean. The facts are transfer_settled/mapping/cache.
- op143: `a=kind6/7/8,b=future absolute hook ordinal,c=raw outcome,d=0`, no
  payload. Reuse the single fault schedule; a busy schedule cannot be replaced.

Keep63/64 original-cookie cancellation. Disable62/67 arbitrary observation,
66 saved-observation creation/replay and65 direct CPU writes in this variant;
old generic completion bypasses remain disabled as in publication. A positive
normal packet may never enter the old observer directly through a test input.

Natural private probes can run without new opcodes: immediately after a genuine
DCD bind and before its callback unwinds, and from each acquisition hook, call
packet() recursively with the captured cookie. Require WAIT and unchanged
component/adapter/queue/descriptor/diagnostics/hook trace/failure schedule. Never
set production busy or owner fields to fabricate these cases. Probes deliberately
violate the documented caller serialization to test its guard; they must do no
nested work. Probe counts must prove actual coverage, including one from every
kind6/7/8 hook in the callback-authority profile.

## Shared setup, success and cancellation recipes

`CONFIGURE`: actual reset if initially needed; existing typed SC1, exact program
INITIAL trace, original automatic status owner/grant with GRANT trace, then all
three existing separately acknowledged recovery promises. Recovery reachesG2.
Do not count the automatic permission as EP0 status transmission or ACK.

`SEND`: actual publisher arm with frozen publication trace; independently select
original DCD cookie/slot; create literal device image for a <=64-byte input
fragment; poison CPU; real acquire; verify prefix15 + exact local snapshot, OUT
FREE and original adapter PENDING. **Before service**, receive issued/count and
consumed/READY fields are unchanged, no pixel/document/wire or reset progress.
Duplicate acquire must be STALE with no hook. Service through actual TinyUSB,
then pump as allowed. Acquiring64 never changes the descriptor's actual count;
only the supplied input fragment reaches the parser. ZLP is not EOF. No explicit
close/finish is used to claim the final page; validated END_PAGE/END_DOC suffice.
Normal streaming must witness all four actual queue-prefix ranges.

`CANCEL_RECOVER`: retain failing cookie and its exact CPU partial effect. Repeated
acquire returns the existing fault path with ZERO new hooks, unchanged first
failure and no fabricated snapshot; cancellation/set faults cannot erase it.
Unsettled cancel WAIT, then actual reset admission and settled original-cookie
cancellation. Check borrowed bytes before clearing live flags. Settle the old
auto-status owner separately and service drainage. Nonzero receive accounting
remains until the existing three-promise restart. For a publication failure,
its own exact-cookie physical-clean acknowledgement is ALSO required after
owners drain; it supplies no document promise and preserves count. Reconfigure,
acknowledge the three promises and send one entire fresh small document inG3.
A successful later acquisition must not erase the earlier first_failure record.

Ordinary missing-fact/busy/not-DONE WAIT permits a WHOLE fresh acquisition with a
new valid lease. A hook failure does not: repeating its tail would hide a fault.
Fault-report WAIT/ADAPTER_ERROR is an API retry obligation, but under serialized
stationary hooks and the pre-hook adapter-busy guard it is not obviously naturally
reachable. Do not fabricate adapter.busy to claim that case. This first matrix
covers repeated already-admitted fault delivery and real cancellation; separately
report any unreachable report-retry branch instead of inventing its execution.

## Exact semantic profiles

Every profile is run at fills0 and204, capacity64, interface0. Existing literal
publication/program/auto-grant recipes remain required, not inferred from final
success. The names and final generations are frozen in the helper.

1. **visibility-packets (G2):** send a ZLP first, then small[0:7], small[7:71],
   remainder in <=64-byte packets. Confirm no ZLP EOF/closure, payload count7
   consumes no device tail, full64 count works and every actual slot appears.
   Before each successful acquisition CPU bytes differ from device input; final
   pixels32FF and exactly `(2,1,0,1,0)` prove the complete unchanged document.
2. **facts-and-identities (G2):** after one arm/image, independently test each
   prerequisite0=>WAIT and2/255=>INVALID; each of five original cookie mutations
   =>STALE; no hooks, snapshot or metadata/storage change. Then success, attempt
   old op140 and acquire while PENDING and again after service/FREE: both refuse
   without writes/hooks. Complete the same document exactly. Explicitly probe
   disabled62/65/66/67 without altering current ownership.
3. **callback-authority (G2):** natural after-bind callback and descriptor,
   payload, order hook reentry probes all return WAIT, without nested trace or
   diagnostic changes. Successful outer packet and full exact document continue.
   Do not make direct unowned object mutations to obtain the busy state.
4. **held-setup-settlement (G2):** arm/image, offer raw GET_CONFIGURATION
   `8008000000000100` with unknown capture facts. Forward progress0/arm WAIT, but
   exact acquisition succeeds and only makes original adapter PENDING. No pump
   while held. Dispatch the SAME original request with supplied facts; settle
   old auto-status owner; service/control transfer with exactly IN byte01 plus
   OUT0 ZLP status. Finish the same document. Other profiles have no ordinary
   EP0 wire bytes. No stale status grant is revived.
5. **admitted-reset-settlement (G3):** arm/image31 bytes, admit actual reset,
   verify cancellation requested and new forward work blocked. Acquire the
   exact old cookie successfully despite newer control/transport admission;
   old owner becomes PENDING without reset promises or parsing. Service drains
   it under the stopped generation; no old page/END_DOC. Normal separate restart
   and a fresh complete document produce the only32FF/G3 notification.
6. **same-address-reuse (G3):** acquire31 initial bytes and service/pump incomplete
   input, reset/recover; the next G3 slot0 descriptor/buffer use the SAME numerical
   DMA and CPU allocations. Before acquiring the new poisoned image, old op140,
   acquire, cancel-request and cancel-settled must be stale and leave new bytes,
   hook trace, owner, transport and fault state unchanged. New original cookie
   succeeds, and the fresh document alone produces32FF/G3. No retagging old input.
7. **prepared-publication-failure (G3):** inject publication RX-before-device
   failure (existing kind4), retaining PREPARED original owner and publisher
   failure. Ordinary acquisition is INVALID before hooks/snapshot; op140 also
   refuses. Cancel via the existing original-cookie path, preserve publisher
   failure, complete its independent cleanup and three-promise recovery. Fresh
   acquired document succeeds; there was no acquisition hook failure to invent.
8. **exposed-publication-failure (G3):** inject publication DESPTR uncertain-write
   failure after exposure. With independently supplied actual settlement and a
   valid image, exact acquisition may accept despite publication progress0.
   Publisher failure remains byte-for-byte intact; no service/pump bypass or
   automatic cleanup follows. Actual reset, original auto-owner drainage,
   publisher cleanup and separate recovery precede the fresh G3 document.
9. **endpoint-fault-only (G3):** with exact retained EXPOSED owner and missing
   prerequisite facts000, supply nonzero reason0x5a17. Existing fault path must
   run with no cache trace or snapshot and request cancellation without releasing
   bytes. Repeat with another reason and then reason0: no cache retry, first local
   reason retained. Explicit settlement/recovery yields only the fresh G3 page.
10. **not-done-fresh-retry (G2):** CPU poison is plausible DONE/count64, device
    image is owner1/count31. Full trace + actual snapshot produce WAIT and keep
    original ownership. Replace image with DONE/count31 and invalid CPU poison;
    full three-hook trace must run AGAIN, giving exact snapshot and acceptance.
    Finish the same document; there is no persistent cached visibility ticket.
11–16. **descriptor/payload/order × NOT_PERFORMED/UNKNOWN (G3):** arm/image31;
    fail exactly the named hook. Assert the literal attempted prefix and exact
    partial CPU visibility from the helper; original cookie/slot retained,
    no valid snapshot, no completion, no queue READY/pixel/doc/wire activity,
    first_failure from original input cookie (not reverse-derived from output).
    Repeated acquire and ordinary forward attempts cannot retry hooks or clear
    the fault. `CANCEL_RECOVER` then one complete acquired G3 document. First
    failure fields survive later successful packets and report their originalG2.

## Bounded exclusions and executable review gates

Do not multiply the old owner/RX/L/count/body descriptor matrix; the existing
observer owns that policy and is invoked through the shared locked helper.
This matrix intentionally omits a second independent acquisition failure inG4,
malformed raw hook returns beyond the two contractual failures, pointer-alias
initialization probes and naturally unreachable fault-report WAIT injection.
Those remain source-review obligations or later evidence, not executed claims.

The eventual runner must capture source closure and fixture bytes, independently
audit the target before QEMU, replay every event with the exact raw payload and
original cookie, compare all old496 rows plus appended named diagnostics, all
prior raw storage/pixels/wire/documents plus device-image storage, and serialize
both last/first-failure diagnostics without padding. Preserve raw input device
images, CPU poison selections, trace results, source hashes and failure captures.
Acquisition appends no stock instruction execution and proves no peripheral,
physical cache, DMA, USB acceptance, IRQ acknowledgement or physical printing.
