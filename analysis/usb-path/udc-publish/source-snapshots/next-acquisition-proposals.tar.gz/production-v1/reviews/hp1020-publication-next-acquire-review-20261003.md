# Next boundary: synchronous acquisition of the retained OUT1 packet

2026-10-03. Static proposal only. No repository edit, source import, build,
validator, QEMU, stock execution, peripheral operation or USB contact. The lead
owns the currently unexecuted publication experiment. This is a possible next
implementation after that experiment, not a claim that publication or physical
receive works.

## Recommendation

Yes: a small acquisition entry point beside the existing `udc-out` observer
would remove an actual implementation gap. It should obtain CPU visibility of
the **already retained** descriptor16 and receive-prefix64 through mandatory
range hooks, order those operations, copy the actual descriptor memory locally,
and invoke the existing descriptor/admission policy. It must not accept a caller
descriptor snapshot or caller-supplied `descriptor_cpu_visible` /
`payload_cpu_visible` booleans. Physical settlement, stable CPU/DMA ownership and
the architecture's maintenance capability remain explicit prerequisites.

This closes the counterpart of publication: the production code controls which
memory is acquired and when it becomes eligible for software completion. It
does not add a controller model, descriptor decoder, receive queue, owner,
identity allocator, IRQ producer or cancellation implementation.

The current gap is concrete:

- `udc-out/hp1020_udc_out.h:53-65` accepts an immutable16-byte observation plus
  three supplied facts; `.c:166-207` trusts the two visibility facts before
  handing a successful count to the adapter.
- `udc-composed-test/fixture.c:657-661` copies arbitrary fixture input into that
  observation. Its saved-snapshot path at683-687 also supplies visibility flags.
  Those paths correctly test descriptor policy, but no production routine
  acquires that snapshot from its retained CPU allocation.
- `udc-publish/README.md:96-101` expressly leaves post-device acquisition out.
  The new publisher implements before-device hooks; treating their successful
  return as later CPU visibility would be incorrect.

## Smallest useful implementation shape

Prefer an additional synchronous `hp1020_udc_out_acquire(...)` entry point in the
existing OUT component, with the old `observe(...)` API and its tests retained.
Factor the existing locked observation policy into a private common routine so
the new path does not reproduce the owner/RX/L/count/body checks. This can use
the existing component's busy guard and fault/cancellation state; it does not
need a new acquisition phase or owner ledger.

The conceptual inputs are the existing OUT object, the **original cookie**,
an independently identified endpoint fault reason (zero for ordinary data),
three explicit prerequisite facts, and a stationary set of mandatory hooks.
No code or ABI is committed by this note. Keep hook configuration separate from
the old initializer so existing RAM-only callers do not acquire pretend cache
capabilities. An optional diagnostic output is evidence, never authority.

Required hooks, each synchronous and using the established three-result policy
OK / NOT_PERFORMED / UNKNOWN:

1. Descriptor-for-CPU: original cookie plus the exact retained `{cpu,dma,16}`
   span, the after-device phase of its bidirectional mapping.
2. Receive-for-CPU: original cookie plus the exact retained `{cpu,dma,64}` span,
   the after-device phase of a device-write mapping.
3. Acquire-order: completes the provider's documented cache-maintenance and
   CPU-load ordering before descriptor loads and later parser access.

Use the same result meanings as `hp1020_udc_program_io_result`, without assuming
the existing register `order` hook necessarily has acquire semantics. Its header
promises the documented ordered CPU operation, not a particular hardware barrier.
Either supply a separate acquire-order hook or explicitly establish that a shared
provider implements both roles. A release-only register barrier is insufficient.
There is no weak successful no-op fallback. A justified coherent/uncached provider
is a physical capability, not a conclusion from OK.

The three proposed prerequisite facts are exact booleans:

- **transfer_settled:** all old accesses belonging to this retained packet have
  finished and cannot recur; queued old events keep their original identities.
  It must hold before any maintenance or load, not merely at adapter completion.
- **mapping_lease:** both original CPU/DMA spans still correspond byte-for-byte,
  remain allocated and exclusive, and cannot be replaced, rebuilt, rearmed or
  modified by another actor throughout this acquisition. Existing ownership
  lasts through subsequent adapter/queue use; the call does not end that lease.
- **cache_range_safe:** the supplied real maintenance/coherent capability is
  applicable, range rounding cannot wrap, and every touched whole cache line is
  exclusively owned.16-byte alignment alone is not a larger-line isolation proof.

All calls and hooks remain serialized and nonreentrant. Hooks cannot dispatch
ingress, invoke TinyUSB/the adapter, acquire a new packet, change a mapping,
release an owner, or defer their effect. Stable memory is necessary even if an
ordinary C copy is used; `volatile` would not establish atomicity or visibility.

## Proposed normal acquisition sequence

1. Before any maintenance or descriptor/payload load, validate arguments and match all five
   original cookie fields against the retained OUT cookie **and** the actual
   adapter DCD owner. Match its buffer/length to the retained receive prefix.
   Require EXPOSED for the normal data path. An old unretained cookie, a FREE
   component, or an already-PENDING adapter packet must cause no hook or read.
   Never derive a cookie from today's endpoint, generation or descriptor address.
   The original retained owner may legitimately be old relative to current reset
   epochs; do not reject exact settlement solely because its generation is old.
2. Require the initiating submission callback to have unwound. Reject/retry while
   the component, adapter or surrounding publication/program callback is active.
   Check every prerequisite boolean before touching memory: nonboolean INVALID,
   unknown required fact WAIT. These refusals do not manufacture a packet fault.
3. Acquire descriptor16, acquire receive64, then perform acquire-order. The first
   slice can synchronize the complete owned64-byte prefix unconditionally; it
   need not decode count early or introduce a second descriptor-validation pass.
   It must not acquire all1024 bytes of a queue slot, a current endpoint's new
   buffer, or a count-derived unbounded range. With the supplied settled/exclusive
   lease, acquiring the full64 is safe even if the descriptor later reports zero,
   a short packet, or a rejected status. It is not a64-byte USB completion claim.
4. After all three operations succeed, copy exactly16 bytes from the retained
   descriptor CPU address into one local immutable observation. No CPU descriptor
   decode occurs before this point. Preserve that snapshot for diagnostics if
   desired. The hooks must not provide an alternate descriptor value or pointer.
5. Run the existing locked observer with visibility facts justified by those
   actual hook calls and the separately supplied settlement fact. Its BE body,
   owner/RX/L/count policy remains authoritative. It alone calls the existing
   adapter completion path; the acquisition routine must not submit a normalized
   completion independently.
6. On accepted success the OUT component becomes FREE and the adapter owner
   becomes PENDING. The payload is still owned by the adapter/receive queue;
   acquisition does not service TinyUSB, parse, pump, grant another publication,
   mark EOF for a zero count, or satisfy a reset promise. Duplicate acquisition
   with that cookie is stale before any further cache operation.

This sequence deliberately acquires both ranges before asking the existing
decoder to decide the status. It avoids another validator for owner/count and a
cached visibility ticket that might later be replayed for reused memory.

## Fault, retry and cancellation rules

**Known faults do not wait for physical settlement.** After exact retained-owner
validation, an existing local fault or a supplied nonzero endpoint fault takes
the current OUT fault path without loading descriptor or payload bytes. Its
purpose is to request cancellation and fence software consumption, not to claim
settlement. Diagnostics must distinguish this fault-only call from a captured
descriptor; no synthetic zero descriptor is presented as evidence. Preserve the
existing rule that endpoint_fault is a reason, not an unfiltered EPSTS register.

**A failed acquisition operation is retained and fail-closed.** After any range
or acquire-order hook returns NOT_PERFORMED, UNKNOWN, or an invalid result, latch
a distinct local acquisition reason through the existing `fault_reason` /
`report_fault` mechanism. Preserve original cookie, failed operation, result,
exact DMA/range and completed prefix for diagnosis; never label a failed copy
as valid. Do not call the adapter from inside a hook. The call is already outside
the initiating stack callback, so fault delivery is attempted only after the
hook returns. Both definite and uncertain failures stop normal completion; this
bounded profile has no automatic cache retry after a failure.

The OUT fault path already marks local cancellation and preserves every borrowed
byte (`udc-out.c:71-86`). If reporting returns WAIT/ADAPTER_ERROR, retry fault
delivery before ordinary service/pump, with **no more cache work**. Stale fault
delivery for an exact retained old packet does not fence a newer generation;
the old component still retains its storage until explicit cancellation. A
debug diagnostic is not a new cleanup permission or identity. Reinitialization
must never clear the fault.

Ordinary WAIT caused by missing prerequisite facts, a busy caller or the existing
observer's not-DONE status is different: storage remains retained and a later
call may acquire afresh using the same original cookie and fresh current lease.
Never retry only the tail of the operation or trust an earlier visibility bit.
If a physically settled descriptor never becomes acceptable, explicit cancellation
is the available resolution; time alone does not make it a successful packet.

Existing `request_cancel` / `cancelled(..., settled=1)` stay independently
available and need no descriptor/payload cache acquisition merely to discard
the packet. A clean late success after an ordinary cancellation request may
still pass the existing observer, as the current README explicitly permits;
once a local acquisition/descriptor fault has latched, normal success cannot
erase it and only the explicit cancellation path retires it. None of these
operations constitutes physical cancellation itself.

Do **not** gate exact completion acquisition on full progress7, mounted state,
binding readiness or the absence of a held SETUP. Those are forward-operation
gates and can be false precisely while old owners must settle. Allow the retained
cookie path after real-reset admission, held raw ingress, or a prior publication
failure, provided the call itself is outside active callbacks and the physical
lease is supplied. A PREPARED/unexposed record uses fault/cancellation instead of
normal acquisition. Existing program/publication failures and cleanup records
remain untouched; acceptance of an old settled packet does not clear them or
grant RECEIVE/TRANSPORT/OUTPUT promises. An unavailable fault report must still
block forward work under the existing scheduling contract.

## Small independent experiment

Use the current actual publisher/OUT/adapter composition, with an optional
acquisition build so historical observer cases keep their exact old ABI. In
the new build, normal bulk completion must enter through acquisition; disable
direct arbitrary-observation and saved-snapshot completion bypasses. Explicit
original-cookie cancellation stays available.

The most useful independence control is a small **fixture-only visibility
witness**: retain synthetic device-written descriptor/payload images separately
from the poisoned CPU allocations. A successful after-device hook makes exactly
its witnessed original span visible; scripted NOT_PERFORMED leaves it unchanged,
and UNKNOWN can make an explicitly recorded partial effect. This is a test of
which memory the production routine actually reads, not a claim about physical
cache behavior. No second production queue or owner is needed. Check separate
guards/tails and the source images independently, rather than filling expected
bytes from the component's output.

Bound the profiles to the new seam:

- A short packet, zero packet and full64 packet, followed by an existing small
  exact document, through descriptor and payload hooks to unchanged final pixels.
- Poisoned CPU descriptor/data versus different device images: no decode before
  the correct acquisition/order prefix; literal16-byte body and known payload
  are the oracle. All four receive-slot prefixes should be reachable over the
  normal stream, without manufacturing extra owners.
- Wrong cookie fields, FREE/PENDING duplicate, PREPARED record, callback reentry,
  missing/nonboolean lease facts: no hook, snapshot, completion or queue change.
- Each of the three hook positions with NOT_PERFORMED and UNKNOWN: exact prefix,
  unchanged original ownership, no normal completion and no hook replay; later
  exact settled cancellation drains the old owner. Include nonzero retained
  receive accounting rather than requiring an empty receive queue for cleanup.
- Held raw ingress / admitted reset / old-cookie after descriptor reuse, and a
  possibly exposed publication failure: exact settlement remains possible while
  forward publication stays blocked; stale cookie never touches the new ranges
  or stops new work. Existing publication failure diagnostics survive unchanged.

Do not repeat the whole descriptor/error matrix: that remains the executed OUT
observer's responsibility. Do not rerun original IRQ/SETUP/cancellation slices
for this boundary. Reuse their pinned evidence and run the new composition only
after the lead has completed the current publication checkpoint.

## Evidence and limits

This recommendation reuses, rather than re-investigates, the frozen reviews:

- CACHE_REVIEW.md: original clean candidate at100173c8..100173e5 (DHWB at
  100173db, DSYNC at100173e1), clean/invalidate candidate at10017414..10017431
  (DHWBI10017427, DSYNC1001742d), and callback100087b8..100087cc retaining a
  distinct numeric alias while invoking maintenance on its original destination.
  They establish instruction/operand intent, not a safe universal mapping,
  cache geometry, physical visibility, or transfer settlement.
- PRIMARY_REVIEW.md: Sony rev1.1.0 p1190 section3.18.8.6 and p1209
  section3.18.11.2.3 describe family normal-OUT DMA disable/processing/rearm;
  p1208 separates packet modes. A status bit or RDE observation does not replace
  the original-cookie physical settlement requirement.
- Existing `udc-out/README.md:80-95` anchors original owner/count reconstruction
  at100084fe..1000853f and distinguishes the replacement's stricter RX/L policy.
  No new interpretation of those instructions is necessary here.
- Pinned TinyUSB weak cache functions return success without maintenance;
  the frozen cache review identifies them explicitly. Pinned Linux separates
  CPU allocation from DMA mapping/unmapping. Neither supplies HP's physical
  bare-metal cache/mapping implementation.

What would become executable is range selection, required hook invocation and
failure order, actual CPU snapshot construction, and composition with already
retained protocol ownership. Still external: controller identity/mode, actual
event-cookie producer, physical alias/reachability/cache-line safety, real cache
and acquire primitives, stable memory and physical settlement, global RDE/SETUP
readiness, IRQ acknowledgements and rearm, startup, mechanics, and observed
printing. A passing RAM test is not evidence that any of those promises holds.

## Exact source identities read

Repository root:
`/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos`.
The OUT/adapter baseline has no local diff. Publication and fixture integration
are lead-owned, unexecuted working-tree files at the time of this review.

```text
ad2d189c25e0788bd3191d189921bb2dce75cd6cb9dd95ab89f6aa9aeaf31b62  CURRENT_STATUS.md
1a7f1f1a4b422b3630291210f45c1824396b99c809ebbf2c55b36eec51996a1d  open-firmware/udc-out/hp1020_udc_out.c
824771c76157cfda6ca6681f7f37927a769c28c1eaecbf7f56c4edca003744f2  open-firmware/udc-out/hp1020_udc_out.h
4492d8387bffd6156c8df9513c2eb86cd2c0435a97afb73f4f8ee7de5467a5b3  open-firmware/udc-out/README.md
f3608666e58b4b1e328d0166d3dbdce68d7bdebef7beca766d464c81a56f5f7a  open-firmware/udc-publish/hp1020_udc_publish.c
4818e02254d64a799a1909e0af9a7fcc89a3df11a926b3be4164a366ef22677f  open-firmware/udc-publish/hp1020_udc_publish.h
e756779cbbaae17c13b01994eedbb091ec98699572843cfc45bdfaebbf22789c  open-firmware/udc-publish/README.md
e84cf4a8ff293d6dc3e36f502bf1029041367c0c697585f7d7f76cd2fd896f2b  open-firmware/udc-program/hp1020_udc_program.h
a5bb1d281dd7226f9346e0dce3b13a475ac25320cf6b276f39d539d78584c3d7  open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.c
0f809b1ac03f5fb96d8524cab2e5cf18d5ad8d9fe6348e50ae4b2d6d2509e5bf  open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.h
3a9fde438d4a969a913409755e6663263761e1b9d926816c44826834900e8626  open-firmware/udc-composed-test/fixture.c
7b68c1a19c5b7a8c1ccc123fa060600f955330dc76a2890509f3c52a0a3cdc2c  /tmp/hp1020-publication-resume-20261003/backend/reviews/CACHE_REVIEW.md
39a4f942b986e74b48668c1e49449c5fa04312c6833e574c007b1d781ff60ee9  /tmp/hp1020-publication-resume-20261003/backend/reviews/PRIMARY_REVIEW.md
```

Original ELF/manual/Linux/TinyUSB hashes and precise byte/page anchors are retained
in those two frozen reviews. They were reused as existing evidence, not newly
executed or promoted to hardware observations here.
