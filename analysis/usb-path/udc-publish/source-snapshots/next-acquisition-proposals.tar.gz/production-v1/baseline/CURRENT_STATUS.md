# Current handoff

Updated: 2026-10-03. **The open firmware replacement cannot print yet.** Resumed
at the owner's request; continue autonomously until asked to yield. Do not
enumerate/contact USB, upload firmware, execute print-driving hardware paths or
change installed printing.
AGENTS.md owns scope; `analysis/README.md` is the evidence/tool-recovery map.

## Current checkpoint

The latest full sequential `scripts/validate.sh` run passed **129 consistency
checks and both suites**, including28 host/28 QEMU recording-program cases,
62/62 composed,58/58 typed offload,132/132 raw adapter and52 unchanged/160 patched
protocol cases. Log: `/tmp/hp1020-full-program-20261002.log`, child
`hp1020-validation.xVacWU`. This validated code is committed and pushed. The later
publication work below is separate from that fully validated checkpoint.

The new endpoint register-command backend connects actual TinyUSB callbacks to
recorded command sequences and immediate one-shot status permission. Fixed FIFO
allocation is checked; failures retain their original cleanup identity across
reset. No physical register binding exists. Its first focused28/28 run passed
without production/scenario execution corrections. The independently frozen gate
passed unchanged and nine deliberate corruptions were rejected. The full rerun's
1876 paired rows and captures match the first; its raw-capture gate also passed.
Target backend88, adapter/document128588, EP0296, bulk80, SETUP96 bytes.

Exact first134-source and full135-source closures, target, fixtures and eleven
capture pairs per case are in `analysis/usb-path/udc-program/source-snapshots/`.
Untouched proposals, first negative-control indexing correction and independent
reviews remain separately archived. Shared optional fixture seams leave existing
adapter/OUT/EP0/composed/offload case rows and captures unchanged. Full composed
and offload archives are `program-full-suite-62-cases.*` and
`program-full-suite-58-cases.*` in their respective evidence directories.
Ordinary raw SET_INTERFACE rejection continues to preserve input and old recovery
identities; typed SI remains separately conditional. Detailed evidence and limits
live in `analysis/open-firmware-model/next-evidence.md`.

## Next action

Root owns integration and sequential execution. Recovered and hash-verified
the next OUT1 publication component from
`analysis/usb-path/udc-program/source-snapshots/unexecuted-publication-drafts.*`.
the archive into `/tmp/hp1020-publication-resume-20261003/`. Its `RESUME.md` identifies
frozen C/H, fixture/codec/builder, independent literal oracles and the incomplete
runner fragments. Independent C/H static review found no blocking issue within
the supplied contract. C/H and the separately reviewed fixture are integrated;
an additional private duplicate-callback guard is preserved as fixture V2.
The 40-case runner and independently frozen gate are assembled and statically
reviewed. Gate V1/V2 preserve two pre-execution ABI expectation corrections.
The first focused run passed all40 sanitized host cases (4784 event rows), then
target compilation stopped because disposable GCC headers were missing. There
was no target ELF, audit, QEMU execution or paired report. Exact144-source closure,
six fixtures, all raw host captures and log are sealed in
`analysis/usb-path/udc-publish/source-snapshots/first-host-toolchain-stop.*`.
No candidate correction followed. The first GCC recovery exposed missing
binutils archive tools; the pinned binutils recovery passed its byte gate after
using a fresh scratch source directory (the old Git metadata was incomplete).
Pinned GCC recovery is running again. Retry the identical candidate after it
finishes, then apply the frozen independent gate and corruption controls.
Shared-suite integration follows; keep validators sequential and sources frozen.
The archive preserves two nested baseline paths and one earlier README template
with explicit hash metadata; do not silently repair the frozen package. Earlier
primary/cache reviews and original-byte checks remain in `next-publication-reviews.*`.

The selected synchronous arm wrapper checks readiness and the stopped/settled
window BEFORE existing prepare writes HOST_READY. It then reuses the actual
adapter reserve/bind, original cookie and descriptor, with explicit RX64/descriptor16
cache hooks and immediate DESPTR/CNAK/readback/RDE command construction. No proposal
escapes. A failure retains its exact cookie/prefix until external cleanup; reset
alone cannot clear it. Preserve fenced receive accounting until the later existing
three-promise restart. Never require receive.count0 for failure cleanup.

Mode, safe IN SNAK, FIFO geometry, complete table, endpoint defaults, global RX/
SETUP readiness, register stability, mapping/cache and physical settlement remain
supplied. No physical DCD exists. Boot, engine behavior, physical status/printing
and power-cycle recovery are unproved. Never run validators concurrently, edit
captured sources during a run or manually relabel report hashes. Recover
disposable tools only through the pinned scripts in the analysis map; the presence
of compiler binaries alone does not establish complete headers/archive tools.

Keep separate:26 completed empty-document lifecycles, six conditional original
null reads,28 retirement cases,36 native page lifecycles with supplied completion,
and42 fragment/bypass cases. USB/component tests add zero physical USB or native
page lifecycles. Do not repeat cancellation/END_DOC or completed IRQ/SETUP research.
Continue beyond a passing checkpoint while the owner is away.

## Installed Mac driver (separate, preserve)

The authorized HP-based native driver uses Apple's renderer, unchanged foo2zjs
and a per-job CUPS backend. CUPS owns copies, queueing and job lifetime. README
owns clone/install/uninstall; MANIFEST owns validation/recovery. No app/package,
ZIP or Homebrew runtime is required. Do not restore the obsolete daemon/runtime.

Support checks passed35 printing,14 setup, three sandbox and five actual macOS
scheduler cases with simulated transport. Installed signatures/ownership/bytes
matched the build and the queue was empty/idle; actual copies, status/recovery
and fresh-Mac installation remain unverified. Evidence:
`assets/macos-system-validation.json`, `/private/tmp/hp1020-system-install-20260928-2/`.
Root-only migration backup: `/private/tmp/hp1020-native-migration-backup-20260928/`.
System checks require separate authorization; no physical print occurred here.
