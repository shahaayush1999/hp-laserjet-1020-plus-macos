# OUT1 acquisition proposal — unexecuted

This package changes copied sources only. No import, compilation, validator,
QEMU, stock execution, register operation, USB contact or repository edit was
performed. The lead owns integration and all execution after the publication
checkpoint. `baseline/` preserves the exact inputs named by `BASELINE.sha256`;
`draft/` contains complete proposed source files. `acquire.patch` is the unified
repository-relative change. Frozen supporting reviews are in `reviews/`.

## Scope and compatibility

The only source changes are a private common locked observer plus the new
acquisition functions in `open-firmware/udc-out/hp1020_udc_out.c`, and the new
adjacent `hp1020_udc_acquire.h`. The old OUT header, object layout, result values,
initializer, prepare, publication, observe, fault and cancellation contracts are
unchanged. Historical callers do not need new hooks or another C translation
unit. The same quoted-directory include resolves the new header for old builds.
Source closures must include that header before any validation is run.

The new `hp1020_udc_acquire` contains a fixed OUT pointer, hook configuration and
diagnostics. It has no packet owner, busy flag, queue, phase, admission counter,
generation, cancellation flag or cleanup permission. The OUT component's busy,
cookie, phase and fault fields remain authoritative. This separate context keeps
the established OUT layout intact and preserves hook-failure evidence without
changing the existing retirement operation, which intentionally clears its live
fault/cookie fields.

The context must be zero-initialized and initialized exactly once, before the
adapter has any control epoch or submission. Init rejects an already initialized
context, any active/faulted OUT, any adapter owner/reservation/response, and any
post-first-control/submission state. Retired/reset state never authorizes
reinitialization. Context and hook configuration remain stationary and read-only
to the caller. All existing nonalias and serialized/nonreentrant preconditions
continue to apply; numeric checks do not discover physical aliases.

## Public interface and operation

`hp1020_udc_acquire_init(context, out, hooks)` returns the existing OUT result
domain. `hp1020_udc_acquire_packet(context, original_cookie, endpoint_fault,
facts)` is the completion-acquisition ingress. Facts are ordered:
`transfer_settled`, `mapping_lease`, `cache_range_safe`, each exactly0/1.

The original cookie is matched against both the retained OUT record and the
adapter's actual DCD owner before any hook or descriptor/payload load. The
retained buffer must match that owner's original64-byte binding. There is no
current-epoch, mounted or progress7 test: old exact ownership can settle while
ordinary work is fenced. A free/stale/PENDING record is STALE, normal PREPARED
is INVALID, and active/reentrant calls WAIT. Missing required facts WAIT and
malformed facts INVALID; those refusals leave context diagnostics untouched.

Known endpoint/local faults require no physical-settlement fact and perform no
cache operation or descriptor snapshot. They call the existing retained fault
path after argument/current-owner validation. Supplied endpoint_fault remains
a reason, not an unfiltered hardware status word.

Normal acquisition runs exactly:

1. `descriptor_for_cpu(context, original_cookie, retained_span16)`.
2. `payload_for_cpu(context, original_cookie, retained_span64)`.
3. `acquire_order(context, original_cookie)`.
4. Copy exactly16 actual CPU bytes from the retained descriptor into a local
   immutable observation, then run the same locked observer as the historical
   API with the two visibility facts justified by the completed hooks.

The payload never moves to a new production buffer. Its full owned64-byte prefix
is synchronized independently of the later status count; no descriptor field is
decoded before all hooks succeed. No caller snapshot or visibility boolean is
accepted by this new interface. Hooks are mandatory; weak successful no-ops are
not supplied. A coherent/uncached provider requires a separately established
physical capability. Acquire ordering must cover cache operations and subsequent
CPU loads; a release-only register barrier is insufficient.

Success means only that the existing observer admitted a separately settled,
acquired packet. OUT becomes FREE and the adapter stays PENDING until ordinary
service. This function never pumps, parses, rearms, modifies endpoint defaults,
clears other failure records, emits status, or grants reset promises.

## Failure and diagnostics

Hook outcomes use OK0 / NOT_PERFORMED1 / UNKNOWN2. Every nonzero result, including
a malformed value, stops the sequence and latches the distinct software reason
`0x80000103` into the existing OUT fault path. The hook has already returned
before adapter fault/cancel-request delivery occurs. The adapter cancellation
callback must continue to queue work; it must not reenter the OUT component.

No visibility hook is retried after the latch. A later call only retries existing
fault delivery, retaining the original borrowed bytes. WAIT/ADAPTER_ERROR from
that delivery must be resolved before ordinary service/pump. Old retained faults
use their old transport/generation identities; STALE fault delivery cannot fence
newer work, but the old component still requires explicit settled cancellation.
Normal missing-fact/busy/not-DONE WAIT may retry the whole operation with a fresh
lease. Never reuse a prior visibility result for a later packet.

Exact-cookie cancellation remains separate and does not require cache work
merely to discard the packet. A clean late success after an ordinary cancel
request retains the existing observer behavior. A latched acquisition/descriptor
fault cannot be erased by a later clean descriptor. No new failure-cleanup API
is added. A prior publisher/program failure is neither satisfied nor cleared by
acquisition or cancellation settlement.

`last` records an admitted acquisition or fault-only call. It has the original
cookie, successful prefix, most recently attempted operation/range, raw hook
result, OUT result/reason, and a snapshot-valid flag with the actual copied16
bytes. Successful prefix bits are descriptor1, payload2, order4, snapshot8;
normal capture is15, while hook failures retain0/1/3 respectively. Order range
is dma0/bytes0. Fault-only calls have prefix0 and no snapshot. Rejected preflight,
stale and busy calls do not reset these diagnostics.

`first_failure` and `failure_valid` record only acquisition-hook failures. They
survive retry, cancellation, reset and subsequent successful packets. Only a
hook failure of a genuinely later retained cookie may replace that history.
Fault-only retries update `last`, not `first_failure`. Existing descriptor-body
or status failures keep their historical reasons and the captured `last`
snapshot; they are not relabeled as I/O failures. Diagnostics grant no admission
or cleanup authority. Serialize named fields rather than C struct padding.

## Integration and independent controls

Apply only after the lead's current frozen validation finishes. Preserve the
existing observer suites/ABI. A separate optional fixture variant should route
normal bulk completion solely through the acquisition entry, disabling arbitrary
observation/saved-snapshot completion bypasses for that variant. Original-cookie
cancellation remains available. No new source object needs adding to link lists;
the source manifest must include the new header. Actual structure size must be
measured by later compilation, not guessed here.

The existing publisher's ordinary forward gates remain in force. Acquisition
must be invoked outside active stack/program/publication callbacks even when
those gates are blocked; it is settlement ingress, not forward work. The OUT
busy guard rejects recursive acquisition, observation, prepare and cancellation.
It does not turn arbitrary forbidden hook calls directly into the adapter into
safe operations: hooks must not reenter the adapter, dispatch events or run
service/pump. Do not claim this draft replaces that serialized-call contract.

The independent fixture/oracle agent owns a separate review and proposed trace
kinds6 descriptor-for-CPU,7 payload-for-CPU,8 acquire-order. Device images remain
separate from initially poisoned CPU storage. OK copies the witnessed original
range, NOT_PERFORMED copies none, and UNKNOWN can record an explicit partial
effect. This tests range/effect and ownership ordering; ordinary RAM cannot prove
every possible speculative or early CPU load occurred only after a barrier.
Capture exact source versions and raw effects before later host/target execution.

Useful bounded controls: every hook failure/result; no hook for stale/PENDING/
PREPARED/reentry or unknown facts; zero/short/full packet and one existing exact
document; original-cookie cancellation after a partial acquisition with nonzero
retained receive accounting; reset/held-ingress settlement; old cookie after
descriptor reuse; init rejection before, during and after active/faulted use;
failure history preserved over a later successful packet, then replaced only by
a new genuine failure. No need to duplicate the existing descriptor-policy
matrix or original IRQ/SETUP/cancellation experiments.

## Limits

The frozen cache/primary notes retain original-byte and family-reference anchors.
No new original code was executed. CPU/DMA mapping, cache granule/isolation,
physical cache/acquire primitives, stable observation, transfer settlement,
event identity, controller mode, global RDE/SETUP readiness and actual printing
remain supplied/unproved. A correct injected sequence is progress toward a DCD,
not evidence that the printer receives a packet.
