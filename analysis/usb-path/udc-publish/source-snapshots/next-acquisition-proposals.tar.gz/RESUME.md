# Unexecuted acquisition proposals at the publication checkpoint

No acquisition candidate has been compiled, imported, executed or validated.
Production V2 changes initialization wording only; its C is identical to V1.
The original OUT layout and public observer API remain unchanged. The new entry
shares its locked observer, original owner/fault/cancel state and adds only
mandatory descriptor16/payload64/acquire-order hooks plus diagnostics. Physical
settlement, mapping, cache range safety and real ordering remain supplied.

Fixture has80 added words for576 total and twelve raw captures including the
144-byte separate synthetic device image. Only size words59/425/490/555 differ
across CPU engines. Immutable32-profile expectations preceded the new C review.
Private actual callback and hook reentry probes use natural busy guards.

Root header/Host/target replay fragments are incomplete without a scenario body
and independent gate, which were still being drafted when this archive froze.
They are NOT an executable validator. The Host review additions preserve refused
image bytes, original ownership/recovery and earlier first-failure diagnostics.
Its exact pre-review version remains beside the current fragment. The visibility
helper is bounded to the frozen profiles, which reinstall poison before a retry.

To resume, verify member hashes, review production V2 and fixture notes, then
complete/review scenarios and a separate gate before integration/execution. Keep
root responsible for all sequential validation. Integrate only after preserving
the fully tested publication checkpoint. Preserve exact source/capture identities
and every unexpected result before corrections. Do not contact USB or touch the
installed printing setup. This archive adds no physical/native lifecycle.
