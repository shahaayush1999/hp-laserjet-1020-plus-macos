def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', action='store_true')
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    temp = Path(tempfile.mkdtemp(prefix='hp1020-udc-acquire-', dir='/tmp'))
    print('Bulk acquisition captures: '+str(temp), flush=True)
    tested = sources(temp)
    evidence = dict(setup=comp.setup_original_reference(ROOT, core.sha),
                    ep0=ep0.original_reference(), bulk=bulk_reference.original_reference())
    fixtures = [base.pages.OUT/name for name in (
        'fixtures/32x8-stripe4-black.jbg', 'fixtures/9600x132-stripe128-edges.jbg',
        'fixtures/16384x4-stripe128-edges.jbg', 'output-fixtures/1024x260-stripe128-repeat.jbg',
        'output-fixtures/64x12-stripe4-edges.jbg')]
    fixtures.append(ROOT/'analysis/samples/generated/matrix-a4_default.zjs')
    fixture_bytes = {str(p.relative_to(ROOT)): p.read_bytes() for p in fixtures}
    fixture_hashes = {n: core.sha(raw) for n,raw in fixture_bytes.items()}
    for name,raw in fixture_bytes.items():
        destination = temp/'tested-fixtures'/name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
    (temp/'fixture-sha256.json').write_text(json.dumps(fixture_hashes, indent=2)+'\n')

    def unchanged():
        assert all(core.sha((ROOT/n).read_bytes()) == digest for n,digest in tested.items()), 'source changed during execution'
        assert all((ROOT/n).read_bytes() == raw for n,raw in fixture_bytes.items()), 'fixture changed during execution'

    effective = runpy.run_path(str(ROOT/'scripts/prepare-hp1020-tinyusb.py'))['prepare'](temp/'effective-source', True)
    compile_host(temp, temp/'effective-source')
    document, images, used = base.image_documents(temp)
    assert set(used) == set(fixtures)
    unchanged()
    cases, replay = [], []
    matrix = profiles()
    for index,(name,fill,capacity,interface) in enumerate(matrix):
        assert capacity == 64 and interface == 0
        directory = temp/f'case-{index:03}'
        directory.mkdir()
        title = f'{name}/fill={fill}/capacity=64/interface={interface}'
        (directory/'case-name').write_text(title+'\n')
        h = Host(temp/'host', directory, fill, 64, interface)
        try:
            acquisition_oracles = scenario(h,name,document,images)
            captures = h.finish()
        finally:
            h.abort()
        assert len(h.events) == len(h.rows) == len(h.ep0_rows) == len(h.out_rows) == len(h.setup_rows) == len(h.offload_rows) == len(h.program_rows) == len(h.publish_rows) == len(h.acquire_rows)
        cases.append(dict(case=title, scenario=name, fill=fill, capacity=64, interface=interface,
            status='pass', initial=h.initial, initial_ep0=h.ep0_initial,
            initial_bulk=h.out_initial, initial_setup=h.setup_initial, initial_offload=h.offload_initial, initial_program=h.program_initial, initial_publish=h.publish_initial, initial_acquire=h.acquire_initial,
            steps=h.rows, ep0_steps=h.ep0_rows, bulk_steps=h.out_rows, setup_steps=h.setup_rows, offload_steps=h.offload_rows, program_steps=h.program_rows, publish_steps=h.publish_rows, acquire_steps=h.acquire_rows,
            events=h.events, packet_oracles=h.packets, descriptor_oracles=h.descriptor_oracles,
            bulk_descriptor_oracles=h.bulk_oracles, setup_oracles=h.ingress_oracles, offload_oracles=h.offload_oracles, program_oracles=h.program_oracles,
            expected_program_trace=h.expected_trace, supplied_reads=h.expected_reads,
            acquisition_oracles=acquisition_oracles,
            expected_documents=h.expected_documents, expected_pixels_sha256=core.sha(h.expected_pixels),
            pixels_bytes=len(h.expected_pixels), capture_sha256={n:core.sha(raw) for n,raw in captures.items()}))
        replay.append((h,captures,directory))
        print(f'Bulk acquisition: {len(cases)}/{len(matrix)} host cases passed', flush=True)
    unchanged()
    target = None
    if args.target:
        core.command(['bash', ROOT/'scripts/build-hp1020-udc-acquire-target.sh'])
        built = OUT/'target'
        assert json.loads((built/'effective-source.json').read_text()) == effective
        saved = temp/'target'
        saved.mkdir()
        for path in built.iterdir():
            if path.is_file() and path.name != 'annotated-disassembly.txt':
                shutil.copyfile(path, saved/path.name)
        elf = saved/'target-check.elf'
        artifacts = {p.name:core.sha(p.read_bytes()) for p in saved.iterdir() if p.is_file()}
        program, audit = core.audit_target(elf)
        assert all(core.sha((saved/n).read_bytes()) == digest for n,digest in artifacts.items()), 'audit changed a build artifact'
        artifacts['annotated-disassembly.txt'] = core.sha((saved/'annotated-disassembly.txt').read_bytes())
        (temp/'target-sha256.json').write_text(json.dumps(artifacts, indent=2)+'\n')
        unchanged()
        from hp1020_qemu_ram import QemuRAM
        native = []

        def rows(q):
            result = []
            for symbol,length in (('hp1020_bulk_fixture_stats',96),('hp1020_ep0_fixture_stats',104),
                                  ('hp1020_composed_out_stats',48),('hp1020_composed_setup_stats',40),
                                  ('hp1020_offload_fixture_stats',80), ('hp1020_program_fixture_stats',64), ('hp1020_publish_fixture_stats',64), ('hp1020_acquire_fixture_stats',80)):
                result.append(list(struct.unpack('>'+str(length)+'I',q.read(program.symbols[symbol],length*4))))
            return result

        with QemuRAM() as q:
            version = q.version
            for case,(h,captures,directory) in zip(cases,replay):
                q.load(elf)
                assert q.call0(program.symbols['hp1020_bulk_fixture_reset'],[case['fill'],64,case['interface'],0xffffffff]) == 0
                initial,e,b,s,o,p,u,a = rows(q)
                assert initial[:59]+initial[60:] == h.initial[:59]+h.initial[60:]
                assert (e,b,s,o) == (h.ep0_initial,h.out_initial,h.setup_initial,h.offload_initial)
                assert p[:57]+p[58:] == h.program_initial[:57]+h.program_initial[58:]
                assert u[:58]+u[59:] == h.publish_initial[:58]+h.publish_initial[59:]
                assert a[:59]+a[60:] == h.acquire_initial[:59]+h.acquire_initial[60:]
                for index,(event,host_row,host_ep0,host_bulk,host_setup,host_offload,host_program,host_publish,host_acquire) in enumerate(zip(
                        h.events,h.rows,h.ep0_rows,h.out_rows,h.setup_rows,h.offload_rows,h.program_rows,h.publish_rows,h.acquire_rows)):
                    validate_event(event['words'], bytes.fromhex(event['data_hex']))
                    data = bytes.fromhex(event['data_hex'])
                    if data:
                        q.put(program.symbols['hp1020_bulk_fixture_input'],data)
                    result = q.call0(program.symbols['hp1020_bulk_fixture_step'],event['words'])
                    row,e,b,s,o,p,u,a = rows(q)
                    with (directory/'target-steps.jsonl').open('a') as output:
                        output.write(json.dumps(row+e+b+s+o+p+u+a)+'\n')
                    assert result == row[0] == event['result'] and row[15:17] == [0,1]
                    assert e[2:5] == [0,1,1] and b[7:10] == [0,1,1] and s[12:15] == [0,1,3] and o[11:13] == [0,1]
                    assert row[:59]+row[60:] == host_row[:59]+host_row[60:], (case['case'],index,row,host_row)
                    assert (e,b,s,o) == (host_ep0,host_bulk,host_setup,host_offload), (case['case'],index,e,b,s,o)
                    assert p[:57]+p[58:] == host_program[:57]+host_program[58:], (case['case'],index,p,host_program)
                    assert u[:58]+u[59:] == host_publish[:58]+host_publish[59:], (case['case'],index,u,host_publish)
                    assert a[:59]+a[60:] == host_acquire[:59]+host_acquire[60:], (case['case'],index,a,host_acquire)
                observed = {}
                for name,symbol in (('pixels','hp1020_bulk_fixture_pixels'),('wire','hp1020_bulk_fixture_wire'),
                                    ('documents','hp1020_bulk_fixture_documents')):
                    observed[name] = q.read(program.symbols[symbol],len(captures[name]))
                for name,symbol in (('receive','hp1020_bulk_fixture_receive_storage'),
                        ('output','hp1020_bulk_fixture_output_storage'),('ep0','hp1020_ep0_fixture_storage'),
                        ('bulk_descriptor','hp1020_composed_fixture_out_storage'),
                        ('setup_record','hp1020_composed_fixture_setup_storage'),
                        ('acquire_device','hp1020_acquire_fixture_device_storage')):
                    observed[name] = q.read(q.call0(program.symbols[symbol],[]),len(captures[name]))
                for name,symbol in (('ep0','hp1020_ep0_fixture_storage_bytes'),
                        ('bulk_descriptor','hp1020_composed_fixture_out_storage_bytes'),
                        ('setup_record','hp1020_composed_fixture_setup_storage_bytes'),
                        ('acquire_device','hp1020_acquire_fixture_device_storage_bytes')):
                    assert q.call0(program.symbols[symbol],[]) == len(captures[name])
                observed['program_reads'] = q.read(program.symbols['hp1020_program_fixture_reads']+16, p[24]*12)
                observed['program_trace'] = q.read(program.symbols['hp1020_program_fixture_trace']+16, p[26]*24)
                observed['program_storage'] = (q.read(program.symbols['hp1020_program_fixture_reads'],3104) +
                    q.read(program.symbols['hp1020_program_fixture_trace'],24608))
                sizes = {'program':p[57], 'publisher':u[58], 'acquisition':a[59]}
                assert q.call0(program.symbols['hp1020_acquire_fixture_component_bytes'],[]) == a[59]
                assert q.call0(program.symbols['hp1020_publish_fixture_component_bytes'],[]) == u[58]
                for name,symbol in (('ep0','hp1020_ep0_fixture_component_bytes'),
                        ('bulk','hp1020_composed_fixture_out_component_bytes'),
                        ('setup','hp1020_composed_fixture_setup_component_bytes')):
                    sizes[name] = q.call0(program.symbols[symbol],[])
                assert sizes['ep0'] == 296 and sizes['bulk'] == 80
                for name,raw in observed.items():
                    (directory/('target-'+name)).write_bytes(raw)
                    assert raw == captures[name], (case['case'],name)
                native.append(dict(case=case['case'],status='pass',all_steps_equal=True,
                    all_pixels_wire_notifications_descriptors_and_storage_equal=True,
                    typed_captures_original_cookies_and_grants_equal=True,
                    complete_recorded_io_and_explicit_read_script_equal=True,
                    adapter_state_and_memory_bytes=row[59],component_and_allocation_bytes=sizes,
                    capture_sha256={n:core.sha(raw) for n,raw in observed.items()}))
                print(f'Bulk acquisition: {len(native)}/{len(cases)} target cases passed',flush=True)
        assert all(core.sha((saved/n).read_bytes()) == digest for n,digest in artifacts.items()), 'captured target changed'
        target = dict(status='pass',cases=native,qemu_version=version,elf_sha256=core.sha(elf.read_bytes()),
                      audit=audit,captured_artifact_sha256=artifacts)
    unchanged()
    assert len(cases) == len(matrix) == len(replay)
    if target:
        assert len(target['cases']) == len(cases)
    report = dict(status='pass',source_sha256=tested,fixture_sha256=fixture_hashes,effective_source=effective,
        original_reference=evidence,offload_mode_evidence={n:tested[n] for n in MODE_EVIDENCE},
        hp_dynamic_csr_capability_established=False,automatic_grants_are_acknowledgments=False,
        cases=cases,target=target,target_publisher_bytes=target['cases'][0]['component_and_allocation_bytes']['publisher'] if target else None,
        target_acquisition_bytes=target['cases'][0]['component_and_allocation_bytes']['acquisition'] if target else None,completed_native_page_lifecycles=0,
        usb_transfers=0,actual_peripheral_accesses=0,controller_quiescence_established=False,
        scope='Synchronous post-device acquisition of the original retained OUT descriptor16 and payload64 through mandatory recording hooks, actual CPU copies and the shared existing observer. Separate synthetic device images and poisoned CPU storage, original cookies, partial visibility failures, bounded hook ordering and exact page/document output are compared on host and audited Xtensa RAM.',
        limits='No physical register/cache backend, DMA/IRQ producer, boot, USB traffic or printing. Transfer settlement, stationary exclusive CPU/DMA mappings, safe cache-line envelopes and real acquire/compiler ordering remain supplied. Fixture hook effects are explicit synthetic input copies, not a cache/DMA model. No speculative-load or device-visibility proof follows. Tests add zero native or physical page lifecycles; first profile is full-speed64, configuration0/1, interface0/alt0.')
    name = 'validation' if args.target else 'host-validation'
    raw = json.dumps(report,sort_keys=True,separators=(',',':'))+'\n'
    (temp/(name+'.json')).write_text(raw)
    (OUT/(name+'.json')).write_text(raw)
    (OUT/(name+'.md')).write_text('# Retained bulk-OUT acquisition execution\n\n'+report['scope']+'\n\n'+
        f'{len(cases)} host; {len(target["cases"]) if target else 0} QEMU cases. Every explicit read, attempted register/cache/acquire hook, original identity, device image, CPU visibility effect, packet, pixel, document event and guarded allocation is compared.\n\n'+report['limits']+'\n')


if __name__ == '__main__':
    main()
