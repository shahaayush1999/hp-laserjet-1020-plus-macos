class Host(pub.Host):
    def __init__(self, executable, directory, fill, capacity, interface):
        self.acquire_rows = []
        self.device_images = {}
        self.expected_receive = bytearray([fill])*4096
        self.expected_descriptor = bytes([fill])*16
        self.expected_device_storage = bytes([fill])*144
        super().__init__(executable,directory,fill,capacity,interface)
        self.acquire_initial = self.acquire.copy()
        assert self.acquire[1:3] == [1,0] and self.acquire[7:9] == [0,1]
        assert self.acquire[11] == 0x010101

    def read_row(self):
        if not select.select([self.process.stdout],[],[],30)[0]:
            self.process.kill(); self.process.wait()
            raise AssertionError('acquisition fixture timed out: '+str(self.directory))
        raw = self.process.stdout.readline()
        with (self.directory/'raw-stdout').open('ab') as saved: saved.write(raw)
        assert raw, ('fixture ended early',self.directory)
        row = json.loads(raw)
        assert len(row) == 576
        self.ep0,self.udc,self.ingress = row[96:200],row[200:248],row[248:288]
        self.offload,self.program,self.publish,self.acquire = row[288:368],row[368:432],row[432:496],row[496:576]
        return row[:96]

    def step(self,op,a=0,b=0,c=0,d=0,data=b'',result=OK,expect=None):
        validate_event([op,a,b,c,d],data)
        before_issued = self.row[33] if hasattr(self,'row') else 0
        before_preparations = self.udc[10]
        row = super().step(op,a,b,c,d,data,result,expect)
        self.acquire_rows.append(self.acquire.copy())
        assert self.acquire[7:9] == [0,1] and self.acquire[73:77] == [0]*4 and self.acquire[79] == 0
        assert self.acquire[63] == 1
        with (self.directory/'host-acquire-steps.jsonl').open('a') as saved:
            saved.write(json.dumps(self.acquire)+'\n')
        if op == 6 and self.udc[10] == before_preparations+1:
            slot = before_issued % 4
            self.expected_descriptor = O['words']((0x08000000,0,O['slot_dma'](slot),0))
        return row

    def io(self,expected,invoke,*,supplied=None):
        expected = tuple(expected)
        trace_start,read_start = len(self.expected_trace),len(self.expected_reads)
        reads = list(supplied if supplied is not None else pub.O['supplied_reads'](expected))
        assert len(reads) <= 85
        if reads:
            self.expected_reads.extend(tuple(r) for r in reads)
            self.step(120,len(reads),data=b''.join(struct.pack('>3I',*r) for r in reads))
        failures = [(i,r) for i,r in enumerate(expected) if r[0] != 1 and r[3]]
        assert len(failures) <= 1
        if failures:
            index,row = failures[0]
            op = 143 if row[0] in (6,7,8) else 131 if row[0] in (4,5) else 121
            self.step(op,row[0],trace_start+index+1,row[3])
        event_index = len(self.events)+1
        self.expected_trace.extend((event_index,trace_start+i+1,kind,offset,
            value if kind != 1 or outcome == 0 else 0,outcome)
            for i,(kind,offset,value,outcome) in enumerate(expected))
        value = invoke()
        assert len(self.events) == event_index
        assert self.program[25] == len(self.expected_reads) and self.program[35] == 0
        self.program_oracles.append(dict(event=event_index,trace_begin=trace_start,
            trace_end=len(self.expected_trace),read_begin=read_start,read_end=len(self.expected_reads),
            literal_trace=[list(r) for r in expected]))
        return value

    def acquire_facts(self,raw):
        assert len(raw) == 3
        self.step(141,data=bytes(raw))
        assert self.acquire[11] == int.from_bytes(bytes(raw),'big')

    def device_image(self,token,payload,*,done=True,false_done=False,result=OK):
        assert token in self.bulk and len(payload) <= 64
        original = self.bulk[token]
        slot = original['slot']
        descriptor,data = O['device_images'](slot,bytes(payload),done=done)
        before = self.row.copy(),self.udc.copy(),self.acquire.copy()
        self.step(140,token,int(false_done),data=descriptor+data,result=result)
        if result == OK:
            self.device_images[token] = dict(cookie=original['cookie'].copy(),slot=slot,
                descriptor=descriptor,payload=data,false_done=false_done,input=bytes(payload),done=done)
            poison_d,poison_p = O['cpu_poison'](slot,false_done=false_done)
            self.expected_descriptor = poison_d
            self.expected_receive[slot*1024:slot*1024+64] = poison_p
            guard = bytes([self.fill])*16
            self.expected_device_storage = guard+descriptor+guard+guard+data+guard
            assert self.acquire[9:11] == [before[2][9]+1,before[2][10]+1]
            assert self.acquire[12:14] == [slot,int(false_done)]
            assert self.acquire[19:25] == [1]+original['cookie']
            assert struct.pack('>4I',*self.acquire[69:73]) == descriptor
        else:
            assert self.row[2:96] == before[0][2:96]
            assert self.udc[2:46] == before[1][2:46]
            assert self.acquire[9:61] == before[2][9:61]

    def arm_write(self,data):
        token = self.arm()
        self.device_image(token,bytes(data))
        return token

    @staticmethod
    def diagnostic(values):
        assert len(values) == 17
        return dict(cookie=values[:5],prefix=values[5],dma=values[6],bytes=values[7],
            io_result=values[8],reason=values[9],result=values[10],operation=values[11],
            snapshot_valid=values[12],snapshot_hex=struct.pack('>4I',*values[13:17]).hex())

    def acquire_packet(self,token,*,mutant=0,fault=0,result=OK,fail_kind=None,outcome=1):
        before = self.row.copy(),self.udc.copy(),self.acquire.copy()
        original = self.bulk[token]
        slot = original['slot']
        exact = not mutant and before[1][16:21] == original['cookie'] and ((before[1][44]>>16)&255) == 1
        work = exact and before[1][2] == 2 and not before[1][5] and not fault and before[2][11] == 0x010101
        assert fail_kind is None or work
        trace = O['acquire_trace'](slot,fail_kind=fail_kind,outcome=outcome) if work else ()
        self.io(trace,lambda:self.step(142,token,mutant,fault,result=result))
        if work:
            image = self.device_images[token]
            descriptor,payload = O['expected_visibility'](slot,image['descriptor'],image['payload'],
                false_done=image['false_done'],fail_kind=fail_kind,outcome=outcome)
            self.expected_descriptor = descriptor
            self.expected_receive[slot*1024:slot*1024+64] = payload
            assert self.acquire[14:19] == original['cookie']
            actual = self.diagnostic(self.acquire[25:42])
            wanted = O['failure_fields'](original['cookie'],slot,fail_kind,outcome) if fail_kind is not None else O['captured_fields'](original['cookie'],image['descriptor'],result)
            assert all(actual[key] == value for key,value in wanted.items()),(actual,wanted)
            if fail_kind is not None:
                retained = self.diagnostic(self.acquire[42:59])
                assert self.acquire[2] == 1
                assert all(retained[key] == value for key,value in wanted.items())
                assert self.udc[2] == 2 and self.row[30] == token
                assert self.row[33:36] == before[0][33:36]
            if result == OK:
                assert self.udc[2] == 0 and self.row[30] == 0 and ((self.udc[44]>>16)&255) == 2
                assert self.row[33:36] == before[0][33:36]
                assert self.row[69:73] == before[0][69:73]
                assert self.row[17:18]+self.row[24:26]+self.row[50:59]+self.row[90:96] == before[0][17:18]+before[0][24:26]+before[0][50:59]+before[0][90:96]
        else:
            assert self.acquire[3:7] == before[2][3:7]
            if result in (WAIT,INVALID,STALE):
                assert self.acquire[25:59] == before[2][25:59]
        return self.row

    def complete(self,token,length,usb_result=0,result=OK,service=True):
        if token not in self.bulk:
            return super().complete(token,length,usb_result,result,service)
        assert usb_result == 0
        if result != STALE:
            assert len(self.device_images[token]['input']) == length
        self.acquire_packet(token,result=result)
        if service: self.service()

    def finish(self):
        captures = super().finish()
        raw = (self.directory/'output.acquire-device').read_bytes()
        assert len(raw) == 144 and raw == self.expected_device_storage
        assert captures['receive'] == self.expected_receive
        assert captures['bulk_descriptor'][16:32] == self.expected_descriptor
        captures['acquire_device'] = raw
        return captures

