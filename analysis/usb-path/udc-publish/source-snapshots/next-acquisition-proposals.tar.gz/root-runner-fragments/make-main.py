"""Assemble an unexecuted replay draft from reviewed publication plumbing."""
from pathlib import Path

root=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
destination=Path(__file__).parent
text=(root/'scripts/validate-hp1020-udc-publish.py').read_text().split('def main():',1)[1]
text='def main():'+text

def replace(old,new,count=1):
    global text
    assert text.count(old)==count,(old,text.count(old),count)
    text=text.replace(old,new)

replace("prefix='hp1020-udc-publish-'", "prefix='hp1020-udc-acquire-'")
replace('Bulk publication', 'Bulk acquisition',3)
replace('publication_oracles = scenario(h,name,document,images)', 'acquisition_oracles = scenario(h,name,document,images)')
replace(' == len(h.publish_rows)', ' == len(h.publish_rows) == len(h.acquire_rows)')
replace('initial_publish=h.publish_initial,', 'initial_publish=h.publish_initial, initial_acquire=h.acquire_initial,')
replace('publish_steps=h.publish_rows,', 'publish_steps=h.publish_rows, acquire_steps=h.acquire_rows,')
replace('publication_oracles=publication_oracles,', 'acquisition_oracles=acquisition_oracles,')
replace('build-hp1020-udc-publish-target.sh', 'build-hp1020-udc-acquire-target.sh')
replace("('hp1020_publish_fixture_stats',64))", "('hp1020_publish_fixture_stats',64), ('hp1020_acquire_fixture_stats',80))")
replace('initial,e,b,s,o,p,u = rows(q)', 'initial,e,b,s,o,p,u,a = rows(q)')
replace('assert u[:58]+u[59:] == h.publish_initial[:58]+h.publish_initial[59:]',
        'assert u[:58]+u[59:] == h.publish_initial[:58]+h.publish_initial[59:]\n                assert a[:59]+a[60:] == h.acquire_initial[:59]+h.acquire_initial[60:]')
replace('host_offload,host_program,host_publish)', 'host_offload,host_program,host_publish,host_acquire)')
replace('h.program_rows,h.publish_rows))', 'h.program_rows,h.publish_rows,h.acquire_rows))')
replace('row,e,b,s,o,p,u = rows(q)', 'row,e,b,s,o,p,u,a = rows(q)')
replace('row+e+b+s+o+p+u', 'row+e+b+s+o+p+u+a')
replace("assert u[:58]+u[59:] == host_publish[:58]+host_publish[59:], (case['case'],index,u,host_publish)",
        "assert u[:58]+u[59:] == host_publish[:58]+host_publish[59:], (case['case'],index,u,host_publish)\n                    assert a[:59]+a[60:] == host_acquire[:59]+host_acquire[60:], (case['case'],index,a,host_acquire)")
replace("('setup_record','hp1020_composed_fixture_setup_storage')):",
        "('setup_record','hp1020_composed_fixture_setup_storage'),\n                        ('acquire_device','hp1020_acquire_fixture_device_storage')):")
replace("('setup_record','hp1020_composed_fixture_setup_storage_bytes')):",
        "('setup_record','hp1020_composed_fixture_setup_storage_bytes'),\n                        ('acquire_device','hp1020_acquire_fixture_device_storage_bytes')):")
replace("sizes = {'program':p[57], 'publisher':u[58]}",
        "sizes = {'program':p[57], 'publisher':u[58], 'acquisition':a[59]}\n                assert q.call0(program.symbols['hp1020_acquire_fixture_component_bytes'],[]) == a[59]")
replace("if target else None,completed_native_page_lifecycles=0,", "if target else None,\n        target_acquisition_bytes=target['cases'][0]['component_and_allocation_bytes']['acquisition'] if target else None,completed_native_page_lifecycles=0,")
begin=text.index("        scope='Synchronous")
end=text.index("    name = 'validation'",begin)
text=text[:begin]+'''        scope='Synchronous post-device acquisition of the original retained OUT descriptor16 and payload64 through mandatory recording hooks, actual CPU copies and the shared existing observer. Separate synthetic device images and poisoned CPU storage, original cookies, partial visibility failures, bounded hook ordering and exact page/document output are compared on host and audited Xtensa RAM.',
        limits='No physical register/cache backend, DMA/IRQ producer, boot, USB traffic or printing. Transfer settlement, stationary exclusive CPU/DMA mappings, safe cache-line envelopes and real acquire/compiler ordering remain supplied. Fixture hook effects are explicit synthetic input copies, not a cache/DMA model. No speculative-load or device-visibility proof follows. Tests add zero native or physical page lifecycles; first profile is full-speed64, configuration0/1, interface0/alt0.')
''' + text[end:]
replace('# Recorded bulk-OUT publication execution', '# Retained bulk-OUT acquisition execution')
replace('Every explicit read, attempted register command and ordering hook, original cleanup/grant identity, packet, pixel, document event and guarded allocation is compared.',
        'Every explicit read, attempted register/cache/acquire hook, original identity, device image, CPU visibility effect, packet, pixel, document event and guarded allocation is compared.')
(destination/'main.py').write_text(text)
print('Saved unexecuted replay draft',len(text.splitlines()),'lines')
