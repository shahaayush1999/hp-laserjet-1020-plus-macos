# Wording-only revision, unexecuted

V1 remains unchanged at `/tmp/hp1020-udc-acquire-draft-20261003/`.
The independent reviewer correctly distinguished empty adapter in-flight
preparation/owner/response state from a document's retained receive accounting.
Adapter initialization may stop an already-used receive queue without clearing
its count. The new header and package README now describe the actual check and
preserve caller document-lifetime preconditions. No new count-zero or cleanup
rule is proposed.

The complete acquisition C file is byte-identical to V1:
`63361d26de832654eeb75f3a87248d1badb08d074419ff870880127e6d7ba91c`.
Existing OUT header/layout and every function/result/fact/diagnostic ABI are
unchanged. Only comments in the new header and explanatory package text change.
No compilation, import, test, validator or target execution has occurred.
