"""Compare completed publication checkpoint evidence, never execute candidates."""
from pathlib import Path
import hashlib
import json

ROOT=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
BASE=Path('/tmp/hp1020-publication-baseline-20261003')
OUTPUT=Path('/tmp/hp1020-publication-full-comparison-20261003.json')
assert not OUTPUT.exists()
rows=[]
for old_path in sorted(BASE.glob('*.json')):
    if old_path.name=='host-retry-comparison.json': continue
    new_path=ROOT/'analysis/usb-path'/old_path.stem/'validation.json'
    a,b=json.loads(old_path.read_text()),json.loads(new_path.read_text())
    assert a['status']==b['status']=='pass',old_path.stem
    assert a['cases']==b['cases'],(old_path.stem,'host case behavior/captures changed')
    at,bt=a.get('target'),b.get('target')
    assert bool(at)==bool(bt)
    if at:
        assert at['status']==bt['status']=='pass'
        assert at['cases']==bt['cases'],(old_path.stem,'target case behavior/captures changed')
    rows.append(dict(component=old_path.stem,host_cases=len(a['cases']),
        target_cases=len(at['cases']) if at else 0,all_case_rows_oracles_and_capture_hashes_equal=True,
        baseline_report_sha256=hashlib.sha256(old_path.read_bytes()).hexdigest(),
        current_report_sha256=hashlib.sha256(new_path.read_bytes()).hexdigest()))
result=dict(status='pass',comparison='pre-integration reports versus full publication suite',
    scope='Case behavior and capture identities only; source/tool/build metadata may change.',components=rows)
OUTPUT.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
