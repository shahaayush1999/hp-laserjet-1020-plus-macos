# Frozen publication fixture integration review

2026-10-03. Read-only static review of the recovered package at
`/tmp/hp1020-publication-resume-20261003/`. No repository or draft edits, imports,
compilation, validators, QEMU, USB or physical operations. This reviews the
fixture integration, not the previously reviewed production contract. The lead
owns application and all sequential execution.

**No blocking fixture integration defect found within the declared serialized
recording profile.** The notes below distinguish verified wiring from untested
coverage boundaries. Nothing here claims this unexecuted fixture passes.

## Actual callbacks and retained ownership

`udc-publish-test/fixture.c:126–186` routes the genuine bulk callback through the
new helper. Its first guard rejects an already-live ledger before it can replace
that ledger. It snapshots the selected actual receive prefix before preparation
and detects binding from `adapter.owners[2]`, independently of helper success.
Lines150–169 verify the complete returned/original/component cookie and actual
buffer/mapping, then retain the packet, shadow and history even when the helper
returned a post-bind failure. This occurs before false returns to TinyUSB; the
adapter's later cancellation callback therefore finds the original live packet.

PREPARED versus EXPOSED is observed from the component separately from command
success. Lines170–181 build proposal-equivalent diagnostics from the original
buffer and fixed addresses, without another take or copying production output
into an expected descriptor. Exposure after a failed register prefix is retained.
The allowed descriptor shadow is literal `08000000,0,selected_dma,0`.

The shared composed cancellation worker runs after the actual step/arm has
unwound. Existing `composed_observe` and `composed_cancelled` check borrowed
storage through component retirement before clearing the packet ledger's live
flag. There is no synchronous fault/settlement callback added by the new hooks.

## Independent cache and storage witnesses

`publish_cache_record:48–78` obtains its cookie witness from the real adapter
owner at hook entry. It compares all original cookie fields, exact owner buffer,
length64, actual callback slot, original payload bytes and independent literal
descriptor bytes. Kind4 requires the selected receive CPU pointer/DMA/64; kind5
requires the dedicated descriptor CPU pointer/DMA/16. The recorded DMA/length
does not replace the CPU-identity comparison, and no raw CPU pointer is serialized.

The temporary omission of whole-composed checks while preparation replaces its
old shadow is deliberate and bounded. The hook validates the newly built bytes,
then the final callback guard checks the whole composed state after the allowed
shadow is updated. The base step protects all receive/output memory during arm;
the payload is not writable merely because the fixture borrowed it. Existing
descriptor/SETUP/EP0 guards and the read/trace shadow checks remain in place.

Each hook uses the original single fault schedule. Cache kinds4/5 add trace rows
without falsely incrementing the older read/write/order counters. Scripted reads
remain independent inputs; writes do not emulate FIFO, NAK or RDE effects. An
invalid range/cookie causes a harness violation even if an injected outcome is
also present. Full used/unused guarded storage is retained by the codec.

## Admission, reset and cleanup seams

The three shared-file diffs are optional. Without `HP1020_COMPOSED_PUBLISH`, the
arm macro defaults to the original adapter call and all previous program/composed
paths remain selected. In the publication variant, init occurs after program,
OUT and bridge initialization and before any control or transfer activity.

The actual final `dcd_edpt_xfer` and direct `dcd_set_address` checks still route
through the program fixture's wrapper, now calling combined publisher submission
permission. Ordinary service/progress use the combined publisher wrappers; op6
uses the actual arm wrapper. Existing composed scheduling gates cover pump,
finish, finish-reset and manual EP0 publication. Ops14/60/61 cannot bypass the new
bulk path; already-disabled ops102/106/107 remain disabled.

The additional program guard applies to selection/grant ops123/124. It rejects
local publication failure/active calls but correctly retains the program's own
SERVICE-only `complete_selection` admission. Requiring combined7 there would
prevent valid SI readiness from ever being established. Diagnostic program
progress remains the underlying program value; publisher word7 is the combined
permission, so the two must not be conflated by the runner.

Cleanup op133 uses an original saved history cookie, with explicit independent
field mutations. It snapshots the entire receive metadata, class reset ticket,
reset active/part flags and output-quiescence promise, and checks those remain
unchanged. It also checks no new I/O. A successful cleanup independently requires
no live packet/adapter/prepared/delivering/response owner, OUT FREE, stopped and
unmounted/fenced state. Recorded before/after counts preserve nonzero old receive
accounting; cleanup does not fabricate the later three-promise restart.

Original-cookie settlement and actual reset admission remain outside ordinary
progress gates. The production wrapper decides the admitted inactive-reset
SERVICE exception; the fixture does not substitute a mounted-only state or
clear publisher failure when a reset is notified.

## Diagnostics, codec and target envelope

The row layout sums to496 words:96+104+48+40+80+64+64. The first432 positions are
preserved. Publisher words22–35 and the query digest serialize14 explicit fields,
including five original cookie fields, with no padding or pointer dependence.
The digest's initial poison words and byte fields agree with the C initializer.
Rejected queries compare the complete output object bytes before/after. Reserved
publisher word63 remains0. The three host/target size exclusions are absolute
59,425 and490; publisher size is measured by its getter rather than guessed.

The host codec requires exactly7 payload bytes for op130 and none for131–134.
Its existing maximum1024-byte input/read checks remain intact. Argument envelopes
are then enforced by the shared fixture: exact zero fields where required,
future injection ordinal/kind/outcome, full-byte cleanup facts and bounded
slot/rhport/endpoint/length for direct probes. Seven-byte raw facts intentionally
reach the production boolean checks unchanged.

Read and trace storage sizes remain3104 and24608; their used payloads begin at
the existing symbols+16 and the full27712-byte guarded envelope is serialized.
The codec preserves all previous output arguments/captures and explicitly writes
word captures in BE. The linker is the same synthetic RAM layout/entry. The
builder changes only destination/source/include names plus the new production
unit, retaining pinned materialization/profile, freestanding flags, undefined
symbol and disassembly checks. It still delegates the independent ISA audit to
the runner before QEMU.

## Coverage boundaries for the lead

1. Direct helper probes at fixture lines251–265 happen only after the arm wrapper
   returns, including the second probe with a retained owner. They demonstrate
   out-of-window rejection and immutable output; they do **not** exercise a
   second helper call while the original synchronous arm call is still active.
   The present40-case plan can accurately describe the former. If it claims the
   one-shot window-consumption branch itself executed, a separate intentional
   in-callback probe is needed; the current ABI cannot produce it. This is a
   coverage limit, not a demonstrated production defect.
2. Init uses only the one valid fixed mapping table. Numerical invalid-map,
   overlap/alignment/wrap and missing-hook init rejection paths are not exercised
   by this fixture's current event ABI. Per-transfer exact CPU/DMA/range witnesses
   are independent and useful; they are not negative init tests or evidence of
   physical mapping/cache validity.
3. The recovered runner contains unfinished fragments, not a target replay main.
   This fixture review cannot establish its forthcoming event/payload validation,
   complete496-row replay, size exclusions, source closure or capture comparisons.
   In particular the target must enforce the same op130/131–134 payload envelopes
   before copying inputs/calling the five-word fixture API, which has no length
   argument. Preserve all11 prior capture pairs plus the existing full storage
   envelope and used cache trace rows. Those are review obligations for the
   completed runner, not a reason to claim a fixture failure now.

## Exact inspected source identities

Paths below are relative to the recovered package unless stated otherwise.

```text
04539e509e1a29cdf48de6df395159b84eb06fba1a87f2576e7cd642e96d85cf fixture/draft/open-firmware/udc-publish-test/fixture.c
f0b18e1afe749e82ad58cb14c4df8ea24cc61621159f5ccebb179108753a7612 fixture/draft/open-firmware/udc-publish-test/host-check.c
2abbd11da052e76b4d5f8d7815b881d7b5b0f32657927bb340e4e768c04ff84e fixture/draft/open-firmware/udc-publish-test/target-check.ld
9eb0a91bd82df9d97fd572d9d499e2953f37321073820ba3290974a72ed6370b fixture/draft/open-firmware/udc-publish-test/README.md
fad897c3a274e0d2d06cdef7c2e7d31a3cd196ade23bdc2250fa2e5b01bafd22 fixture/draft/open-firmware/tinyusb-printer-test/fixture.c
3a9fde438d4a969a913409755e6663263761e1b9d926816c44826834900e8626 fixture/draft/open-firmware/udc-composed-test/fixture.c
66414a2dfda05cd25c15b8ee5b060d17c4f24acd116162c7af7727b9a3969501 fixture/draft/open-firmware/udc-program-test/fixture.c
10d49019462026085f06442b7448a409ff01f44dc8e0b018577c74c261617129 fixture/draft/scripts/build-hp1020-udc-publish-target.sh
69075b35d64ab3e62f93619f6a3858d401cb994633f721bc97193650784665e2 fixture/fixture.patch
e3b5cb3a083a6f0988247da3a9c50c5dc7b284e41a86bc4b332fe09b88fefb9b fixture/manifest.json
37056d75049abcbeb543e2844a908a5022a28b7f1a2dc9d0e874444220bd3a10 fixture/INTEGRATION.md
9b985218b829ec12bd62d78ed840833c1af7216c2b7e85ecf2cf14236f8f655a review/fixture-plan.md
d294b122ad0321ead398995eaac7edb5333d78a166ddc52a521270c108055ab8 fixture/references/udc-publish/hp1020_udc_publish.c
4dad4d4e0b1b59e10bfbac77cb9be59a0243bf52b34233aa287601d3395b49fd fixture/references/udc-publish/hp1020_udc_publish.h
e8f98e821f468e6dbb0788bdaa5dcd1b53d273be4e660728fd7c34d9ec622463 fixture/original/open-firmware/tinyusb-printer-test/fixture.c
8c2089d9ae14e5ca364ac727f546488829d6935f1daa0027d38e6858ab2378eb fixture/original/open-firmware/udc-composed-test/fixture.c
94ed7e6893085a253c41e08f01d397100a0f60f1eaa27cc78c1666977a677dbc fixture/original/open-firmware/udc-program-test/fixture.c
```

The independently reviewed production source remains unchanged. The previously
reported nested root-document snapshot paths are already documented by RESUME;
this review did not alter or repackage the frozen archive.
