"""Seal static reviews and negative controls without duplicating base captures."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
TMP = Path('/tmp')
BASE = TMP/'hp1020-udc-publish-rq1quaka'
NEGATIVE = TMP/'hp1020-publication-negative-first-20261003'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
files = {}
for label, directory in [
    ('fixture-v2', 'hp1020-publication-fixture-v2-20261003'),
    ('root-integration', 'hp1020-publication-integration-20261003'),
    ('independent-gate', 'hp1020-publication-gate-draft-20261003')]:
    for path in (TMP/directory).rglob('*'):
        if path.is_file(): files[label+'/'+path.relative_to(TMP/directory).as_posix()] = path.read_bytes()
for label, name in [
    ('fixture-review.md', 'hp1020-publication-fixture-review-20261003.md'),
    ('runner-review.md', 'hp1020-publication-runner-review-20261003.md'),
    ('scenarios-draft.py', 'hp1020-publication-scenarios-draft-20261003.py'),
    ('scenarios-integration.md', 'hp1020-publication-scenarios-integration-20261003.md'),
    ('next-acquisition-review.md', 'hp1020-publication-next-acquire-review-20261003.md'),
    ('gate-first.log', 'hp1020-publication-gate-first-20261003.log'),
    ('gate-raw-first.log', 'hp1020-publication-gate-raw-first-20261003.log'),
    ('negative-first.log', 'hp1020-publication-negative-first-20261003.log'),
    ('tool-recovery/gcc-first.log', 'hp1020-gcc-recovery-20261003.log'),
    ('tool-recovery/binutils-stale-source.log', 'hp1020-binutils-recovery-20261003.log'),
    ('tool-recovery/binutils-fresh.log', 'hp1020-binutils-recovery-fresh-20261003.log'),
    ('tool-recovery/gcc-complete.log', 'hp1020-gcc-recovery-complete-20261003.log'),
    ('host-retry-comparison.json', 'hp1020-publication-baseline-20261003/host-retry-comparison.json')]:
    files[label] = (TMP/name).read_bytes()
results = json.loads((NEGATIVE/'negative-controls.json').read_text())
assert results['status'] == 'pass' and results['count'] == 10
assert all(c['status'] == 'rejected-as-intended' for c in results['controls'])
base_manifest = {p.relative_to(BASE).as_posix():sha(p.read_bytes())
                 for p in BASE.rglob('*') if p.is_file()}
reconstruction = {}
for path in NEGATIVE.rglob('*'):
    if not path.is_file(): continue
    relative=path.relative_to(NEGATIVE)
    raw=path.read_bytes()
    if len(relative.parts)>2 and relative.parts[1]=='capture':
        base_name=Path(*relative.parts[2:]).as_posix()
        if base_manifest.get(base_name)==sha(raw):
            reconstruction[relative.as_posix()] = dict(base_member=base_name,sha256=sha(raw))
            continue
    files['negative-controls/'+relative.as_posix()] = raw
files['negative-controls/unchanged-base-members.json']=(json.dumps(reconstruction,indent=2,sort_keys=True)+'\n').encode()
files['archive-check.py']=Path(__file__).read_bytes()
base_metadata=json.loads((ROOT/'analysis/usb-path/udc-publish/source-snapshots/first-paired-40-cases.json').read_text())
files['README.md']=('''# Publication reviews and corruption controls

Static proposals, reviews and frozen gate versions preceded the first paired run.
The gate and all ten synthetic controls passed on their first execution. Controls
alter copied evidence, never production or the original run; they add no firmware,
host/target or physical lifecycle. Both report-only and raw modes rejected each
control at its named independent semantic contract after paired sealing passed.

To reconstruct each negative capture, copy the corresponding unchanged members
from `first-paired-40-cases.tar.gz`, as listed in
`negative-controls/unchanged-base-members.json`, then overlay that control's saved
changed members. All referenced base and changed hashes are sealed. Do not run
this synthetic report as if it were original execution evidence.

Tool recovery logs include the missing binutils archive tools and stale scratch
Git metadata, followed by successful pinned binutils/GCC recovery. Original pins
and verification gates were unchanged. Acquisition review is an unexecuted next
step, not evidence that post-device acquisition is implemented or validated.
''').encode()
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as gz:
    with tarfile.open(fileobj=gz,mode='w') as archive:
        for name,raw in sorted(files.items()):
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            entry=tarfile.TarInfo(name);entry.size,entry.mode,entry.mtime=len(raw),0o644,0
            archive.addfile(entry,io.BytesIO(raw))
payload=buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as archive:
    assert set(archive.getnames())==set(files)
    for name,raw in files.items(): assert archive.extractfile(name).read()==raw
    for name,record in reconstruction.items():
        original=(BASE/record['base_member']).read_bytes()
        assert sha(original)==record['sha256']
        assert original==(NEGATIVE/name).read_bytes()
metadata=dict(status='frozen static reviews; unchanged gate passed; ten internally paired corruptions rejected',
    archive_sha256=sha(payload),archive_bytes=len(payload),member_count=len(files),
    base_archive='first-paired-40-cases.tar.gz',base_archive_sha256=base_metadata['archive_sha256'],
    referenced_unchanged_members=len(reconstruction),negative_controls=10,
    member_sha256={name:sha(raw) for name,raw in sorted(files.items())})
destination=ROOT/'analysis/usb-path/udc-publish/source-snapshots'
for suffix,data in [('.tar.gz',payload),('.json',(json.dumps(metadata,indent=2)+'\n').encode())]:
    path=destination/('reviews-and-independent-gate'+suffix)
    assert not path.exists();path.write_bytes(data)
print(json.dumps({key:metadata[key] for key in ('archive_sha256','archive_bytes','member_count','referenced_unchanged_members')},indent=2))
