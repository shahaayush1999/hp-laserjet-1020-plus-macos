# Publication reviews and corruption controls

Static proposals, reviews and frozen gate versions preceded the first paired run.
The gate and all ten synthetic controls passed on their first execution. Controls
alter copied evidence, never production or the original run; they add no firmware,
host/target or physical lifecycle. Both report-only and raw modes rejected each
control at its named independent semantic contract after paired sealing passed.

To reconstruct each negative capture, copy the corresponding unchanged members
from `first-paired-40-cases.tar.gz`, as listed in
`negative-controls/unchanged-base-members.json`, then overlay that control's saved
changed members. All referenced base and changed hashes are sealed. Do not run
this synthetic report as if it were original execution evidence.

Tool recovery logs include the missing binutils archive tools and stale scratch
Git metadata, followed by successful pinned binutils/GCC recovery. Original pins
and verification gates were unchanged. Acquisition review is an unexecuted next
step, not evidence that post-device acquisition is implemented or validated.
