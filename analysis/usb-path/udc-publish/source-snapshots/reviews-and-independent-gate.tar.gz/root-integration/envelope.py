def validate_event(words, data):
    """Same explicit binary input envelope before host and target entry."""
    assert len(words) == 5 and all(type(v) is int and 0 <= v <= 0xffffffff for v in words)
    op,a,b,c,d = words
    n = len(data)
    assert n <= 1024
    if op == 44: assert n == 20
    if op == 48: assert n == 4
    if op in (46,65): assert n == d
    if op in (62,80): assert n == 16
    if 100 <= op <= 107: assert n == 0
    if op == 120: assert a <= 85 and n == a*12
    if op in (122,130): assert n == 7
    if op == 124: assert n == 5
    if op in (121,123,125,126) or 131 <= op <= 134: assert n == 0

