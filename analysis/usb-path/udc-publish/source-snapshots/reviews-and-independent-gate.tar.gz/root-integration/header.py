#!/usr/bin/env python3
"""Offline OUT1 arm/publication experiment. Recording hooks only, no device."""
import argparse
import importlib.util
import json
from pathlib import Path
import runpy
import select
import shutil
import struct
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('publish_program', ROOT/'scripts/validate-hp1020-udc-program.py')
pg = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = pg
spec.loader.exec_module(pg)
off, comp, ep0, base, core = pg.off, pg.comp, pg.ep0, pg.base, pg.core
bulk_reference = pg.bulk_reference
SRC = ROOT/'open-firmware/udc-publish-test'
OUT = ROOT/'analysis/usb-path/udc-publish'
PROGRAM = ROOT/'open-firmware/udc-program'
PUBLISH = ROOT/'open-firmware/udc-publish'
MODE_EVIDENCE = pg.MODE_EVIDENCE
OK, WAIT, STALE, INVALID, FAULT, ADAPTER_ERROR, PREFLIGHT_ERROR = range(7)
ORACLES = SRC/'trace-oracles.py'
O = runpy.run_path(str(ORACLES))


def profiles():
    return O['publication_profiles']()


def sources(temp):
    tested = pg.sources(temp)
    selected = set(SRC.glob('*.[ch]')) | set(SRC.glob('*.ld')) | set(PUBLISH.glob('*.[ch]'))
    selected.add(ORACLES)
    selected.update(ROOT/'scripts'/name for name in (
        'validate-hp1020-udc-publish.py', 'build-hp1020-udc-publish-target.sh',
        'check-hp1020-udc-publish.py'))
    for path in sorted(selected):
        if not path.is_file():
            continue
        name = str(path.relative_to(ROOT)); tested[name] = core.sha(path.read_bytes())
        destination = temp/'source'/name; destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
    (temp/'source-sha256.json').write_text(json.dumps(tested, indent=2)+'\n')
    return tested
