from pathlib import Path
root=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
text=(root/'scripts/validate-hp1020-udc-program.py').read_text()
main='def main():\n'+text.split('def main():\n',1)[1]
changes=[
    ("prefix='hp1020-udc-program-'", "prefix='hp1020-udc-publish-'"),
    ('Register program', 'Bulk publication'),
    ('scripts/build-hp1020-udc-program-target.sh', 'scripts/build-hp1020-udc-publish-target.sh'),
    ('len(h.program_rows)', 'len(h.program_rows) == len(h.publish_rows)'),
    ('initial_program=h.program_initial,', 'initial_program=h.program_initial, initial_publish=h.publish_initial,'),
    ('program_steps=h.program_rows,', 'program_steps=h.program_rows, publish_steps=h.publish_rows,'),
    ("('hp1020_program_fixture_stats',64)):", "('hp1020_program_fixture_stats',64), ('hp1020_publish_fixture_stats',64)):"),
    ('initial,e,b,s,o,p = rows(q)', 'initial,e,b,s,o,p,u = rows(q)'),
    ('                for index,(event,host_row,host_ep0,host_bulk,host_setup,host_offload,host_program) in enumerate(zip(',
     '                assert u[:58]+u[59:] == h.publish_initial[:58]+h.publish_initial[59:]\n                for index,(event,host_row,host_ep0,host_bulk,host_setup,host_offload,host_program,host_publish) in enumerate(zip('),
    ('h.events,h.rows,h.ep0_rows,h.out_rows,h.setup_rows,h.offload_rows,h.program_rows)):',
     'h.events,h.rows,h.ep0_rows,h.out_rows,h.setup_rows,h.offload_rows,h.program_rows,h.publish_rows)):'),
    ("                    data = bytes.fromhex(event['data_hex'])", "                    validate_event(event['words'], bytes.fromhex(event['data_hex']))\n                    data = bytes.fromhex(event['data_hex'])"),
    ('row,e,b,s,o,p = rows(q)', 'row,e,b,s,o,p,u = rows(q)'),
    ('json.dumps(row+e+b+s+o+p)', 'json.dumps(row+e+b+s+o+p+u)'),
    ('                observed = {}', '                    assert u[:58]+u[59:] == host_publish[:58]+host_publish[59:], (case[\'case\'],index,u,host_publish)\n                observed = {}'),
    ("sizes = {'program':p[57]}", "sizes = {'program':p[57], 'publisher':u[58]}\n                assert q.call0(program.symbols['hp1020_publish_fixture_component_bytes'],[]) == u[58]"),
    ('cases=cases,target=target,completed_native_page_lifecycles=0,', "cases=cases,target=target,target_publisher_bytes=target['cases'][0]['component_and_allocation_bytes']['publisher'] if target else None,completed_native_page_lifecycles=0,"),
    ('# Recorded controller-programming execution', '# Recorded bulk-OUT publication execution'),
]
for old,new in changes:
    assert old in main,old
    main=main.replace(old,new)
start=main.index("        scope='")
end=main.index("\n    name = 'validation'",start)
main=main[:start]+'''        scope='Synchronous full-speed OUT1 arm and publication through recording cache/register hooks, actual TinyUSB callbacks and the existing adapter/descriptor/document path. Independent literal traces, pre-reservation refusals, retained original failure identity, explicit cleanup, exact pixels and END_DOC are compared in synthetic RAM.',
        limits='No physical register/cache backend, DMA/IRQ acquisition, boot, USB traffic or printing. Mode, stopped receive DMA, global SETUP/OUT readiness, stable register/RDE writers, CNAK window, exact CPU/DMA mappings and safe cache-line envelopes remain supplied. Completion and physical cleanup are external facts. Recorded writes never generate read observations or imply USB acceptance. Tests add zero native or physical page lifecycles; first profile is full-speed64, configuration0/1, interface0/alt0.')'''+main[end:]
Path(__file__).with_name('main.py').write_text(main)
print('Prepared main/target replay fragment without executing the candidate.')
