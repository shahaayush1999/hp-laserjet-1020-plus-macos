# Literal operation sequences are frozen independently of the implementation.
class Host(pg.Host):
    def __init__(self, executable, directory, fill, capacity, interface):
        self.publish_rows = []
        self.use_cnak = True
        super().__init__(executable, directory, fill, capacity, interface)
        self.publish_initial = self.publish.copy()
        assert self.publish[1:7] == [1, 0, 0, 0, 0, 0]
        assert self.publish[53] == 0 and self.publish[63] == 0

    def read_row(self):
        if not select.select([self.process.stdout], [], [], 30)[0]:
            self.process.kill(); self.process.wait()
            raise AssertionError('publish fixture timed out: '+str(self.directory))
        raw = self.process.stdout.readline()
        with (self.directory/'raw-stdout').open('ab') as saved:
            saved.write(raw)
        assert raw, ('fixture ended early', self.directory)
        row = json.loads(raw)
        assert len(row) == 496, row
        self.ep0, self.udc, self.ingress = row[96:200], row[200:248], row[248:288]
        self.offload, self.program, self.publish = row[288:368], row[368:432], row[432:496]
        return row[:96]

    def step(self, op, a=0, b=0, c=0, d=0, data=b'', result=OK, expect=None):
        validate_event([op,a,b,c,d], data)
        row = super().step(op, a, b, c, d, data, result, expect)
        self.publish_rows.append(self.publish.copy())
        p = self.publish
        assert p[2:6] == [0, 0, 0, 0] and p[53] == p[63] == 0, ('publication guards', op, p)
        with (self.directory/'host-publish-steps.jsonl').open('a') as saved:
            saved.write(json.dumps(p)+'\n')
        return row

    def publish_facts(self, values):
        assert len(values) == 7
        self.step(130, data=bytes(values))
        assert self.publish[36:43] == list(values)

    def io(self, expected, invoke, *, supplied=None):
        expected = tuple(expected)
        trace_start, read_start = len(self.expected_trace), len(self.expected_reads)
        reads = list(supplied if supplied is not None else O['supplied_reads'](expected))
        assert len(reads) <= 85
        if reads:
            self.expected_reads.extend(tuple(r) for r in reads)
            self.step(120, len(reads), data=b''.join(struct.pack('>3I', *row) for row in reads))
        failures = [(i, row) for i, row in enumerate(expected) if row[0] != 1 and row[3]]
        assert len(failures) <= 1
        if failures:
            index, row = failures[0]
            self.step(131 if row[0] in (4, 5) else 121, row[0], trace_start+index+1, row[3])
        event_index = len(self.events)+1
        self.expected_trace.extend((event_index, trace_start+i+1, kind, offset,
                                    value if kind != 1 or outcome == 0 else 0, outcome)
                                   for i, (kind, offset, value, outcome) in enumerate(expected))
        value = invoke()
        assert len(self.events) == event_index, 'trace must belong to one actual API event'
        assert self.program[25] == len(self.expected_reads)
        assert self.program[35] == 0, 'scheduled failure must be consumed'
        self.program_oracles.append(dict(event=event_index, trace_begin=trace_start,
            trace_end=len(self.expected_trace), read_begin=read_start,
            read_end=len(self.expected_reads), literal_trace=[list(r) for r in expected]))
        return value

    def arm(self, trace=None, *, result=OK, supplied=None):
        before = self.row.copy()
        slot = before[33] % 4
        expected = O['publication_trace'](slot, self.use_cnak) if trace is None else trace
        self.io(expected, lambda: self.step(6, result=result), supplied=supplied)
        if result == OK:
            token = self.row[30]
            assert token in self.bulk and self.row[31] == 64
            assert self.row[33] == before[33]+1 and self.row[35] == before[35]+1
            cookie = self.bulk[token]['cookie']
            assert cookie == [token, before[5], before[32], before[33]+1, 1]
            assert self.publish[45:50] == cookie
            assert self.publish[62] == slot
            assert self.publish[8] == (O['SUCCESS_CNAK_PREFIX'] if self.use_cnak else O['SUCCESS_NO_CNAK_PREFIX'])
            assert self.udc[2] == 2
            assert self.row[24:26] == before[24:26] and self.row[50:59] == before[50:59]
            return token
        return self.row[30]

    def arm_write(self, data):
        assert len(data) <= 64
        token = self.arm()
        if data:
            self.step(65, token, 1, 0, len(data), data=data)
        return token

    def publication_cleanup(self, token, *, mutant=0, fact=1, result=OK):
        before = self.row.copy()
        previous = self.publish.copy()
        self.step(133, token, mutant, fact, result=result)
        assert self.row[32:48] == before[32:48], 'publication cleanup is not document recovery'
        assert self.row[17:26] == before[17:26] and self.row[50:59] == before[50:59]
        if result == OK:
            assert self.publish[6] == 0 and self.publish[55] == previous[55]+1
            assert self.publish[56:58] == [before[35], before[35]] and before[35] > 0
            assert self.publish[22:36] == previous[22:36], 'historical failure bytes are retained'

    def query_publication(self, result=OK):
        self.step(132, result=result)
        assert self.publish[43] == result
        if result == OK:
            assert self.publish[44] == core.fnv(struct.pack('>14I', *self.publish[22:36]))
