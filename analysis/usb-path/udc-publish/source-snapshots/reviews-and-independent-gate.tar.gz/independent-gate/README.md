# Independent publication capture gate, 2026-10-03

This package contains a pre-execution static draft. This agent has not imported,
syntax-parsed, run or tested either Python version, built source, run a validator,
or touched hardware. Root owns all eventual sequential execution. No repository
file was edited. The implementation/runner's future results were not read.

Use `v2/check-hp1020-udc-publish.py` for the first independent gate attempt. Keep
the original file unchanged as V1. A failed attempt must retain its exact gate,
report and captures before any correction; do not reinterpret it as a pass.

## Frozen identities

| File | SHA256 |
| --- | --- |
| V1 `check-hp1020-udc-publish.py` | `31e6d9f252b532eedf9d51ddf75995b82239513aff432ecd9321b28645022380` |
| V2 `v2/check-hp1020-udc-publish.py` | `03769f37e3a67877ff8100a6ad651fd9f20e5649166340d93c9498d11ec379e0` |
| Existing `scripts/check-hp1020-udc-program.py` | `ad8bb1709b2f9128748ea5900e45eac1c35918612cec193039944cf19f10ea28` |
| Recovered independent `review/trace-oracles.py` | `b677dc57ee631186585fc8759c7b05d5fba30d8b35fb0e5767a94a99e1fdc694` |
| Recovered independent `review/fixture-plan.md` | `9b985218b829ec12bd62d78ed840833c1af7216c2b7e85ecf2cf14236f8f655a` |
| Recovered `fixture/draft/open-firmware/udc-publish-test/README.md` | `9eb0a91bd82df9d97fd572d9d499e2953f37321073820ba3290974a72ed6370b` |

The recovered paths above are relative to
`/tmp/hp1020-publication-resume-20261003/`. The program checker supplied common
source/effective-TinyUSB/raw-capture/target sealing plumbing. Publication
literals and the 20-profile matrix were frozen independently on 2026-10-02,
before the publisher C was read; they are copied into the gate, not imported from
the producer. The gate never accepts `program_oracles`, `expected_program_trace`,
new publication labels or their result classifications as truth. Expected trace
summaries must equal its own reconstruction.

Root confirmed before execution that initial and recovery configuration use the
audited program `INITIAL + GRANT` blocks. The scenario author separately confirmed
the sole ordinary request is raw `8008000000000100` (GET_CONFIGURATION): IN byte01,
then an OUT status ZLP. All other configuration status owners are the existing
typed automatic path, with separate settlement and no ordinary wire ACK. The
preflight controls, direct probes, cleanup mutations and generations match the
old frozen plan; these choices were confirmed without reading runner results.

## V1 to V2: two static ABI corrections before execution

Root found both mismatches during static review, before any candidate execution:

1. The outer composed fixture, lines621-640 of its frozen draft, checks the
   combined permission before op6 calls the direct publisher. A sticky failure
   therefore returns public fixture WAIT1, not the direct publisher's FAULT4.
   V2 changes only this repeated blocked-arm expected result. The first actual
   post-bind failure still returns FAULT4 and keeps the exact expected prefix.
2. Existing `scripts/validate-hp1020-udc-ep0.py:98-115` writes each normal EP0
   descriptor via op46 before passing an immutable observation via op44.
   Existing EP0 fixture414-421 defines that simulated write. V1 incorrectly
   excluded it. V2 requires exactly the IN then OUT descriptor writes for the
   one GET_CONFIGURATION control transfer: statuses8800ffff and88000000,
   correct explicit DMA labels, no payload write, and independently supplied
   actual lengths1 and0. It updates only those 16-byte descriptor regions in its
   independent full EP0 memory oracle. IN low16 is deliberately not the actual
   length. Both64-byte payload tails stay independently checked.

No production expectation, literal publication command, ownership requirement,
negative vector or scenario was changed to accommodate an observed result.

## Public schema and independent checks

`check_publish_report(report, capture_root=None, source_root=None)` returns
`(passed, detail)`. `validate_publish_report` instead raises a precise
`EvidenceError`. The CLI takes report JSON, optional `--capture-root` and optional
`--source-root`. The gate uses only standard-library reads/hashes/arithmetic.

The existing program schema gains `initial_publish` and `publish_steps`; rows
are496 words, with only measured size words59,425,490 omitted from host/target
value equality. Target component sizes add `publisher`, and the report's
`target_publisher_bytes` must match. All source and six fixture hashes, pinned
effective TinyUSB patch closure, target ELF/audit/artifacts and reused original
stock references remain sealed. Physical claims remain false/zero.

The gate independently requires40 paired cases (20 fixed names, fills0/204),
full-speed capacity64/interface0, exact program/first-publication command blocks,
preflight refusal vectors, injection identities, original bind cookies and slot
selection from prior issued count. No CPU pointer supplies a DMA expectation.
It checks each successful prefix, retained phase, exact failure fields,
separately supplied facts, first-failure retention, failed-state scheduling,
original-cookie cleanup and nonzero unchanged reservation accounting. Generation
can advance only at the existing three-promise finish operation.

It rebuilds the complete4096-byte receive allocation from the original raw
simulated DMA writes, full live normal/SETUP/EP0 descriptor storage and EP0 tails,
explicit read script, all-hook trace, and the entire27712-byte guarded recording
allocation including untouched tails. Exactly one32-byte FF page and one
END_DOC record in the specified G2/G3 are independent constants. Interrupted
input yields no extra page. All eleven host/target capture pairs are sealed;
the existing output-allocation hash/ownership witnesses supplement the exact
pixel oracle. No hardware effect, successful USB transfer or physical printing
follows these checks.

The gate is deliberately bounded to the frozen40-case matrix. It is not a
general parser/controller verifier, an IRQ source, a cache/mapping implementation
or a proof of externally supplied physical cleanup. The later immediate
duplicate-callback fixture assertion uses the existing violation field; it
changes neither this public ABI nor the frozen literal oracle.
