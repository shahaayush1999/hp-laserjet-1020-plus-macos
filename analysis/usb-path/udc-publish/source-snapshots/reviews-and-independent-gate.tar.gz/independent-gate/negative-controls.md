# Planned independent gate corruption controls

Unexecuted plan, 2026-10-03. Root performs these only after the untouched V2 gate
has been tried on the untouched first paired run. Never mutate original reports,
captures, gates, tested source hashes or source snapshots. Use disposable copies
and save every mutation/result separately. A changed source report must not be
mistaken for new hardware or firmware execution.

For semantic controls, keep host and target artifacts internally consistent:
change affected report rows and matching raw stdout/target rows, both relevant
capture files, their SHA256 entries in both host/target cases, and the saved
`validation.json`. Update redundant derived summaries when applicable. This
prevents an early report-versus-file mismatch from being the only rejection.
Select steps by semantic operation and original cookie rather than a guessed
case/row index. Recompute SHA/FNV only for the disposable corrupted evidence.
Run report-only and raw-capture modes and record the precise failed condition.

1. **Paired wrong pixel, consistently hashed.** In one successful case change
   one of the32 pixels from FF to FE. Change both pixel captures, their reported
   hashes, `expected_pixels_sha256` and every subsequent pixel FNV witness. The
   gate must reject its own constant32FF oracle, even though the two engines and
   the producer's expected hash now agree on the wrong pixels.

2. **CNAK command replays read-only NAK.** In a full positive CNAK publication
   change the logical write at220 from120 to160 in the producer's expected
   trace, both raw traces and the corresponding used words of both full program
   storage captures. Update capture hashes. Read inputs and trace counts stay
   unchanged. The gate must reject the independently reconstructed command.

3. **Wrong selected receive DMA.** In one first-slot RX cache trace change
   DMA24681340 to24682340, consistently in expected/raw trace and recording
   storage. Optionally propagate the same false mapping through descriptor and
   proposal diagnostics/captures to demonstrate paired agreement. The gate must
   derive slot0 from the pre-arm issued count and reject the different DMA,
   rather than accepting a label from the new publisher.

4. **Wrong successful prefix, consistently retained.** In a post-bind failure
   change its software prefix (for example uncertain DESPTR31 to63) in both
   engines' publisher current/failure fields and all later retained copies.
   Recompute the explicit-field query FNV wherever queried. The hook trace stays
   the original failed sequence. The gate must reject the exact authored prefix,
   not merely inconsistencies between retained copies.

5. **Failure relabeled after reset.** Retag the original publication failure's
   epoch/generation to a newer reset identity in both result streams and all
   later failure/query records, recomputing query FNV. Preserve the real earlier
   bind/cache witness. The gate must reject against the independently saved
   pre-fence original cookie. A more aggressive variant may also retag the owner
   and cache records; the pre-arm identities still establish the original.

6. **Invented settlement at a cache failure.** Change the failing event's OUT
   phase to FREE, adapter owner witness to NONE, fixture live token to0 and
   reservation count to0 consistently across both engines. Leave the original
   raw event sequence without settlement. The gate must reject the required
   PREPARED/DCD original owner and retained count; no implicit cleanup is legal.

7. **Cleanup supplies recovery promises.** On one successful cleanup change
   post-cleanup reset parts/count/generation in both engines to claim recovery,
   while preserving the original cleanup event and prior state. The gate must
   reject unchanged-before/after accounting and three-promise provenance. A
   narrower variant changes only the diagnostics' before/after counts to0;
   the independent nonzero old reservation requirement must reject that too.

8. **Automatic status permission becomes a normal ACK.** At an otherwise valid
   typed grant increment both engines' genuine status callback counter or create
   a synthetic ordinary ZLP publication, propagate later counter values and
   packet summaries consistently. The gate must reject the unchanged-wire/
   ordinary-owner/ACK requirement rather than treat CSR_DONE as wire completion.

9. **Wrong IN actual length justified by descriptor low16.** In the single
   GET_CONFIGURATION case keep the IN descriptor status8800ffff, but change the
   op44 independent actual length from1 to65535 in raw input and report event.
   Make host/target results agree on a claimed success. The gate must reject its
   separate packet-length oracle. Descriptor low16 cannot authorize that count.

10. **Unused storage-tail corruption, paired and rehashed.** Flip one byte in
    a known unused read or trace payload tail in both full27712-byte storage
    captures; update both capture hashes and saved report. Keep guards and used
    records intact. The independently reconstructed fill bytes must reject it.
    This exercises raw storage validation beyond checking an existing hash or
    matching host to target.

Separate integrity controls may also corrupt a raw event header, omit a target
row, or change a source snapshot without updating its manifest. Those should be
rejected, but report them as sealing tests rather than independent semantic
oracle evidence. Do not count variants that fail only due to stale file hashes
as successful semantic controls above.
