# Negative-control driver provenance

Frozen on2026-10-03, without this agent importing, parsing, executing or testing
the driver/gate/candidates, and without repository edits or hardware contact.
Root owns all sequential execution. The first complete report and its captures
were not read to author these controls. Root later reported that the complete
40/40 experiment and unchanged V2 gate had passed; that report is not itself a
test result of this driver.

`run-negative-controls.py` SHA256:
`22b902a964570bef579775cf93af26e7a072edcdc9d44af777895860b0d39496`.

Gate V1 remains `31e6d9f252b532eedf9d51ddf75995b82239513aff432ecd9321b28645022380`;
V2 remains `03769f37e3a67877ff8100a6ad651fd9f20e5649166340d93c9498d11ec379e0`.
Neither was edited for this task. The existing negative-control plan remains
`cbb94fd0702d56af082e656ac1160dbf4fc6b7a103a8818f42ad964b0b1a80c4`.

The driver follows that ten-control plan. The cleanup variant specifically drops
the old issued/consumed/count accounting without a restart. It checks the same
promises/accounting boundary without requiring a prior reset-parts field to have
an unset bit. The final storage control modifies an unused read-allocation byte
in fill204, keeping used records and guard words intact.

Only source/schema excerpts were additionally read: producer report field names,
program `trace_begin/trace_end/literal_trace` metadata and names/layouts of optional
per-layer row logs. No future runtime result informed expected rejection rules.
The relevant source identities at that read were:

| Source | SHA256 |
| --- | --- |
| `scripts/validate-hp1020-udc-publish.py` | `1ce1c22a3dd75a0e14e5a38f4e065db5820bb6e712126a587c217aecc828c486` |
| `scripts/validate-hp1020-udc-program.py` | `15f76489dc4602c7a18caf42b3e9e9149ab941a29c08187e6cc0808651043c7a` |
| `scripts/validate-hp1020-udc-ep0.py` | `b6fa90e24c14c1a38d443c5bec0e48fe0e453b97c9c13fc67ec24ae8afa850bf` |
| `scripts/validate-hp1020-udc-composed.py` | `620cf6c352096085a9d7d8c5808257444ec4db946520beaf0a56df3402ebfe7a` |

## Operation and containment

The CLI requires report, capture-root, selected gate and a new output-root. An
optional gate SHA verifies exact selection. It imports the selected gate only
when root deliberately executes the driver; bytecode-cache writes are disabled
during that import. It uses no producer import, subprocess, build, firmware or
hardware operation.

First it requires a successful unchanged raw-capture baseline. If that fails,
it records the failure and executes no controls. Then each control gets a fresh
deep copy of the report and a separate evidence tree. Unchanged files may be
hardlinked for bounded storage use; **every modified file is replaced atomically**
so no write traverses a link back to original evidence. Cross-filesystem hardlink
failure falls back to ordinary copying. Existing output directories are refused.

For touched cases it synchronizes raw event bytes, host rows, paired target rows
(retaining three actual measured size fields), known auxiliary row logs, both
capture files/digests, redundant literal trace summaries and the saved report.
Source/fixture/target-build manifests stay unchanged. A separate sealing check
requires paired agreement before the gate is called. The corrupt report still
claims success intentionally; `SYNTHETIC-CORRUPTION.json` explicitly marks each
copy as fabricated negative evidence, never a new execution.

Both report-only and raw-capture gate modes must reject at a named independent
contract check. A generic source/hash mismatch, an exception while constructing
the mutation, acceptance or rejection at another mechanism is not counted as a
successful control. Exact changes, paired-check result, gate diagnostics and
mutated-report digest are saved per control; the final summary distinguishes
`rejected-as-intended`, `wrong-result-or-mechanism` and construction errors.
All copies remain available for audit. There is no automatic source/oracle fix.

Root may invoke the draft with the actual completed capture directory:

```sh
python3 /tmp/hp1020-publication-gate-draft-20261003/run-negative-controls.py \
  /tmp/hp1020-udc-publish-rq1quaka/validation.json \
  --capture-root /tmp/hp1020-udc-publish-rq1quaka \
  --gate /tmp/hp1020-publication-gate-draft-20261003/v2/check-hp1020-udc-publish.py \
  --gate-sha256 03769f37e3a67877ff8100a6ad651fd9f20e5649166340d93c9498d11ec379e0 \
  --output-root /tmp/hp1020-publication-negative-first-20261003
```

This is an intended invocation, not a claim that it was run. Exit0 requires all
ten precise rejections; exit1 means a completed matrix had an unexpected result;
exit2 means preconditions/baseline failed. Preserve the frozen driver and exact
first outcome before any later amendment.
