# Publication runner integration review

Static review only, 2026-10-03. No imports, builds, validators, QEMU execution, USB operations, or repository edits were performed.

Reviewed assembled runner: `scripts/validate-hp1020-udc-publish.py`.
SHA256: `1ce1c22a3dd75a0e14e5a38f4e065db5820bb6e712126a587c217aecc828c486`.

No blocking integration defect found in the reviewed wrapper/main. This is not execution evidence or a repeated scenario review.

- Parent module aliases resolve through program -> offload -> composed -> EP0/base/core; original bulk reference and source recovery are retained. Host and target compile the actual new publisher together with the same program, adapter, descriptor, semantic, image and effective TinyUSB implementations. The host retains the independent full JBIG reference decoder.
- The recursive source closure is extended with the new production/test C/H, linker script, oracle, builder, runner and checker. Six fixture files are hashed and copied before use; sources and fixtures are rechecked after host execution, after target construction/audit, and before the report. Effective-source metadata must match the separately built target. The new checker path is currently optional in sources(), as in the program parent: freeze/install the intended checker before first capture if it is to belong to this exact run's source closure.
- Target build artifacts are copied without a stale audit-derived listing. Immutable copied hashes are checked through audit; the freshly generated annotated listing is added afterward. The conservative original-byte-supported ISA audit runs before QEMU is imported or entered. Captured target hashes are checked again after replay.
- Every row is exactly 496 words with partitions 96/104/48/40/80/64/64. Host row-list lengths are explicitly equal to event count before replay, so zip cannot silently truncate. Only the three known host/target sizeof words are excluded: base59, program57 (global425), publisher58 (global490). The publisher target size is separately checked through its getter and reported.
- Both entry paths enforce matching payload constraints against the same 1024-byte input buffer, including 120 read records, 122/130 facts, 124 grant facts, and 131..134 empty payloads. Target events use the same original five arguments and payload bytes. Native rows are saved before comparison assertions.
- All eleven raw host/target capture pairs are present: pixels, wire, documents, receive, output, EP0 storage, OUT descriptor, SETUP record, program read script, program trace, and full program storage. Host word serialization is explicitly big-endian; target raw memory is big-endian. Trace/read prefixes plus all 27,712 guarded/tail storage bytes are compared against inherited literal expected storage. Target storage-length getters are checked for the three descriptor/record allocations.
- The report preserves initial and event rows, event inputs, all inherited oracles, new publication_oracles, expected documents and independent pixel digest, fixture/source/effective-source hashes, raw captures, audit and artifact hashes. A successful report is emitted only after the final immutable closure checks and complete host/target case counts.

Scope remains recording I/O/cache hooks in synthetic RAM. No actual mapping, cache, controller quiescence, peripheral command, USB status acknowledgement or physical printing is established. The report correctly preserves those exclusions.
