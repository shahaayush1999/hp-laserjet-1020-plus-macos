# Immediate duplicate-callback guard — unexecuted fixture revision

2026-10-03. This is a separate revision of the recovered publication fixture.
The recovered package at `/tmp/hp1020-publication-resume-20261003/` remains
unchanged. No production source, public API, event opcode,496-word row, cache/I/O
trace envelope, codec, builder or public direct-probe counter changes.

`fixture-v2.patch` applies **after** the original fixture patch. It modifies only
`open-firmware/udc-publish-test/fixture.c` and its README. `original/` preserves
both exact previous files; `draft/` holds the proposed replacements.

Each genuine bulk callback immediately retries `prepare_and_publish` after the
first call returns, before callback ledger updates and before the arm wrapper
or adapter unwind. The same rhport/endpoint/buffer/length are passed with a
separate poison-initialized cookie output. This runs after every first helper,
including successful publication and cache/register failure.

The fixture first proves the retry is still inside the original arm/callback:
publisher.arming1, consumed window0, publisher busy/servicing0, adapter busy/
stack_active/prepared1 and fixture in_callback1. Thus an accidental early end to
the wrapper cannot make an outside-window rejection look like this coverage.
The retry must return INVALID with no change to:

- Its poisoned cookie output and complete adapter/receive/OUT metadata.
- The16 descriptor bytes and full publisher state, including original failure.
- Program metadata and I/O state, including read cursor, trace/cache/register
  counts and pending injection schedule.
- Fixture state with submission/cancellation/wire/page/document forward counters.

Private `duplicate_checked` increments only after all comparisons pass. The
existing publication violation guard requires it equal genuine callbacks whenever
the callback is no longer active. Existing op134 direct-probe count/unchanged
fields and all64 public diagnostics remain unchanged. A failed assertion reaches
the same existing violation counters used by both host and target replay.

The snapshots are local metadata/range copies; no duplicate memory queue or owner
is created. Existing whole-composed checks still verify payload/output/descriptor
guards after the normal original-cookie ledger update. The first helper's result
remains the result returned to TinyUSB, so its false-return fence/cancellation
timing is unchanged. The duplicate grants no ownership and expects no hooks.

Static review only. Nothing in this revision has been compiled, imported or
executed. Root must review the delta, preserve its exact source closure, and own
all execution. The existing40-case matrix automatically encounters this private
probe on each genuine callback; invalid-init mapping coverage remains explicitly
outside this first matrix.
