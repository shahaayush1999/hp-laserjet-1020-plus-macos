"""Unexecuted runner scenario/helper fragment for the bounded40-case publisher.

Concatenate after the lead-owned header/Host. No imports or execution belong in
this fragment. Expected commands come from frozen independent O, while expected
cookies come from pre-arm adapter/queue state. No publisher failure field is an
oracle input. Existing Host raw capture/descriptor/borrow checks remain enabled.
"""


def _publication_record(h, records, kind, label, **expected):
    records.append(dict(kind=kind, label=label, event=len(h.events), **expected))


def _publication_no_reservation(h, records, label, trace=(), result=WAIT, supplied=None):
    before = h.row.copy()
    descriptor = h.udc[16:40].copy()
    counts = h.udc[10:14].copy()
    failure = h.publish[22:36].copy()
    calls = h.publish[50:55].copy()
    h.arm(trace, result=result, supplied=supplied)
    assert h.row[2:96] == before[2:96], ('preflight changed existing state', label)
    assert h.udc[16:40] == descriptor and h.udc[10:14] == counts
    assert h.publish[6] == 0 and h.publish[22:36] == failure
    assert h.publish[50:55] == calls, 'preflight cannot invoke DCD/cache hooks'
    _publication_record(h, records, 'preflight-refusal', label, result=result,
        issued=before[33], count=before[35], submissions=before[17],
        last_id=before[21], expected_trace=[list(row) for row in trace])


def _publication_direct_probes(h, records, label):
    for probe in O['DIRECT_CALLBACK_PROBES']:
        before = h.row.copy()
        descriptor = h.udc[16:40].copy()
        preparations, exposures = h.udc[10:12]
        old = h.publish.copy()
        h.step(134, *probe, result=INVALID)
        assert h.row[2:96] == before[2:96]
        assert h.udc[16:40] == descriptor and h.udc[10:12] == [preparations, exposures]
        assert h.publish[22:36] == old[22:36]
        assert h.publish[50:55] == old[50:55]
        assert h.publish[59:61] == [old[59]+1, 1]
        _publication_record(h, records, 'direct-refusal', label, arguments=list(probe))


def _publication_bypasses(h, records, token=0):
    # These routes are deliberately disabled in this fixture variant. They
    # must not inject an untracked submission error or expose a second proposal.
    for op, args in ((14, (2,)), (60, (0, 0x010101)), (61, (token, 0x010101))):
        before = h.row.copy()
        descriptor = h.udc[16:40].copy()
        counters = h.udc[10:14].copy()
        h.step(op, *args, result=INVALID)
        assert h.row[2:96] == before[2:96]
        assert h.udc[16:40] == descriptor and h.udc[10:14] == counters
        _publication_record(h, records, 'legacy-bypass-refusal', str(op), token=token)


def _publication_failure(h, records, name, vector):
    before = h.row.copy()
    slot = before[33] % 4
    assert before[30] == 0 and before[36] == before[44] == 0
    assert before[4] == before[5] and before[32] == 2
    token = h.arm(vector['trace'], result=FAULT, supplied=vector['reads'])
    # The one real bind is the next existing adapter ID and receive reservation;
    # its epoch is sampled BEFORE adapter false-submission fencing advances it.
    cookie = [before[21]+1, before[5], before[32], before[33]+1, 1]
    assert token == cookie[0] and h.bulk[token]['cookie'] == cookie
    assert h.udc[16:21] == cookie and h.publish[45:50] == cookie
    location = vector['location']
    wanted = cookie + [vector['prefix'], location['offset'], location['attempted_value'],
        location['dma'], location['bytes'], vector['operation'], vector['io_result'],
        vector['exposed'], vector['out_result']]
    assert h.publish[6] == 1 and h.publish[8] == vector['prefix']
    assert h.publish[22:36] == wanted
    assert h.publish[61:63] == [FAULT, slot]
    assert h.udc[2:4] == [vector['phase'], 1]
    assert (h.udc[44] >> 16) & 255 == 1, 'failed bind stays DCD-owned, not PENDING'
    assert h.row[17] == before[17]+1 and h.row[30:32] == [token, 64]
    assert h.row[33:36] == [before[33]+1, before[34], before[35]+1]
    assert h.row[4] > cookie[1] and h.row[5] == cookie[1]
    assert h.row[7] == h.row[9] == h.row[36] == 1 and h.row[44] == 0
    assert h.row[24:26] == before[24:26] and h.row[50:59] == before[50:59]
    assert h.row[90:96] == before[90:96]
    h.query_publication()
    assert h.publish[22:36] == wanted
    _publication_record(h, records, 'bound-failure', name, original_cookie=cookie,
        expected_failure=wanted, phase=vector['phase'], receive_count=before[35]+1)
    return token, cookie, wanted


def _publication_failed_barrier(h, records, token, sequence, auto_owner):
    assert h.publish[6] == 1 and h.publish[7] == 0
    before = h.row.copy()
    failure = h.publish[22:36].copy()
    descriptor = h.udc[16:40].copy()
    trace_count = len(h.expected_trace)
    # Combined fixture scheduling rejects these before entering normal APIs.
    # op9 is RX_WAIT1; the others here have their existing WAIT1 domains.
    for op in (1, 6, 7, 8, 9, 12, 41):
        h.step(op, result=WAIT)
        assert h.row[2:96] == before[2:96]
        assert h.publish[22:36] == failure and h.udc[16:40] == descriptor
    h.complete_selection(result=WAIT)
    h.grant(sequence, auto_owner, result=WAIT)
    assert h.row[2:96] == before[2:96]
    assert len(h.expected_trace) == trace_count
    assert h.publish[22:36] == failure and h.udc[16:40] == descriptor
    _publication_record(h, records, 'sticky-forward-barrier', 'no replay after failure',
        original_cookie=h.bulk[token]['cookie'].copy(), failure=failure)


def _publication_reset_cleanup(h, records, token, auto_owner, wanted, thorough=False):
    generation, count = h.row[32], h.row[35]
    assert count > 0 and h.row[10] == 1
    assert h.publish[22:36] == wanted and h.publish[6] == 1
    h.publication_cleanup(token, fact=0, result=WAIT)
    h.publication_cleanup(token, result=WAIT)  # Real DCD owner, mounted, stopped.
    if thorough:
        for fact in (2, 255):
            h.publication_cleanup(token, fact=fact, result=INVALID)
        for mutant in range(1, 6):
            h.publication_cleanup(token, mutant=mutant, result=STALE)
    else:
        h.publication_cleanup(token, mutant=3, result=STALE)

    before_wire = off._offload_wire_state(h)
    h.step(5)  # Actual bus-reset observation in the existing shared ingress order.
    assert h.publish[6] == 1 and h.publish[22:36] == wanted
    assert h.row[32] == generation and h.row[35] == count
    assert h.publish[7] == 1 and h.ingress[11] == 1
    h.service(WAIT)
    h.publication_cleanup(token, result=WAIT)
    # Explicit unsettled/settled inputs retain the ORIGINAL bulk cookie. A
    # successful controller cancellation only changes DCD -> pending adapter.
    h.step(64, token, 0, result=WAIT)
    assert h.row[30] == token and h.udc[16:21] == wanted[:5]
    h.step(64, token, 1)
    assert h.row[30] == 0 and h.udc[2] == 0
    assert (h.udc[44] >> 16) & 255 == 2
    h.publication_cleanup(token, result=WAIT)
    if auto_owner:
        assert h.row[28] == auto_owner
        off._offload_settle_auto(h, auto_owner, service=False)
    h.publication_cleanup(token, result=WAIT)  # PENDING notifications still own state.
    h.service()
    assert h.row[8] == h.row[10] == h.row[13] == h.row[77] == h.row[85] == 0
    assert h.udc[44] == 0 and h.row[36] == h.row[7] == 1
    assert h.row[32:36] == [generation, wanted[3], 0, count]
    assert h.row[44:46] == [0, 0] and h.publish[6] == 1
    assert h.publish[22:36] == wanted
    h.publication_cleanup(token, fact=0, result=WAIT)
    h.publication_cleanup(token)
    assert h.publish[56:58] == [count, count]
    assert h.row[32] == generation and h.row[35] == count and h.row[44:46] == [0, 0]
    _publication_record(h, records, 'publication-cleanup', 'original identity after reset',
        original_cookie=wanted[:5], generation=generation, count=count,
        expected_failure=wanted, no_reset_promises=True)
    h.publication_cleanup(token, result=STALE)
    old_digest = h.publish[44]
    h.query_publication(result=STALE)
    assert h.publish[44] == old_digest, 'failed query preserves its prior output'
    off._offload_no_wire(h, before_wire)


def _publication_finish_page(h, records, name, small, images, offset=0):
    generation = O['expected_final_generation'](name)
    assert h.row[32] == generation
    # Retain the separate JBIG reference path while making this pixel oracle
    # literal, rather than accepting a hash of the production output.
    expected = O['EXPECTED_PAGE_PIXELS']
    assert expected == b'\xff' * 32 and images['small'][1] == expected
    h.send(small[offset:], 64)
    h.expected_pixels = expected
    h.notification(generation, 1, 0, 1)
    h.repeat_pump()
    assert h.row[50] == 32 and h.row[56:59] == [1, 1, 1]
    assert h.row[90:93] == [1, 1, 1]
    assert h.row[35] == 0 and h.row[36] == h.row[40] == h.row[44] == 0
    assert h.publish[6] == 0
    ordinary = int(name == 'publish/progress-barriers')
    wire = b'\x01' if ordinary else b''
    assert h.row[24:26] == [len(wire), core.fnv(wire)]
    assert h.slot(0)[31] == h.slot(1)[31] == h.offload[57] == ordinary
    assert [packet['expected_hex'] for packet in h.packets] == (['01'] if ordinary else [])
    _publication_record(h, records, 'complete-document', name,
        generation=generation, pixels_hex=expected.hex(), document=[generation, 1, 0, 1, 0])


def scenario(h, name, document, images):
    assert name in O['PROFILE_NAMES']
    records = []
    short = name.removeprefix('publish/')
    small = document(['small'])
    assert len(small) > 31 and images['small'][1] == b'\xff' * 32
    h.facts([1]*7)
    h.grant_facts([1]*5)
    h.publish_facts(O['FACTS_ALL'])
    off._offload_reset(h)
    assert h.row[32] == 1

    if short == 'progress-barriers':
        _publication_no_reservation(h, records, 'unconfigured')
        sequence, owner = pg.configure(h, recover=False, grant=True)
        assert h.row[44:46] == [1, 0]
        _publication_no_reservation(h, records, 'three promises still missing')
        off._offload_recovery(h, owner)
        assert h.row[32] == 2
        held = h.capture(bytes.fromhex('8008000000000100'))
        assert h.ingress[2:5] == [1, held, held]
        _publication_no_reservation(h, records, 'newer raw SETUP captured but not admitted')
        h.dispatch(held)
        h.service(WAIT)
        assert h.row[28] == owner and h.offload[14] == 1
        off._offload_settle_auto(h, owner, service=False)
        h.service()
        assert h.row[29] == 1
        h.control_in(b'\x01', 'GET_CONFIGURATION after original auto-owner settlement')
        assert h.row[24] == 1 and not h.row[26] and not h.row[28]
        _publication_record(h, records, 'ordinary-control', 'GET_CONFIGURATION',
            request_hex='8008000000000100', in_hex='01', status_endpoint=0, status_length=0)
        _publication_finish_page(h, records, name, small, images)
        return records

    sequence, owner = pg.configure(h, recover=True, grant=True)
    assert h.row[32] == 2 and h.publish[6] == 0

    if short == 'cnak-and-page':
        _publication_finish_page(h, records, name, small, images)
    elif short == 'no-cnak-and-page':
        facts = list(O['FACTS_ALL']); facts[4] = 0
        h.publish_facts(facts)
        h.use_cnak = False
        _publication_finish_page(h, records, name, small, images)
        assert not any(row[2:4] == (2, 0x220) and row[4] == 0x120 for row in h.expected_trace)
    elif short == 'preflight-facts':
        for label, facts, trace, result in O['fact_refusals']():
            h.publish_facts(facts)
            _publication_no_reservation(h, records, label, trace, result)
        h.publish_facts(O['FACTS_ALL'])
        _publication_finish_page(h, records, name, small, images)
    elif short == 'preflight-registers':
        for label, trace, result in O['register_refusals']():
            _publication_no_reservation(h, records, label, trace, result)
            assert h.publish[18:22] == [trace[-1][1], trace[-1][2], 0, 1]
        _publication_finish_page(h, records, name, small, images)
    elif short == 'preflight-read-failures':
        for label, trace, supplied, result in O['preflight_read_failures']():
            _publication_no_reservation(h, records, label, trace, result, supplied)
            assert h.publish[18:22] == [trace[-1][1], 0, trace[-1][3], 0]
        _publication_finish_page(h, records, name, small, images)
    elif short == 'callback-authority':
        _publication_direct_probes(h, records, 'outside arm window')
        _publication_bypasses(h, records)
        token = h.arm_write(small[:31])
        original = h.bulk[token]['cookie'].copy()
        _publication_direct_probes(h, records, 'same allocation with retained real owner')
        _publication_bypasses(h, records, token)
        assert h.row[30] == token and h.udc[16:21] == original
        h.complete(token, 31)
        h.step(7)
        assert h.row[50] == h.row[90] == 0
        _publication_finish_page(h, records, name, small, images, 31)
    elif short == 'cancel-and-descriptor-reuse':
        token = h.arm_write(small[:31])
        original = h.bulk[token]['cookie'].copy()
        old_dma = h.bulk[token]['dma']
        assert h.bulk[token]['slot'] == 0
        before_wire = off._offload_wire_state(h)
        h.step(5)
        assert h.row[30] == token and h.udc[3] == 1 and h.publish[6] == 0
        h.service(WAIT)
        h.step(64, token, 0, result=WAIT)
        h.cancel_retained()
        h.service()
        assert h.row[32] == 2 and h.row[35] == 1 and h.row[50] == h.row[90] == 0
        assert h.row[8] == h.row[10] == h.row[13] == 0
        h.publication_cleanup(token, result=STALE)  # There was no publication failure.
        off._offload_no_wire(h, before_wire)
        sequence, owner = pg.configure(h, recover=True, grant=True)
        assert h.row[32] == 3
        new = h.arm_write(small[:31])
        current = h.bulk[new]['cookie'].copy()
        assert new != token and current[2] == 3 and original[2] == 2
        assert h.bulk[new]['slot'] == 0 and h.bulk[new]['dma'] == old_dma
        assert h.udc[21] == O['DESCRIPTOR_DMA']
        descriptor = h.udc[16:40].copy()
        forward = h.forward_state()
        h.observe_bulk(token, 0x8800001f, result=STALE)
        h.step(63, token, result=STALE)
        h.step(64, token, 1, result=STALE)
        h.publication_cleanup(token, result=STALE)
        _publication_direct_probes(h, records, 'descriptor address reused with a new original cookie')
        assert h.row[30] == new and h.udc[16:40] == descriptor
        assert h.forward_state() == forward and h.udc[16:21] == current
        _publication_record(h, records, 'same-address-old-cookie-refused', short,
            old_cookie=original, new_cookie=current, descriptor_dma=O['DESCRIPTOR_DMA'], buffer_dma=old_dma)
        h.complete(new, 31)
        h.step(7)
        _publication_finish_page(h, records, name, small, images, 31)
    else:
        # One common real failure/recovery schedule, with an independently
        # enumerated boundary-specific trace and expected prefix/location.
        slot = h.row[33] % 4
        if short == 'nak-still-set':
            vector = dict(O['NAK_STILL_SET_FAILURE'])
            vector['trace'] = O['NAK_STILL_SET']
            vector['reads'] = O['supplied_reads'](vector['trace'])
            assert slot == 0
        elif short == 'cleanup-original-cookie':
            vector = O['post_bind_failure']('desptr-write-uncertain', slot)
        else:
            assert short in [entry[0] for entry in O['POST_BIND_FAILURES']]
            vector = O['post_bind_failure'](short, slot)
        token, original, wanted = _publication_failure(h, records, short, vector)
        _publication_failed_barrier(h, records, token, sequence, owner)
        _publication_reset_cleanup(h, records, token, owner, wanted,
            thorough=short == 'cleanup-original-cookie')
        sequence, owner = pg.configure(h, recover=True, grant=True)
        assert h.row[32] == 3 and original[2] == 2
        h.publication_cleanup(token, result=STALE)
        assert h.publish[22:36] == wanted, 'success recovery retains diagnostic provenance'
        _publication_finish_page(h, records, name, small, images)
    return records
