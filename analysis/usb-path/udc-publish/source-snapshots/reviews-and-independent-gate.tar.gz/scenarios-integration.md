# Publication scenario fragment — unexecuted

The fragment `/tmp/hp1020-publication-scenarios-draft-20261003.py` contains only
scenario/helper function definitions and its explanatory docstring. No imports,
builds, validators or target execution were performed. No repository source was
edited. Concatenate it after the lead's recovered header and Host; the header's
existing `profiles()` remains the authority for20 frozen names x fills0/204.

Required globals are the lead's `pg/off/comp/ep0/base/core` aliases, frozen oracle
dictionary `O`, and result names from its seven-value publisher enum. Required
Host methods are the recovered publication wrapper and inherited program/
offload/composed methods. No fixture ABI or new state mutation is introduced.
`scenario(h,name,document,images)` returns a JSON-serializable list for the
report's `publication_oracles` field. Event indices are one-based counts matching
the actual saved event stream, not inferred target instruction counts.

Every case explicitly sets programming facts, grant facts and publication facts
to1, then admits/services an actual reset. Typed configuration uses exactly
`pg.configure(recover=True,grant=True)`, i.e. independent `pg.INITIAL`,
`pg.GRANT`, then the existing three-promise recovery. The progress-barrier case
temporarily delays that recovery to probe the fence. Both fault recovery and
ordinary cancellation/reuse retain the old G2 reservation until later normal
configuration/recovery advances toG3. Every case ends in one independently
expected32-byteFF page and one `[G,1,0,1,0]` document record. The first seven
profiles end atG2, all remaining profiles atG3, exactly as frozen in `O`.

The only ordinary control request is progress-barriers' literal
GET_CONFIGURATION `8008000000000100`. Its capture precedes adapter admission and
blocks bulk arm. After dispatch, the retained original typed automatic-status
owner must settle before normal service creates one-byte IN01, followed by an
OUT0 zero-length status. Final oracles require that one actual IN/OUT control
preparation and one ordinary status callback there; every other profile has
none. Typed status permission and canceled automatic owners create no wire
packet or ordinary ACK. The final wire-byte/digest and packet expectations are
literal and independent of the publisher.

For post-bind failure, expected cookie is computed from the pre-arm adapter
last-id+1, active transport epoch, receive generation and issued+1. It is compared
to the actual inherited bulk ledger, descriptor record, cache witness and exact
14-field failure record. No expected field is copied from publisher failure.
Frozen independent traces supply prefix, phase, operation and attempted values.
Current transport epoch may advance after false submission; the original active
epoch remains the cookie oracle. Direct command/cache outcomes remain supplied.

Sticky forward operations use the real composed gate: op6 and normal service/
pump/finish return WAIT before entering the direct publisher API. Do not change
them to the production arm function's FAULT result. Original-cookie cancellation,
query and actual-reset admission remain available. Cleanup probes DCD and PENDING
ownership, malformed clean facts, each altered cookie field, missing cleanup,
and duplicate cleanup. It succeeds only after reset service drains all owners,
while receive.count remains nonzero and G/recovery promises remain unchanged.

Two limits are intentional and must survive report prose:

- The public fixture cannot isolate a stopped-but-mounted state with *all*
  adapter owners already drained during sticky failure: ordinary service is
  blocked until actual reset admission. Tests cover the real mounted+DCD and
  PENDING combinations, without claiming an isolated mounted-only guard test.
- Each failure case contains one failed publication and one later recovery.
  There is no second failed attempt in the same case. Old-cookie rejection
  after address/generation reuse is covered by cancellation/reuse, but this
  matrix must not claim old-failure cleanup against a newer retained failure.
  Adding that sequence would need a separately reviewed G4 profile.

The fragment was read against the frozen contract, source paths and recovered
Host without execution. The lead must review the assembled runner, preserve
all drafts/captured sources before its first run, and distinguish any future
harness corrections from production corrections. Runtime agreement, source
closure and exact host/target raw captures are still unverified.
