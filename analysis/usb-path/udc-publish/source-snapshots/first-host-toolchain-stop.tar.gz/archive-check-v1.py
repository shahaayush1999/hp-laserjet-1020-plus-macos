"""Preserve a stopped run and its exact evidence; never synthesize a report."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import struct
import tarfile

ROOT = Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
CAPTURE = Path('/tmp/hp1020-udc-publish-53968qr7')
LOG = Path('/tmp/hp1020-publication-first-20261003.log')
sha = lambda data: hashlib.sha256(data).hexdigest()
assert not (CAPTURE/'validation.json').exists()
assert not (CAPTURE/'target').exists()
assert 'Bulk publication: 40/40 host cases passed' in LOG.read_text()
assert 'fatal error: stdint.h: No such file or directory' in LOG.read_text()
sources = json.loads((CAPTURE/'source-sha256.json').read_text())
fixtures = json.loads((CAPTURE/'fixture-sha256.json').read_text())
for manifest, folder in [(sources, 'source'), (fixtures, 'tested-fixtures')]:
    for name, digest in manifest.items():
        assert sha((CAPTURE/folder/name).read_bytes()) == digest
        assert sha((ROOT/name).read_bytes()) == digest
directories = sorted(CAPTURE.glob('case-*'))
assert len(directories) == 40
cases = []
for directory in directories:
    assert not list(directory.glob('target-*'))
    raw = (directory/'events.bin').read_bytes()
    events, offset = [], 0
    while offset < len(raw):
        assert len(raw)-offset >= 24
        header = struct.unpack_from('>6I', raw, offset)
        offset += 24
        assert header[-1] <= 1024 and offset+header[-1] <= len(raw)
        events.append((header, raw[offset:offset+header[-1]]))
        offset += header[-1]
    rows = [json.loads(line) for line in (directory/'raw-stdout').read_text().splitlines()]
    assert len(rows) == len(events)+1 and all(len(row) == 496 for row in rows)
    assert (directory/'pixels').read_bytes() == b'\xff'*32
    assert (directory/'stderr').read_bytes() == b''
    assert len((directory/'documents').read_bytes()) == 20
    assert rows[-1][55:58] == [1,1,1]
    assert rows[-1][91:93] == [1,1]
    assert len((directory/'receive').read_bytes()) == 4096
    assert len((directory/'output.program-storage').read_bytes()) == 27712
    cases.append(dict(case=(directory/'case-name').read_text().strip(),
                      host_event_rows=len(events), final_generation=rows[-1][32]))
files = {p.relative_to(CAPTURE).as_posix():p.read_bytes()
         for p in CAPTURE.rglob('*') if p.is_file()}
files['stopped-run.log'] = LOG.read_bytes()
files['archive-check.py'] = Path(__file__).read_bytes()
metadata = dict(status='partial: 40 sanitized host cases passed; target compilation failed before ELF/audit/QEMU',
    failure='Disposable GCC installation lacked stdint.h; no candidate correction made',
    complete_paired_report=False, target_cases=0, source_files=len(sources), fixture_files=len(fixtures),
    host_event_rows=sum(case['host_event_rows'] for case in cases), cases=cases,
    usb_transfers=0, physical_prints=0, completed_native_page_lifecycles=0,
    member_sha256={name:sha(raw) for name,raw in sorted(files.items())})
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w') as archive:
        for name,raw in sorted(files.items()):
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            entry=tarfile.TarInfo(name)
            entry.size,entry.mode,entry.mtime=len(raw),0o644,0
            archive.addfile(entry,io.BytesIO(raw))
payload=buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as archive:
    assert set(archive.getnames()) == set(files)
    for name,raw in files.items(): assert archive.extractfile(name).read() == raw
metadata.update(archive_sha256=sha(payload), archive_bytes=len(payload), member_count=len(files))
destination=ROOT/'analysis/usb-path/udc-publish/source-snapshots'
destination.mkdir(parents=True,exist_ok=True)
for suffix,data in [('.tar.gz',payload),('.json',(json.dumps(metadata,indent=2)+'\n').encode())]:
    path=destination/('first-host-toolchain-stop'+suffix)
    assert not path.exists()
    path.write_bytes(data)
print(json.dumps({key:metadata[key] for key in ('status','source_files','host_event_rows','archive_bytes','archive_sha256')},indent=2))
