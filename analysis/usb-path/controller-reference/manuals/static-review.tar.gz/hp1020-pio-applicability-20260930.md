# Stock PIO applicability review — 2026-09-30

No positive stock PIO path was found in this bounded static search. The inspected startup branch explicitly selects family DMA MODE=1 and subsequently publishes SETUP/ordinary OUT/IN descriptors. The alternative startup branch skips that mode programming; it does not select MODE=0. This favors continuing the existing DMA/capture work. It does not prove that HP hardware lacks PIO support.

## Exact original input and search

- Stock: analysis/sihp1020.elf, 128372 bytes; SHA256 2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d.
- Existing disassembler: GNU objdump (GNU Binutils) 2.30.0.20180625. All 435 legacy .xt.insn regions (85858 bytes) were disassembled separately, yielding 32600 instruction boundaries; each decoded byte sequence was checked against the file. No original instruction was executed; no harness, generator, validator or build was imported/run.
- Scanned every 4-byte window in the entire ELF, and separately every file-backed allocated section, for BE/LE numeric addresses 0xb3000800..0xb3001fff. This includes the CS5536 RX/TX FIFO range and additional possible FIFO space; it is not an HP FIFO map.
- Resolved all annotated L32R instructions. Exactly 98 loads reference 28 distinct controller-address literals, all in 0xb3000000..0xb3000510; no L32R reaches a FIFO-address value. All five loads of the unique DEVCTL literal 0x10005ea8 were inspected below.
- Also inspected the actual USB initialization and known indexed controller-address arithmetic. Original EPSTS selection is b3000004/b3000204 plus lane*0x20 (0x100083c9..0x100083eb), bounded to lanes 0..15 and directions 0..1 (0x100086c5..0x100086e4), so that indexing remains below 0xb3000400. Do not interpret it as a FIFO loop.

## Concrete DEVCTL anchors

The family bit labels below come from the pinned classic-UDC reference; original byte values and stores are independently observed.

| Original code | Literal/raw anchors | Derived operation |
|---|---|---|
| 0x10009031..0x1000904a | 10005ea8=b3000404;10005eb0=00ffffff;09044:098801;0904a:98a0 | AND 0x00ffffff clears only bits 31:24; preserves MODE9, TDE3, RDE2. |
| 0x1000904f..0x1000905d | 10005eb4=00030000;09057:098802;0905d:98a0 | OR 0x00030000; no MODE/TDE/RDE clear. |
| 0x10009062..0x1000906d | 09064:293a20 (movi a9,0x320);09067:098802;0906d:98a0 | OR 0x320 sets MODE9,burst8, BE5. This is the explicit DMA selection. |
| 0x100092d0..0x100092ef | 092d0:1cf2f6;092e9:048802;092ef:98c0; a4=8 at09179:c048 | OR 8 enables TDE. a4 is not redefined in the intervening original instructions. |
| 0x10008f93..0x10008fa3 | 08f93:18f3c5;08f9b:c0a4;08f9d:0a9902;08fa3:9980 | Existing idle helper OR 4 enables RDE. No MODE selection. |
| 0x10009a13..0x10009a26 | 09a13:1af125;09a16:c797;09a20:098801;09a26:98a0 | Existing pause AND ~8 clears only TDE, preserving MODE and RDE. |
| 0x10009a73..0x10009a83 | 09a73:14f10d;09a7b:c038;09a7d:032202;09a83:9240 | Existing restore OR 8 enables TDE; no MODE selection. |

These five literal-loading sites cover seven DEVCTL stores; none chooses MODE0 with both DMA enables clear. The startup decision at 0x10009003/0x10009006 can branch to 0x100090fd, bypassing the first three writes. That branch preserves pre-existing controller configuration rather than establishing a PIO path; later descriptor setup is common.

Positive DMA construction anchors remain: SUBPTR write at 0x100091b0 through literal 0x10005ef4=b3000210; ordinary OUT0 DESPTR write at 0x100091c7 through 0x10005ef8=b3000214; SETUP reception reads SUBPTR at 0x10009361 then checks RAM ownership/status. Control-IN sender uses descriptor submission at 0x10008d0c/0x10008f1b and CNAK/PollDemand 0x108, not a directly observed FIFO write. These were read only, not re-executed.

## False matches and limits

The only raw BE FIFO-range match is b30013be at file offset 0x14404 / VA0x10016ea4. Those bytes cross actual instructions: b300=addi.n a0,a0,3 at 0x10016ea4;13bef1=l32r a3,0x10006a6c at 0x10016ea6. It is not a literal or PIO access. Two LE matches at file offsets 0x1b05f/0x1b067 occur in nonallocated .xt.insn metadata, not target data.

This is not whole-program pointer analysis. Addresses assembled from arithmetic, indirect/runtime-supplied pointers, code outside compiler annotations and boot/ROM outside this ELF are not excluded. The absence of a stock FIFO literal does not prove that the silicon lacks this capability. Generic read/write helpers do not establish that callers use FIFO addresses. Hardware byte order, FIFO geometry, bus-access rules and safe mode transitions remain unknown.

Sony's separate global PIO mode (CXD5602 manual1.1.0, §§3.18.5/3.18.11, pp1128/1205–1207; official-document provenance in /tmp/hp1020-udc-manual-review-20260929/PROVENANCE.json) therefore remains a possible alternative, not an easier proven HP path: it would require a new backend for FIFO reads/writes and controller completion semantics, including bulk, rather than a drop-in EP0-only change. Keep the existing original-byte DMA evidence and immutable-capture component. Its truthful stable-capture/settlement facts remain external; all RDE writers must be serialized, and the executed stock idle worker should not be reused blindly.

## Provenance / recovery

Annotated static rows are retained in /tmp/hp1020-pio-annotated-20260930.{json,txt}; these are inspection artifacts, not execution reports. The earlier coarse USB-range disassembly starts inside a literal pool and must not be used as a whole-region instruction oracle; the annotation-bounded rows supersede it.

Read-source SHA256 values:

- `analysis/sihp1020.elf`: `2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`
- `analysis/usb-path/controller-family.md`: `04f1d5d8e195df72827ad6afc7620df3cd3e53c9afaa1ca25823acf5a161970c`
- `analysis/usb-path/idle-receive.md`: `9a4eb042791ec1003b6bbfb7f2834e7a5578b9b44e4ea41079364f059c828295`
- `analysis/usb-path/setup-ingress.md`: `becb8f72c54cd0a6626bbbe651ace5a718ff6fa67a9ddccc7acc5a47a313e5b4`
- `analysis/usb-path/usb-bulk-probe-contract.md`: `4d77b9c9b22ac2a90bfb1ae79e97ed302d9101e3e891b918caffadcc27a2ad68`
- `analysis/usb-path/decompiled-neighbors/10008ff0_hp1020_usb2_thread.c`: `626c9c76cc531d763641277712485cc4e4dc22d8024c21a6ce55b4447a1b89b2`

No repository files were modified. No hardware/USB, original-code execution, validation suite or build occurred.
