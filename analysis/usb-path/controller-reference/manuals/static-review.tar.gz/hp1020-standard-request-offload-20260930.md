# Classic UDC standard-request offload: bounded port review

Read-only review, 2026-09-30. No experiment, validator, build, QEMU, networking,
repository edit or hardware operation was performed. This note concerns three
standard requests and the software/controller boundary, not a complete DCD.
The Sony/AMD/Micrel implementations are family references; an exact HP silicon
revision, supported options and reset behavior remain unproved.

## Practical result

The documented family handles SET_ADDRESS internally and handles
SET_CONFIGURATION/SET_INTERFACE with a hardware status response that software
may defer while programming endpoint CSRs. A DCD that always submits the
current synthetic fixture's EP0 descriptor for these requests could do the same
work twice. Conversely, a DCD that forwards only raw application SETUP records
could leave TinyUSB unconfigured: Linux explicitly reconstructs SC/SI requests
from device interrupts/status because the hardware consumed them.

The useful next component is a typed **offloaded-request notification/status
grant**, kept distinct from the existing raw-record capture bridge. No change
is proposed to raw SETUP provenance, actual reset identity, borrowed-buffer
settlement or the three recovery promises. Address commit stays with hardware
if the selected HP mode is shown to have the documented offload behavior.

## Sources and exact scope

Page numbers below are both printed and one-based PDF pages. Source PDFs are in
`/tmp/hp1020-udc-manual-review-20260929/`; their official URLs and provenance are
also recorded in repository `analysis/usb-path/controller-reference/manuals/`.

| Reference | Revision | SHA-256 |
|---|---|---|
| [Sony CXD5602 User Manual](https://www.sony-semicon.com/files/62/pdf/p-28_CXD5602_user_manual.pdf) | 1.1.0, 2022-10-24 | `c21b1d93018421d7c283ab377a7dabec3339badd4809652885a8a1b76e522802` |
| [AMD Geode CS5536 Companion Device Data Book](https://www.amd.com/content/dam/amd/en/documents/archived-tech-docs/datasheets/33238G_cs5536_db.pdf) | 33238G, May 2007 | `a829ae505ed96a180856c84291ab26e838453ff19a589c9af7624c1e7bfcd929` |
| [Micrel KSZ9692MPB/KSZ9692XPB Registration Description](https://ww1.microchip.com/downloads/en/DeviceDoc/ksz9692mpb_xpb_reg_descp_v1.0.pdf) | M9999-102008-1.0, October 2008 | `27948fa8a9da03295a5790fb79acf0deafebbba8186e4ae7e06face287f14afe` |

Sony p1113 §3.18.1 identifies the underlying description as Synopsys
`d20ahb_databook`, USB1.1 Release 2.11a, USB2.0 AHB-VCI 2.45a/VCI 1.93a,
June 2009. This is a reference revision, not an identification of HP's controller.
Sony pp1114 and1212 were also rendered and visually checked. Text was extracted
with installed Poppler; source PDFs were not changed.

Pinned Linux is v6.12 commit `adc218676eef25575469234709c2d87185ca223a`, under
`analysis/usb-path/controller-reference/linux-v6.12/`:

- `snps_udc_core.c`: `c1b09e8f69d3340f2afd3a033d77a42775b52716d45b1aceb211dcaab89127bf`.
- `amd5536udc.h`: `8dbf2ebffe7de042bdfea1c5e4e0d7e7ca334cb821fbfaa1cf9ccfeeae302648`.

Original bytes are `analysis/sihp1020.elf`, SHA-256
`2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`.
Instruction anchors below were checked with the pinned Xtensa objdump; no stock
instruction was executed. TinyUSB anchors refer to current pinned/patched
`vendor/tinyusb-0.21.0/src/device/{usbd.c,dcd.h}`. Line numbers are an inspection
locator, not a substitute for those saved sources.

## What the documented hardware owns

**SET_ADDRESS.** Sony p1114, §3.18.1.2 continuation, states that the subsystem
handles standard device requests except Get_Descriptor, Set_Descriptor and
Synch_Frame; class/vendor requests also pass to the application. SET_ADDRESS
therefore belongs to the documented hardware-handled set. This supports leaving
its response and address transition to that controller. It does not specify an
application-visible address-commit interrupt, justify committing at TDC, or
prove HP implements the same offload. No software address-write operation was
found in the scoped Linux core; absence alone is not hardware proof.

**SET_CONFIGURATION / SET_INTERFACE.** The command is decoded internally;
software receives device SC/SI notifications and can read the selected values:

- Sony p1143 Table USB-58: DEVSTS CFG[3:0], INTF[7:4], ALT[11:8]. These are
  four-bit state fields, not an immutable original eight-byte SETUP packet.
- Sony p1146 Table USB-61: SC bit0 and SI bit1 indicate receipt. Pending/unserved
  notifications cause NAKs except for the eight SETUP bytes. Thus the notification
  does not exclude later SETUP arrival or establish immutable DEVSTS history.
- Sony p1134 Table USB-49: DEVCFG.CSR_PRG bit17 enables dynamic register
  programming and NAKs status IN until application writes DEVCTL.CSR_DONE bit13.
- Sony p1138 Table USB-53: CSR_DONE notifies the controller that required UDC
  programming is complete. It is a permission/action, not a readback ACK flag.
- Sony p1212, §3.18.12.1.4 continuation, shows command-stage ACK, a device
  notification, endpoint/size CSR programming, NAK, software CSR_DONE and
  interrupt clear, then hardware status ZLP, then host ACK. The figure labels
  the notification SI for both commands; Table USB-61 separately defines SC/SI.
  Do not reinterpret that diagram label as evidence there is only one bit.

AMD p321 §6.4.5.14 corroborates CSR_PRG; p323 §6.4.5.15 corroborates CSR_DONE
and explicitly says it reads as zero; pp324–325 §6.4.5.16 give DEVSTS fields;
p325 §6.4.5.17 gives SC/SI/UR. Micrel pp133,135–137 §§2.17.1–4 corroborate
these fields and dynamic response permission. These corroborations do not
convert Sony's implementation-specific options into HP facts.

The initialization needed for dynamic mode is broader than setting CSR_DONE:
Sony p1211 §3.18.12.1.2 includes Device Config/Control, endpoint control/buffer/
maximum-packet registers, EP0 SETUP pointer and UDC11/20 endpoint CSRs. Endpoint
definitions and the hardware's logical configuration/interface mapping must
agree. Static CSR mode is an alternative family policy; CSR_PRG controls the
application's extra status gate, not a documented switch that forwards every
standard SETUP packet unchanged to software.

## What the pinned Linux implementation actually does

`amd5536udc.h:32–50` explicitly explains the reconstructed requests: some SETUP
commands are handled in hardware but must be passed to the gadget driver.

1. `snps_udc_core.c:1455–1485`, `udc_basic_init`, disables DMA and enables
   DEVCFG.CSR_PRG. `:256–274` unmasks SC, SI, UR and other needed device events.
2. `:2751–2798` reads DEVSTS.CFG, marks `set_cfg_not_acked`, creates a canonical
   SET_CONFIGURATION request, updates endpoint CSR config fields, clears endpoint
   stalls and invokes the gadget driver's setup callback.
3. `:2800–2858` similarly reads INTF/ALT, constructs SET_INTERFACE and updates
   endpoint CSR interface/alternate fields before calling the gadget driver.
4. `:318–432`, endpoint enable, programs endpoint type, packet size, FIFO size,
   and the CSRNE number/direction/type/config/interface/alternate mapping.
5. `:1088–1120`, the zero-length queue path, says IN ZLPs are hardware handled.
   It calls `complete_req` **before** setting CSR_DONE for a pending SC/SI;
   a separate ordinary-control flag uses CNAK. That upstream giveback is a
   software convention, not a measurement of host receipt of the status packet.
6. `:2860–2918`, UR processing, clears the pending software status flags,
   invokes gadget reset, empties EP0 queues, handles FIFO/reset recovery, and
   reinitializes/unmasks the controller. Those implementation choices do not
   prove that HP borrowed memory is settled after a reset bit or queue removal.

`udc_irq:2980–3021` processes endpoint notifications before reading/clearing
device notifications. `udc_dev_isr` processes SC, then SI, then UR from a saved
mask. This is code order, not physical request chronology. It is not an ordering
rule to transplant into the one-slot capture bridge.

## HP original-byte anchors: consistent with offload, not proof of its mode

The original application's dispatch compares the combined bmRequestType and
bRequest at `0x1000940e..0x10009459`. Literal words at `0x10005f80..0x10005f94`
are exactly `0000a100 00002102 00008006 0000c100 0000a101 0000c101`.
These select printer GET_DEVICE_ID, SOFT_RESET, standard GET_DESCRIPTOR, two
vendor requests and printer GET_PORT_STATUS. The normal standard tuples
SET_ADDRESS `0005`, SET_CONFIGURATION `0009` and SET_INTERFACE `010b` are not
members. From this inspected dispatcher they go to `0x10009859` (bytes
`220a01`, set rejection flag); the rejection tail ORs1 into both EP0 control
registers at `0x10009870` and `0x1000987f`. No missing decompiler switch arm is
being assumed here: the comparison branches and constants were read directly.

In the inspected cold-branch startup:

- `0x1000902d..0x1000903a` loads DEVCFG and ORs8. This preserves CSR_PRG bit17;
  it does **not** establish that bit is zero or one. The earlier startup call
  and inherited/reset state are outside this small inspection.
- `0x100090a4` loads `0x77`; `0x100090b8` stores the old device mask OR0x77.
  Under the family field layout this masks SC/SI. Literal `0x10005eb8` is
  `b3000410`. The bit-3 reset mask is preserved, not forced clear here.
- `0x100090bd/ce/d9/de` program the static endpoint CSR words: `+0x504 =
  0x02000000`, `+0x508 = 0x100000c1`, `+0x510 = 0x100080c1`, `+0x50c =
  0x100000d1`. Literals are at `0x10005c84`, `0x10005ebc..0x10005ed4`.
  With pinned Linux field positions these encode EP0/64 and EP1 bulk
  configuration1, OUT alternate0/1 and IN alternate0, initially with512-byte
  bulk packet fields. Existing descriptor-speed branches separately program
  the64-byte alternatives; this is not a new live mode choice.
- In the saved IRQ branch, `0x1000833c` checks SC; `0x10008347` writes literal1
  to DEVINT. `0x1000834b` checks SI; `0x10008354` writes literal2. These two
  branches contain no CSR programming, request copy or task wakeup. Their
  literal store encodings are `9890` and `9980`. This does not establish that
  these masked branches execute on a real SC/SI event.

These bytes fit a hardware-offloaded, statically described application. They
do not prove the complete initial register state, that HP accepts dynamic CSR
mode, that no other path can write CSR_DONE, or which side validates unsupported
configuration/alternate values. Do not copy stock's masked SC/SI policy into a
TinyUSB port that needs a configuration notification.

## Connection to current TinyUSB and adapter contracts

`dcd.h:128–129` assigns SET_ADDRESS including status to the DCD. The core at
`usbd.c:969–975` explicitly allows hardware that needs no software status
response. If HP's selected mode consumes SET_ADDRESS, no extra EP0 descriptor,
address write or invented ACK is necessary. An offload-mode `dcd_set_address`
implementation may be a documented no-op if it is ever notified, but only after
that mode has been established. There is no need to synthesize SET_ADDRESS just
to exercise this hook. In this pinned profile `_usbd_dev.addressed` affects only
the small-EP0 device-descriptor workaround (`usbd.c:1314–1320`); EP0 is fixed64
and the adapter rejects any other size (`hp1020_tusb_adapter.c:355`). This is a
bounded reason that omitted hardware-only address notification need not block
the current profile, not a general TinyUSB guarantee.

For SC/SI the upper software state does need notification:

- `usbd.c:983–1019` changes configuration, opens/closes classes and always calls
  `tud_control_status`. `:1154–1180` has a standard SET_INTERFACE fallback;
  this adapter's class callback rejects non-class requests. A port must prevent
  that IN0 zero-length submission from producing a second status packet after
  the controller has already taken responsibility.
- Linux's canonical-request reconstruction is a viable *design pattern*. It
  must have explicit offload provenance, original external event identity and
  the sampled CFG/INTF/ALT fields. It must not be passed off as a16-byte raw SETUP
  capture through `hp1020_udc_setup_offer/dispatch`, nor be assigned fabricated
  original reserved/high bytes. The present bridge only accepts unchanged raw
  records and actual reset observations, so this requires a reviewed extension.
- The bounded profile can restrict notifications to supported configuration0/1,
  interface0/alternate0. Four-bit DEVSTS fields cannot reproduce arbitrary
  original16-bit values or prove malformed-request rejection. Hardware rejection
  policy and sampling stability are explicit port obligations.
- Endpoint open/close programming belongs to the DCD. When the exact current
  SC/SI has been admitted and programming succeeds, its standard zero-length
  status submission can mean **grant hardware auto-status** by CSR_DONE, with no
  DMA descriptor and no fake ZLP payload. This must retain the same control
  identity and satisfy the adapter's accepted-status/binding guard; merely
  returning true without its expected owner fails `begin_binding_recovery`
  (`hp1020_tusb_adapter.c:222–241`). Normalizing the notification alone is not a
  complete port.
- CSR_DONE, TDC and Linux early giveback must not be labeled host-ACK evidence.
  `usbd.c:900–912` invokes the optional status-complete hook and
  CONTROL_STAGE_ACK callback upon a supplied completion. The real DCD must
  document what completion/ownership release means and audit which callbacks
  rely on it. Do not weaken the current component's external settlement fact to
  infer success from a status-permission write.

A conservative bounded option is to bind/retain the no-buffer auto-status owner
after the grant and retire it only on an available, justified controller event
or proven supersession/cancellation. The existing adapter already allows a
held configuration-status owner through the three-promise recovery path; a
separate status-ACK IRQ is not required merely to restart the configured
document path. This option is a design proposal, not evidence that a new SETUP
or reset already settles every HP controller state. Another viable port policy
could use a narrower local-handoff completion convention like Linux, but it
would need an explicit API/evidence distinction and callback audit before use;
the present stronger completion contract cannot silently be relabeled.

Actual UR still enters `hp1020_udc_setup_bus_reset` with the original ingress
sequence and negotiated supported speed. SC/SI is not a fake reset and cannot
manufacture the receive/parser/output reset promises. Superseding reset or a
newer request invalidates the old CSR_DONE permission. A stale handler must
never authorize whatever request now occupies the controller's status gate.

## Concrete remaining obligations and bounded next experiment

1. Establish HP's offload/dynamic-CSR capability and chosen initialization state;
   do not assume CSR_PRG reset value from another chip or try a hardware write.
2. Extend the ingress barrier to distinguish raw SETUP, SC, SI and actual reset
   observations in one external nonwrapping order. Saved pending bits and live
   DEVSTS values alone are not a chronology or a queue. If reset and offload
   notification cannot be assigned to a stable domain, fence/discard ambiguous
   state rather than recreate Linux/stock bit-scan order.
3. Tie CSR programming and the one status grant to that exact accepted offload
   event. Preserve three recovery promises and any outstanding EP0/bulk owners.
4. Define separately controller responsibility for protocol retry/address
   timing, memory-buffer settlement, and upper-stack completion callbacks.
   No unsupported host-ACK or wire-byte-count requirement should be invented.
5. Decide rejection policy for unsupported/malformed configuration/interface
   requests using actual capability evidence; the4-bit status field cannot
   supply lost original high bits.

The next useful offline experiment is a small, explicitly **reconstructed
offload-event** integration fixture: SC config1, same-config repeat, config0,
SI alt0, unsupported values, failed endpoint programming, delayed CSR grant,
newer raw SETUP before grant, reset overlap and event exhaustion. It should
assert exact config/open/close behavior, no fabricated raw capture, no added
EP0 DMA descriptor or wire ZLP, one grant only for the original current event,
and no old grant after reset/supersession. It can hold the zero-length status
owner instead of manufacturing ACK. This would verify software plumbing under
supplied controller facts; it would add no physical USB or printing proof.

Cross-review: `/root/usb_reference_contract` independently owns the IN
TDC/DMA-versus-wire/ACK and actual-count investigation. Its reported Sony anchors
include p1125 Figure USB-39, pp1192–1193, p1208 PPBDU count refinement and
pp1220–1222 protocol flows. This note relies only on the narrow separation of
status permission/DMA from host ACK; it does not adopt a blanket claim that the
IN low16 field can never contain a DMA transferred count.
