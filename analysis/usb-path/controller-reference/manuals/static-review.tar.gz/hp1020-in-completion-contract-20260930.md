# IN completion: DMA ownership is separate from USB acceptance

Read-only review, 2026-09-30. No validator, build, target execution, USB access,
MMIO or repository edit. This is controller-family documentation and static
stock evidence, not proof of the HP controller revision or its current mode.

## Result

TDC and a successfully updated IN descriptor describe the memory-to-TxFIFO
side. They do not establish that the USB host ACKed the packet. This distinction
permits an implementation to recycle completed DMA storage while the controller
retains a separate FIFO copy for retransmission. It does not, by itself, justify
TinyUSB's status-stage completion callback or a software address commit.

There is a **conditional DMA byte-count statement** in Sony's manual that must
not be omitted: in PPBDU mode the descriptor TXBYTES field reports packet size
transferred. Neither that statement nor an unchanged requested count is a
hardware-reported successful-wire byte count. Keep the current separately
supplied `in_actual` and settlement facts; define their producer's precise
meaning when choosing the physical DCD/offload contract.

## Exact manual evidence

All page numbers below are both printed pages and 1-based PDF pages; the PDF
zero-based index is page minus one. Links and hashes are recorded below.

| Observation | Exact primary reference | Limit |
| --- | --- | --- |
| EP status TDC bit 10 denotes descriptor-chain data moved to TxFIFO; IN bit 6 denotes an IN token received. | AMD 33238G p314 §6.4.5.2; Micrel M9999-102008-1.0 p141 §2.17.10; Sony 1.1.0 pp1158–1159 Tables USB-74/75. | Neither bit identifies a host ACK or the original software packet. An IN token can elicit NAK. |
| DMA completion and USB acceptance are separate branches. | Sony p1125 Figure USB-39, visually inspected: one branch copies memory to TxFIFO then updates descriptor; the other transmits FIFO data, waits for host status, and rewinds the read pointer when no ACK arrives. | This resolves the less precise transmission wording in p1124 §3.18.4.1. |
| DMA_DONE and TX success are written after the memory-to-TxFIFO operation. | Sony p1192 Figure USB-52 (PPBDU); p1193 Figure USB-53 (PPBNDU), visually inspected. | DU updates each descriptor; without DU the successful update shown is the final descriptor. Neither figure waits for a USB ACK. |
| Retries use the FIFO copy, not a promised reread of the application source. | Sony p1174 §3.18.7.2: unsuccessful IN transactions retain FIFO data; successful USB transactions confirm the FIFO read pointers. | FIFO retention and memory ownership are different resources. Reset, flush, preemption and stale event identity still need their own handling. |
| TDC can precede the host's next IN token, DATA and ACK. | Sony p1217 §3.18.12.4.1 control-IN flow, steps9–12; p1222 §3.18.12.4.3 bulk/interrupt-IN flow, steps5–8. | These flows do not expose a separate per-IN-ACK software interrupt. Control-IN additionally receives OUT-status notification, pp1217–1218. |

**TXBYTES refinement.** Sony pp1186–1187 §3.18.8.4 Tables USB-92/93 give
BS 31:30 = HostReady0/DMABusy1/DMADone2/HostBusy3; TX 29:28 = success0,
DESERR1, reserved2, BUFERR3; L 27; non-ISO TXBYTES 15:0 is the programmed
0..65535-byte size. However, p1208 §3.18.11.2.2 explicitly says:

> In descriptor update mode, the descriptor’s Tx Bytes field contains the size of the packet transferred.

That is the only verbatim manual quotation in this note (16 words). It supports
a mode-dependent **DMA packet-size report**, not an unconditional claim that IN
low16 is input-only. It does not specify a successful-wire partial count or
justify importing OUT's last-descriptor aggregate-count rule into IN PPBNDU.
For a validated successful single packet, requested length can also describe
bytes staged into FIFO; that remains distinct from host acceptance. Sony p1188
§3.18.8.5.1 mentions an internal memory-transfer count used for error/retry
decisions; it does not identify a separate software-readable USB-ACK count.

**Revision-sensitive FIFO notifications.** Sony p1156 Table USB-72 defines
XFERDONE_TXEMPTY bit27 as FIFO empty after DMA completion; p1154 Table USB-70
requires this notification before the next PollDemand after a short packet or
ZLP. Sony p1157 Table USB-73 separately defines TXEMPTY bit24, dependent on an
optional FIFO-empty enhancement (configuration discussion p1122). AMD p314
reserves31:11; Micrel p141 reserves31:24; the pinned Linux header defines neither
bit24 nor bit27. These newer fields cannot be added to HP expectations merely
because the lower register map matches. Even a FIFO-empty indication requires
context excluding flush/reset/stale events before inferring packet acceptance.
Sony's descriptor access is little-endian (p1189); HP's explicit BE records are
separate stock evidence, another reason not to assume implementation identity.

## Reuse versus request completion

The documented normal-DMA handoff is successful descriptor completion after
source-to-FIFO transfer and terminal descriptor update. With correct mode,
visibility, current event identity and no remaining DMA reference, the source
bytes and finished descriptor can be reused **before** host ACK: retransmission
uses FIFO storage. This is a family-derived intended ownership rule, not an HP
bus-settlement observation. A stale DONE word or TDC bit alone does not prove
those preconditions, nor does any normal-completion rule settle abort/reset.
Check independent HE/BNA errors; a memory-access error can occur while fetching,
transferring or updating a descriptor (Sony p1210 §3.18.11.2.3).

Do not collapse these three milestones:

1. Exact source/descriptor accesses have settled; their memory may be reused.
2. FIFO data has been consumed through the controller's USB transaction rules.
3. The software USB request may advance or invoke its status-stage callback.

Classic-family software may give back buffers at milestone1 because hardware
owns the remaining USB work. That can be valid for its stack/offload arrangement;
it is not evidence that milestone1 means milestone2, or that another stack can
use the same notification for all control stages. A future DCD must reconcile
TinyUSB packetization, hardware standard-request/status offload and correct
next-PollDemand timing. Do not require or fabricate an ACK interrupt or actual
wire counter which the matched classic registers have not been shown to expose.

## Pinned Linux behavior, not an independent physical oracle

Pinned v6.12 `snps_udc_core.c`:

- `udc_data_in_isr`, lines2282–2332: rejects BNA/HE paths first, then handles TDC;
  sets `req.actual = req.length` and calls `complete_req`. In PPBDU it first
  obtains the last descriptor. Despite the comment at2316–2318,
  `udc_get_last_dma_desc` at994–1002 only follows `next` until L; it does not
  inspect BS, TX status or TXBYTES. This is not measured actual-count evidence.
- `complete_req`, lines960–989: unmaps the request and gives it back to the gadget
  caller. This documents the driver's chosen memory/API lifetime boundary.
- `udc_control_in_isr`, lines2652–2660,2683–2704: TDC is merely cleared; the IN
  branch publishes descriptor/PollDemand, immediately assumes requested bytes
  and gives back the request. It does not wait for TDC or host ACK.
- Queue shortcut1094–1120 completes a zero-length request before CSR_DONE/CNAK
  actions used for hardware status handling. This is not a ZLP-ACK observation.
- Header `amd5536udc.h:237–240,313–326` defines the matched event and IN fields;
  it supplies no additional wire-completion count or FIFO-empty event.

## Narrow original-stock anchors

Rechecked against ELF load bytes using the cached annotation-bounded disassembly;
no stock instructions were executed. Original sender span
`[0x10008c24,0x10008f40)` is 796 bytes, SHA256
`b179a25b722a2a7ed2e602df5befc3481f38ce11d969600c7b6abbfff4061c92`.

- Literal `0x10005e04` = `b3000004` (IN0 status), `0x10005ea0` =
  `b3000014` (IN0 descriptor pointer), `0x10005e18` = `10021318` (event object).
- IRQ chooses the IN status base at `0x100083c7..0x100083cc` for direction0;
  then reads the selected EP status at `0x100083eb`. The same saved status is
  used after HE0x200/BNA0x80 acknowledgements at `0x100083ed..0x10008401`.
  Their presence does not prevent the later TDC branch.
- `0x10008446..0x1000844f` checks/acknowledges mask 0x400. Exact 11 bytes:
  `284a0078606a0c02009870`.
  For IN0, the derived event mask is 1; the non-mask2 path at
  `0x100084a9..0x100084b4` calls event-set `0x10017dac` on that object.
  Exact 14 bytes: `1af65bdb702c0a00011102583e3d`.
- Zero and nonzero sender paths publish DESPTR, OR control0x108 and call event
  wait `0x10017d28` at `0x10008d25` / `0x10008f30`. The latter resumes with a
  software remaining-length load/branch at `0x10008f33..0x10008f36`; it does
  not inspect completed TX status/TXBYTES. The existing event-contract evidence
  identifies wait bit 1, OR+clear, infinite timeout.

Thus stock also offers a DMA wake hint, not an original-cookie-tagged ACK/count
record. Existing IRQ investigations own the broader ordering analysis; it was
not repeated here.

## Current component and practical next decision

`open-firmware/udc-ep0/hp1020_udc_ep0.c:165–202` requires original cookie,
visible immutable descriptor, owner2/TX0/L1/body checks, supplied settlement and
packet visibility, plus separately supplied known actual length equal to the
request. It intentionally ignores IN low16 as its success oracle. On acceptance
it calls `adapter_complete(SUCCESS, requested)`. The header/README supply no
hardware producer for those facts and are unchanged by this review.

Do not populate `in_actual` by copying the requested field and relabeling TDC as
USB success. Conversely, the manuals do not justify demanding an unavailable
successful-wire byte counter. A real backend must explicitly choose the
completion semantics for each stage and retain the controller's FIFO/protocol
ownership independently of released source memory.

This matters concretely: current TinyUSB `usbd.c:901–911` treats a status-endpoint
completion as `dcd_edpt0_status_complete` plus `CONTROL_STAGE_ACK`; data completion
advances counts and can submit another packet/status stage at927–949. A generic
DMA-done notification cannot be mapped blindly to both. The highest-value next
step is the parent agent's standard-request/offload integration decision, not a
new RAM test pretending to establish wire delivery. No production change is
recommended from this note alone.

## Provenance

Manuals remain cached only under `/tmp/hp1020-udc-manual-review-20260929/`.
They were fetched from the official URLs on 2026-09-29; hashes were reverified
on 2026-09-30. Existing retrieval metadata is `PROVENANCE.json` there.

| Document | Official source/revision | Bytes; SHA256 |
| --- | --- | --- |
| `CXD5602-user-manual-1.1.0.pdf` | [Sony CXD5602 User Manual](https://www.sony-semicon.com/files/62/pdf/p-28_CXD5602_user_manual.pdf),1.1.0,2022-10-24 (revision history p1290);1293 pages |16312211; `c21b1d93018421d7c283ab377a7dabec3339badd4809652885a8a1b76e522802` |
| `33238G_cs5536_db.pdf` | [AMD Geode CS5536 Companion Device Data Book](https://www.amd.com/content/dam/amd/en/documents/archived-tech-docs/datasheets/33238G_cs5536_db.pdf),33238G,May2007;612 pages |5468952; `a829ae505ed96a180856c84291ab26e838453ff19a589c9af7624c1e7bfcd929` |
| `ksz9692mpb_xpb_reg_descp_v1.0.pdf` | [Micrel KSZ9692MPB/XPB Register Description](https://ww1.microchip.com/downloads/en/DeviceDoc/ksz9692mpb_xpb_reg_descp_v1.0.pdf),M9999-102008-1.0,October2008;248 pages |1940799; `27948fa8a9da03295a5790fb79acf0deafebbba8186e4ae7e06face287f14afe` |

Repository root:
`/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos`.
Linux commit `adc218676eef25575469234709c2d87185ca223a` (v6.12); local source
base `analysis/usb-path/controller-reference/linux-v6.12/`.

| Source | SHA256 |
| --- | --- |
| `analysis/sihp1020.elf` | `2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d` |
| Linux `snps_udc_core.c` | `c1b09e8f69d3340f2afd3a033d77a42775b52716d45b1aceb211dcaab89127bf` |
| Linux `amd5536udc.h` | `8dbf2ebffe7de042bdfea1c5e4e0d7e7ca334cb821fbfaa1cf9ccfeeae302648` |
| `open-firmware/udc-ep0/README.md` | `d8be88fd1e6ab2438041b68e2cc721fcdfb9355d00b77eb4e3343b9aed6319eb` |
| `open-firmware/udc-ep0/hp1020_udc_ep0.h` | `e9e9abb620e6a7c81bb7c3bb1050a1fd47820e5d6c228a16834c1150996cad11` |
| `open-firmware/udc-ep0/hp1020_udc_ep0.c` | `397c99e7b25239ae4dfb59179ea401f1e9e7d5befeb92aed853681ab90bcf140` |
| Current `vendor/tinyusb-0.21.0/src/device/usbd.c` | `38de54351d81878e6543f2b022d0c39f45d28c8f0888491796398dec45e727be` |
| `open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.c` | `ed7195a2d007d909a177d5f5e3451257f4341e84898946a3b0eef5adaac0d72f` |

Static disassembly cache: `/tmp/hp1020-pio-annotated-20260930.{json,txt}`,
created with pinned `/tmp/hp1020-xtensa-manual-systemz/bin/xtensa-fsf-elf-objdump`
(GNU Binutils2.30.0.20180625). Rendered diagram checks:
`/tmp/hp1020-in-sony-{1125,1192,1193}.png`. Text extracts are under
`/tmp/hp1020-in-{sony,amd,micrel}-*.txt`. These are inspection aids; the exact
PDFs and original ELF above remain the primary bytes.
