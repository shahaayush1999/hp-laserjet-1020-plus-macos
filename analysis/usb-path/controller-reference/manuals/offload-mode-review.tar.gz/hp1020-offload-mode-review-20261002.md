# HP dynamic CSR applicability: bounded original-byte review

2026-10-02. Repository baseline `c5d59b9`; read-only work. No validator, build,
QEMU/target execution, USB contact, MMIO or repository edits. This extends the
prior standard-request review only at startup/caller state and direct register
references. It does not repeat the PIO, IN-completion or IRQ experiments.

## Actionable conclusion

No additional stock path establishing DEVCFG.CSR_PRG=1 was found. The startup
helper previously left outside the inspection is **an event barrier**, not a
controller initializer. All seven annotated direct loads of the DEVCFG literal
are now accounted for: five stores preserve CSR_PRG from their sampled value;
two accesses only read speed. The seven direct DEVCTL stores do not explicitly
set CSR_DONE. Under the reference's read-zero CSR_DONE semantics they never grant
that permission.

The original code is therefore better evidence for an application using static
hardware offload than for the proposed dynamic status gate. This is still an
inference: the undocumented HP wrapper pulse or inherited boot/ROM state could
supply controller state. There is no offline proof of HP's CSR_PRG reset value,
writability, dynamic capability or resulting handshake behavior.

A typed dynamic-offload software fixture remains useful **with an explicit
supplied mode/capability precondition**. It must not treat running the stock
startup, calling the ready helper, or observing a configuration value as proof
that the gate is enabled. A physical backend would require its own deliberate
initialization and verification of that capability. No such hardware operation
is proposed or authorized by this note.

## Startup call and creator

1. USB2Thread at `0x10008ff0` calls `0x1001214c` at `0x10008ff6`
   (bytes `582455`). The wrapper sets argument3 and calls `0x1001215c`:
   `[0x1001214c,0x1001215a)` =
   `6c10042a0a03011102580001d10f`.
2. For argument3, `0x1001215c..0x10012180` selects mask4, loads literal
   `0x10006530` = `0x1002c6f8`, and calls event-get `0x10017d28` at
   `0x1001217d`. Arguments are event pointer, mask4, mode0, stack result,
   timeout `0xffffffff`. This is the non-clearing OR wait in the existing
   event-flag contract. No DEVCFG/DEVCTL access occurs in this wrapper.
   It does not test the returned result before returning to USB2Thread.
3. Initialization caller `0x100120f9` invokes creator `0x10009940` (bytes
   `5bde11`). The creator initializes RAM/event/thread objects and invokes
   `0x10018274` at `0x10009a08`; literals at `0x10005fc0/c4/c8/cc` are the
   control block, name, entry `0x10008ff0`, and stack respectively. Its entry
   argument is zero (`a2=0` at `0x1000994d`, `a13=a2` at `0x10009a00`).
   There is no hidden mode argument or direct controller-address load in this
   inspected creator. This does not prove the entire RTOS/caller environment.
4. Waiting permits other tasks to run. The shared ready event does not encode a
   USB register snapshot or dynamic-mode promise. Preceding boot/initialization
   code and indirect calls are not discharged merely because this wait returns.

The exact per-instruction rows and original bytes for both helpers and the
creator are in the neighboring `/tmp` anchor JSON. Padding between separate
functions was excluded from fresh disassembly starts.

## DEVCFG: every direct literal reference

The only aligned loadable ELF word equal to `0xb3000400` is at `0x10005df4`.
The annotation-bounded instruction inventory contains seven L32R references.
`R0` and `R1` below are distinct peripheral reads, not assumed identical.

| Literal load | Use / store | Byte-derived operation |
| --- | --- | --- |
| `0x1000824f` | store `0x1000825f` | `R0 & 0xfffffffc` |
| `0x10008312` | store `0x10008332` | `(R0 & 0xfffffffc) | 1 | (R1 & 3)` |
| `0x1000901f` | store `0x1000903a` | `R0 | 8` |
| `0x10009484` | read `0x1000948a` | low2 extraction at `0x1000948c`; descriptor-speed branch only |
| `0x100095c2` | read `0x100095c8` | low2 extraction at `0x100095cb`; descriptor-speed branch only |
| `0x10009ae6` | store `0x10009b06` | for function argument2: `(R0 & 0xfffffffc) | 1 | (R1 & 3)` |
| `0x10009b0b` | store `0x10009b1b` | for unsigned argument<2: `R0 & 0xfffffffc`; higher values do not write |

Each written bit17 equals bit17 from the relevant first read. This is a property
of the instructions, not an assertion that hardware/concurrent writers cannot
change the register. The `0x10009ae0` setter cannot smuggle a high mode bit through
its argument: it compares the argument and uses fixed low-bit operations.

## DEVCTL: no explicit CSR_DONE permission

The only aligned loadable ELF word equal to `0xb3000404` is at `0x10005ea8`.
Its five direct L32R loads cover these seven stores:

| Store | Operation on sampled DEVCTL | CSR_DONE bit13 |
| --- | --- | --- |
| `0x10008fa3` | OR4 | unchanged |
| `0x1000904a` | AND `0x00ffffff` | unchanged |
| `0x1000905d` | OR `0x00030000` | unchanged |
| `0x1000906d` | OR `0x320` | unchanged |
| `0x100092ef` | OR8 (`a4=8` from original `0x10009179`) | unchanged |
| `0x10009a26` | AND `0xfffffff7` | unchanged |
| `0x10009a83` | OR8 | unchanged |

The `0x00030000` literal is DEVCTL's burst-length field; its bit17 is **not**
DEVCFG.CSR_PRG. No inspected write introduces `0x00002000`.
AMD33238G p323 explicitly makes CSR_DONE read as zero; Sony p1138 marks it
write-only. Under that documented behavior, these read/modify/write paths write
zero to the permission bit. This is stronger than merely finding no named
CSR_DONE constant, but remains conditional on the actual HP register semantics.

## The remaining initial-state ambiguity is precise

`0x10005eac` is `0xb3010000`, outside the matched classic UDC register block.
After the barrier, startup tests its numeric bit0 at `0x10009003`; when zero it
writes the sampled wrapper word OR2 at `0x10009018`, then a fresh read AND~2
at `0x10009028`. Only afterward does it read DEVCFG and OR8. If numeric bit0 is
one, it jumps to `0x100090fd`, skipping that configuration prefix. Xtensa BE
bit-branch index31 denotes numeric bit0; it must not be misread as mask
`0x80000000`.

Later common code ORs4 and ORs1 into the wrapper at `0x100092c9/0x100092d9`.
These bytes support an initialization/latch sequence. They do **not** identify
bit1 as a reset, prove what it resets, or prove that it forces CSR_PRG to zero.
Calling this a cold branch is useful shorthand, not established hardware reset
semantics. Even if it were a controller reset, transferring another chip's
reset defaults to HP would be an additional assumption.

Family documents do supply reset-zero CSR_PRG: Sony1.1.0 p1134 Table USB-49;
AMD33238G p321 DEVCFG reset word `0x20`. They cannot resolve HP wrapper behavior
or inherited bootloader state. The known static endpoint CSR writes, masked SC/SI
and acknowledgement-only SC/SI branches remain consistent with static offload,
but they do not logically establish the initial mode. A guarded RAM execution
of these preserving operations would only repeat this arithmetic, not answer
the peripheral reset question.

## Reference comparison and next integration constraint

Pinned Linux v6.12 `snps_udc_core.c:1455–1485` takes a different explicit action:
`udc_basic_init` disables RDE/TDE and sets DEVCFG.CSR_PRG before returning.
Its CSR_DONE write at1103–1107 grants status for pending configuration/interface
work. Those actions are absent from the bounded HP reference paths above.
Sony pp1134/1138 and p1212 separately specify the dynamic programming gate and
permission-before-status flow. This makes dynamic offload a documented family
option, not a demonstrated HP firmware mode.

Keep three facts separate in the new software integration:

- The hardware handled the original standard request and supplied typed fields.
- The chosen controller mode actually holds its status response until permission.
- The current operation owns the one permission, after software configuration is
  ready and without issuing a second normal EP0 status packet.

The draft can test the second as a supplied fact. It cannot infer it from the
first, from DEVCFG's unrelated low-speed bits, or from the shared ready event.
No new queue, fabricated raw SETUP packet, hardware allowlist or experimental
MMIO is justified by this review.

## Search scope and provenance

The original ELF's annotation-bounded instructions and direct L32R references
were inspected, and every retained instruction's raw bytes were compared to its
load segment. Fresh disassembly used the pinned BE objdump, separately aligned
at each relevant function/cut. The unique-literal scan covered aligned words in
PT_LOAD file bytes. It is **not** whole-program pointer analysis: synthesized
addresses, offsets from another register base, runtime pointers, unannotated
code, aliases, earlier resident firmware and peripheral side effects remain
outside the negative claim. No imported emulator/generator was run.

New inspection aids (not execution reports):

- `/tmp/hp1020-offload-mode-anchors-20261002.json`: full raw bytes, independent
  literal words, disassembly rows and per-region SHA256; hash
  `c876d65de3ddbba8ae62276effc11e29320a99b45be7d3cbf6502727ec7bf2e9`.
- `/tmp/hp1020-offload-mode-disassembly-20261002.txt`: fresh aligned disassembly;
  hash `05faf4124342251400844ebbda2849031750c5691272fe8dd246320306b5e376`.
- Reused annotated cache `/tmp/hp1020-pio-annotated-20260930.json`; hash
  `58b8d91665187865f88cc45bc5d4d7cebac49fc8a1b420eced6d0fb38059956d`.

Repository root:
`/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos`.
Stock `analysis/sihp1020.elf`:128372 bytes; SHA256
`2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`.
Tool: `/tmp/hp1020-xtensa-manual-systemz/bin/xtensa-fsf-elf-objdump`,
GNU Binutils2.30.0.20180625. No firmware instructions were executed.

Linux v6.12 commit `adc218676eef25575469234709c2d87185ca223a`, local directory
`analysis/usb-path/controller-reference/linux-v6.12/`:
`snps_udc_core.c` SHA256
`c1b09e8f69d3340f2afd3a033d77a42775b52716d45b1aceb211dcaab89127bf`;
`amd5536udc.h` SHA256
`8dbf2ebffe7de042bdfea1c5e4e0d7e7ca334cb821fbfaa1cf9ccfeeae302648`.

Cached official manuals remain in `/tmp/hp1020-udc-manual-review-20260929/`:

- [Sony CXD5602 User Manual](https://www.sony-semicon.com/files/62/pdf/p-28_CXD5602_user_manual.pdf),
  revision1.1.0,2022-10-24; file `CXD5602-user-manual-1.1.0.pdf`,16312211 bytes;
  SHA256 `c21b1d93018421d7c283ab377a7dabec3339badd4809652885a8a1b76e522802`.
- [AMD Geode CS5536 Companion Device Data Book](https://www.amd.com/content/dam/amd/en/documents/archived-tech-docs/datasheets/33238G_cs5536_db.pdf),
  publication33238G,May2007; file `33238G_cs5536_db.pdf`,5468952 bytes;
  SHA256 `a829ae505ed96a180856c84291ab26e838453ff19a589c9af7624c1e7bfcd929`.

Printed page numbers equal1-based PDF pages; zero-based page index is page minus
one. No verbatim manual quotation is reproduced. This note does not change the
prior official-manual or original execution evidence.
