# USB controller-family comparison

Strong register/descriptor-family match to the classic Synopsys device-only UDC used by the Linux snps_udc driver; not the DWC2 high-speed OTG register layout. This does not identify an AMD chip or prove a compatible silicon revision.

Pinned Linux v6.12 [register definitions](https://github.com/torvalds/linux/blob/adc218676eef25575469234709c2d87185ca223a/drivers/usb/gadget/udc/amd5536udc.h), [driver](https://github.com/torvalds/linux/blob/adc218676eef25575469234709c2d87185ca223a/drivers/usb/gadget/udc/snps_udc_core.c) and [platform glue](https://github.com/torvalds/linux/blob/adc218676eef25575469234709c2d87185ca223a/drivers/usb/gadget/udc/snps_udc_plat.c) are preserved with provenance and GPL license under `controller-reference/linux-v6.12/`.

24 stock literal/layout matches and 18 byte-checked instruction anchors. Twelve re-arm cases agree between original instruction interpretation, independent QEMU and an independently constructed byte oracle. Both unredirected-store controls reject before MMIO.

| Item | Stock literal | Value |
|---|---|---|
| devcfg | `0x10005df4` | `0xb3000400` |
| devctl | `0x10005ea8` | `0xb3000404` |
| devsts | `0x10005e68` | `0xb3000408` |
| devint | `0x10005de4` | `0xb300040c` |
| devint_msk | `0x10005eb8` | `0xb3000410` |
| epint | `0x10005de8` | `0xb3000414` |
| epint_msk | `0x10005e00` | `0xb3000418` |
| in0_status | `0x10005e04` | `0xb3000004` |
| out0_status | `0x10005e08` | `0xb3000204` |
| out0_control | `0x10005e24` | `0xb3000200` |
| out1_control | `0x10005e70` | `0xb3000220` |
| out1_max_packet | `0x10005f08` | `0xb300022c` |
| out1_descriptor | `0x10005e60` | `0xb3000234` |
| in1_descriptor | `0x10005e84` | `0xb3000034` |
| in0_max_packet | `0x10005e9c` | `0xb300000c` |
| in0_descriptor | `0x10005ea0` | `0xb3000014` |
| out0_setup | `0x10005ef4` | `0xb3000210` |
| out0_descriptor | `0x10005ef8` | `0xb3000214` |
| out0_max_packet | `0x10005ee4` | `0xb300020c` |
| descriptor_owner_mask | `0x10005e30` | `0xc0000000` |
| descriptor_dma_done | `0x10005e34` | `0x80000000` |
| descriptor_last | `0x10005e80` | `0x8000000` |
| enumerated_speed_mask | `0x10005ea4` | `0x6000` |
| control_pair_and_out1_unmasked | `0x10005f04` | `0xfffcfffe` |

The old re-arm note called the leading byte an opcode/value 8. The full status word is `0x08000000`: the reference identifies bit 27 as the last-descriptor flag, with ownership bits 31:30 zero (host ready). Stock completion separately requires ownership 2 and reads the low 16-bit count. These labels are a cross-source interpretation supported by exact original bytes, not live controller observation.

Re-arm preserves descriptor bytes 4..7, selects an aligned nonzero next pointer or base plus offset, writes the target at +8, and clears +12. Submission precedes the status-byte stores in the original instruction order; this RAM experiment does not validate the bus ordering. Entire guard regions and completion flags are compared under two initial fills.

A separately byte-checked startup branch ORs `0x320` into device control, matching the reference BE/burst/mode bit positions. The branch and its peripheral stores are inspected only. This supports investigating the controller byte-order setting; it does not prove live configuration or portable DMA/cache behavior.

Use the existing Linux controller code to guide a small freestanding adapter, then assess a generic USB/printer class layer. Retain HP-specific startup, byte order, cache/alias and reset/abort questions. Do not add peripheral writes to the current software image pipeline or bypass the existing inert hardware-test ladder.

Only original re-arm descriptor construction executes, with supplied globals and the one submission literal redirected to RAM. No USB controller behavior, real DMA/interrupts/cache, setup/reset/cancel correctness, live traffic, boot or printing is established. HP-specific wrapper registers at 0xb3010000/4 remain outside this match. The Linux driver is a reference, not a linked runtime or usable HP port.
