# Acquisition copied-evidence controls

This is synthetic checker evidence, not additional host/target execution or
physical lifecycles. The frozen driver ran unchanged against the first sealed
32-case acquisition run and its unchanged V2 checker. Fifteen internally paired
semantic corruptions were rejected in both modes at the intended contract.
The saved-effective-source corruption passes report-only (which cannot inspect
unsupplied files) and fails raw mode at the exact saved-byte seal. The original
positive report, raw captures, checker and source manifests remained unchanged.

Reconstruct each synthetic capture by copying its listed unchanged base members
from first-paired-32-cases.tar.gz and overlaying its saved changed members here.
unchanged-base-members.json seals every referenced base hash; this archive was
read back and all references checked against the durable base archive. Never
substitute these deliberately corrupted reports for actual execution evidence.
The driver's original draft note remains a historical pre-execution document.
