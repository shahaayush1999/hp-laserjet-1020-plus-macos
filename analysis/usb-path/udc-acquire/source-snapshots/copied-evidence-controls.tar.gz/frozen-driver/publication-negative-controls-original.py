#!/usr/bin/env python3
"""Unexecuted stdlib corruption driver for the publication capture gate.

Root must run this only after the unchanged gate has passed the first complete
paired report. Every control uses a separate copied report/evidence tree; the
original gate, report, source and captures are never edited. All writes replace
files atomically, including when unchanged files are initially hardlinked.

No compiler, firmware, decoder, hardware access or producer import is used.
When explicitly executed, this driver imports only the selected local gate and
standard-library modules. It first verifies the positive baseline, then requires
both report-only and raw-capture rejection at a named independent contract check.
Synthetic corrupted observations are not new host/target execution evidence.
"""
import argparse
import copy
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import struct
import sys
import tempfile


WIDTHS=(96,104,48,40,80,64,64)
STEP_KEYS=('steps','ep0_steps','bulk_steps','setup_steps','offload_steps','program_steps','publish_steps')
INITIAL_KEYS=('initial','initial_ep0','initial_bulk','initial_setup','initial_offload','initial_program','initial_publish')
CAPTURE_NAMES={'pixels':'pixels','wire':'wire','documents':'documents',
    'receive':'receive','output':'output','ep0':'output.ep0-descriptors',
    'bulk_descriptor':'output.udc-descriptor','setup_record':'output.setup-record',
    'program_reads':'output.program-read-script','program_trace':'output.program-trace',
    'program_storage':'output.program-storage'}
U32=0xffffffff


class ControlError(ValueError):
    pass


def require(condition,message):
    if not condition:
        raise ControlError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def fnv(raw):
    value=2166136261
    for byte in raw:
        value=((value^byte)*16777619)&U32
    return value


def packed(words):
    return b''.join(v.to_bytes(4,'big') for v in words)


def flat(rows):
    return b''.join(packed(row) for row in rows)


def json_bytes(value):
    return (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()


def rows_bytes(rows):
    return b''.join((json.dumps(row,separators=(',',':'))+'\n').encode() for row in rows)


def atomic_write(path,raw):
    """Never write through a hardlink to original evidence."""
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix='.'+path.name+'-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as output:
            output.write(raw)
        os.replace(name,path)
    finally:
        if os.path.exists(name): os.unlink(name)


def link_or_copy(source,destination):
    try:
        os.link(source,destination)
    except OSError as error:
        if error.errno!=errno.EXDEV: raise
        shutil.copy2(source,destination)
    return destination


def load_gate(path):
    spec=importlib.util.spec_from_file_location('independent_publication_gate',path)
    require(spec is not None and spec.loader is not None,'cannot load selected gate')
    module=importlib.util.module_from_spec(spec)
    previous=sys.dont_write_bytecode
    sys.dont_write_bytecode=True
    try:
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode=previous
    require(callable(getattr(module,'check_publish_report',None)),
            'selected gate lacks check_publish_report')
    return module


class EvidenceCopy:
    def __init__(self,original,original_root,root):
        self.original=original
        self.report=copy.deepcopy(original)
        self.root=Path(root)
        require(not self.root.exists(),'refuse to overwrite existing control evidence '+str(root))
        shutil.copytree(original_root,self.root,copy_function=link_or_copy)
        self.touched=set()
        self.changes=[]

    def choose(self,profile,fill=0):
        found=[i for i,c in enumerate(self.report['cases'])
               if c['scenario']=='publish/'+profile and c['fill']==fill]
        require(len(found)==1,'unique independent control profile '+profile)
        self.touched.add(found[0])
        return found[0],self.report['cases'][found[0]]

    def directory(self,index):
        return self.root/f'case-{index:03}'

    def capture(self,index,key):
        return (self.directory(index)/CAPTURE_NAMES[key]).read_bytes()

    def replace_capture(self,index,key,raw):
        directory=self.directory(index)
        atomic_write(directory/CAPTURE_NAMES[key],raw)
        atomic_write(directory/('target-'+key),raw)
        digest=sha(raw)
        self.report['cases'][index]['capture_sha256'][key]=digest
        self.report['target']['cases'][index]['capture_sha256'][key]=digest
        self.touched.add(index)

    def replace_trace(self,index,rows):
        case=self.report['cases'][index]
        require(len(rows)==len(case['expected_program_trace']),'trace mutation may not resize the ledger')
        case['expected_program_trace']=rows
        for entry in case.get('program_oracles',[]):
            begin,end=entry['trace_begin'],entry['trace_end']
            require(0<=begin<=end<=len(rows),'redundant trace block extent')
            entry['literal_trace']=[row[2:] for row in rows[begin:end]]
        raw=flat(rows)
        storage=bytearray(self.capture(index,'program_storage'))
        require(len(storage)==27712 and len(raw)<=24576,'recording storage geometry')
        # Existing read allocation3104, then trace guard16 and1024x24 bytes.
        storage[3120:3120+len(raw)]=raw
        self.replace_capture(index,'program_trace',raw)
        self.replace_capture(index,'program_storage',bytes(storage))

    def change(self,label,detail):
        self.changes.append({'field':label,'change':detail})

    def sync(self):
        for index in sorted(self.touched):
            case=self.report['cases'][index]; native=self.report['target']['cases'][index]
            directory=self.directory(index)
            raw_events=b''.join(packed(e['words']+[len(bytes.fromhex(e['data_hex']))])+
                                bytes.fromhex(e['data_hex']) for e in case['events'])
            atomic_write(directory/'events.bin',raw_events)
            host_rows=[sum([case[k] for k in INITIAL_KEYS],[])]+[
                sum([case[k][i] for k in STEP_KEYS],[]) for i in range(len(case['events']))]
            require(all(len(row)==496 for row in host_rows),'mutated host row width')
            target_rows=[]
            for host in host_rows[1:]:
                target=host.copy()
                target[59]=native['adapter_state_and_memory_bytes']
                target[425]=native['component_and_allocation_bytes']['program']
                target[490]=native['component_and_allocation_bytes']['publisher']
                target_rows.append(target)
            atomic_write(directory/'raw-stdout',rows_bytes(host_rows))
            atomic_write(directory/'target-steps.jsonl',rows_bytes(target_rows))
            # Keep auxiliary diagnostic logs coherent if this producer saved
            # them. They are not an alternative oracle or execution transcript.
            for key,path in (('steps','host-steps.jsonl'),('ep0_steps','host-ep0-steps.jsonl'),
                             ('bulk_steps','host-udc-steps.jsonl'),
                             ('setup_steps','host-setup-steps.jsonl'),
                             ('offload_steps','host-offload-steps.jsonl'),
                             ('program_steps','host-program-steps.jsonl'),
                             ('publish_steps','host-publish-steps.jsonl')):
                if (directory/path).exists(): atomic_write(directory/path,rows_bytes(case[key]))
            if (directory/'host-composed-steps.jsonl').exists():
                composed=[a+b for a,b in zip(case['bulk_steps'],case['setup_steps'])]
                atomic_write(directory/'host-composed-steps.jsonl',rows_bytes(composed))
        for key in ('source_sha256','fixture_sha256','effective_source'):
            require(self.report[key]==self.original[key],'mutation changed protected '+key)
        require(self.report['target']['captured_artifact_sha256']==
                self.original['target']['captured_artifact_sha256'],'mutation changed target build artifacts')
        atomic_write(self.root/'validation.json',json_bytes(self.report))
        atomic_write(self.root/'SYNTHETIC-CORRUPTION.json',json_bytes({
            'not_host_target_or_device_execution':True,'mutations':self.changes}))

    def paired_consistency(self):
        """Sealing only, intentionally no semantic assumptions from the gate."""
        require(json.loads((self.root/'validation.json').read_bytes())==self.report,
                'saved mutated report mismatch')
        for index in sorted(self.touched):
            case=self.report['cases'][index]; native=self.report['target']['cases'][index]
            directory=self.directory(index)
            expected_events=b''.join(packed(e['words']+[len(bytes.fromhex(e['data_hex']))])+
                                     bytes.fromhex(e['data_hex']) for e in case['events'])
            require((directory/'events.bin').read_bytes()==expected_events,'paired input bytes')
            host_rows=[json.loads(line) for line in (directory/'raw-stdout').read_bytes().splitlines()]
            wanted=[sum([case[k] for k in INITIAL_KEYS],[])]+[
                sum([case[k][i] for k in STEP_KEYS],[]) for i in range(len(case['events']))]
            require(host_rows==wanted,'paired host raw rows versus report')
            target_rows=[json.loads(line) for line in (directory/'target-steps.jsonl').read_bytes().splitlines()]
            require(len(target_rows)==len(host_rows)-1,'paired target row count')
            for host,target in zip(host_rows[1:],target_rows):
                require(len(target)==496 and all(a==b for j,(a,b) in enumerate(zip(host,target))
                        if j not in (59,425,490)),'paired target rows differ outside measured sizes')
                require([target[59],target[425],target[490]]==[
                    native['adapter_state_and_memory_bytes'],native['component_and_allocation_bytes']['program'],
                    native['component_and_allocation_bytes']['publisher']],'paired target measured sizes')
            require(set(case['capture_sha256'])==set(CAPTURE_NAMES) and
                    case['capture_sha256']==native['capture_sha256'],'paired capture manifests')
            for key,path in CAPTURE_NAMES.items():
                raw=(directory/path).read_bytes()
                require(raw==(directory/('target-'+key)).read_bytes(),'paired capture bytes '+key)
                require(sha(raw)==case['capture_sha256'][key],'paired capture digest '+key)
            require((directory/'output.program-read-script').read_bytes()==flat(case['supplied_reads']),
                    'paired supplied read summary')
            raw_trace=(directory/'output.program-trace').read_bytes()
            require(raw_trace==flat(case['expected_program_trace']),'paired trace summary')
            storage=(directory/'output.program-storage').read_bytes()
            require(len(storage)==27712 and storage[3120:3120+len(raw_trace)]==raw_trace,
                    'paired used trace storage')
            raw_reads=flat(case['supplied_reads'])
            require(storage[16:16+len(raw_reads)]==raw_reads,'paired used read storage')
        return {'cases':sorted(self.touched),'raw_input_rows_and_all_capture_pairs_agree':True,
                'source_fixture_and_target_build_manifests_unchanged':True}


def first_step(case,predicate,label):
    found=[i for i,e in enumerate(case['events']) if predicate(i,e)]
    require(found,'missing intended baseline event '+label)
    return found[0]


def first_failure(case):
    return first_step(case,lambda i,e:case['publish_steps'][i][6]==1 and
                      (i==0 or case['publish_steps'][i-1][6]==0),'new publication failure')


def replace_failure_query_digest(case,old_fields,new_fields):
    old_digest,new_digest=fnv(packed(old_fields)),fnv(packed(new_fields))
    for row in case['publish_steps']:
        if row[44]==old_digest: row[44]=new_digest


def wrong_pixel(evidence):
    index,case=evidence.choose('cnak-and-page')
    pixels=evidence.capture(index,'pixels')
    require(pixels==b'\xff'*32,'positive pixel baseline must be independent32FF')
    changed=pixels[:17]+b'\xfe'+pixels[18:]
    evidence.replace_capture(index,'pixels',changed)
    case['expected_pixels_sha256']=sha(changed)
    for row in case['steps']:
        require(row[50] in (0,32),'selected simple page pixel count')
        if row[50]: row[51]=fnv(changed)
    evidence.change('pixel bytes/FNV/expected digest','both engines consistently claim32bytes with byte17=FE')


def wrong_cnak(evidence):
    index,case=evidence.choose('cnak-and-page')
    rows=copy.deepcopy(case['expected_program_trace'])
    positions=[i for i,row in enumerate(rows) if row[2:]==[2,0x220,0x120,0]]
    require(positions,'original literal CNAK command')
    rows[positions[0]][4]=0x160
    evidence.replace_trace(index,rows)
    evidence.change('CNAK trace/logical write','120 becomes160 in both used trace captures and full recording storage')


def wrong_receive_dma(evidence):
    index,case=evidence.choose('cnak-and-page')
    rows=copy.deepcopy(case['expected_program_trace'])
    positions=[i for i,row in enumerate(rows) if row[2:]==[4,0x24681340,64,0]]
    require(positions,'first-slot independent RX cache trace')
    rows[positions[0]][3]=0x24682340
    evidence.replace_trace(index,rows)
    evidence.change('selected RX cache DMA','both engines now claim slot1cache for original slot0reservation')


def wrong_prefix(evidence):
    _,case=evidence.choose('desptr-write-uncertain'); at=first_failure(case)
    old=list(case['publish_steps'][at][22:36]); new=old.copy()
    require(old[5]==31,'independent DESPTR-failure prefix31')
    new[5]=63
    for row in case['publish_steps'][at:]:
        if row[22:27]==old[:5]:
            row[27]=63
            if row[8]==31: row[8]=63
    replace_failure_query_digest(case,old,new)
    evidence.change('current/retained prefix and query FNV','claim successful DESPTR write despite original UNKNOWN attempt')


def retag_failure(evidence):
    _,case=evidence.choose('desptr-write-uncertain'); at=first_failure(case)
    old=list(case['publish_steps'][at][22:36]); new=old.copy()
    new_epoch=case['steps'][at][4]
    require(new_epoch!=old[1],'post-fence epoch must differ from original bound epoch')
    new[1]=new_epoch
    for row in case['publish_steps'][at:]:
        if row[22:27]==old[:5]: row[23]=new_epoch
    replace_failure_query_digest(case,old,new)
    evidence.change('failure original epoch and query FNV','retag all retained diagnostics to newer fenced epoch; earlier bind remains original')


def fake_settlement(evidence):
    _,case=evidence.choose('rx-cache-failure'); at=first_failure(case)
    base=case['steps'][at]; out=case['bulk_steps'][at]
    require(out[2]==1 and base[35]>0 and (out[44]>>16)==1,'PREPARED/DCD failure with reserved input')
    base[13]&=~4; base[14]&=~4; base[30]=base[31]=base[35]=0
    out[2]=0; out[16:21]=[0]*5; out[22:24]=[0,0]; out[44]&=0xffff
    evidence.change('first failed owner/reservation row','both engines claim FREE/NONE and dropped input without any raw settlement event')


def cleanup_drops_accounting(evidence):
    _,case=evidence.choose('cleanup-original-cookie')
    at=first_step(case,lambda i,e:e['words'][0]==133 and case['steps'][i][0]==0,'successful original cleanup')
    base=case['steps'][at]; publish=case['publish_steps'][at]
    require(base[35]>0 and publish[56]==publish[57]==base[35],'independently retained nonzero cleanup count')
    base[33:36]=[0,0,0]; publish[56:58]=[0,0]
    evidence.change('successful cleanup accounting','both engines now clear issued/consumed/count without the later three-promise restart')


def grant_invents_ack(evidence):
    _,case=evidence.choose('cnak-and-page')
    at=first_step(case,lambda i,e:e['words'][0]==124 and case['steps'][i][0]==0,'original automatic grant')
    for row in case['offload_steps'][at:]: row[57]+=1
    evidence.change('genuine status callback count','one fabricated callback at grant, consistently carried through both later streams')


def in_length_from_status(evidence):
    _,case=evidence.choose('progress-barriers')
    at=first_step(case,lambda i,e:e['words'][0]==44 and
                  bytes.fromhex(e['data_hex'])[:4]==bytes.fromhex('8800ffff'),'one-byte IN observation')
    event=case['events'][at]; raw=bytes.fromhex(event['data_hex'])
    require(len(raw)==20 and raw[-4:]==packed([1]),'independent IN actual1 baseline')
    event['data_hex']=(raw[:16]+packed([65535])).hex()
    for row in case['ep0_steps'][at:]: row[56+41]=65535
    evidence.change('raw IN observation/actual witness','descriptor unchanged8800ffff; separately supplied actual falsely becomes65535')


def unused_tail(evidence):
    index,case=evidence.choose('cnak-and-page',204)
    raw=bytearray(evidence.capture(index,'program_storage'))
    used=len(evidence.capture(index,'program_reads')); offset=16+used
    require(used<3072 and raw[offset]==204,'known unused read payload tail and fill')
    raw[offset]^=1
    evidence.replace_capture(index,'program_storage',bytes(raw))
    evidence.change('paired full storage unused byte',f'flip byte{offset}; used records and guards untouched, both capture digests updated')


CONTROLS=(
    ('paired-wrong-pixel',wrong_pixel,('independent exact black page and END_DOC oracle',)),
    ('cnak-replays-read-only-nak',wrong_cnak,('untrusted trace/read summaries differ from independent rebuild',)),
    ('wrong-selected-receive-dma',wrong_receive_dma,('untrusted trace/read summaries differ from independent rebuild',)),
    ('wrong-successful-prefix',wrong_prefix,('literal descriptor/prefix/genuine callback','exact first original-cookie failure')),
    ('retagged-original-failure',retag_failure,('exact first original-cookie failure and post-callback fence',)),
    ('invented-cache-failure-settlement',fake_settlement,('one actual bind/reservation without fabricated payload delivery',)),
    ('cleanup-clears-reserved-accounting',cleanup_drops_accounting,('cleanup changed accounting, recovery, storage, or traffic',)),
    ('automatic-grant-invents-ack',grant_invents_ack,('grant cannot fabricate ACK, packet, or recovery',)),
    ('in-status-low16-becomes-actual',in_length_from_status,('immutable normal observation and separately supplied actual length',)),
    ('paired-unused-storage-tail',unused_tail,('independent complete capture digest program_storage',)),
)


def run(args):
    report_path=args.report.resolve(); capture_root=args.capture_root.resolve()
    gate_path=args.gate.resolve(); output_root=args.output_root.resolve()
    require(report_path.is_file() and capture_root.is_dir() and gate_path.is_file(),'missing input file/directory')
    require(not output_root.exists(),'output root must be new; never overwrite evidence')
    require(capture_root!=output_root and capture_root not in output_root.parents,
            'negative output cannot be inside original captures')
    output_root.mkdir(parents=True)
    report_raw=report_path.read_bytes(); original=json.loads(report_raw)
    gate_digest=sha(gate_path.read_bytes())
    if args.gate_sha256 is not None:
        require(gate_digest==args.gate_sha256,'selected gate hash differs from explicit expected identity')
    gate=load_gate(gate_path)
    baseline=gate.check_publish_report(original,capture_root=capture_root)
    baseline_note={'status':'pass' if baseline[0] else 'fail','detail':baseline[1],
        'report':str(report_path),'report_sha256':sha(report_raw),'capture_root':str(capture_root),
        'gate':str(gate_path),'gate_sha256':gate_digest,
        'driver_sha256':sha(Path(__file__).read_bytes()),'synthetic_corruptions_executed':0}
    atomic_write(output_root/'baseline.json',json_bytes(baseline_note))
    require(baseline[0],'unchanged raw baseline did not pass; no negative controls executed: '+baseline[1])
    results=[]
    for label,mutate,expected in CONTROLS:
        control_root=output_root/label; control_root.mkdir()
        result={'control':label,'status':'error','expected_rejection_contains_any':list(expected),
                'original_gate_sha256':gate_digest,'synthetic_not_new_execution':True}
        try:
            evidence=EvidenceCopy(original,capture_root,control_root/'capture')
            mutate(evidence); evidence.sync()
            result['mutations']=evidence.changes
            result['paired_sealing']=evidence.paired_consistency()
            result['mutated_report_sha256']=sha((evidence.root/'validation.json').read_bytes())
            report_only=gate.check_publish_report(evidence.report)
            raw=gate.check_publish_report(evidence.report,capture_root=evidence.root)
            result['report_only']={'accepted':report_only[0],'detail':report_only[1]}
            result['raw_capture']={'accepted':raw[0],'detail':raw[1]}
            precise=all(not accepted and any(fragment in detail for fragment in expected)
                        for accepted,detail in (report_only,raw))
            result['status']='rejected-as-intended' if precise else 'wrong-result-or-mechanism'
        except (ControlError,KeyError,ValueError,TypeError,IndexError,OSError,OverflowError) as error:
            result['error']=str(error)
        atomic_write(control_root/'result.json',json_bytes(result))
        results.append(result)
        print(label+': '+result['status'],flush=True)
    require(sha(report_path.read_bytes())==sha(report_raw),'original report changed during controls')
    require(sha(gate_path.read_bytes())==gate_digest,'selected gate changed during controls')
    summary={'status':'pass' if all(r['status']=='rejected-as-intended' for r in results) else 'fail',
        'controls':results,'count':len(results),'baseline':baseline_note,
        'no_new_host_target_or_hardware_execution':True,
        'copies_use_atomic_replacement_for_all_changes':True}
    atomic_write(output_root/'negative-controls.json',json_bytes(summary))
    return summary['status']=='pass'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('report',type=Path)
    parser.add_argument('--capture-root',type=Path,required=True)
    parser.add_argument('--gate',type=Path,required=True)
    parser.add_argument('--gate-sha256')
    parser.add_argument('--output-root',type=Path,required=True,
                        help='new disposable directory; every corrupted evidence tree is retained')
    args=parser.parse_args()
    try:
        passed=run(args)
    except (ControlError,KeyError,ValueError,TypeError,IndexError,OSError,OverflowError) as error:
        print('STOP: '+str(error),flush=True)
        raise SystemExit(2)
    raise SystemExit(0 if passed else 1)


if __name__=='__main__':
    main()
