# Acquisition copied-evidence controls — unexecuted draft

The driver is `/tmp/hp1020-acquisition-gate-draft-20261003/run-negative-controls.py`,
SHA256 `f060f2b996ae560fd8c1bbf9f035d3cba148b590791a343488dbf8441ae7f196`.
It has not been parsed, imported, executed or tested by its author. The candidate
execution results and captures were not read. Root owns review and execution,
only after the unchanged positive acquisition baseline and its gate pass.

The complete existing publication driver was read before drafting. Its atomic
replacement, hardlink-copy, paired-row/capture sealing and baseline-first
machinery are preserved here, with acquisition ABI/API changes. The exact input
is saved beside this note as `publication-negative-controls-original.py`, SHA256
`22b902a964570bef579775cf93af26e7a072edcdc9d44af777895860b0d39496`.
The selected acquisition gate for static message/ABI review was frozen V2:
`v2/check-hp1020-udc-acquire.py`, SHA256
`45b452944da502ec4d5f1b59dbd015111c21e2b3eb2fdacce058cc2794f5dd13`.
No change was made to either gate version, any frozen candidate, any real report
or repository file. V1's README and independent plan/oracles remain untouched.

## Operation and boundaries

The driver imports only the explicitly selected independent gate and the Python
standard library. It requires BOTH unchanged report-only and full raw baseline
checks to pass before making any corruption. Every control copies the complete
evidence tree into a new directory and deep-copies the report. Unchanged files
may share hardlinks; every changed file is written to a new temporary inode and
atomically replaced, never edited through a hardlink. The original complete raw
baseline is checked again at the end, alongside unchanged gate/report hashes.

The codec is576 words with exact size bindings at59/425/490/555. Each touched
case rewrites its raw event framing, host576-word rows and paired target rows,
preserves the original four measured target sizes, updates all touched paired
capture hashes, and checks all twelve raw capture pairs. Trace changes update
the six-word trace and the used region of the full27712-byte storage capture.
Device images remain the exact144-byte capture. Source, fixture, patch/effective
and target-artifact manifests remain unchanged for every control.

Fifteen semantic controls require BOTH modes to reject at the named independent
contract, after paired sealing succeeds. A rejection due to an unrelated source
seal, missing file, malformed capture envelope or wrong target size is a failed
control. The sixteenth control changes only actual saved effective-source bytes:
report-only MUST remain accepted and raw mode MUST reject the exact saved-byte
seal. Report-only has no access to unsupplied files; this deliberate asymmetry
was approved by root, rather than corrupting an unrelated report field to force
an artificial double rejection.

Every copied tree contains `SYNTHETIC-CORRUPTION.json`, and the control results
explicitly deny new host/target/device execution. Mutated pass-shaped reports
are adversarial checker inputs only. Their hashes must never replace the real
positive report, tested source hashes or raw evidence.

## Fixed controls

| Control | Frozen selector | Intended independent rejection |
|---|---|---|
|wrong-original-payload-dma|visibility-packets, first kind7|Original slot0 range cannot become slot1; literal trace rebuild|
|wrong-descriptor-hook-length|visibility-packets, first kind6|Descriptor acquisition must cover16 bytes|
|wrong-payload-hook-length|visibility-packets, first kind7|Payload acquisition must cover64 bytes|
|unknown-descriptor-full-copy|descriptor-unknown, fill204|UNKNOWN copies exactly first8, not all16|
|unknown-payload-full-copy|payload-unknown, fill204|UNKNOWN copies exactly first32, not all64|
|hook-before-missing-facts|facts-and-identities, first op142 WAIT|Missing facts prohibit hook/effect/metadata change|
|retagged-retained-first-failure|payload-unknown, first G3 row|Retained failure keeps original G2 cookie|
|acquisition-invents-recovery-promise|admitted-reset-settlement, accepted old op142|No recovery/accounting mutation before service|
|paused-dispatch-fake-admission|held-setup-settlement, op82 facts0|Unknown capture facts cannot admit a control request|
|stale-device-input-changes-witness|same-address-reuse, stale op140|Old event cannot copy its image identity/write accounting into current state|
|publisher-cleanup-drops-accounting|prepared-publication-failure, successful cleanup|Physical cleanup does not clear reserved receive accounting|
|paired-wrong-pixel|visibility-packets|Literal32FF pixels override paired producer digest|
|paired-wrong-document-generation|visibility-packets|Literal G2 BE notification overrides paired producer summary|
|paired-device-guard|visibility-packets, fill204|Entire144-byte device capture includes untouched guard|
|paired-unused-storage-tail|visibility-packets, fill204|Entire recording allocation includes unused read tail|
|saved-effective-source-bytes|saved effective src/device/usbd.c|Raw mode hashes actual saved materialized bytes, not merely matching metadata|

The UNKNOWN controls propagate the altered CPU effect through all rows until
later explicit writes replace it, and reseal final CPU captures. Their bounded
byte-write helper is only a corruption constructor: before mutation it must
match every already-validated descriptor/receive witness and final capture. It
uses explicit op140 bytes, actual fixed ranges and six-word hook records; it
does not emulate the parser, controller, fault policy or a second owner. Real
prepared descriptor bytes are taken from the already-passing baseline and are
never changed by that control. Failure diagnostics and raw IO result2 remain
unchanged, so rejection tests the chosen partial-visibility effect itself.

The missing-fact control moves the same original descriptor hook earlier and
carries its counters/CPU effect; either the no-effect refusal guard or exact
hook-count guard is the intended rejection. It adds no fresh owner. The stale
image control keeps STALE but corrupts copied-image identity/accounting, then
retains the later genuine new input. These synthetic contradictory observations
are designed to challenge the checker, not to claim another runnable firmware
behavior.

## Lead integration

Use the report and capture root from the untouched successful first run. Supply
the exact checker hash that actually validated that run, and choose a NEW
disposable output directory. The command below is a template, not an executed
command or assertion that those results exist:

```sh
python3 /tmp/hp1020-acquisition-gate-draft-20261003/run-negative-controls.py \
  /path/to/untouched/validation.json \
  --capture-root /path/to/untouched/capture \
  --gate /path/to/exact/tested/check-hp1020-udc-acquire.py \
  --gate-sha256 EXACT_TESTED_GATE_SHA256 \
  --output-root /tmp/NEW-acquisition-negative-controls
```

Selectors require the frozen32-profile input shape and fail explicitly if the
baseline differs. No executed result was used to tune selectors or expected
error messages. If the first attempt exposes a driver assumption or unrelated
failure mechanism, preserve its driver/log/copies before a separately reviewed
correction. These controls establish checker discrimination only; they add no
physical/cache/DMA/USB/printing evidence and no additional firmware lifecycle.
