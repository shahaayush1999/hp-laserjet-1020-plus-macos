#!/usr/bin/env python3
"""Unexecuted stdlib corruption driver for the acquisition capture gate.

Root must run this only after the unchanged gate has passed the first complete
paired report. Every control uses a separate copied report/evidence tree; the
original gate, report, source and captures are never edited. All writes replace
files atomically, including when unchanged files are initially hardlinked.

No compiler, firmware, decoder, hardware access or producer import is used.
When explicitly executed, this driver imports only the selected local gate and
standard-library modules. It first verifies the positive baseline, then requires
both report-only and raw-capture rejection at a named independent contract check.
The separately labelled saved-effective-source control instead requires the
report-only check to pass and raw mode to reject that byte seal: report-only
mode cannot inspect a file which was not supplied to it.
Synthetic corrupted observations are not new host/target execution evidence.
"""
import argparse
import copy
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import struct
import sys
import tempfile


WIDTHS=(96,104,48,40,80,64,64,80)
STEP_KEYS=('steps','ep0_steps','bulk_steps','setup_steps','offload_steps','program_steps','publish_steps','acquire_steps')
INITIAL_KEYS=('initial','initial_ep0','initial_bulk','initial_setup','initial_offload','initial_program','initial_publish','initial_acquire')
CAPTURE_NAMES={'pixels':'pixels','wire':'wire','documents':'documents',
    'receive':'receive','output':'output','ep0':'output.ep0-descriptors',
    'bulk_descriptor':'output.udc-descriptor','setup_record':'output.setup-record',
    'program_reads':'output.program-read-script','program_trace':'output.program-trace',
    'program_storage':'output.program-storage','acquire_device':'output.acquire-device'}
U32=0xffffffff
RECEIVE_DMAS=(0x24681340,0x24682340,0x24683340,0x24684340)


class ControlError(ValueError):
    pass


def require(condition,message):
    if not condition:
        raise ControlError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def fnv(raw):
    value=2166136261
    for byte in raw:
        value=((value^byte)*16777619)&U32
    return value


def packed(words):
    return b''.join(v.to_bytes(4,'big') for v in words)


def flat(rows):
    return b''.join(packed(row) for row in rows)


def json_bytes(value):
    return (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()


def rows_bytes(rows):
    return b''.join((json.dumps(row,separators=(',',':'))+'\n').encode() for row in rows)


def atomic_write(path,raw):
    """Never write through a hardlink to original evidence."""
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(prefix='.'+path.name+'-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as output:
            output.write(raw)
        os.replace(name,path)
    finally:
        if os.path.exists(name): os.unlink(name)


def link_or_copy(source,destination):
    try:
        os.link(source,destination)
    except OSError as error:
        if error.errno!=errno.EXDEV: raise
        shutil.copy2(source,destination)
    return destination


def load_gate(path):
    spec=importlib.util.spec_from_file_location('independent_acquisition_gate',path)
    require(spec is not None and spec.loader is not None,'cannot load selected gate')
    module=importlib.util.module_from_spec(spec)
    previous=sys.dont_write_bytecode
    sys.dont_write_bytecode=True
    try:
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode=previous
    require(callable(getattr(module,'check_acquire_report',None)),
            'selected gate lacks check_acquire_report')
    return module


class EvidenceCopy:
    def __init__(self,original,original_root,root):
        self.original=original
        self.report=copy.deepcopy(original)
        self.root=Path(root)
        require(not self.root.exists(),'refuse to overwrite existing control evidence '+str(root))
        shutil.copytree(original_root,self.root,copy_function=link_or_copy)
        self.touched=set()
        self.changes=[]

    def choose(self,profile,fill=0):
        found=[i for i,c in enumerate(self.report['cases'])
               if c['scenario']=='acquire/'+profile and c['fill']==fill]
        require(len(found)==1,'unique independent control profile '+profile)
        self.touched.add(found[0])
        return found[0],self.report['cases'][found[0]]

    def directory(self,index):
        return self.root/f'case-{index:03}'

    def capture(self,index,key):
        return (self.directory(index)/CAPTURE_NAMES[key]).read_bytes()

    def replace_capture(self,index,key,raw):
        directory=self.directory(index)
        atomic_write(directory/CAPTURE_NAMES[key],raw)
        atomic_write(directory/('target-'+key),raw)
        digest=sha(raw)
        self.report['cases'][index]['capture_sha256'][key]=digest
        self.report['target']['cases'][index]['capture_sha256'][key]=digest
        self.touched.add(index)

    def replace_trace(self,index,rows):
        case=self.report['cases'][index]
        require(len(rows)==len(case['expected_program_trace']),'trace mutation may not resize the ledger')
        case['expected_program_trace']=rows
        for entry in case.get('program_oracles',[]):
            begin,end=entry['trace_begin'],entry['trace_end']
            require(0<=begin<=end<=len(rows),'redundant trace block extent')
            entry['literal_trace']=[row[2:] for row in rows[begin:end]]
        raw=flat(rows)
        storage=bytearray(self.capture(index,'program_storage'))
        require(len(storage)==27712 and len(raw)<=24576,'recording storage geometry')
        # Existing read allocation3104, then trace guard16 and1024x24 bytes.
        storage[3120:3120+len(raw)]=raw
        self.replace_capture(index,'program_trace',raw)
        self.replace_capture(index,'program_storage',bytes(storage))

    def change(self,label,detail):
        self.changes.append({'field':label,'change':detail})

    def sync(self):
        for index in sorted(self.touched):
            case=self.report['cases'][index]; native=self.report['target']['cases'][index]
            directory=self.directory(index)
            raw_events=b''.join(packed(e['words']+[len(bytes.fromhex(e['data_hex']))])+
                                bytes.fromhex(e['data_hex']) for e in case['events'])
            atomic_write(directory/'events.bin',raw_events)
            host_rows=[sum([case[k] for k in INITIAL_KEYS],[])]+[
                sum([case[k][i] for k in STEP_KEYS],[]) for i in range(len(case['events']))]
            require(all(len(row)==576 for row in host_rows),'mutated host row width')
            target_rows=[]
            for host in host_rows[1:]:
                target=host.copy()
                target[59]=native['adapter_state_and_memory_bytes']
                target[425]=native['component_and_allocation_bytes']['program']
                target[490]=native['component_and_allocation_bytes']['publisher']
                target[555]=native['component_and_allocation_bytes']['acquisition']
                target_rows.append(target)
            atomic_write(directory/'raw-stdout',rows_bytes(host_rows))
            atomic_write(directory/'target-steps.jsonl',rows_bytes(target_rows))
            # Keep auxiliary diagnostic logs coherent if this producer saved
            # them. They are not an alternative oracle or execution transcript.
            for key,path in (('steps','host-steps.jsonl'),('ep0_steps','host-ep0-steps.jsonl'),
                             ('bulk_steps','host-udc-steps.jsonl'),
                             ('setup_steps','host-setup-steps.jsonl'),
                             ('offload_steps','host-offload-steps.jsonl'),
                             ('program_steps','host-program-steps.jsonl'),
                             ('publish_steps','host-publish-steps.jsonl'),
                             ('acquire_steps','host-acquire-steps.jsonl')):
                if (directory/path).exists(): atomic_write(directory/path,rows_bytes(case[key]))
            if (directory/'host-composed-steps.jsonl').exists():
                composed=[a+b for a,b in zip(case['bulk_steps'],case['setup_steps'])]
                atomic_write(directory/'host-composed-steps.jsonl',rows_bytes(composed))
        for key in ('source_sha256','fixture_sha256','effective_source'):
            require(self.report[key]==self.original[key],'mutation changed protected '+key)
        require(self.report['target']['captured_artifact_sha256']==
                self.original['target']['captured_artifact_sha256'],'mutation changed target build artifacts')
        atomic_write(self.root/'validation.json',json_bytes(self.report))
        atomic_write(self.root/'SYNTHETIC-CORRUPTION.json',json_bytes({
            'not_host_target_or_device_execution':True,'mutations':self.changes}))

    def paired_consistency(self):
        """Sealing only, intentionally no semantic assumptions from the gate."""
        require(json.loads((self.root/'validation.json').read_bytes())==self.report,
                'saved mutated report mismatch')
        for index in sorted(self.touched):
            case=self.report['cases'][index]; native=self.report['target']['cases'][index]
            directory=self.directory(index)
            expected_events=b''.join(packed(e['words']+[len(bytes.fromhex(e['data_hex']))])+
                                     bytes.fromhex(e['data_hex']) for e in case['events'])
            require((directory/'events.bin').read_bytes()==expected_events,'paired input bytes')
            host_rows=[json.loads(line) for line in (directory/'raw-stdout').read_bytes().splitlines()]
            wanted=[sum([case[k] for k in INITIAL_KEYS],[])]+[
                sum([case[k][i] for k in STEP_KEYS],[]) for i in range(len(case['events']))]
            require(host_rows==wanted,'paired host raw rows versus report')
            target_rows=[json.loads(line) for line in (directory/'target-steps.jsonl').read_bytes().splitlines()]
            require(len(target_rows)==len(host_rows)-1,'paired target row count')
            for host,target in zip(host_rows[1:],target_rows):
                require(len(target)==576 and all(a==b for j,(a,b) in enumerate(zip(host,target))
                        if j not in (59,425,490,555)),'paired target rows differ outside measured sizes')
                require([target[59],target[425],target[490],target[555]]==[
                    native['adapter_state_and_memory_bytes'],native['component_and_allocation_bytes']['program'],
                    native['component_and_allocation_bytes']['publisher'],
                    native['component_and_allocation_bytes']['acquisition']],'paired target measured sizes')
            require(set(case['capture_sha256'])==set(CAPTURE_NAMES) and
                    case['capture_sha256']==native['capture_sha256'],'paired capture manifests')
            for key,path in CAPTURE_NAMES.items():
                raw=(directory/path).read_bytes()
                require(raw==(directory/('target-'+key)).read_bytes(),'paired capture bytes '+key)
                require(sha(raw)==case['capture_sha256'][key],'paired capture digest '+key)
            require((directory/'output.program-read-script').read_bytes()==flat(case['supplied_reads']),
                    'paired supplied read summary')
            raw_trace=(directory/'output.program-trace').read_bytes()
            require(raw_trace==flat(case['expected_program_trace']),'paired trace summary')
            storage=(directory/'output.program-storage').read_bytes()
            require(len(storage)==27712 and storage[3120:3120+len(raw_trace)]==raw_trace,
                    'paired used trace storage')
            raw_reads=flat(case['supplied_reads'])
            require(storage[16:16+len(raw_reads)]==raw_reads,'paired used read storage')
        return {'cases':sorted(self.touched),'raw_input_rows_and_all_capture_pairs_agree':True,
                'source_fixture_and_target_build_manifests_unchanged':True}


def first_step(case,predicate,label):
    found=[i for i,e in enumerate(case['events']) if predicate(i,e)]
    require(found,'missing intended baseline event '+label)
    return found[0]


def previous(case,key,index):
    return case[key][index-1] if index else case[INITIAL_KEYS[STEP_KEYS.index(key)]]


def wrong_pixel(evidence):
    index,case=evidence.choose('visibility-packets')
    pixels=evidence.capture(index,'pixels')
    require(pixels==b'\xff'*32,'positive pixel baseline must be independent32FF')
    changed=pixels[:17]+b'\xfe'+pixels[18:]
    evidence.replace_capture(index,'pixels',changed)
    case['expected_pixels_sha256']=sha(changed)
    for row in case['steps']:
        require(row[50] in (0,32),'selected simple page pixel count')
        if row[50]: row[51]=fnv(changed)
    evidence.change('pixel bytes/FNV/expected digest','both engines consistently claim32bytes with byte17=FE')


def wrong_hook(evidence,kind,field,value):
    index,case=evidence.choose('visibility-packets')
    rows=copy.deepcopy(case['expected_program_trace'])
    positions=[i for i,row in enumerate(rows) if row[2]==kind and row[5]==0]
    require(positions,'original after-device hook')
    row=rows[positions[0]]
    require(row[3:5]==([0x579bdf10,16] if kind==6 else [0x24681340,64]),
            'first original after-device range must match the frozen slot0 allocation')
    require(row[field]!=value,'nontrivial range mutation')
    row[field]=value
    evidence.replace_trace(index,rows)
    evidence.change('original after-device hook range',
        f'kind{kind} trace field{field} becomes {value:#x}; both trace captures/storage remain sealed')


def wrong_receive_dma(evidence):
    wrong_hook(evidence,7,3,0x24682340)


def wrong_descriptor_length(evidence):
    wrong_hook(evidence,6,4,8)


def wrong_payload_length(evidence):
    wrong_hook(evidence,7,4,63)


def visible_cpu_rows(case,alter=None):
    """Reconstruct only explicit fixture writes, to propagate one corruption.

    This is not a success oracle. The unaltered result must first match every
    already validated row and final capture. No parser/controller is emulated.
    alter=(one-based event, kind) changes the selected UNKNOWN effect to a full
    copy while preserving the actual hook result2 and its fault diagnostics.
    """
    receive=bytearray([case['fill']]*4096); descriptor=bytearray([case['fill']]*16)
    images={}; states=[]; changed=0
    trace_by_event={}
    for row in case['expected_program_trace']:
        trace_by_event.setdefault(row[0],[]).append(row)
    for i,event in enumerate(case['events']):
        op,a,b,c,d=event['words']; raw=bytes.fromhex(event['data_hex'])
        base=case['steps'][i]; out=case['bulk_steps'][i]
        old=previous(case,'bulk_steps',i)
        if op==6 and out[10]==old[10]+1:
            # A real prepared descriptor is already independently checked by
            # the required positive gate. This driver changes no publication.
            descriptor[:]=packed(out[24:28])
        if op==140 and base[0]==0:
            require(len(raw)==80 and b in (0,1),'original literal image envelope')
            dma=int.from_bytes(raw[8:12],'big')
            require(dma in RECEIVE_DMAS,'device input retains one fixed DMA allocation')
            slot=RECEIVE_DMAS.index(dma)
            images[a]=(slot,raw[:16],raw[16:])
            descriptor[:]=packed([0x88000040,0,dma,0] if b else
                                [0xc35a0000|slot,0x13579bdf,0xfedcba90,0x2468ace0])
            receive[1024*slot:1024*slot+64]=bytes((0xd3^(slot*0x29)^(j*0x17))&255 for j in range(64))
        for _,_,kind,offset,length,result in trace_by_event.get(i+1,[]):
            if kind not in (6,7,8): continue
            require(op==142 and a in images,'after-device effect must use original image input')
            slot,source_descriptor,source_payload=images[a]
            require(result in (0,1,2),'frozen hook result domain')
            if kind==8: continue
            width=16 if kind==6 else 64
            require(length==width and offset==(0x579bdf10 if kind==6 else RECEIVE_DMAS[slot]),
                    'unaltered exact hook span')
            count=width if result==0 else width//2 if result==2 else 0
            if alter==(i+1,kind):
                require(result==2,'control must target a genuine UNKNOWN input')
                count=width; changed+=1
            if kind==6: descriptor[:count]=source_descriptor[:count]
            else: receive[1024*slot:1024*slot+count]=source_payload[:count]
        states.append((bytes(descriptor),fnv(receive)))
    require(alter is None or changed==1,'one exact UNKNOWN copy changed')
    return states,bytes(descriptor),bytes(receive)


def wrong_unknown_effect(evidence,kind):
    profile='descriptor-unknown' if kind==6 else 'payload-unknown'
    index,case=evidence.choose(profile,204)
    rows=[row for row in case['expected_program_trace'] if row[2]==kind and row[5]==2]
    require(len(rows)==1,'one explicit UNKNOWN hook in this frozen profile')
    at=rows[0][0]
    original,old_descriptor,old_receive=visible_cpu_rows(case)
    for i,(descriptor,digest) in enumerate(original):
        require(packed(case['bulk_steps'][i][24:28])==descriptor and
                case['steps'][i][60]==digest,'control reconstruction must match every untouched baseline row')
    require(evidence.capture(index,'receive')==old_receive and
            evidence.capture(index,'bulk_descriptor')[16:32]==old_descriptor,
            'control reconstruction must match both untouched final CPU captures')
    changed,new_descriptor,new_receive=visible_cpu_rows(case,(at,kind))
    require(changed[at-1]!=original[at-1],'UNKNOWN full-copy must differ from the prescribed half-copy')
    for i,(descriptor,digest) in enumerate(changed):
        case['bulk_steps'][i][24:28]=list(struct.unpack('>4I',descriptor))
        case['steps'][i][60]=digest
    guard=bytes([case['fill']])*16
    evidence.replace_capture(index,'bulk_descriptor',guard+new_descriptor+guard)
    evidence.replace_capture(index,'receive',new_receive)
    evidence.change('explicit UNKNOWN visibility effect',
        f'event{at}/kind{kind} copies the full range instead of half; propagate CPU rows until later explicit overwrite; raw hook still result2')


def wrong_unknown_descriptor(evidence):
    wrong_unknown_effect(evidence,6)


def wrong_unknown_payload(evidence):
    wrong_unknown_effect(evidence,7)


def hook_before_missing_facts(evidence):
    index,case=evidence.choose('facts-and-identities')
    at=first_step(case,lambda i,e:e['words'][0]==142 and case['steps'][i][0]==1,
                  'missing prerequisite WAIT before any actual acquisition')
    rows=copy.deepcopy(case['expected_program_trace'])
    position=next((i for i,row in enumerate(rows) if row[2]==6),None)
    require(position is not None and rows[position][0]>at+1,'later first descriptor hook')
    later=rows[position][0]-1
    token=case['events'][at]['words'][1]
    require(case['events'][later]['words'][0:2]==[142,token],
            'move only same-original descriptor hook, never retag an owner')
    rows[position][0]=at+1
    evidence.replace_trace(index,rows)
    cookie=previous(case,'bulk_steps',at)[16:21]
    device=next((bytes.fromhex(case['events'][j]['data_hex'])[:16]
                 for j in range(at-1,-1,-1) if case['events'][j]['words'][0:2]==[140,token]
                 and case['steps'][j][0]==0),None)
    require(device is not None,'same original device input precedes the missing-fact call')
    for i in range(at,later):
        case['program_steps'][i][26]+=1
        acquisition=case['acquire_steps'][i]
        acquisition[3]+=1; acquisition[6]+=1; acquisition[61]+=1
        acquisition[14:19]=cookie; acquisition[62]=1
        case['bulk_steps'][i][24:28]=list(struct.unpack('>4I',device))
    evidence.change('missing-fact WAIT hook prefix',
        'move the same original descriptor hook to the earlier missing-fact call; carry matching counters/CPU descriptor until the later call')


def retag_first_failure(evidence):
    _,case=evidence.choose('payload-unknown')
    at=first_step(case,lambda i,e:case['steps'][i][32]==3,
                  'separate successful G3 recovery after original G2 acquisition failure')
    original=case['acquire_steps'][at][42:47]
    require(original[2]==2 and case['steps'][at][4]!=original[1],
            'retained original G2 failure differs from later recovery identity')
    for i in range(at,len(case['events'])):
        row=case['acquire_steps'][i]
        require(row[42:47]==original,'original failure survives all later success before mutation')
        row[43]=case['steps'][at][4]; row[44]=3
    evidence.change('retained first failure cookie',
        'after real G3 recovery retag only historical failure epoch/generation; original bind and first failure remain unchanged')


def accepted_grants_recovery(evidence):
    _,case=evidence.choose('admitted-reset-settlement')
    at=first_step(case,lambda i,e:e['words'][0]==142 and case['steps'][i][0]==0,
                  'old original acquisition accepted before admitted reset service')
    before=previous(case,'steps',at); row=case['steps'][at]
    require(row[32:48]==before[32:48] and before[2]!=before[3] and before[35]>0,
            'unserviced reset retains its original accounting')
    row[45]^=1
    evidence.change('accepted acquisition reset parts',
        'claim a receive-quiescence promise at op142 before any recovery acknowledgment; count and original ticket remain retained')


def paused_dispatch_admits(evidence):
    _,case=evidence.choose('held-setup-settlement')
    at=first_step(case,lambda i,e:e['words'][0]==82 and e['words'][2]==0,
                  'literal zero-facts raw dispatch')
    row=case['steps'][at]; before=previous(case,'steps',at)
    setup=case['setup_steps'][at]; token=case['events'][at]['words'][1]
    require(row[0]==1 and setup[2:5]==[1,token,token],
            'zero-facts baseline must retain the original capture without admission')
    case['events'][at]['result']=0; row[0]=0
    row[2]=before[2]+1; row[6]=1
    setup[0]=0; setup[2:4]=[0,0]; setup[6]=token; setup[7]=row[2]
    setup[11]=7; setup[19]+=1
    case['program_steps'][at][8]=7; case['publish_steps'][at][7]=7
    evidence.change('zero-facts dispatch result/admission',
        'both engines claim OK/new control epoch/admission and released progress despite the original raw facts0 input')


def stale_image_changes_identity(evidence):
    _,case=evidence.choose('same-address-reuse')
    at=first_step(case,lambda i,e:e['words'][0]==140 and case['steps'][i][0]==2,
                  'old original image refused after same slot0/address reuse')
    token=case['events'][at]['words'][1]
    binding=first_step(case,lambda i,e:e['words'][0]==6 and case['bulk_steps'][i][16]==token,
                       'actual historical G2 binding')
    original=case['bulk_steps'][binding][16:21]
    require(original[2]==2 and case['steps'][at][32]==3,'different original generation at exact address reuse')
    next_image=next((i for i in range(at+1,len(case['events']))
                     if case['events'][i]['words'][0]==140 and case['steps'][i][0]==0),len(case['events']))
    for i in range(at,len(case['events'])):
        case['acquire_steps'][i][9]+=1; case['acquire_steps'][i][10]+=1
        if i<next_image:
            case['acquire_steps'][i][19:25]=[1]+original
    evidence.change('stale input image witness',
        'retain STALE result but claim an image/poison write and old G2 source cookie before the next genuine image input')


def cleanup_drops_accounting(evidence):
    _,case=evidence.choose('prepared-publication-failure')
    at=first_step(case,lambda i,e:e['words'][0]==133 and case['steps'][i][0]==0,'successful original cleanup')
    base=case['steps'][at]; publish=case['publish_steps'][at]
    require(base[35]>0 and publish[56]==publish[57]==base[35],'independently retained nonzero cleanup count')
    base[33:36]=[0,0,0]; publish[56:58]=[0,0]
    evidence.change('successful cleanup accounting','both engines now clear issued/consumed/count without the later three-promise restart')


def wrong_document_generation(evidence):
    index,case=evidence.choose('visibility-packets')
    require(case['expected_documents']==[[2,1,0,1,0]] and
            evidence.capture(index,'documents')==packed([2,1,0,1,0]),
            'one independently fixed G2 document baseline')
    case['expected_documents']=[[3,1,0,1,0]]
    evidence.replace_capture(index,'documents',packed([3,1,0,1,0]))
    for row in case['steps']:
        if row[90]:
            require(row[93]==2,'original document notification generation')
            row[93]=3
    evidence.change('document generation and BE notification',
        'both captures and producer summary claim G3 for the otherwise unchanged G2 input lifecycle')


def device_guard(evidence):
    index,_=evidence.choose('visibility-packets',204)
    raw=bytearray(evidence.capture(index,'acquire_device'))
    require(len(raw)==144 and raw[32]==204,'literal independent descriptor guard')
    raw[32]^=1
    evidence.replace_capture(index,'acquire_device',bytes(raw))
    evidence.change('immutable synthetic device guard',
        'flip guard byte32 in both full144-byte captures; input images, source bytes, and reported guard result remain fixed')


def unused_tail(evidence):
    index,case=evidence.choose('visibility-packets',204)
    raw=bytearray(evidence.capture(index,'program_storage'))
    used=len(evidence.capture(index,'program_reads')); offset=16+used
    require(used<3072 and raw[offset]==204,'known unused read payload tail and fill')
    raw[offset]^=1
    evidence.replace_capture(index,'program_storage',bytes(raw))
    evidence.change('paired full storage unused byte',f'flip byte{offset}; used records and guards untouched, both capture digests updated')


def changed_effective_source(evidence):
    evidence.choose('visibility-packets')
    name='src/device/usbd.c'; path=evidence.root/'effective-source'/name
    original=path.read_bytes()
    require(sha(original)==evidence.report['effective_source']['effective_sha256'][name],
            'actual original materialized source must match its untouched manifest')
    altered=original+b'\n/* SYNTHETIC COPIED-EVIDENCE CORRUPTION ONLY */\n'
    atomic_write(path,altered)
    evidence.change('saved effective source bytes only',
        {'path':name,'original_sha256':sha(original),'mutated_sha256':sha(altered),
         'all_report_source_patch_fixture_target_manifests_unchanged':True})


CONTROLS=(
    ('wrong-original-payload-dma',wrong_receive_dma,('producer trace/read summaries differ from independent raw-event rebuild',),'semantic'),
    ('wrong-descriptor-hook-length',wrong_descriptor_length,('producer trace/read summaries differ from independent raw-event rebuild',),'semantic'),
    ('wrong-payload-hook-length',wrong_payload_length,('producer trace/read summaries differ from independent raw-event rebuild',),'semantic'),
    ('unknown-descriptor-full-copy',wrong_unknown_descriptor,('actual live CPU descriptor/SETUP bytes differ from independent raw effects',),'semantic'),
    ('unknown-payload-full-copy',wrong_unknown_payload,('whole4096 receive allocation differs from input and ordered visibility',),'semantic'),
    ('hook-before-missing-facts',hook_before_missing_facts,('stale/invalid/missing-fact refusal changed retained evidence or storage','missing/unexpected recording hook'),'semantic'),
    ('retagged-retained-first-failure',retag_first_failure,('independent complete acquisition diagnostics',),'semantic'),
    ('acquisition-invents-recovery-promise',accepted_grants_recovery,('acquisition cannot parse, ACK, consume, notify or grant reset',),'semantic'),
    ('paused-dispatch-fake-admission',paused_dispatch_admits,('raw dispatch retains the original pending sequence and exact capture','one explicit missing-facts WAIT before original capture admission'),'semantic'),
    ('stale-device-input-changes-witness',stale_image_changes_identity,('rejected device input modified bytes, owner or diagnostics',),'semantic'),
    ('publisher-cleanup-drops-accounting',cleanup_drops_accounting,('publisher cleanup cannot change accounting, bytes or promises',),'semantic'),
    ('paired-wrong-pixel',wrong_pixel,('independent exact32FF page and oneEND_DOC',),'semantic'),
    ('paired-wrong-document-generation',wrong_document_generation,('independent exact32FF page and oneEND_DOC',),'semantic'),
    ('paired-device-guard',device_guard,('independent complete capture digest acquire_device',),'semantic'),
    ('paired-unused-storage-tail',unused_tail,('independent complete capture digest program_storage',),'semantic'),
    ('saved-effective-source-bytes',changed_effective_source,('saved effective source: bytes differ src/device/usbd.c',),'raw-seal'),
)


def run(args):
    report_path=args.report.resolve(); capture_root=args.capture_root.resolve()
    gate_path=args.gate.resolve(); output_root=args.output_root.resolve()
    require(report_path.is_file() and capture_root.is_dir() and gate_path.is_file(),'missing input file/directory')
    require(not output_root.exists(),'output root must be new; never overwrite evidence')
    require(capture_root!=output_root and capture_root not in output_root.parents,
            'negative output cannot be inside original captures')
    output_root.mkdir(parents=True)
    report_raw=report_path.read_bytes(); original=json.loads(report_raw)
    gate_digest=sha(gate_path.read_bytes())
    if args.gate_sha256 is not None:
        require(gate_digest==args.gate_sha256,'selected gate hash differs from explicit expected identity')
    gate=load_gate(gate_path)
    report_baseline=gate.check_acquire_report(original)
    baseline=gate.check_acquire_report(original,capture_root=capture_root)
    baseline_note={'status':'pass' if baseline[0] else 'fail','detail':baseline[1],
        'report':str(report_path),'report_sha256':sha(report_raw),'capture_root':str(capture_root),
        'gate':str(gate_path),'gate_sha256':gate_digest,
        'driver_sha256':sha(Path(__file__).read_bytes()),'synthetic_corruptions_executed':0,
        'report_only':{'accepted':report_baseline[0],'detail':report_baseline[1]}}
    atomic_write(output_root/'baseline.json',json_bytes(baseline_note))
    require(report_baseline[0],'unchanged report-only baseline did not pass; no controls executed: '+report_baseline[1])
    require(baseline[0],'unchanged raw baseline did not pass; no negative controls executed: '+baseline[1])
    results=[]
    for label,mutate,expected,mode in CONTROLS:
        control_root=output_root/label; control_root.mkdir()
        result={'control':label,'status':'error','expected_rejection_contains_any':list(expected),
                'original_gate_sha256':gate_digest,'synthetic_not_new_execution':True,
                'mode':mode,'expected_report_only_acceptance':mode=='raw-seal'}
        try:
            evidence=EvidenceCopy(original,capture_root,control_root/'capture')
            mutate(evidence); evidence.sync()
            result['mutations']=evidence.changes
            result['paired_sealing']=evidence.paired_consistency()
            result['mutated_report_sha256']=sha((evidence.root/'validation.json').read_bytes())
            report_only=gate.check_acquire_report(evidence.report)
            raw=gate.check_acquire_report(evidence.report,capture_root=evidence.root)
            result['report_only']={'accepted':report_only[0],'detail':report_only[1]}
            result['raw_capture']={'accepted':raw[0],'detail':raw[1]}
            precise=(report_only[0] and not raw[0] and any(fragment in raw[1] for fragment in expected)) if mode=='raw-seal' else all(
                not accepted and any(fragment in detail for fragment in expected)
                for accepted,detail in (report_only,raw))
            result['status']='rejected-as-intended' if precise else 'wrong-result-or-mechanism'
        except (ControlError,KeyError,ValueError,TypeError,IndexError,OSError,OverflowError) as error:
            result['error']=str(error)
        atomic_write(control_root/'result.json',json_bytes(result))
        results.append(result)
        print(label+': '+result['status'],flush=True)
    require(sha(report_path.read_bytes())==sha(report_raw),'original report changed during controls')
    require(sha(gate_path.read_bytes())==gate_digest,'selected gate changed during controls')
    original_still_passes=gate.check_acquire_report(original,capture_root=capture_root)
    require(original_still_passes[0],
            'original source/capture bytes no longer pass after copied controls: '+original_still_passes[1])
    summary={'status':'pass' if all(r['status']=='rejected-as-intended' for r in results) else 'fail',
        'controls':results,'count':len(results),'baseline':baseline_note,
        'no_new_host_target_or_hardware_execution':True,
        'copies_use_atomic_replacement_for_all_changes':True,
        'original_raw_baseline_rechecked':{'accepted':original_still_passes[0],'detail':original_still_passes[1]},
        'report_only_cannot_inspect_unsupplied_effective_source_bytes':True}
    atomic_write(output_root/'negative-controls.json',json_bytes(summary))
    return summary['status']=='pass'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('report',type=Path)
    parser.add_argument('--capture-root',type=Path,required=True)
    parser.add_argument('--gate',type=Path,required=True)
    parser.add_argument('--gate-sha256')
    parser.add_argument('--output-root',type=Path,required=True,
                        help='new disposable directory; every corrupted evidence tree is retained')
    args=parser.parse_args()
    try:
        passed=run(args)
    except (ControlError,KeyError,ValueError,TypeError,IndexError,OSError,OverflowError) as error:
        print('STOP: '+str(error),flush=True)
        raise SystemExit(2)
    raise SystemExit(0 if passed else 1)


if __name__=='__main__':
    main()
