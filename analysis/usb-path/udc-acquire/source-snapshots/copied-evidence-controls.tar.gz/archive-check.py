"""Seal the first copied-evidence acquisition controls against the original run."""
from pathlib import Path
import gzip, hashlib, io, json, tarfile
ROOT=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
TMP=Path('/tmp'); BASE=TMP/'hp1020-udc-acquire-y7t6kkii'
NEGATIVE=TMP/'hp1020-acquisition-negative-first-20261003'
DEST=ROOT/'analysis/usb-path/udc-acquire/source-snapshots'
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
for name in ('run-negative-controls.py','negative-control-driver.md','NEGATIVE-CONTROLS.sha256','publication-negative-controls-original.py'):
 files['frozen-driver/'+name]=(TMP/'hp1020-acquisition-gate-draft-20261003'/name).read_bytes()
assert sha(files['frozen-driver/run-negative-controls.py'])=='f060f2b996ae560fd8c1bbf9f035d3cba148b590791a343488dbf8441ae7f196'
files['first-control-run.log']=(TMP/'hp1020-acquisition-negative-first-20261003.log').read_bytes()
results=json.loads((NEGATIVE/'negative-controls.json').read_text())
assert results['status']=='pass' and results['count']==16
assert all(c['status']=='rejected-as-intended' for c in results['controls'])
semantic=[c for c in results['controls'] if c['mode']=='semantic']; seals=[c for c in results['controls'] if c['mode']=='raw-seal']
assert len(semantic)==15 and len(seals)==1
assert all(not c['report_only']['accepted'] and not c['raw_capture']['accepted'] for c in semantic)
assert seals[0]['report_only']['accepted'] and not seals[0]['raw_capture']['accepted']
assert results['original_raw_baseline_rechecked']['accepted']
assert results['no_new_host_target_or_hardware_execution']
base_metadata=json.loads((DEST/'first-paired-32-cases.json').read_text())
base_payload=(DEST/'first-paired-32-cases.tar.gz').read_bytes()
assert sha(base_payload)==base_metadata['archive_sha256']
base_manifest={p.relative_to(BASE).as_posix():sha(p.read_bytes()) for p in BASE.rglob('*') if p.is_file()}
reconstruction={}
for path in NEGATIVE.rglob('*'):
 if not path.is_file():continue
 rel=path.relative_to(NEGATIVE);raw=path.read_bytes()
 if len(rel.parts)>2 and rel.parts[1]=='capture':
  base_name=Path(*rel.parts[2:]).as_posix()
  if base_manifest.get(base_name)==sha(raw):
   reconstruction[rel.as_posix()]={'base_member':base_name,'sha256':sha(raw)};continue
 files['negative-controls/'+rel.as_posix()]=raw
files['negative-controls/unchanged-base-members.json']=(json.dumps(reconstruction,indent=2,sort_keys=True)+'\n').encode()
files['archive-check.py']=Path(__file__).read_bytes()
files['README.md']=b'''# Acquisition copied-evidence controls

This is synthetic checker evidence, not additional host/target execution or
physical lifecycles. The frozen driver ran unchanged against the first sealed
32-case acquisition run and its unchanged V2 checker. Fifteen internally paired
semantic corruptions were rejected in both modes at the intended contract.
The saved-effective-source corruption passes report-only (which cannot inspect
unsupplied files) and fails raw mode at the exact saved-byte seal. The original
positive report, raw captures, checker and source manifests remained unchanged.

Reconstruct each synthetic capture by copying its listed unchanged base members
from first-paired-32-cases.tar.gz and overlaying its saved changed members here.
unchanged-base-members.json seals every referenced base hash; this archive was
read back and all references checked against the durable base archive. Never
substitute these deliberately corrupted reports for actual execution evidence.
The driver's original draft note remains a historical pre-execution document.
'''
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w') as tf:
  for name,raw in sorted(files.items()):
   assert not Path(name).is_absolute() and '..' not in Path(name).parts
   info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0
   tf.addfile(info,io.BytesIO(raw))
payload=buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tf:
 assert set(tf.getnames())==set(files)
 for name,raw in files.items():assert tf.extractfile(name).read()==raw
with tarfile.open(fileobj=io.BytesIO(base_payload),mode='r:gz') as tf:
 # The positive archive keeps captured files under capture/.
 names=set(tf.getnames())
 for rel,ref in reconstruction.items():
  candidates=[ref['base_member'],'capture/'+ref['base_member']]
  members=[n for n in candidates if n in names];assert len(members)==1,(rel,members)
  original=tf.extractfile(members[0]).read()
  assert sha(original)==ref['sha256'] and original==(NEGATIVE/rel).read_bytes()
metadata=dict(status='frozen controls passed unchanged; original positive evidence preserved',
 archive_sha256=sha(payload),archive_bytes=len(payload),member_count=len(files),
 base_archive='first-paired-32-cases.tar.gz',base_archive_sha256=base_metadata['archive_sha256'],
 referenced_unchanged_members=len(reconstruction),negative_controls=16,
 semantic_controls_rejected_in_both_modes=15,raw_only_source_seal_controls=1,
 no_new_host_target_or_hardware_execution=True,
 member_sha256={name:sha(raw) for name,raw in sorted(files.items())})
for ext,data in [('.tar.gz',payload),('.json',(json.dumps(metadata,indent=2)+'\n').encode())]:
 path=DEST/('copied-evidence-controls'+ext);assert not path.exists();path.write_bytes(data)
print(json.dumps({k:metadata[k] for k in ('archive_sha256','archive_bytes','member_count','referenced_unchanged_members')},indent=2))
