# First acquisition integration, before candidate execution

This archive is a source/review snapshot, not a test report. Production C and
the fixture were integrated unchanged from the earlier proposal archive. The
independent scenario and gate were completed later and are preserved here.
Root assembled its header/Host/scenario/main and syntax-parsed the Python inputs;
no candidate import, compile or execution had occurred when this was captured.

The gate V1 remains unchanged. V2 contains separately recorded pre-execution
corrections from static contract review; the frozen acquisition oracle is not
changed. The scenarios-author reread and independent review are named separately.
Any later run must capture its entire source/fixture closure and raw evidence;
this archive cannot substitute for that execution provenance.
