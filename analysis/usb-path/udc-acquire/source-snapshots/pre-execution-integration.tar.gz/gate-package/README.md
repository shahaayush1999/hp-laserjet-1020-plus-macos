# Independent OUT1 acquisition capture gate — unexecuted draft

2026-10-03. The gate in this directory has not been imported, syntax-parsed,
executed or tested by its author. No producer scenarios or candidate run results
were read. No repository files were changed. The lead owns review, integration
and every later sequential execution.

`check-hp1020-udc-acquire.py` is a standalone standard-library checker. Public API:

```python
check_acquire_report(report, capture_root=None, source_root=None)
```

It returns `(passed, detail)`; the raising form is `validate_acquire_report`.
The CLI accepts a saved JSON report plus optional `--capture-root` and
`--source-root`. There are no producer imports, subprocesses, decoder calls,
hardware operations or writes to the reviewed evidence.

## Independent authority

`original-oracles/` preserves the exact original acquisition helper, plan and
their source manifest. The helper was frozen before acquisition C was read:

```text
06160580c3ecce51f36731be7c3a0ca7097769ee8b2543f1ad715e6d5bddea25  trace-oracles.py
f35238a5e93cce4450e05f5bba23fc110b7c843676ee1a5bc2b5b82ecc0a47b8  PLAN.md
```

The helper's exact bytes are embedded in the checker, and the tested source
closure must bind its copied fixture helper to that frozen SHA256. The matrix is
sixteen semantic profiles at fills0/204, thirty-two cases total. Its expected
generations, zero/short/full examples, missing/nonboolean facts, five original
cookie mutations, retained/reset/reuse paths, known endpoint fault and six
visibility failure prefixes are fixed by that pre-implementation authority.

Common source/raw/target sealing, earlier logical program blocks and publication
contract helpers were copied from the unchanged independently frozen V2 gate:

```text
03769f37e3a67877ff8100a6ad651fd9f20e5649166340d93c9498d11ec379e0  /tmp/hp1020-publication-gate-draft-20261003/v2/check-hp1020-udc-publish.py
```

The new public fixture ABI was confirmed with its separate author, then read in
the frozen README and the corresponding input/serialization source. Its producer
scenarios were not read. The relevant frozen identities are:

```text
a80028559034d8502a86e43e698dfdf6e2bbe21bb625612cecab3a402e3cb7b2  /tmp/hp1020-udc-acquire-fixture-draft-20261003/draft/open-firmware/udc-acquire-test/README.md
deb151a70fe6b895fe70063c6043c683eec10d02d034da2ea09d205a931ceb9f  /tmp/hp1020-udc-acquire-fixture-draft-20261003/draft/open-firmware/udc-acquire-test/fixture.c
```

The lead's public `header.py`/`host.py` drafts were consulted only for report
keys, widths and input/capture framing. They are not expected-result authority.
Existing tested base/EP0/composed/offload helper source was consulted for already
established cancellation and EP0 input ABI. The small document itself is rebuilt
from literal saved ZjStream header/items and the frozen26-byte small JBIG input,
without importing those producer helpers or running a decoder. Both original
fixture digests are independently fixed in the checker.

## What it checks

- Exact32-case matrix, original stock/TinyUSB/source/fixture seals, audited target
  artifacts, no claimed peripheral/USB/native lifecycle execution, and measured
  target component sizes.
- Every576-word paired row, excluding only four measured-size positions
  59/425/490/555 and binding those positions separately to reported target sizes.
  Prior ABI fields remain in place; acquisition appends80 named words.
- Actual raw event framing and original by-value cookie reconstruction at each
  real adapter binding. Failure diagnostics cannot supply their own expected
  cookie. Reused descriptor/slot addresses never retag an old event.
- Frozen INITIAL/GRANT and OUT1 publication command sequences; exact external
  read scripts and one-shot failure ordinals, without deriving reads from writes.
  Automatic permission creates neither ordinary EP0 packets nor a status ACK.
- Literal kinds6/7/8 and exact descriptor16/selected receive64 ranges. CPU poison
  and immutable device images come from op140 input; every successful or partial
  visibility effect is reconstructed independently. Missing facts, stale cookies
  and normal PREPARED refusal create no hook or new diagnostic snapshot.
- Complete last/first-failure diagnostics, no visibility retry after a latched
  fault, fresh full acquisition after not-DONE, actual callback/hook reentry
  witnesses and unchanged first-failure history after later successful packets.
- Exact-cookie cancellation and reset admission, preserved publisher failure and
  nonzero reserved accounting through its separate cleanup, and generation
  restart only after the same three independent recovery promises.
- Complete4096 receive bytes, guarded descriptor48, guarded device144, EP0240,
  SETUP48 and all27712 guarded recording bytes, including untouched tails.
  Every existing capture pair is retained; `acquire_device` is the twelfth pair.
  The opaque existing output allocation is paired and checked against its own
  retained-state witness; final rendered pixels are independently32 bytesFF.
- One exact reconstructed fresh document's admitted bytes, exactly one page and
  one END_DOC notification in G2 or G3, no explicit input EOF, and only the
  designated GET_CONFIGURATION IN01/OUT0 status exchange in its single profile.

Producer `expected_program_trace`, `supplied_reads`, pixel/document summaries and
packet annotations are compared only after independent reconstruction.
`acquisition_oracles` remains optional redundant annotation and is not trusted.
Report-only mode checks independent capture digests; raw mode additionally reads
the original inputs, all row streams, every saved capture and all sealed sources.

## Suggested later negative controls

After an unchanged baseline passes, mutate only copied evidence, updating both
host/target rows and touched capture hashes so paired consistency survives:

1. Wrong kind7 receive DMA or length, with matching trace/storage/counter edits.
2. Wrong UNKNOWN half-copy, with coherent CPU receive/descriptor captures and
   diagnostic digests; the independent byte-effect rule must reject it.
3. A hook before missing-fact refusal, or a hook replay after an I/O fault.
4. Retag first-failure epoch/generation to the later recovery, adjusting matching
   rows while leaving its original binding and explicit input unchanged.
5. Change device input on a stale op140, or accept an old cookie at address reuse.
6. Clear receive accounting or supply a reset promise during publisher cleanup.
7. Coherently change32FF pixels or the fresh document generation/notification.
8. Corrupt only an unused device/storage guard or recording tail, rehashing both
   captures; no incidental source-seal failure should be counted as the result.

These are plans, not executed controls. Preserve this initial gate before any
later ABI correction or report-based diagnosis. A failed first attempt must stay
separate from successful execution; never patch producer report hashes by hand.

This remains an offline logical contract. Recording hooks do not prove physical
cache coherence, stable DMA mapping, transfer settlement, IRQ chronology or
printer behavior. No new physical DCD, firmware upload or print is established.
