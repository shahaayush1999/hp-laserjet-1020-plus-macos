# Acquisition gate V2: pre-execution corrections

2026-10-03. This revision is separate from frozen V1 and from the unchanged
independent literal oracle. No candidate results were available or inspected.
No Python parsing/import, build, test, validator or target execution was
performed by the author. Source text, existing public ABI and hashes were the
only inputs. The lead owns integration and first execution.

V1 remains at `../check-hp1020-udc-acquire.py`, SHA256
`a057fd10ce31f830f76af61abd35fde2fce2702f82e3373647c301be0c7c17a1`.
V2 `check-hp1020-udc-acquire.py` is frozen at SHA256
`45b452944da502ec4d5f1b59dbd015111c21e2b3eb2fdacce058cc2794f5dd13`.

The prior plan and oracle are not amended:

- `../original-oracles/trace-oracles.py` SHA256
  `06160580c3ecce51f36731be7c3a0ca7097769ee8b2543f1ad715e6d5bddea25`.
- `../original-oracles/PLAN.md` SHA256
  `f35238a5e93cce4450e05f5bba23fc110b7c843676ee1a5bc2b5b82ecc0a47b8`.

## 1. Missing capture facts retain the original pending request

Root, the fixture reviewer and this reviewer independently identified that V1
accepted only successful op82 dispatch. The frozen plan's held-SETUP profile
explicitly requires unknown capture facts followed by retry of the SAME event.
Existing `hp1020_udc_setup_dispatch()` returns WAIT before adapter admission
when any required capture fact is absent; this was not a candidate failure.

V2 permits only the exact planned sequence: one op82 with facts000000 and
resultWAIT, then one with facts010101 and resultOK for the same retained
GET_CONFIGURATION capture. It preserves every named ownership/memory/recovery
row on WAIT, except the base result/step and the setup last-result/dispatch/step
diagnostics. Capture sequence and all sixteen captured bytes remain exact. The
successful retry clears the pending tag, advances the control epoch once, leaves
the active epoch unchanged until service and counts exactly one admission.
Arbitrary facts, results, duplicate admission and sequence relabeling remain
rejected. The final profile must contain both attempts for its single capture.

Independent anchors: existing `open-firmware/udc-setup/hp1020_udc_setup.c:100–128`,
`open-firmware/udc-composed-test/fixture.c:751–760` and composed Host
`scripts/validate-hp1020-udc-composed.py:407–418`. Full row mapping is the existing
fixture snapshot at lines397–422. Scenario line251 exposed the overly narrow
gate assumption but does not define the expected protocol result.

## 2. Acceptance cannot silently provide recovery promises

The fixture reviewer identified that V1 protected only issued/consumed/count
`r[33:36]` while describing accepted acquisition as unable to grant reset.
V2 protects the complete receive/recovery slice `r[32:48]`, which includes
generation, stopped/quiescent/error state, reset ticket/generation/active/parts
and retained response state. This is already required by the independent plan
and source-reviewed Host at lines134–138. It strengthens the invariant before
service; it adds no new scenario and changes no expected candidate behavior.

## 3. Raw-mode effective-source metadata binds actual files

V1 checked original source, patch identities, result-hash metadata and the
audited target's effective-source manifest, but did not hash the nineteen
saved materialized files at `capture/effective-source`. The fixture reviewer
identified the missing seal.

When a capture root is supplied, V2 checks every named materialized file against
the independently pinned original/result hash map and requires the adjacent
`effective-source.json` to equal the report's already-validated effective-source
record. Report-only mode remains metadata-only for those files. No assumption
is made about a disposable effective-source directory under `source_root`;
existing source-root and target artifact gates are unchanged.

## Other reviewed material

Scenario review:
`/tmp/hp1020-acquisition-scenarios-independent-review-20261003.md`, SHA256
`d29ae31de862376c8f6b7320ebd3701d4505cad4773b0098deee2085d423d4c1`.
Independent gate review:
`/tmp/hp1020-acquisition-gate-static-review-20261003.md`, SHA256
`77ee2d8f1fa5bea563ba69d5bbcf75a410109f81dbe32565c3e418e7fcc40fe3`.
These are static findings and provenance, not successful execution evidence.
