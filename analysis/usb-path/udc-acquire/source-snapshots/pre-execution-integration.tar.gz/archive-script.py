#!/usr/bin/env python3
"""Preserve unexecuted integration and its independent reviews before first run."""
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
OUT = ROOT/'analysis/usb-path/udc-acquire/source-snapshots'
NAME = 'pre-execution-integration'
members = {}

def add(name, raw):
    assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
    members[name] = raw

def tree(prefix, path):
    path = Path(path)
    assert path.is_dir(), path
    for source in sorted(path.rglob('*')):
        if source.is_file() and '__pycache__' not in source.parts:
            assert not source.is_symlink(), source
            add(prefix+'/'+source.relative_to(path).as_posix(), source.read_bytes())

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

for prefix, path in (
    ('scenario-package', '/tmp/hp1020-udc-acquire-scenarios-20261003'),
    ('root-runner-fragments', '/tmp/hp1020-acquisition-integration-20261003')):
    tree(prefix, path)

gate = Path('/tmp/hp1020-acquisition-gate-draft-20261003')
for name in ('check-hp1020-udc-acquire.py', 'README.md', 'SHA256SUMS'):
    add('gate-package/'+name, (gate/name).read_bytes())
tree('gate-package/original-oracles', gate/'original-oracles')
tree('gate-package/v2', gate/'v2')

for name in (
    'hp1020-udc-acquire-independent-review-20261003.md',
    'hp1020-udc-acquire-independent-review-v2-20261003.md',
    'hp1020-acquisition-runner-review-20261003.md',
    'hp1020-acquisition-runner-review-addendum-20261003.md',
    'hp1020-acquisition-scenarios-review-20261003.md',
    'hp1020-acquisition-scenarios-independent-review-20261003.md',
    'hp1020-acquisition-gate-static-review-20261003.md',
    'hp1020-acquisition-gate-static-review-v2-addendum-20261003.md'):
    add('reviews/'+name, (Path('/tmp')/name).read_bytes())

names = [
    'open-firmware/udc-out/hp1020_udc_out.c',
    'open-firmware/udc-out/hp1020_udc_out.h',
    'open-firmware/udc-out/hp1020_udc_acquire.h',
    'open-firmware/udc-out/README.md',
    'open-firmware/udc-composed-test/fixture.c',
    'open-firmware/udc-publish-test/fixture.c',
    'scripts/build-hp1020-udc-acquire-target.sh',
    'scripts/check-hp1020-udc-acquire.py',
    'scripts/validate-hp1020-udc-acquire.py']
names += [str(p.relative_to(ROOT)) for p in (ROOT/'open-firmware/udc-acquire-test').iterdir() if p.is_file()]
for name in sorted(names):
    add('integrated/'+name, (ROOT/name).read_bytes())
previous = ROOT/'analysis/usb-path/udc-publish/source-snapshots/next-acquisition-proposals.tar.gz'
assert sha(previous.read_bytes()) == '28c2797a750b61656d608962ac474f4831eb2ec286e2331c15fd8fae346f48b1'
add('PREVIOUS.json', (json.dumps({
    'path': str(previous.relative_to(ROOT)), 'sha256': sha(previous.read_bytes()),
    'contents': 'Unexecuted production V1/V2, fixture/codec/builder, original independent plan/oracles, root fragments and earlier static reviews.'
}, indent=2)+'\n').encode())
add('README.md', b'''# First acquisition integration, before candidate execution

This archive is a source/review snapshot, not a test report. Production C and
the fixture were integrated unchanged from the earlier proposal archive. The
independent scenario and gate were completed later and are preserved here.
Root assembled its header/Host/scenario/main and syntax-parsed the Python inputs;
no candidate import, compile or execution had occurred when this was captured.

The gate V1 remains unchanged. V2 contains separately recorded pre-execution
corrections from static contract review; the frozen acquisition oracle is not
changed. The scenarios-author reread and independent review are named separately.
Any later run must capture its entire source/fixture closure and raw evidence;
this archive cannot substitute for that execution provenance.
''')
add('archive-script.py', Path(__file__).read_bytes())
OUT.mkdir(parents=True, exist_ok=True)
archive = OUT/(NAME+'.tar.gz')
assert not archive.exists(), archive
with tarfile.open(archive, 'w:gz', compresslevel=9) as tar:
    for name, raw in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(raw)
        info.mode = 0o644
        tar.addfile(info, io.BytesIO(raw))
digests = {name: sha(raw) for name, raw in sorted(members.items())}
with tarfile.open(archive, 'r:gz') as tar:
    assert {m.name: sha(tar.extractfile(m).read()) for m in tar.getmembers()} == digests
metadata = dict(status='unexecuted-source-snapshot', archive=archive.name,
                archive_sha256=sha(archive.read_bytes()), archive_bytes=archive.stat().st_size,
                member_count=len(members), member_sha256=digests)
(OUT/(NAME+'.json')).write_text(json.dumps(metadata, indent=2)+'\n')
print(json.dumps({k:v for k,v in metadata.items() if k != 'member_sha256'}, indent=2))
