#!/usr/bin/env python3
"""Offline original-owner OUT acquisition through recording visibility hooks."""
import argparse
import importlib.util
import json
from pathlib import Path
import runpy
import select
import shutil
import struct
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('acquire_publish', ROOT/'scripts/validate-hp1020-udc-publish.py')
pub = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = pub
spec.loader.exec_module(pub)
pg, off, comp, ep0, base, core = pub.pg, pub.off, pub.comp, pub.ep0, pub.base, pub.core
bulk_reference, MODE_EVIDENCE = pub.bulk_reference, pub.MODE_EVIDENCE
SRC = ROOT/'open-firmware/udc-acquire-test'
OUT = ROOT/'analysis/usb-path/udc-acquire'
PROGRAM, PUBLISH = pub.PROGRAM, pub.PUBLISH
OK, WAIT, STALE, INVALID, FAULT, ADAPTER_ERROR = range(6)
ORACLES = SRC/'trace-oracles.py'
O = runpy.run_path(str(ORACLES))


def profiles():
    return O['profiles']()


def sources(temp):
    tested = pub.sources(temp)
    selected = set(SRC.glob('*.[ch]')) | set(SRC.glob('*.ld'))
    selected.add(ORACLES)
    selected.add(ROOT/'open-firmware/udc-out/hp1020_udc_acquire.h')
    selected.update(ROOT/'scripts'/name for name in (
        'validate-hp1020-udc-acquire.py', 'build-hp1020-udc-acquire-target.sh',
        'check-hp1020-udc-acquire.py'))
    for path in sorted(selected):
        if not path.is_file():
            continue
        name = str(path.relative_to(ROOT)); tested[name] = core.sha(path.read_bytes())
        destination = temp/'source'/name; destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
    (temp/'source-sha256.json').write_text(json.dumps(tested, indent=2)+'\n')
    return tested


def compile_host(temp, effective):
    ep0_src, out, setup = [ROOT/'open-firmware'/name for name in ('udc-ep0','udc-out','udc-setup')]
    implementation = [SRC/'fixture.c', SRC/'host-check.c', ep0_src/'hp1020_udc_ep0.c',
        out/'hp1020_udc_out.c', setup/'hp1020_udc_setup.c', PROGRAM/'hp1020_udc_program.c', PUBLISH/'hp1020_udc_publish.c',
        base.ADAPTER/'hp1020_tusb_adapter.c', base.PRINTER/'hp1020_usb_printer.c',
        base.RX/'hp1020_usb_receive.c', base.RX/'hp1020_usb_document.c']
    implementation += [base.IMG/name for name in ('hp1020_image.c','hp1020_image_page.c',
        'hp1020_image_stream.c','hp1020_image_ring.c','hp1020_image_output.c')]
    implementation += [base.SEM/'hp1020_semantic.c',base.SEM/'hp1020_page_plan.c',
        core.VENDOR/'libjbig/jbig85.c',core.VENDOR/'libjbig/jbig_ar.c']
    implementation += [effective/'src'/name for name in ('tusb.c','device/usbd.c','common/tusb_fifo.c')]
    flags = ['clang','-std=c11','-O1','-g','-fno-common','-Wall','-Wextra','-Werror',
        '-fsanitize=address,undefined']
    include = ['-I'+str(p) for p in (SRC,PUBLISH,PROGRAM,ep0_src,out,setup,ROOT/'open-firmware',
        base.SRC,base.ADAPTER,base.PROTOCOL,base.PRINTER,base.RX,base.IMG,base.SEM,
        core.VENDOR/'libjbig',effective/'src')]
    core.command(flags+include+implementation+['-o',temp/'host'])
    full = ROOT/'vendor/foo2zjs-source'
    core.command(flags+['-I'+str(full),base.IMG/'reference.c',full/'jbig.c',full/'jbig_ar.c',
        '-o',temp/'reference'])


def validate_event(words, data):
    pub.validate_event(words, data)
    op,a,b,c,d = words
    if op == 140: assert len(data) == 80 and b in (0,1) and c == d == 0
    if op == 141: assert len(data) == 3 and a == b == c == d == 0
    if op in (142,143): assert len(data) == 0 and d == 0

