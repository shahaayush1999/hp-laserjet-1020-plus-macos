# Acquisition scenario fragment

Unexecuted, 2026-10-03. No imports, compilation, test/validator execution, QEMU,
repository edits or device operations were performed while writing this package.
All source reads, copies and hashes are static. Frozen production V1/V2 and the
independently authored fixture are unchanged.

`scenarios.py` supplies `scenario(h, name, document, images)` plus its private
helpers. Concatenate it after the lead-owned header and Host, before the main.
It defines no imports, build/source collection, process startup or replay code.
The lead retains ownership of those operations and their evidence captures.

The matrix is the independently frozen `O['profiles']()` from
`oracles/trace-oracles.py`: 16 named semantic profiles, each at fills0 and204,
receive capacity64 and interface0. It introduces no additional profile or new
fixture operation. `O` must refer to the acquisition oracle; inherited
publication expectations retain `pub.O`. The fragment's globals are
`O,pub,pg,off,base,core,struct,OK,WAIT,STALE,INVALID,FAULT`.

## Inputs and independence

The independent plan/oracle predates this scenario fragment and did not read the
new acquisition C. Scenarios select expected bytes, field mutations, raw facts,
hook failure prefixes and final generations from that frozen plan. The small
image bytes/hash and32FF pixel oracle are literal independent inputs. Original
cookies come from the existing actual DCD submission history, before any fault;
no failure diagnostic becomes an owner or expected-cookie source.

Baseline snapshots preserve the exact inherited helpers, the lead's Host/header
read during drafting, the acquisition public header and frozen fixture source,
ABI note and manifest. The fixture uses real adapter/OUT ownership with separate
synthetic device images; no raw observer or normalized bulk completion is used by
the acquisition scenarios. The implementation C remains separately frozen in
the V2 production package, byte-identical to V1.

## Host and ABI integration

The inspected lead Host already supplies every required method:
`acquire_facts`, `device_image`, `acquire_packet`, `arm`, `arm_write`, `complete`,
`diagnostic`, `io`, plus inherited control/reset/recovery/notification helpers.
No Host signature change is required. `h.acquire` is80 appended words, total576.
The original496 diagnostics remain unchanged. Device image events use140,
facts141, acquisition142 and hook failure143; cancellation stays63/64. Old
observation/write/snapshot routes62/65/66/67 are explicitly rejected in one
profile. All packet fragments from inherited `send()` dynamically route through
the acquisition overrides, including ZLPs.

The Host retains independent literal device images by original token, even after
settlement and address reuse. It tracks complete4096 receive bytes, descriptor16
and device144 storage from explicit poison/input/hook effects and verifies the
corresponding raw captures. Scenarios separately assert original DCD->PENDING
ownership before service, unchanged queue/pixel/document/wire progress, exact
snapshot diagnostics, fault/no-hook barriers and completed page/document output.
Target replay must keep all576 rows and twelve existing/new raw capture pairs;
only measured sizeof words global59/425/490/555 may differ by architecture.

## Lifecycle choices worth preserving

- Missing facts, invalid facts, stale identities and normal PREPARED attempts
  preserve last/first-failure diagnostics and call no hook. NOT_DONE has all
  three hooks and a real snapshot; its next attempt reacquires everything.
- Acquisition fault is an adapter input fence, not a publisher-I/O failure.
  Harmless service polling returns OK in the no-pending-request state; pump
  returns RX_STOPPED. Publisher failure retains its existing WAIT barrier.
- Held unadmitted raw SETUP blocks normal progress but permits exact old-cookie
  acquisition. Later admission, old automatic-owner settlement and the ordinary
  GET_CONFIGURATION transfer remain separate. Only that profile has ordinary
  EP0 bytes01 and an actual normal control-status callback.
- Actual reset admission may precede successful old-cookie acquisition. The
  retained packet becomes PENDING, then drains under the stopped old generation;
  it creates no old document. Reset notification supplies no cleanup or promise.
- Fault recovery explicitly distinguishes DCD settlement, adapter PENDING
  drainage, optional publication-failure cleanup and the existing three-part
  document restart. Nonzero receive accounting survives until that restart.
- A PREPARED publication failure cannot install a device image or acquire.
  An EXPOSED publication failure can accept independently settled original bytes
  while normal forward progress remains blocked. Publisher failure bytes survive.
- G2 first-failure evidence survives cancellation/reset and successful G3 input.
  Reuse of the same descriptor/slot DMA never authorizes old image, acquisition
  or cancellation inputs. Natural callback/hook probes must be counted exactly.

## Static review and scope

The fragment was read through against the frozen fixture's actual event routing,
original-owner checks, device-image refusal order, hook effects and appended
diagnostic map, plus the lead Host snapshots and existing reset/stream helpers.
No syntax check or candidate execution was performed; first execution belongs
to the lead after independent review and source preservation.

This matrix deliberately does not multiply the old observer's descriptor-body,
owner-bit, RX-result or count policy cases. It adds no second G4 hook failure,
malformed noncontractual hook outcome, pointer-alias initialization test or
fabricated fault-report WAIT/ADAPTER_ERROR. Those are not executed claims. Real
mapping, cache-line isolation, physical settlement and cache/acquire operations
remain supplied obligations. Captures can establish observable range authority
and ordering; they cannot prove absence of every unused/speculative CPU read,
physical USB acceptance or printing.
