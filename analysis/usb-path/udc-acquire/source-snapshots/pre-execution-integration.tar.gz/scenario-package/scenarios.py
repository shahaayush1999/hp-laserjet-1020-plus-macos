"""UNEXECUTED acquisition scenario fragment:16 independent profiles x two fills.

Concatenate after the lead-owned header/Host and before its main. Globals O,
pub, pg, off, base, core, struct and the result constants come from that header. O is
the independently frozen acquisition oracle; pub.O remains the independently
frozen publication oracle. No production C is imported or decoded here.
"""


def _acq_record(h, records, kind, label, **expected):
    records.append(dict(kind=kind, label=label, event=len(h.events), **expected))


def _acq_no_effect(h, records, label, invoke):
    """A rejection may count the attempted stale event; it may not change work."""
    before = h.row.copy(), h.udc.copy(), h.acquire.copy()
    traces = len(h.expected_trace)
    result = invoke()
    # Base20 is the historical stale-event diagnostic, not an owner/queue field.
    assert [h.row[i] for i in range(1, 96) if i != 20] == [
        before[0][i] for i in range(1, 96) if i != 20], label
    assert h.udc[2:14] == before[1][2:14], label
    assert h.udc[16:40] == before[1][16:40] and h.udc[44:46] == before[1][44:46], label
    assert h.acquire[3:7] == before[2][3:7], label
    assert h.acquire[9:25] == before[2][9:25], label
    assert h.acquire[25:59] == before[2][25:59], label
    assert h.acquire[69:73] == before[2][69:73] and h.acquire[77:79] == before[2][77:79]
    assert len(h.expected_trace) == traces, label
    _acq_record(h, records, 'no-effect-refusal', label, result=h.row[0],
        owner_states=before[1][44], generation=before[0][32],
        issued=before[0][33], consumed=before[0][34], count=before[0][35])
    return result


def _acq_accept(h, records, token, label, *, service=True, pump=False):
    """Observe the DCD->PENDING boundary before any TinyUSB service/consumption."""
    before = h.row.copy()
    original = h.bulk[token]['cookie'].copy()
    image = h.device_images[token]
    assert image['cookie'] == original and image['done']
    assert image['descriptor'] == O['literal_descriptor'](image['slot'], len(image['input']))
    assert ((h.udc[44] >> 16) & 255) == 1
    h.acquire_packet(token)
    actual = h.diagnostic(h.acquire[25:42])
    wanted = O['captured_fields'](original, image['descriptor'], OK)
    assert all(actual[k] == value for k, value in wanted.items()) and actual['reason'] == 0
    assert h.row[18] == before[18]+1 and h.row[19] == before[19]
    assert h.row[30] == 0 and h.udc[2] == 0 and ((h.udc[44] >> 16) & 255) == 2
    assert h.row[32:48] == before[32:48] and h.row[69:73] == before[69:73]
    assert h.row[17:18]+h.row[24:26]+h.row[50:59]+h.row[90:96] == (
        before[17:18]+before[24:26]+before[50:59]+before[90:96])
    _acq_record(h, records, 'acquired-before-service', label, original_cookie=original,
        descriptor_hex=image['descriptor'].hex(), payload_hex=image['payload'].hex(),
        input_hex=image['input'].hex(), expected_diagnostic=wanted,
        owner_states=h.udc[44], generation=before[32], count=before[35])
    if service:
        h.service()
    if pump:
        h.step(7)


def _acq_fault_only(h, records, token, reason, *, supplied=0, label='retained fault'):
    before = h.row.copy(), h.udc.copy(), h.acquire.copy()
    trace_count = len(h.expected_trace)
    original = h.bulk[token]['cookie'].copy()
    h.acquire_packet(token, fault=supplied, result=FAULT)
    wanted = original + [0, 0, 0, 0, reason, FAULT, 0, 0] + [0]*4
    assert h.acquire[25:42] == wanted
    assert h.acquire[42:59] == before[2][42:59]
    assert h.acquire[3:7] == before[2][3:7] and len(h.expected_trace) == trace_count
    assert h.udc[2:6] == [2, 1, 1, reason]
    assert h.row[30] == token and ((h.udc[44] >> 16) & 255) == 1
    assert h.row[33:36] == before[0][33:36] and h.row[18] == before[0][18]
    assert h.row[7] == h.row[9] == h.row[36] == 1
    assert h.row[24:26] == before[0][24:26] and h.row[50:59] == before[0][50:59]
    assert h.row[90:96] == before[0][90:96]
    _acq_record(h, records, 'fault-without-acquisition', label,
        original_cookie=original, supplied_reason=supplied, retained_reason=reason,
        expected_diagnostic=wanted)


def _acq_fault_barrier(h, records, token, reason):
    """The adapter is fenced; this is not a fabricated publisher failure."""
    before = h.row.copy()
    failure = h.acquire[42:59].copy()
    trace_count = len(h.expected_trace)
    h.arm((), result=WAIT)
    assert h.row[2:96] == before[2:96]
    h.service()  # Harmless poll is allowed: no new dispatch or cache retry.
    assert h.row[2:96] == before[2:96]
    h.step(7, result=base.STOPPED)
    assert h.row[32:48] == before[32:48]
    assert h.row[50:59] == before[50:59] and h.row[90:96] == before[90:96]
    assert h.row[30] == token and h.udc[3:6] == [1, 1, reason]
    assert h.acquire[42:59] == failure and len(h.expected_trace) == trace_count
    assert h.publish[6] == 0, 'an acquisition fault is not a publication-I/O failure'
    _acq_record(h, records, 'fenced-no-retry', 'arm WAIT, service OK, pump STOPPED',
        original_cookie=h.bulk[token]['cookie'].copy(), reason=reason,
        first_failure=failure, count=before[35])


def _acq_reset_recover(h, records, token, auto_owner, *, already_reset=False,
                       already_settled=False, publication_failure=None):
    """Real reset + original settlement, then separate program/document recovery."""
    original = h.bulk[token]['cookie'].copy()
    generation, count = h.row[32], h.row[35]
    failure = h.acquire[42:59].copy()
    wire = off._offload_wire_state(h)
    assert count > 0 and generation == 2
    if not already_reset:
        h.step(5)
    assert h.ingress[11] == 1 and h.row[2] != h.row[3]
    assert h.row[32] == generation and h.row[35] == count
    if publication_failure is not None:
        assert h.publish[6] == 1 and h.publish[22:36] == publication_failure
        h.publication_cleanup(token, result=WAIT)
    h.service(WAIT)  # At least the original automatic-status owner is retained.
    if not already_settled:
        h.step(64, token, 0, result=WAIT)
        assert h.row[30] == token and h.udc[16:21] == original
        h.step(64, token, 1)
        assert h.row[30] == 0 and h.udc[2] == 0
        assert ((h.udc[44] >> 16) & 255) == 2
    if publication_failure is not None:
        h.publication_cleanup(token, result=WAIT)
    assert h.row[28] == auto_owner
    off._offload_settle_auto(h, auto_owner, service=False)
    if publication_failure is not None:
        h.publication_cleanup(token, result=WAIT)  # PENDING owner is not free.
    h.service()
    assert h.row[8] == h.row[10] == h.row[13] == h.row[77] == h.row[85] == 0
    assert h.udc[44] == 0 and h.row[7] == h.row[36] == 1
    assert h.row[32] == generation and h.row[35] == count
    assert h.row[44:46] == [0, 0] and h.row[50] == h.row[90] == 0
    assert h.acquire[42:59] == failure
    if publication_failure is not None:
        h.publication_cleanup(token, fact=0, result=WAIT)
        h.publication_cleanup(token)
        assert h.publish[56:58] == [count, count]
        assert h.publish[22:36] == publication_failure
        assert h.row[32] == generation and h.row[35] == count and h.row[44:46] == [0, 0]
    _acq_record(h, records, 'settled-before-restart', 'retained receive accounting',
        original_cookie=original, generation=generation, count=count,
        first_failure=failure, publication_failure=publication_failure,
        no_reset_promises=True)
    _acq_no_effect(h, records, 'old packet after reset drainage',
        lambda: h.acquire_packet(token, result=STALE))
    off._offload_no_wire(h, wire)
    h.acquire_facts(O['DEFAULT_FACTS'])
    sequence, owner = pg.configure(h, recover=True, grant=True)
    assert h.row[32] == 3 and h.acquire[42:59] == failure
    return sequence, owner


def _acq_finish_page(h, records, name, small, images, offset=0):
    generation = O['expected_generation'](name)
    assert h.row[32] == generation
    expected = O['EXPECTED_BLACK_PIXELS']
    assert expected == bytes.fromhex('ff'*32) and images['small'][1] == expected
    h.send(small[offset:], 64)
    h.expected_pixels = expected
    h.notification(generation, 1, 0, 1)
    h.repeat_pump()
    assert h.row[50] == 32 and h.row[56:59] == [1, 1, 1]
    assert h.row[90:93] == [1, 1, 1]
    assert h.row[35] == h.row[36] == h.row[40] == h.row[44] == 0
    assert h.publish[6] == h.program[4] == 0
    ordinary = int(name == 'acquire/held-setup-settlement')
    wire = b'\x01' if ordinary else b''
    assert h.row[24:26] == [len(wire), core.fnv(wire)]
    assert h.slot(0)[31] == h.slot(1)[31] == h.offload[57] == ordinary
    assert [packet['expected_hex'] for packet in h.packets] == (['01'] if ordinary else [])
    assert b''.join(struct.pack('>5I', *row) for row in h.expected_documents) == O['document_event'](generation)
    assert h.acquire[60] == h.publish[54] and h.acquire[60] > 0
    assert h.acquire[61] == sum(h.acquire[3:6]) and h.acquire[61] > 0
    assert h.acquire[62:64] == [WAIT, 1]
    _acq_record(h, records, 'complete-document', name, generation=generation,
        pixels_hex=expected.hex(), document=[generation, 1, 0, 1, 0],
        ordinary_wire_hex=wire.hex(), callback_probes=h.acquire[60], hook_probes=h.acquire[61])


def scenario(h, name, document, images):
    assert name in {profile[0] for profile in O['profiles']()}
    records = []
    short = name.removeprefix('acquire/')
    small = document(['small'])
    assert len(small) > 71 and images['small'][0] == O['SMALL_BIE']
    assert core.sha(images['small'][0]) == O['SMALL_BIE_SHA256']
    assert images['small'][1] == O['EXPECTED_BLACK_PIXELS']
    h.facts([1]*7)
    h.grant_facts([1]*5)
    h.publish_facts(pub.O['FACTS_ALL'])
    h.acquire_facts(O['DEFAULT_FACTS'])
    off._offload_reset(h)
    sequence, owner = pg.configure(h, recover=True, grant=True)
    assert h.row[32] == 2 and h.publish[6] == h.acquire[2] == 0

    if short == 'visibility-packets':
        for label, fragment in (('zero is not EOF', b''), ('short7', small[:7]),
                                ('full64', small[7:71])):
            token = h.arm_write(fragment)
            _acq_accept(h, records, token, label)
            assert h.row[36] == h.row[40] == 0
        h.step(7)
        _acq_finish_page(h, records, name, small, images, 71)
        assert {row[3] for row in h.expected_trace if row[2] == 7} == set(O['RECEIVE_DMAS'])

    elif short == 'facts-and-identities':
        token = h.arm_write(small[:31])
        for label, facts, expected in O['fact_probes']():
            h.acquire_facts(facts)
            _acq_no_effect(h, records, label,
                lambda expected=expected: h.acquire_packet(token, result=expected))
        h.acquire_facts(O['DEFAULT_FACTS'])
        for mutant in range(1, 6):
            _acq_no_effect(h, records, 'cookie-field-'+str(mutant),
                lambda mutant=mutant: h.acquire_packet(token, mutant=mutant, result=STALE))
        # All old snapshot/direct-write paths stay disabled in this variant.
        for op, args, raw in ((62, (token, 0x010101), bytes(16)),
                              (65, (token, 0, 0, 16), bytes(16)),
                              (66, (token, 0), b''), (67, (0, 0x010101), b'')):
            _acq_no_effect(h, records, 'disabled-'+str(op),
                lambda op=op, args=args, raw=raw: h.step(op, *args, data=raw, result=INVALID))
        _acq_accept(h, records, token, 'pending packet', service=False)
        _acq_no_effect(h, records, 'PENDING image cannot poison bytes',
            lambda: h.device_image(token, small[:31], result=STALE))
        _acq_no_effect(h, records, 'PENDING duplicate acquisition',
            lambda: h.acquire_packet(token, result=STALE))
        h.service()
        _acq_no_effect(h, records, 'FREE image cannot poison bytes',
            lambda: h.device_image(token, small[:31], result=STALE))
        _acq_no_effect(h, records, 'FREE duplicate acquisition',
            lambda: h.acquire_packet(token, result=STALE))
        h.step(7)
        _acq_finish_page(h, records, name, small, images, 31)

    elif short == 'callback-authority':
        callback_probes, hook_probes = h.acquire[60], h.acquire[61]
        token = h.arm_write(small[:31])
        assert h.acquire[60] == callback_probes+1 and h.acquire[61] == hook_probes
        assert h.acquire[62:64] == [WAIT, 1]
        _acq_accept(h, records, token, 'natural callback and three hook probes', pump=True)
        assert h.acquire[61] == hook_probes+3 and h.acquire[62:64] == [WAIT, 1]
        _acq_record(h, records, 'natural-reentry-refusals', short,
            callback_delta=1, hook_delta=3, result=WAIT, unchanged=True)
        _acq_finish_page(h, records, name, small, images, 31)

    elif short == 'held-setup-settlement':
        token = h.arm_write(small[:31])
        held = h.capture(O['GET_CONFIGURATION'])
        h.dispatch(held, facts=0, result=WAIT)
        assert h.ingress[2:5] == [1, held, held] and h.ingress[11] == 0
        h.arm((), result=WAIT)
        _acq_accept(h, records, token, 'settlement while raw capture held', service=False)
        forward = h.forward_state()
        h.service(WAIT)
        h.step(7, result=WAIT)
        assert h.forward_state() == forward and ((h.udc[44] >> 16) & 255) == 2
        h.dispatch(held)
        h.service(WAIT)
        assert h.row[28] == owner and h.offload[14] == 1
        off._offload_settle_auto(h, owner, service=False)
        h.service()
        h.control_in(b'\x01', 'GET_CONFIGURATION after held acquire')
        h.step(7)
        _acq_record(h, records, 'ordinary-control-after-held-capture', short,
            original_sequence=held, request_hex=O['GET_CONFIGURATION'].hex(),
            in_hex='01', status_endpoint=0, status_length=0)
        _acq_finish_page(h, records, name, small, images, 31)

    elif short == 'admitted-reset-settlement':
        token = h.arm_write(small[:31])
        original = h.bulk[token]['cookie'].copy()
        h.step(5)
        assert h.ingress[11] == 1 and h.row[2] != h.row[3]
        assert h.row[4] != original[1] and h.udc[3] == 1
        h.arm((), result=WAIT)
        _acq_accept(h, records, token, 'old packet after actual reset admission', service=False)
        sequence, owner = _acq_reset_recover(h, records, token, owner,
            already_reset=True, already_settled=True)
        _acq_finish_page(h, records, name, small, images)

    elif short == 'same-address-reuse':
        token = h.arm_write(small[:31])
        original = h.bulk[token]['cookie'].copy()
        old_dma = h.bulk[token]['dma']
        _acq_accept(h, records, token, 'old incomplete input', pump=True)
        assert h.row[50] == h.row[90] == 0
        off._offload_reset(h)
        sequence, owner = pg.configure(h, recover=True, grant=True)
        new = h.arm_write(small[:31])
        current = h.bulk[new]['cookie'].copy()
        assert current[2] == 3 and original[2] == 2 and current != original
        assert h.bulk[token]['slot'] == h.bulk[new]['slot'] == 0
        assert h.bulk[new]['dma'] == old_dma and h.udc[21] == O['DESCRIPTOR_DMA']
        _acq_no_effect(h, records, 'reused address rejects old image',
            lambda: h.device_image(token, small[:31], result=STALE))
        _acq_no_effect(h, records, 'reused address rejects old acquire',
            lambda: h.acquire_packet(token, result=STALE))
        _acq_no_effect(h, records, 'reused address rejects old cancel request',
            lambda: h.step(63, token, result=STALE))
        _acq_no_effect(h, records, 'reused address rejects old cancel settlement',
            lambda: h.step(64, token, 1, result=STALE))
        _acq_record(h, records, 'same-address-new-owner', short, old_cookie=original,
            new_cookie=current, descriptor_dma=O['DESCRIPTOR_DMA'], buffer_dma=old_dma)
        _acq_accept(h, records, new, 'new original owner', pump=True)
        _acq_finish_page(h, records, name, small, images, 31)

    elif short in ('prepared-publication-failure', 'exposed-publication-failure'):
        prepared = short == 'prepared-publication-failure'
        vector = pub.O['post_bind_failure'](
            'rx-cache-failure' if prepared else 'desptr-write-uncertain', h.row[33] % 4)
        token, original, wanted = pub._publication_failure(h, records, short, vector)
        assert h.acquire[2] == 0
        if prepared:
            _acq_no_effect(h, records, 'PREPARED image refuses before mutation',
                lambda: h.device_image(token, small[:31], result=INVALID))
            _acq_no_effect(h, records, 'PREPARED acquisition refuses before hooks',
                lambda: h.acquire_packet(token, result=INVALID))
            pub._publication_reset_cleanup(h, records, token, owner, wanted)
            sequence, owner = pg.configure(h, recover=True, grant=True)
        else:
            h.device_image(token, small[:31])
            _acq_accept(h, records, token, 'settled EXPOSED publication failure', service=False)
            assert h.publish[6] == 1 and h.publish[22:36] == wanted
            pub._publication_failed_barrier(h, records, token, sequence, owner)
            sequence, owner = _acq_reset_recover(h, records, token, owner,
                already_settled=True, publication_failure=wanted)
        assert h.row[32] == 3 and h.acquire[2] == 0 and h.publish[22:36] == wanted
        _acq_finish_page(h, records, name, small, images)
        assert h.acquire[2] == 0 and h.publish[22:36] == wanted

    elif short == 'endpoint-fault-only':
        token = h.arm_write(small[:31])
        h.acquire_facts(bytes(3))
        _acq_fault_only(h, records, token, 0x5a17, supplied=0x5a17, label='fault without settlement')
        _acq_fault_only(h, records, token, 0x5a17, supplied=0x6b28, label='first reason survives')
        _acq_fault_only(h, records, token, 0x5a17, label='clean retry cannot erase fault')
        assert h.acquire[2] == 0, 'endpoint fault is not an acquisition-I/O failure'
        _acq_fault_barrier(h, records, token, 0x5a17)
        sequence, owner = _acq_reset_recover(h, records, token, owner)
        _acq_finish_page(h, records, name, small, images)
        assert h.acquire[2] == 0

    elif short == 'not-done-fresh-retry':
        token = h.arm()
        h.device_image(token, small[:31], done=False, false_done=True)
        before = h.row.copy()
        hooks = h.acquire[3:6].copy()
        h.acquire_packet(token, result=WAIT)
        image = h.device_images[token]
        actual = h.diagnostic(h.acquire[25:42])
        wanted = O['captured_fields'](h.bulk[token]['cookie'], image['descriptor'], WAIT)
        assert all(actual[k] == value for k, value in wanted.items())
        assert actual['reason'] == 0 and h.acquire[2] == 0
        assert h.udc[2] == 2 and h.row[30] == token and ((h.udc[44] >> 16) & 255) == 1
        assert h.row[18] == before[18] and h.row[32:48] == before[32:48]
        assert h.row[69:73] == before[69:73]
        assert h.acquire[3:6] == [value+1 for value in hooks]
        _acq_record(h, records, 'not-done-authority', 'CPU false DONE is not evidence',
            original_cookie=h.bulk[token]['cookie'].copy(),
            device_descriptor_hex=image['descriptor'].hex(), expected_diagnostic=wanted)
        h.device_image(token, small[:31], done=True, false_done=False)
        _acq_accept(h, records, token, 'whole fresh acquisition after WAIT', pump=True)
        assert h.acquire[3:6] == [value+2 for value in hooks]
        _acq_finish_page(h, records, name, small, images, 31)

    else:
        selected = [entry for entry in O['HOOK_FAILURE_PROFILES'] if entry[0] == short]
        assert len(selected) == 1
        _, kind, outcome = selected[0]
        token = h.arm_write(small[:31])
        original = h.bulk[token]['cookie'].copy()
        slot = h.bulk[token]['slot']
        image = h.device_images[token]
        before = h.row.copy()
        h.acquire_packet(token, fail_kind=kind, outcome=outcome, result=FAULT)
        fields = O['failure_fields'](original, slot, kind, outcome)
        wanted = original + [fields['prefix'], fields['dma'], fields['bytes'], outcome,
                             O['REASON_IO'], FAULT, fields['operation'], 0] + [0]*4
        assert h.acquire[25:42] == wanted and h.acquire[42:59] == wanted and h.acquire[2] == 1
        assert h.row[18] == before[18] and h.row[33:36] == before[33:36]
        assert h.row[69:73] == before[69:73] and h.row[50] == h.row[90] == 0
        assert h.udc[2:6] == [2, 1, 1, O['REASON_IO']]
        cpu_d, cpu_p = O['expected_visibility'](slot, image['descriptor'], image['payload'],
            fail_kind=kind, outcome=outcome)
        assert struct.pack('>4I', *h.udc[24:28]) == cpu_d
        _acq_record(h, records, 'hook-failure', short, original_cookie=original,
            expected_failure=wanted, descriptor_hex=cpu_d.hex(), payload_hex=cpu_p.hex(),
            trace=[list(row) for row in O['acquire_trace'](slot, fail_kind=kind, outcome=outcome)])
        _acq_fault_only(h, records, token, O['REASON_IO'], label='same fault retry, no cache tail')
        _acq_fault_only(h, records, token, O['REASON_IO'], supplied=0x5a17,
            label='endpoint reason cannot overwrite first acquisition failure')
        _acq_fault_barrier(h, records, token, O['REASON_IO'])
        sequence, owner = _acq_reset_recover(h, records, token, owner)
        _acq_finish_page(h, records, name, small, images)
        assert h.acquire[2] == 1 and h.acquire[42:59] == wanted
        assert h.acquire[44] == 2 and h.acquire[27] == 3, 'original failed G2 survives successful G3'
    return records
