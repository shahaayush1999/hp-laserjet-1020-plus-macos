# Acquisition scenarios: independent static review

2026-10-03. Reviewer: `/root/usb_reference_contract`. This review read source
text and computed file hashes only. No Python was parsed/imported/executed, no
candidate was built or run, and no repository file or frozen proposal was
changed. The candidate remained unexecuted during this review.

## Result

No additional substantive scenario/fixture/Host mismatch was found in the
bounded sixteen-profile matrix. One pre-execution blocker is in the independent
gate V1, not the proposed scenario: its raw SETUP dispatch check only accepts
successful admission and rejects the deliberately missing-facts WAIT. Preserve
the scenario and correct that assumption in a separately preserved gate V2.

The lead also approved two narrowly scoped gate hardenings raised by the
independent fixture reviewer: protect the full receive/recovery state on accepted
acquisition, and hash the actual saved effective-source files in raw mode.
Neither is an observed candidate failure or a reason to change the frozen
literal acquisition oracle. Those gate changes are separate from this review.

## Author and evidence separation

`/root/printer_class_reuse` froze the plan, literal oracle and fixture without
reading the new acquisition implementation. `/root/adapter_review` authored the
production C and this scenario fragment; therefore the fragment is not an
independent implementation oracle merely because it consumes independent
constants. The lead owns the Host, integration and eventual execution. This
reviewer froze gate V1 before reading the scenario fragment, then compared the
fragment with that gate, the prior plan, the public fixture ABI and inherited
helpers. Scenario `acquisition_oracles` annotations remain redundant narrative,
never evidence authority for the independent gate.

Exact reviewed SHA256 values:

| Source | SHA256 |
|---|---|
|`/tmp/hp1020-udc-acquire-scenarios-20261003/scenarios.py`|`6a50b95a7e420831a3625e2e8ade2e7e5dc3795b81f5dc57e287a5f55c829b64`|
|`/tmp/hp1020-acquisition-integration-20261003/host.py`|`c2374e9af2cf501a42a040e51ca46205606dd12466c9718eae472639b882ee8f`|
|`/tmp/hp1020-acquisition-integration-20261003/header.py`|`24dd9b14fa9670879f960709b8dda7f56af92c3b613dfbf84fff1824dbb0d052`|
|`/tmp/hp1020-acquisition-gate-draft-20261003/check-hp1020-udc-acquire.py` (V1)|`a057fd10ce31f830f76af61abd35fde2fce2702f82e3373647c301be0c7c17a1`|
|`/tmp/hp1020-udc-acquire-oracles-20261003/trace-oracles.py`|`06160580c3ecce51f36731be7c3a0ca7097769ee8b2543f1ad715e6d5bddea25`|
|`/tmp/hp1020-udc-acquire-oracles-20261003/PLAN.md`|`f35238a5e93cce4450e05f5bba23fc110b7c843676ee1a5bc2b5b82ecc0a47b8`|
|`/tmp/hp1020-udc-acquire-fixture-draft-20261003/draft/open-firmware/udc-acquire-test/README.md`|`a80028559034d8502a86e43e698dfdf6e2bbe21bb625612cecab3a402e3cb7b2`|
|`/tmp/hp1020-udc-acquire-fixture-draft-20261003/draft/open-firmware/udc-acquire-test/fixture.c`|`deb151a70fe6b895fe70063c6043c683eec10d02d034da2ea09d205a931ceb9f`|

## Gate V1 mismatch, with independent contract anchors

Scenario lines248–269 offer GET_CONFIGURATION, call
`dispatch(held, facts=0, result=WAIT)`, acquire the exact older bulk packet while
the same capture remains held, and later call `dispatch(held)` with all facts.
This directly exercises frozen plan profile4; replacing the first call with
success would remove the intended unknown-facts boundary.

Gate V1 lines1006–1008 instead require every op82 to have facts010101, resultOK,
and an incremented control epoch. The existing
`open-firmware/udc-setup/hp1020_udc_setup.c:100–128` checks original pending
capture identity, then returns WAIT for missing facts before invoking adapter
admission. Existing `scripts/validate-hp1020-udc-composed.py:407–418` sends the
same sequence and updates its admitted-request witness only for OK. Fixture
`open-firmware/udc-composed-test/fixture.c:751–760` records the dispatch attempt
and supplied external stall-clear fact; it counts admission only on OK.

A narrow gate correction should require exactly one zero-facts WAIT for that
retained record, unchanged control/owners/storage/recovery, and one later full-
facts success for the SAME sequence with exactly one epoch advance. It should
not accept arbitrary dispatch results or derive facts from the reported result.
Root and the fixture reviewer independently identified this same mismatch
before candidate execution; V1 remains the preserved original gate.

## Bounded checks that agree

- Scenario lines35–59 inspect DCD-to-PENDING before service. The full
  `row[32:48]` and ready-slot state stay unchanged; only the exact original
  completion/owner transition is permitted. Lead Host lines134–138 independently
  requires the same preservation. This applies while a newer SETUP is held,
  after actual reset admission and during an exposed publisher failure.
- Scenario lines102–152 retain the original cookie through cancellation and
  reset. Explicit bulk and automatic-status settlement precede adapter drainage;
  nonzero receive accounting survives until separately supplied restart
  promises. Publisher cleanup is additional and changes neither accounting nor
  promises. The inherited high-level `step(5)` is intentionally translated to
  raw op83 with the next external sequence by composed Host lines359–365; it
  does not use the forbidden legacy raw-reset path.
- Lines208–235 cover all nine raw-fact refusals, five original-cookie mutations,
  disabled observation/write bypasses and PENDING/FREE image/acquisition replay.
  Allowed stale-attempt counters are explicitly separated from ownership and
  work state. The independent whole-storage shadows originate in input poison
  and device bytes, not accepted post-operation memory.
- Lines282–307 reuse the same numerical slot0/descriptor allocations in G3,
  retain the G2 historical token, and require old image/acquire/cancellation
  inputs to leave the new owner untouched. Lines309–332 distinguish PREPARED
  refusal from settled EXPOSED completion without clearing publisher failure.
- Lines334–344 distinguish a supplied endpoint fault with facts000 from a cache
  attempt. Lines346–365 first present plausible CPU DONE bytes but device
  owner1, then require a complete fresh three-hook acquisition after replacing
  the device image. Lines367–396 use independent failure prefixes/partial
  effects and retain first-failure G2 evidence across G3 success.
- The final oracle is literal32FF, one exact G2/G3 END_DOC record and, only for
  the held-SETUP profile, ordinary IN01 followed by OUT0 status. Device image
  tail bytes are distinct; only reported packet count enters the original
  input stream. Normal inherited streaming routes through the acquisition
  overrides, including its extra ZLPs. No normal bulk observer bypass is used.

## Limits

This is static review, not successful execution. The scenario fragment alone
does not prove the raw memory or effective-source seals: those depend on the
fixture, Host, target replay and independent gate together. The explicitly
excluded G4 second fault, malformed noncontractual hook returns, pointer-alias
initialization controls and fabricated fault-report WAIT remain untested.
Supplied mapping/cache/settlement facts remain physical preconditions; these
RAM recordings cannot establish DMA, USB acceptance, IRQ handling or printing.
