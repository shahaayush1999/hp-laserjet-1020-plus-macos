# Acquisition gate V2 static delta confirmation

The original review and V1 remain unchanged. V2 is
`/tmp/hp1020-acquisition-gate-draft-20261003/v2/check-hp1020-udc-acquire.py`,
SHA256 `45b452944da502ec4d5f1b59dbd015111c21e2b3eb2fdacce058cc2794f5dd13`.
Its textual diff against V1 contains only the three approved changes and their
per-case coverage counters. No import, parsing, execution or repository edit was
performed for this confirmation.

The missing-fact op82 form now requires WAIT, retained capture/owner state, no
admission, and exactly the fixture's permitted setup result/dispatch/step counter
changes. Existing composed fixture source increments dispatches at stats18 and
steps at36, increments admissions19 only on OK, and explicitly supplies EP0
stall clearing independently of dispatch success. The frozen profile already
has clear stalls. Existing setup dispatch source returns WAIT on missing facts
before admission. The later full-fact retry must use the same pending sequence
and increments the control epoch/admission exactly once. The final profile gate
requires both events, rather than merely permitting them.

Successful acquisition now protects all base32..47 before service, including
generation, accounting, quiescence, reset identity/activity/parts and deferred
control state. The new raw-mode source seal reads all 19 actual materialized
effective files and their exact manifest from capture/effective-source. This
closes the substantive saved-byte omission; rejecting extra unreferenced files
would be optional archive hardening and is not needed for this checkpoint.

No further concrete mismatch was found in these changes. Runtime acceptance
remains unobserved; root owns the first sequential positive execution and later
copied-evidence negative controls.
