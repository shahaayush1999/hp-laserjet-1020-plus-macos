# Acquisition scenarios: author contract reread

2026-10-03. Static review only: no candidate import, parser/syntax check, build,
test, validator, target/stock execution, repository mutation or device contact.
I authored the scenario fragment, so this is a second author contract reread,
not an independent-author review. The frozen plan/oracle and fixture were
authored independently without reading the new acquisition implementation.

## Result

No actionable scenario/Host/fixture mismatch found in this pass. No frozen input
was changed. This result is limited to the named32-case matrix and actual helper
contracts below; it is not an execution result or a substitute for the separate
reviewer and first preserved run.

The scenario function matches the independent helper's ten named positive/guard
profiles plus six hook-failure profiles. The helper supplies each at fills0 and
204, capacity64 and interface0:16×2=32. The catch-all branch requires exactly one
named hook-failure match; it cannot silently accept another profile. There is
no extra Cartesian expansion or silently omitted profile in the fragment.

## Ownership and event checks

At lines37–60, successful acquisition is checked before service: exact original
DCD history cookie and independent device descriptor; one completion admission;
OUT object FREE and adapter bulk owner PENDING; unchanged receive accounting,
READY flags, pixels, documents and wire. Neither scenario nor fixture creates a
second success event. The fixture invokes the real acquisition API and checks
borrowed bytes before retiring its own live flag.

The lead Host's ordinary `complete()` override routes every bulk packet to
op142. Inherited `send()` dynamically calls that override through `transfer()`
and the overridden `arm_write()`. All subsequent stream data and ZLPs therefore
use actual publication, independent device-image input and acquisition. Ordinary
EP0 continues through its existing descriptor component. The only direct old
OUT observation/write/snapshot events62/65/66/67 are negative controls, requiring
INVALID and unchanged ownership/storage diagnostics.

Missing/invalid facts and cookie mutations leave both acquisition diagnostics
unchanged and call no hook. PENDING/FREE image and acquisition retries are stale.
The helper intentionally ignores only the historical stale-event counters in its
ownership comparisons. Same-address reuse checks old image/acquire/cancel inputs
against the genuinely new G3 owner and equal numerical slot/descriptor mapping;
it does not reassign the old cookie to new storage.

Natural callback/hook probes are private fixture checks, not scenario writes to
production busy flags. The callback-authority branch checks one new after-bind
probe and three new hook probes. Final checks require total callback probes to
equal actual publication callbacks and total hook probes to equal all three hook
attempt counters, including attempted failed hooks.

## Reset, fault and generation checks

The apparent `h.step(5)` is the inherited composed Host shorthand for an actual
ordered ingress reset event83. It does not use disabled normalized fixture op5.
Initial reset does not increment the receive generation. Typed configuration
with its existing three external promises reachesG2; every reset/recovery
profile subsequently repeats the same real configuration/recovery path toG3.

The held-SETUP profile permits exact packet settlement while ingress permission
is0, then checks that service/pump remain blocked. It admits that same capture,
settles the original held automatic status owner separately and completes one
ordinary GET_CONFIGURATION: IN01 followed by OUT0 ZLP. No automatic status owner
is presented as a wire packet or TinyUSB ACK. All other profiles require zero
ordinary EP0 preparations/status callbacks and empty ordinary wire.

The admitted-reset profile intentionally allows a successful old-cookie packet
after newer control/transport admission, because the old DCD owner still exists
and settlement is supplied. It becomes PENDING without queue READY or parser
progress. Subsequent service drains it under the stopped old generation; actual
adapter `driver_xfer` suppresses delivery to the receive queue while fenced.
The first sole page/document belongs toG3.

Lines102–152 retain count>0 through controller settlement, automatic-owner
settlement and adapter notification drainage. DCD settlement is not PENDING
drainage. Optional publisher cleanup remains WAIT until all owners drain and is
then acknowledged separately, still preserving receive count and no document
reset promises. Configuration/recovery is the operation that restarts the queue.

The PREPARED publication-failure profile refuses image/acquisition before hooks;
the EXPOSED profile accepts explicitly settled original bytes while retaining
the publisher's failure record and ordinary WAIT barrier. The latter does not
attempt cancellation again after the bulk owner is already PENDING/FREE.

Acquisition fault and publisher failure keep different result domains. The
former fences/stops adapter input but does not set publisher.failed: armWAIT,
benign no-pending serviceOK, pumpRX_STOPPED3. The latter continues to use its
existing combined-progress WAIT barrier. Endpoint-fault-only calls with facts000
report the original reason with no hooks and create no acquisition-I/O failure.

Each hook failure has its independent literal prefix0/1/3 and no valid snapshot;
partial CPU effects are explicit fixture inputs, not inferred from success.
Later fault-only calls run no cache tail and preserve first_failure exactly.
G3 successful input updates last diagnostics without erasing the saved G2 first
failure. NOT_DONE is distinct: full three-hook acquisition plus real snapshot
returnsWAIT, and a later attempt freshly reacquires all three operations.

## Output and remaining boundaries

Every profile ends with the pinned small image,32 literal FF bytes, one page and
one BE document notification `(G,1,0,1,0)`. Old partial input must yield no page
or document; normal END_DOC is used without explicit close/EOF. Repeated pump
checks forbid duplicate notifications. The lead Host reconstructs all4096 receive
bytes, descriptor16 and device144 from input/poison/hook outcomes for final raw
capture comparison. Existing guards check allowed byte effects during each event
and before fake-DCD retirement; no final digest substitutes for that lifecycle
check. Row/replay/source preservation remains the lead main's responsibility.

No recommendation to broaden the matrix. The independent plan already excludes
another G4 failure, noncontractual raw hook return values, alias/init probes,
and fabricated report-WAIT/ADAPTER_ERROR. Real mapping, cache-line safety,
physical settlement and implementation of acquire hooks remain externally
supplied. Observable hook order is not proof of physical DMA/cache or every
speculative CPU load.

## Exact inspected inputs

SHA256 values:

| File | SHA256 |
|---|---|
| `/tmp/hp1020-udc-acquire-scenarios-20261003/scenarios.py` | `6a50b95a7e420831a3625e2e8ade2e7e5dc3795b81f5dc57e287a5f55c829b64` |
| `/tmp/hp1020-udc-acquire-oracles-20261003/PLAN.md` | `f35238a5e93cce4450e05f5bba23fc110b7c843676ee1a5bc2b5b82ecc0a47b8` |
| `/tmp/hp1020-udc-acquire-oracles-20261003/trace-oracles.py` | `06160580c3ecce51f36731be7c3a0ca7097769ee8b2543f1ad715e6d5bddea25` |
| `/tmp/hp1020-acquisition-integration-20261003/host.py` | `c2374e9af2cf501a42a040e51ca46205606dd12466c9718eae472639b882ee8f` |
| `/tmp/hp1020-acquisition-integration-20261003/header.py` | `24dd9b14fa9670879f960709b8dda7f56af92c3b613dfbf84fff1824dbb0d052` |
| `/tmp/hp1020-udc-acquire-fixture-draft-20261003/changes.patch` | `5dd19ee515a4a070b035a6bdcd9a3eb7057a1896b96b50beae518a509f3b082f` |
| fixture package `draft/open-firmware/udc-acquire-test/fixture.c` | `deb151a70fe6b895fe70063c6043c683eec10d02d034da2ea09d205a931ceb9f` |
| fixture package `draft/open-firmware/udc-acquire-test/README.md` | `a80028559034d8502a86e43e698dfdf6e2bbe21bb625612cecab3a402e3cb7b2` |
| V2 public `hp1020_udc_acquire.h` | `e073d84e4f0223e07997a3cce5125a420591317681f80c7b80a5b2adc0bfc653` |
| repo `scripts/validate-hp1020-udc-publish.py` | `1ce1c22a3dd75a0e14e5a38f4e065db5820bb6e712126a587c217aecc828c486` |
| repo `scripts/validate-hp1020-udc-program.py` | `15f76489dc4602c7a18caf42b3e9e9149ab941a29c08187e6cc0808651043c7a` |
| repo `scripts/validate-hp1020-udc-offload.py` | `a40d918122e8052c37b7c8aadfc7a861a843b4354a3f486c094fd1b3283bacdb` |
| repo `scripts/validate-hp1020-udc-composed.py` | `620cf6c352096085a9d7d8c5808257444ec4db946520beaf0a56df3402ebfe7a` |
| repo `scripts/validate-hp1020-tinyusb-printer.py` | `1b7030af58f3a855fa5f58e8996eaf354a6f0a0007db60e474c321f124e92afa` |
| repo `scripts/validate-hp1020-continuous-printer.py` | `3e9a27fac60c29b423ae458a7e2116b668e03355af3ffd07021689c2e457e1ed` |
| repo `open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.c` | `a5bb1d281dd7226f9346e0dce3b13a475ac25320cf6b276f39d539d78584c3d7` |
| repo historical `open-firmware/udc-out/hp1020_udc_out.c` | `1a7f1f1a4b422b3630291210f45c1824396b99c809ebbf2c55b36eec51996a1d` |

Repo is `/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos`.
The scenario package preserves the inherited helper snapshots, inspected lead
Host/header and fixture/API snapshots in its baseline manifest. Frozen candidate
implementation sources remain in the separate V1/V2 packages; this review did
not alter those or the scenario package.
