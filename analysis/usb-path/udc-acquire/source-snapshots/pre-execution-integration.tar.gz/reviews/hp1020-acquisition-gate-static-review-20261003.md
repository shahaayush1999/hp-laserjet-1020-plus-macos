# Acquisition gate static review — 2026-10-03

Status: read-only static review of the frozen, unexecuted V1 checker. One concrete
pre-execution mismatch and two bounded evidence-strengthening changes are below.
V1 was not modified. The gate author owns a separate V2; this note does not supply
a competing edited checker. No script was parsed, imported or executed; no build,
validator, QEMU, repository mutation or hardware operation was performed. The new
acquisition C implementation was not read.

## Frozen inputs

| Input | SHA256 |
|---|---|
| `/tmp/hp1020-acquisition-gate-draft-20261003/check-hp1020-udc-acquire.py` | `a057fd10ce31f830f76af61abd35fde2fce2702f82e3373647c301be0c7c17a1` |
| `/tmp/hp1020-udc-acquire-oracles-20261003/PLAN.md` | `f35238a5e93cce4450e05f5bba23fc110b7c843676ee1a5bc2b5b82ecc0a47b8` |
| `/tmp/hp1020-udc-acquire-oracles-20261003/trace-oracles.py` | `06160580c3ecce51f36731be7c3a0ca7097769ee8b2543f1ad715e6d5bddea25` |
| `/tmp/hp1020-udc-acquire-fixture-draft-20261003/draft/open-firmware/udc-acquire-test/fixture.c` | `deb151a70fe6b895fe70063c6043c683eec10d02d034da2ea09d205a931ceb9f` |
| `/tmp/hp1020-udc-acquire-fixture-draft-20261003/draft/open-firmware/udc-acquire-test/README.md` | `a80028559034d8502a86e43e698dfdf6e2bbe21bb625612cecab3a402e3cb7b2` |
| `/tmp/hp1020-udc-acquire-draft-20261003/draft/open-firmware/udc-out/hp1020_udc_acquire.h` | `f2baab1c349d99c00005f3a761222f1bd80d9e355b35abaf5eb1fa83eedea3d6` |
| `/tmp/hp1020-acquisition-integration-20261003/header.py` | `24dd9b14fa9670879f960709b8dda7f56af92c3b613dfbf84fff1824dbb0d052` |
| `/tmp/hp1020-acquisition-integration-20261003/host.py` | `c2374e9af2cf501a42a040e51ca46205606dd12466c9718eae472639b882ee8f` |
| `/tmp/hp1020-acquisition-integration-20261003/main.py` | `f59ed46cbe26fee1248f1860635bafed092f0a460093d64005201915c5dd0bef` |
| `/tmp/hp1020-udc-acquire-scenarios-20261003/scenarios.py` | `6a50b95a7e420831a3625e2e8ade2e7e5dc3795b81f5dc57e287a5f55c829b64` |

The scenario source was consulted narrowly to confirm the held-request schedule,
not used as the authority for pixels, document bytes, visibility or descriptor
expectations. The independent plan and public header remain the contract.

## 1. Required correction: missing-fact raw dispatch is an intended WAIT

Gate lines 1006–1008 currently require every op82 to supply `b == 0x010101`,
return OK, set `s[6]` to the original ingress sequence and increment the adapter
control epoch. This excludes the intended first dispatch of the
`held-setup-settlement` profile. PLAN.md lines 183–189 prescribe a captured raw
GET_CONFIGURATION with unknown facts and blocked forward progress. Frozen
scenarios.py lines 248–259 deliberately call `dispatch(held, facts=0, result=WAIT)`
before acquisition, then retry the SAME capture with supplied facts after the
original bulk completion is PENDING. This is a static oracle mismatch, not an
observed production failure.

V2 should admit precisely the two planned op82 forms for the retained original
raw request: `(original_sequence, 0, 1, 0)` must WAIT without control admission;
`(same_original_sequence, 0x010101, 1, 0)` must later admit once. Both have no
payload. For the missing-fact call, require the captured pending kind/sequence,
immutable raw record, previous last-admitted identity and adapter epochs to stay
unchanged, progress to remain zero, and original owners/accounting/diagnostics to
remain retained. A supplied stalls-cleared fact is fixture input and must not be
confused with successful admission; this profile already has clear stalls. On
the later canonical retry, retain the existing exact `s[6] == sequence` and
one-control-epoch increment checks. Track exactly one missing-fact refusal and
one successful same-sequence retry in this profile, so simply deleting the
negative call cannot preserve its advertised coverage.

## 2. Strengthen accepted acquisition's pre-service recovery invariant

Gate lines 919–922 assert unchanged issued/consumed/count, READY slots, pixel,
wire and document witnesses after successful op142, but omit the remainder of
the document/reset state while saying the call cannot grant reset. A mutation
of reset ticket/activity/parts/quiescence could escape this local assertion and
be overwritten by later service/recovery. Replace the narrower
`r[33:36] == pr[33:36]` with `r[32:48] == pr[32:48]`, retaining every other
assertion. This follows the public API: successful acquisition only retires OUT
transport into adapter PENDING. The already-reviewed Host contains exactly this
stronger invariant. It remains valid when an old original packet settles after
a newer admitted reset or while publication failure blocks forward work.

This is an independent gate omission, not a demonstrated implementation defect
or a reason to relax any fixture invariant.

## 3. Hash the saved effective source bytes in raw-capture mode

`source_contract()` lines 431–445 reconstructs the expected 19 effective TinyUSB
hashes from original-source hashes plus the pinned patch manifest. It compares
that map with report metadata, and the end of the gate compares target
`effective-source.json` metadata. It does not currently hash files in the actual
saved `capture_root/effective-source/` directory. Missing or changed materialized
source bytes can therefore evade this raw-archive check while their manifest
still matches.

When capture_root is supplied, apply `sealed_file` to each reconstructed
effective path/hash under `capture/effective-source`, require its
`effective-source.json` to equal the report's effective source object, and
preferably require the directory's file set to be exactly those 19 paths plus
that one manifest. Root main lines 28–29 already preserve and compile this
directory. Do not require a nonexistent effective-source directory inside the
target-artifact folder; that folder contains the target's manifest and immutable
build outputs. Report-only mode may remain explicitly metadata-bound.

## Bounded positive assessment

No other concrete ABI or semantic mismatch was found in this static pass. The
checker uses the 576-word row split and excludes only global 59/425/490/555,
then binds their target values to measured footprints. It retains all twelve
host/target captures, including exact 144-byte synthetic device images, and
reconstructs complete descriptor/receive/EP0/recording storage with untouched
tails from input bytes and literal hook effects. The ordered descriptor16,
payload64, acquire-order traces, NOT_PERFORMED versus chosen UNKNOWN half-copy,
fault-only no-hook retries, original stale-cookie identity and first-failure
retention are derived independently of production failure output.

The small 352-byte document is reconstructed from literal sample chunk/item
bytes and the fixed 26-byte JBIG input. Read-only byte inspection of the saved
sample and JBIG agrees with these literals and the width32/height8 substitutions.
Expected output is independently 32 FF bytes and one five-word BE document
notification using the final original generation. Ordinary EP0 traffic is
confined to the held-request profile: IN byte01 then separate OUT0 status ZLP;
automatic CSR permission remains distinct from wire bytes and ACK callbacks.

The fixed 32-case matrix covers all four slots and the named failure/refusal
paths without importing a decoder, candidate implementation or producer oracle.
Existing source/audit/target capture checks do not establish physical DMA,
cache coherence, ordering, controller settlement or printing. Runtime schema
agreement and actual host/target results remain unobserved until root executes
the reviewed successor.
