# Independent entry workload/build review

2026-10-03, `/root/adapter_review`. Read-only review of the workload author's
frozen C/header and root's unexecuted builder, against the actual receive,
document, output and ring APIs. I did not author the workload. I did author the
separate startup/linker draft, so this is not an independent review of startup.
No source was changed, parsed/imported as code, compiled, built or executed.
No validator, QEMU, hardware operation or repository mutation was performed.

## Result

No actionable workload-C defect found in this bounded single-document profile.
The one concrete builder integration change is already known: line28 names
`$SOURCE/workload.c`, while the frozen implementation is
`hp1020_entry_workload.c`. Update that filename before the first build; no API or
source change is implied. The exact old builder is preserved with this review.

The C PASS word is deliberately not an independent pixel oracle. It copies the
actual output but does not compare it against hardcoded FF bytes. Root must
assert the literal32-byte all-FF result, its presence before the real finish
entry, the original document tuple and all guards from external observations.
That is a remaining execution obligation, not a defect in the producer.

## Confirmed source contracts

- **Pre-initializer authority:** C184–192 scans all13496 state bytes,1024 mailbox
  bytes and114704 memory bytes through volatile character lvalues, then all256
  sentinel bytes. It accesses representations rather than reading uninitialized
  pointer fields. The maximum bad-byte count is129224, within32 bits. Only local
  counters/addresses and the already owned stack change during these scans.
  The empty compiler memory barrier precedes the first mailbox write. C193–211
  then records results; failure returns without an initializer or production
  field dereference. Only mailbox words0..13/61 are written on that path. The
  comment at C44 says "until ... pass" too broadly: failure diagnostics are
  intentionally written after all scans **finish**, even if they fail. The
  header/README correctly describe that behavior; this is not a lifecycle issue.
- **Sentinel and sections:** C14–22 define exactly the four agreed writable
  objects. Their16-byte section alignment and C24–33 static assertions retain
  all production capacities and32-bit ABI. The16-byte sentinel row agrees with
  `(0x31 + 0x21*(i&15)) & 255`; its16 repeats fill exactly256 bytes. The workload
  never writes that data object. Static functions have no mutable static locals;
  the generated input is a static const array in text/rodata. Actual linked
  section flags and sizes remain mandatory first-build checks.
- **One original receive identity:** C224–256 requires six reservations for the
  accepted352-byte profile. Each capacity is64, with lengths64,64,64,64,64,32.
  It checks G1/ticket sequence1..6 and the actual slot pointer before copying.
  It then completes that same by-value ticket and pumps before the next
  reservation. The source offset/length stay within the frozen input, and no
  copy exceeds its64-byte reservation or1024-byte actual slot. Count0 and
  consumed sequence are checked after each pump. No reinitialization, restart,
  release bypass, generation relabel or quiescence acknowledgement occurs.
- **Legal synchronous output:** C75–125 receives the actual plan/ring/context,
  uses ring_peek/accept/complete, and never directly mutates ring state. It
  bounds index, row count, stride, slot size and witness length before computing
  or using the source range. Short-circuit checks bound index<4 and
  slot_bytes<=8192 before their product. The bytes are copied from the original
  accepted view while still owned, then software completion frees that same
  index. The mailbox copy is not generated from the expected black pattern.
  It neither reenters document parsing nor touches output hardware. A non-OK
  callback preserves the ordinary production error/ownership semantics.
- **Original notification:** C128–148 copies the callback event fields by
  value, then checks G1/feed generation and tuple(1,1,0,1). A second callback
  fails before overwriting the first event. The production document_out gate
  independently requires active feeding and the matching receive generation;
  this workload does not create or restamp an event. Returning OK lets the
  production output increment documents_completed in its normal place.
- **Finish timing:** Both callbacks reject once FINISH_CALLS becomes nonzero.
  C258–269 requires one already-observed document and32 copied pixels after all
  six pumps, then closes its finite local sender and invokes exactly one finish.
  A short final packet is not treated as EOF. Final checks require stopped1,
  finished1, count0, issued=consumed6, G1, no errors and quiescent0. No physical
  receive/output promise is synthesized. Root's observer should break at the
  actual `hp1020_usb_document_finish` entry to inspect the preceding event and
 32 pixel bytes independently.
- **Bounded output/result:** Final state requires one output callback, accept
  and complete, eight rows, stride4 and final1. C151–181 snapshots production
  counters and hashes the complete4096-byte receive area and32768-byte output
  slots. The736 reserved mailbox bytes are untouched after successful startup
  clearing. The final sentinel is checked again before PASS. Ordinary C return
  is the only exit; there is no longjmp, inherited callback or external return
  target. The separate startup's CALL0/park must still be audited on actual bytes.

## Builder and remaining execution obligations

The inspected builder retains the existing BE/call0 compiler-profile check,
freestanding/fno-builtin/fno-common/function-section/data-section flags, full
production dependency list, preserved Xtensa annotations, linked libgcc and
undefined-symbol check. The generated header contains only a bounded static
const byte array; generation validates JZJZ and length, not the complete intended
input. Root's exact fixture/hash oracle must therefore precede compilation.

The builder is intended for `scripts/` after integration: its ROOT_DIR is based
on that location, not its current `/tmp` draft directory. It does not generate
or upload `.img`/`.dl`, alter firmware machine-id bytes or inspect a device.
Its last message correctly says that linked footprint/instruction auditing and
execution remain outstanding. The compiler-profile check alone does not prove
the newly assembled entry; preserve the separate encoding/property/layout gate
before running it. This review ran none of those commands.

The expected32 FF pixels and event must be checked from independent external
data, including before finish. Also inspect the pre-C checkpoint before any C
scan/initializer, changed stack bytes/high-water, initialized data and immutable
gaps. This review does not establish emitted volatile loads, final instruction
selection, linker acceptance, runtime stack depth, physical boot or printing.

## Exact inspected input copies

Copies are preserved in `/tmp/hp1020-entry-workload-review-inputs-20261003/`.
The twelve-file `SOURCES.sha256` manifest hash is
`f80dd8f5aa06109fd053f7ffb1dbafc6f230e8ddeb31bc09c27d79a5bb661e55`.

| Input | SHA256 |
|---|---|
| Frozen workload C | `6b84d6a1168630402483d0c5dd397a0d2b8335fa502d2e01ef7049f66dd62090` |
| Frozen workload header | `8602f2588f768c694fdbace5923ab785149eba4f25bb2c8f9414ed47b6773287` |
| Workload README | `eeaab04504a87a175b8f7fc6f069e7603776d26d9247ae3241611898ba02f113` |
| Inspected builder, before filename change | `b1c356939a2af66c3fee26d1f787ed940cf2b65fd0f2caf82ab789ac9467032e` |
| Receive implementation | `352413d1c3d5cd8dbe1aa1788ab27383d1c45bfc344842d3b9b08c7e64827a8e` |
| Receive header | `20853cc8f4504b216d9bb0c1732da5b79c97b05796e7ea4b2a17ecc296389367` |
| Document implementation | `6df4c51a364b78a1d8e3bc9c81ce41f4daacddf383d13238e5f5407616575885` |
| Document header | `a6a966892400f431293f5ac94b487426f2211fdb3ea65df306f10ce96f88e8b7` |
| Output implementation | `ed469978829f1cc35b10062912db2fd88d030fb112b9ca35596bf115211c9728` |
| Output header | `3aa55aa287a8315da4e2575f3fc754848be66a45d0d44c76fb373e4bebaf7d8a` |
| Ring implementation | `9ee8f5955e8d6f30a3b12778553477835dc245eb3d928f6e81b467f8562d4e2b` |
| Ring header | `b5c1ba9add6710330eaae94ae1f6496b9d51fb46c1de09cdc98b73ec6f9b5a33` |
