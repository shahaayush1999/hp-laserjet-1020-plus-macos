# Frozen independent entry acceptance inputs

This directory preserves inputs used by `/root/usb_reference_contract` for
`/tmp/hp1020-entry-independent-plan-20261003.md` and its pure literal helper
`/tmp/hp1020-entry-literal-oracle-20261003.py`. Both were frozen before the
reviewer read any candidate startup assembly, linker script, workload C or
runner. Neither Python syntax parsing/import nor any build/test/target execution
was performed by this reviewer. Static hash/read/copy operations only.

The public workload header was allowed and defines the mailbox/scheduling ABI.
Its initial draft hash fb0320f1... was replaced before plan freeze by the author's
8602f258... header, which adds the agreed word7/55/57/58 semantics and six-fragment
schedule without changing the ABI. The final copy is preserved here.

`usb-receive-core/` and `image-core/` files are unchanged existing production
API/implementation contracts from corresponding `open-firmware/` directories,
not the forthcoming candidate workload. The fixture comes from
`analysis/open-firmware-model/image-core/fixtures/32x8-stripe4-black.jbg`.
Existing implementation was used only for public memory/ownership consequences:
release retains RX bytes, one final output view at this geometry, explicit
finish fences admission without granting quiescence, and original-generation
document notification occurs during input pumping. No decoder internals were
reimplemented as an independent byte oracle.

The copied CPU/layout/lead reviews provide byte and envelope evidence. The
`qemu-primary/` directory is the lead's exact official QEMU11.1.1 source closure
and URL/hash provenance, independently read and hash-matched here. It identifies
the selected emulator's register map and PC-relative literal configuration, not
the physical HP CPU's entire feature set. Runtime initial register read-back
remains required before the first candidate launch.

The literal helper implements only semantic/register/full-memory subset checks.
Its final comment explicitly leaves source/load seals, initial input equality,
continuous execution, forbidden access/call audit, actual park, complete initial
physical register read-back, measured target member offsets and stack evidence
to the independently reviewed runner. A caller must compare actual input bytes
to `small_input()`, not just its FNV. The plan's corruption controls are proposed,
not executed. Passing this helper alone is not the whole acceptance contract.
