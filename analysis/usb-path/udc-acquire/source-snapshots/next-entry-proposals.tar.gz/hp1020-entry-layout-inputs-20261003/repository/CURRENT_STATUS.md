# Current handoff

Updated: 2026-10-03. **The open firmware replacement cannot print yet.** Resumed
at the owner's request; continue autonomously until asked to yield. No USB
contact/enumeration, upload, print-driving hardware or installed-printing changes.
AGENTS.md owns scope; `analysis/README.md` is the evidence/tool-recovery map.

## Current work and validation

The first retained-OUT acquisition experiment passed **32 sanitized host/32 audited
QEMU cases**,3372 paired event rows and384 paired raw captures. Its independently
frozen V2 gate passed unchanged in report-only and raw-capture modes. No production,
fixture, scenario or checker correction followed execution. Full sequential
`scripts/validate.sh` is running: `/tmp/hp1020-full-acquisition-20261003.log`, child
`hp1020-validation.0uAKzc`. Do not label this integration fully validated yet.

The previous completed full checkpoint passed130 consistency checks and both
suites and was committed/pushed as `968d0f1`. Publication40/40 and its ten copied-
evidence corruption controls are separately preserved. Current acquisition edits
refactor the shared OUT observer and add optional fixture seams; the full suite
must confirm earlier behavior before the next commit.

Acquisition now checks the original retained cookie AND actual adapter DCD owner,
performs mandatory descriptor16/payload64/acquire-order hooks, then copies actual
CPU descriptor bytes into the existing observer. Separate synthetic device images
and poisoned CPU storage reveal wrong sources or partial visibility. Failures
retain their original identity and do not retry cache work. Old settlement remains
available while forward work is blocked; cleanup/recovery stay separate. No physical
cache/register binding exists. Target acquisition152 bytes, OUT80, publisher140,
backend88, adapter/document128588, EP0296, SETUP96.

First captures: `/tmp/hp1020-udc-acquire-y7t6kkii`; log
`/tmp/hp1020-acquisition-first-20261003.log`. The exact152-source/six-fixture closure,
target and raw captures are sealed in `analysis/usb-path/udc-acquire/source-snapshots/`
under `first-paired-32-cases.*`. `pre-execution-integration.*` preserves scenarios,
runner, reviews and gateV1/V2. Its three static corrections predate execution;
the independent literal oracle is unchanged. The earlier publication archive's
`next-acquisition-proposals.*` remains an unexecuted historical draft snapshot.

## Next action

Finish full sequential regression validation, run the separately drafted copied-
evidence corruption controls, preserve raw results/comparisons and update the
existing handoff before committing/pushing a coherent acquisition checkpoint.
Root owns all execution; agents perform static review/drafting only. Tested sources
stay frozen. Preserve unexpected evidence before correction; never edit report
hashes manually. Acquisition full-suite baseline reports are under
`/tmp/hp1020-acquisition-baseline-20261003/`.

Then pursue the selected loader-entry-to-C experiment: establish our own
ABI/stack/BSS and execute one existing RAM document workload continuously.
Current component tests supply CPU/stack state separately at each call. Static
entry-byte and memory-layout reviews are in progress under `/tmp`; the next-step
proposal is `/tmp/hp1020-next-after-acquisition-review-20261003.md`. No startup
candidate exists yet. Audit exact stock entry/CPU bytes, candidate RAM envelope
and required footprint before implementation. Do not introduce USB/MMIO/cache/TLB/
engine operations or replace a hardware-test .dl. Actual ROM entry and HP memory
attributes remain supplied/unproved.

Pinned binutils/GCC were recovered with unchanged gates; headers/libgcc/ar/ranlib
can disappear independently of binaries. Use only recovery scripts in the map.
Boot, IRQ producers, real cache/mapping/settlement, engine behavior, physical status/
printing and power-cycle recovery remain unproved. Keep separate:26 empty-document
lifecycles, six conditional original null reads,28 retirement cases,36 native page
lifecycles with supplied completion and42 fragment/bypass cases. Component tests
add zero native/physical lifecycles. Do not repeat resolved cancellation/END_DOC or
original IRQ/SETUP investigations.

## Installed Mac driver (separate, preserve)

The authorized HP-based native driver uses Apple's renderer, unchanged foo2zjs
and a per-job CUPS backend. CUPS owns copies, queueing and job lifetime. README
owns clone/install/uninstall; MANIFEST owns validation/recovery. No app/package,
ZIP or Homebrew runtime is required. Do not restore the obsolete daemon/runtime.

Support checks passed35 printing,14 setup, three sandbox and five actual macOS
scheduler cases with simulated transport. Installed signatures/ownership/bytes
matched the build and the queue was empty/idle; actual copies, status/recovery
and fresh-Mac installation remain unverified. Evidence:
`assets/macos-system-validation.json`, `/private/tmp/hp1020-system-install-20260928-2/`.
Root-only migration backup: `/private/tmp/hp1020-native-migration-backup-20260928/`.
System checks require separate authorization; no physical print occurred here.
