# Next after acquisition: owned loader-entry-to-C startup

2026-10-03. Static recommendation only. No source import, candidate execution,
build, test, validator, stock/QEMU execution, repository edit, download or device
contact. Acquisition is being integrated by the lead; its result is not assumed
here. Repository root is
`/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos`.

## Recommendation

Make the next bounded experiment **one entry into our own inert startup, followed
by a continuous run of existing production C in its declared firmware RAM
layout**. It should establish its own compiler ABI state, stack and BSS, process
one already verified small document entirely in RAM, write a diagnostic mailbox
and park. Do not add a physical DCD, USB register operation, IRQ handler, cache/TLB
operation, upload or print path to this experiment.

Call it loader-entry-to-C, not a proved cold boot. Code already loaded into
accessible RAM and privilege sufficient for the reviewed CPU-state instructions
remain explicit input conditions. The experiment removes a concrete software
startup prerequisite while keeping ROM loading, actual HP memory attributes and
physical execution unresolved.

## The concrete gap

Current `open-firmware/udc-publish-test/target-check.ld` explicitly says synthetic
RAM, links at0x20000000 and selects `hp1020_bulk_fixture_reset` as its entry. Its
validator calls `QemuRAM.call0()` independently for reset and every event.
`scripts/hp1020_qemu_ram.py:171–190` supplies WINDOWBASE0, WINDOWSTART1, PS0,
clears physical registers/loops/SAR, supplies a return address and STACK_TOP,
then jumps directly to each C function. `load()` also zeroes every PT_LOAD
memory tail. The acquisition target inherits this useful component harness.
Those results establish neither startup instructions nor their memory layout.

The HP-shaped `open-firmware/minimal-idle/idle.S` goes from `_start` straight to
an assembly loop. It has no stack/BSS/C runtime. The older USB bulk/parser draft
raises interrupt level at entry and jumps to an assembly polling implementation;
it is not an entry for the independently compiled C components. Building more
packet hooks would leave that exact gap intact.

The current compiler is deliberately BE/call0, with hardware loops, windowed
calls, thread pointer, atomic/release extensions and hardware division disabled.
That makes a small independent startup practical; reproducing HP's ThreadX boot
or scheduler is unnecessary. Important stock-byte counterparts already pinned by
the compiler gate are CALL0 at100187b1=`500a5d`, RET.N at1001b1fa=`d00f`, MULL at
10013f8e=`098828`, NSAU at1001b670=`056f04`, ADDX4 at10013f75=`07a80a`, and MEMW at
10008211=`0c0200`. They prove instruction compatibility, not initial CPU state.

## One useful experiment

1. **Review the tiny entry contract first.** Independently recover the exact
   original entry bytes at100167a8 and the necessary standard CPU-state writes
   in10006cd0 before choosing the replacement sequence. Existing startup notes
   locate the entry pointer10006a14→10006cd0 but explicitly admit truncated
   decompilation. Do not transcribe its ambiguous special-register pseudocode.
   Identify which state the conservative call0 ABI actually needs, including
   interrupt exclusion, window/PS state, loop state and stack alignment. Reject
   unknown opcodes and stop the stock inspection before unrelated CPU/TLB,
   controller, wrapper, RTOS or engine initialization. This is a prerequisite
   byte audit, not another execution of HP's runtime.
2. **Implement one small reusable entry and layout.** Reuse the verified
   HP-shaped ELF anchors/entry from the idle skeleton, with explicit linker
   assertions for every text/literal/data/BSS/stack/mailbox span and anchor gap.
   Place existing production C and its real memory object separately where
   necessary; do not import the large synthetic fixture, its history/trace
   arrays or0x20000000 arena. Measure the actual footprint and stack bound before
   choosing addresses. Stay inside a byte-derived stock-owned candidate RAM
   envelope for this experiment; failure to fit is a result requiring a memory
   decision, not permission to guess a larger HP RAM region. Preserve loaded
   `.data`, clear only owned BSS, establish the stack before any C call and park
   on an unexpected vector. No opaque boot-ROM callback is required.
3. **Enter once; do not seed the ABI again.** Reuse QEMU only as a CPU executor.
   Load file-backed segments, deliberately poison BSS/stack in selected controls,
   supply explicit hostile-but-supported initial register/window/loop states and
   start at the ELF entry. Do not call `reset_cpu()` or `call0()` after entry,
   patch registers between phases, zero BSS from the runner or skip to a C
   symbol. Supply no pending external interrupt; handling real interrupts is a
   later board-port boundary. One initial entry is followed by one continuous
   execution until the reviewed RAM mailbox/park boundary.
4. **Use a known workload as the C reachability oracle.** Reuse the existing
   receive/document/image implementation and the pinned32×8 black input, with a
   synchronous RAM output consumer. Its supplied input and software output
   completion must be labeled as such; no USB descriptor/event is fabricated.
   Check literal32FF pixels, exactly one document boundary, unchanged input and
   initialized-data bytes, owned-range guards, bounded stack high-water, and
   persistent C state across multiple calls/chunks. This is not another parser
   policy matrix. A minimal clean-entry control plus dirty-BSS/stack and distinct
   supported incoming CPU states is enough to challenge startup.

Before execution, audit the final linked instructions and resolved control flow,
preserve original/replacement bytes and all exact source/tool identities, and
enforce pre-access traps outside the declared RAM and permitted CPU-state
operations. No MMIO, TLB/cache operation, IRQ enabling, inherited system-interface
call or mechanical instruction is in this executable closure. A fresh target
boot test should not automatically produce or replace a `.dl` used by a hardware
harness. Package integration can remain a separate offline decision.

The useful pass criterion is narrow: **the reviewed replacement entry, rather
than the Python fixture, establishes the conditions needed by actual C, and the
same loaded program stays correct until its own stop**. A failure can identify
an ABI, literal-placement, BSS, stack or memory-footprint problem now, before a
controller port makes it hard to distinguish from USB/DMA failures. The entry
and linker layout are production assets reusable by the eventual inert DCD.

## Why this before another hook layer

| Candidate | What a next offline slice could establish | Why not select it first |
|---|---|---|
| More EP0 publication/acquisition hooks | Exact staging/cache/register call order and retained owner behavior | Valuable later, but repeats much of the just-built synchronous boundary while leaving all code dependent on a supplied C entry. IN DMA-to-FIFO completion still cannot be promoted into host ACK. |
| SETUP acquisition/rearm hooks | Explicit actual-copy/order and gated global-RX command intent | Necessary eventually, but stable acquisition, original event identity and exclusion of hardware overwrite still require a justified controller source. Another boolean/hook layer cannot establish those facts. |
| Cache/DMA physical binding | Potentially remove mapping and maintenance promises | Existing bytes do not yet identify a universal alias map or physical cache/interconnect semantics. Executing QEMU cache no-ops or recording DHWB/DHWBI calls cannot prove them. |
| Controller readiness/initialization | Reviewed mode/table/FIFO/receive-enable command construction | Boot/inherited CSR_PRG and HP dynamic-mode support remain unknown; the existing program/publisher already demonstrate command intent without claiming reset/defaults. Avoid a new collection of supplied-ready booleans. |
| IRQ/reset provenance | A practical event producer under stated observations | Original sampling, conditional selection, SETUP ingress and retirement cuts are complete. Repeating them cannot recover physical chronology or tag overwritten records. |

The cache evidence supports this choice rather than making startup impossible.
Stock helpers100173c8/10017414 visibly use16-byte DHWB/DHWBI stepping and DSYNC;
the root byte-check preserves their exact30-byte encodings. Boot literals
10005cd0=`22222222`,10005c9c=`ff222244`,10005ca0=`e0000000` and the DII loop at
10006dd6 show CPU-memory setup exists. They do not justify toggling80000000 as a
CPU/DMA translation or calling the synthetic core's configuration the HP core.
The proposed CPU-only run does not need to settle DMA visibility: it leaves
inherited mapping/cache attributes untouched and never hands memory to a device.
Physical alias/cache recovery can remain a separately named board task.

## Authority and limits

Offline drafting, builds and guarded RAM execution are within the owner's scope;
this note performs only static research. The lead still owns sequencing and
must freeze/preserve the acquisition checkpoint before the next experiment.
There is no authority to contact/enumerate the printer, upload, read descriptors
or alter the installed setup. A later live inert-entry/marker test needs the
owner's specific fresh-power-cycle authorization and the guarded ladder.

Passing this experiment would not establish that the ROM enters our ELF, that
the loader supplies the assumed RAM/privilege state, that the HP cache or DMA
mapping is known, that USB enumerates, or that the printer can print. The older
quiet idle upload and unchanged HP identity are not entry proof; current handoff
also records the old instruction-encoding defect. No completion percentage or
physical-lifecycle count follows from this proposal.

## Exact main inputs

SHA256; repository-relative unless marked `/tmp`:

```text
CURRENT_STATUS.md a9da6068ccec256bcb032f4792f25e4fce5cddffa9e7e0bf0c11dd6ca62d41e7
analysis/README.md b4a7804b6136158da95fe74298765b1e2e6c710aedade33fdeebdcd3928594a4
analysis/open-firmware-model/next-evidence.md 59dfe838126f32d1c892501510bec3a15410cef03bca1d44104e12e40c9d692b
analysis/startup-chain-report.md a575f5bbc1d5e9bae80dc756acc926de843b29050a9c31a35821f4c39cc02df7
analysis/boot-handoff/boot-handoff.md dbe02fff65dc6707260ed1ef525f18e493720311a6bab07374b2d5cefa8cf5f2
open-firmware/minimal-idle/idle.S 99c76eb2e4a0b11939b372f3b6d88e5c2059f0234afc4431c25a52c419f9ed4b
open-firmware/minimal-idle/hp1020-idle.ld c41373794e0316eafba1edb907083daef7d0bcf8d1f4809b8a15d9a378b12587
open-firmware/udc-publish-test/target-check.ld 2abbd11da052e76b4d5f8d7815b881d7b5b0f32657927bb340e4e768c04ff84e
scripts/hp1020_qemu_ram.py 8fe170ab6161d47d17ef93eb6c25622878e00dc2d4747cfd70073a0fd777b5e2
scripts/validate-hp1020-udc-publish.py 1ce1c22a3dd75a0e14e5a38f4e065db5820bb6e712126a587c217aecc828c486
scripts/check-hp1020-c-compiler-profile.py c9d5cce3591a402f1b3f0e4ad343fb1064747a4d9c256b4a61cea60eccdf8aa4
analysis/toolchain-probe/freestanding-c-compiler.md 44d8d1264c4ab916152f68a0ac0844cfa0688b06082b1586db2d9ea9bb991236
/tmp/hp1020-dma-visibility-contract-review-20261002.md 7b68c1a19c5b7a8c1ccc123fa060600f955330dc76a2890509f3c52a0a3cdc2c
/tmp/hp1020-next-dcd-boundary-review-20261002.md 39a4f942b986e74b48668c1e49449c5fa04312c6833e574c007b1d781ff60ee9
/tmp/hp1020-dma-visibility-root-byte-check-20261002.json 900a64c22b1d8137dde93e61f60684289bc4ab0873ff2c21e72974180dc3aa9f
```

Pinned stock ELF identity from the byte checks:
`2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`.
No new original instruction execution is claimed by this recommendation.
