"""Preserve reviewed, unexecuted entry proposals beside the acquisition checkpoint."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

TMP=Path('/tmp')
ROOT=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
names='''hp1020-next-after-acquisition-review-20261003.md
hp1020-entry-cpu-contract-review-20261003.md
hp1020-entry-cpu-contract-evidence-20261003
hp1020-entry-layout-review-20261003.md
hp1020-entry-layout-inputs-20261003
hp1020-entry-root-decisions-20261003.md
hp1020-entry-startup-draft-20261003
hp1020-entry-startup-independent-review-20261003.md
hp1020-entry-workload-draft-20261003
hp1020-entry-workload-independent-review-20261003.md
hp1020-entry-workload-review-inputs-20261003
hp1020-entry-independent-plan-20261003.md
hp1020-entry-literal-oracle-20261003.py
hp1020-entry-independent-inputs-20261003
hp1020-entry-qemu-registers-20261003
hp1020-entry-qemu-register-description-20261003.log
hp1020-entry-qemu-primary-20261003
hp1020-entry-integration-20261003
hp1020-entry-layout-witness-draft-20261003
hp1020-entry-machine-independent-review-20261003.md
hp1020-entry-machine-independent-review-inputs-20261003.sha256
hp1020-entry-audit-draft-20261003
hp1020-entry-audit-v2-20261003
hp1020-entry-qemu-adapter-draft-20261003
hp1020-entry-qemu-independent-review-20261003.md
hp1020-entry-qemu-independent-review-inputs-20261003.sha256
hp1020-entry-runner-independent-review-20261003.md'''.splitlines()
files={}
for name in names:
    p=TMP/name
    assert p.exists(),p
    if p.is_dir():
        files.update({str(f.relative_to(TMP)):f for f in p.rglob('*') if f.is_file()})
    else:files[name]=p
files['archive-proposals.py']=Path(__file__)
assert all(not p.is_symlink() for p in files.values())
raw={n:p.read_bytes() for n,p in sorted(files.items())}
raw['PROPOSAL-STATUS.md']=(
    'Unbuilt and unexecuted startup candidate proposals at the acquisition checkpoint. '
    'Includes frozen independent literals, original-byte/layout reviews, assembly/C, compiler-layout witness, '
    'root runner V1/V2, concrete interpreter, linked audit V1/V2 and QEMU adapter V1 with review. '
    'The separate stopped debugger XML-capability probe executed zero target instructions. '
    'Its exact QEMU primary-source register correction is preserved. '
    'A QEMU adapter cleanup/metadata correction and independent capture gate are still being drafted separately; '
    'this archive does not claim they exist or pass. Actual emitted ELF, call/frame audit and all startup execution remain pending.\n'
).encode()
for n,p in files.items():assert p.read_bytes()==raw[n],('source changed during proposal archive',n)
buf=io.BytesIO()
with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0) as gz:
    with tarfile.open(fileobj=gz,mode='w') as tf:
        for n,data in sorted(raw.items()):
            assert not Path(n).is_absolute() and '..' not in Path(n).parts
            info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0
            tf.addfile(info,io.BytesIO(data))
payload=buf.getvalue()
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tf:
    assert tf.getnames()==sorted(raw)
    for n,data in raw.items():assert tf.extractfile(n).read()==data
sha=lambda x:hashlib.sha256(x).hexdigest()
metadata=dict(status='unbuilt/unexecuted entry proposals; no candidate execution',
    archive_sha256=sha(payload),archive_bytes=len(payload),members=len(raw),
    member_sha256={n:sha(data) for n,data in sorted(raw.items())})
out=ROOT/'analysis/usb-path/udc-acquire/source-snapshots'
for suffix,data in (('.tar.gz',payload),('.json',(json.dumps(metadata,indent=2)+'\n').encode())):
    dest=out/('next-entry-proposals'+suffix);assert not dest.exists();dest.write_bytes(data)
print(json.dumps({k:v for k,v in metadata.items() if k!='member_sha256'},indent=2))
