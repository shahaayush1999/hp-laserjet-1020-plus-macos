# Current handoff

Updated: 2026-10-03. **The open firmware replacement cannot print yet.** Resumed
at the owner's request; continue autonomously until asked to yield. No USB
contact/enumeration, upload, print-driving hardware or installed-printing changes.
AGENTS.md owns scope; `analysis/README.md` is the evidence/tool-recovery map.

## Current work and validation

The first retained-OUT acquisition experiment passed **32 sanitized host/32 audited
QEMU cases**,3372 paired event rows and384 paired raw captures. Its independently
frozen V2 gate passed unchanged in report-only and raw-capture modes. No production,
fixture, scenario or acquisition-checker correction followed execution. First full
`scripts/validate.sh` completed every execution stage but stopped at three legacy
source-count gates among131checks: OUT97→98, composed117→118, offload126→127,
each solely adding `hp1020_udc_acquire.h`. All eleven component case arrays and
raw capture identities matched the pre-run baseline. No report hashes were edited.
The independent acquisition gate and all16 copied-evidence controls passed
unchanged. Full validation remains incomplete; the driver suite was not reached.

The previous completed full checkpoint passed130 consistency checks and both
suites and was committed/pushed as `968d0f1`. Publication40/40 and its ten copied-
evidence corruption controls are separately preserved. Current acquisition edits
refactor the shared OUT observer and add optional fixture seams; the full suite
must confirm earlier behavior before the next commit.

Acquisition now checks the original retained cookie AND actual adapter DCD owner,
performs mandatory descriptor16/payload64/acquire-order hooks, then copies actual
CPU descriptor bytes into the existing observer. Separate synthetic device images
and poisoned CPU storage reveal wrong sources or partial visibility. Failures
retain their original identity and do not retry cache work. Old settlement remains
available while forward work is blocked; cleanup/recovery stay separate. No physical
cache/register binding exists. Target acquisition152 bytes, OUT80, publisher140,
backend88, adapter/document128588, EP0296, SETUP96.

First captures: `/tmp/hp1020-udc-acquire-y7t6kkii`; log
`/tmp/hp1020-acquisition-first-20261003.log`. The exact152-source/six-fixture closure,
target and raw captures are sealed in `analysis/usb-path/udc-acquire/source-snapshots/`
under `first-paired-32-cases.*`. `pre-execution-integration.*` preserves scenarios,
runner, reviews and gateV1/V2. Its three static corrections predate execution;
the independent literal oracle is unchanged. The earlier publication archive's
`next-acquisition-proposals.*` remains an unexecuted historical draft snapshot.

## Next action

The three counts now include the added header, with explicit OUT/offload membership;
the unchanged composed union and all hash/oracle checks remain. Independent static
review confirmed the correction. Focused consistency passed131/0. Full sequential
retry is running: `/tmp/hp1020-full-acquisition-retry-20261003.log`, child
`hp1020-validation.glwQ3y`. Finish it, preserve results/comparisons and
update the existing handoff before committing/pushing the acquisition checkpoint.
The stopped full run is sealed under `first-full-consistency-stop.*`; the three
affected raw runs and all eleven baseline reports under
`legacy-count-consistency-stop.*`. The16 unchanged copied-evidence controls passed
and are sealed in `copied-evidence-controls.*`. Original log `/tmp/hp1020-full-acquisition-20261003.log`,
child `hp1020-validation.0uAKzc`; full acquisition capture `/tmp/hp1020-udc-acquire-2gdl6ewq`.
Root owns all execution; agents perform static review/drafting only. Tested sources
stay frozen. Preserve unexpected evidence before correction; never edit report
hashes manually. Acquisition full-suite baseline reports are under
`/tmp/hp1020-acquisition-baseline-20261003/`.

Then pursue the selected loader-entry-to-C experiment: establish our own
ABI/stack/BSS and execute one existing RAM document workload continuously.
Current component tests supply CPU/stack state separately at each call. Static
entry-byte and memory-layout reviews are complete and exact original bytes were
independently checked by root. Unbuilt/unexecuted assembly/linker and C workload
drafts are under `/tmp/hp1020-entry-{startup,workload}-draft-20261003/`; root decisions
are `/tmp/hp1020-entry-root-decisions-20261003.md`. The new layout preserves full
production capacities but deliberately reuses HP private runtime locations;
loader compatibility is unproved. Audit linked footprint/closure before execution.
Do not introduce USB/MMIO/cache/TLB/
engine operations or replace a hardware-test .dl. Actual ROM entry and HP memory
attributes remain supplied/unproved.

Pinned binutils/GCC were recovered with unchanged gates; headers/libgcc/ar/ranlib
can disappear independently of binaries. Use only recovery scripts in the map.
Boot, IRQ producers, real cache/mapping/settlement, engine behavior, physical status/
printing and power-cycle recovery remain unproved. Keep separate:26 empty-document
lifecycles, six conditional original null reads,28 retirement cases,36 native page
lifecycles with supplied completion and42 fragment/bypass cases. Component tests
add zero native/physical lifecycles. Do not repeat resolved cancellation/END_DOC or
original IRQ/SETUP investigations.

## Installed Mac driver (separate, preserve)

The authorized HP-based native driver uses Apple's renderer, unchanged foo2zjs
and a per-job CUPS backend. CUPS owns copies, queueing and job lifetime. README
owns clone/install/uninstall; MANIFEST owns validation/recovery. No app/package,
ZIP or Homebrew runtime is required. Do not restore the obsolete daemon/runtime.

Support checks passed35 printing,14 setup, three sandbox and five actual macOS
scheduler cases with simulated transport. Installed signatures/ownership/bytes
matched the build and the queue was empty/idle; actual copies, status/recovery
and fresh-Mac installation remain unverified. Evidence:
`assets/macos-system-validation.json`, `/private/tmp/hp1020-system-install-20260928-2/`.
Root-only migration backup: `/private/tmp/hp1020-native-migration-backup-20260928/`.
System checks require separate authorization; no physical print occurred here.
