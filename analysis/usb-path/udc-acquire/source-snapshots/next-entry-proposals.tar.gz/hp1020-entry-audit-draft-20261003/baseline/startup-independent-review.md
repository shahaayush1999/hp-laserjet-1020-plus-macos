# Independent startup/linker static review — 2026-10-03

Read-only review by `/root/printer_class_reuse`. No assembler, compiler, import,
script parsing, execution, validator, QEMU, hardware operation or repository edit
was performed. The source package remains unchanged. This review found no
concrete source-level blocker against the accepted CPU/layout contract; emitted
instructions, section flags, segment extents and stack behavior remain untested.

## Exact inputs

| Input | SHA256 |
|---|---|
|`/tmp/hp1020-entry-startup-draft-20261003/startup.S`|`c1184dd473f513189cfbbdee6e059a1ac429bbec962ada1c048dd0a433e4433f`|
|`/tmp/hp1020-entry-startup-draft-20261003/entry.ld`|`de92c21e52ec9c250d5ced551f31d4ead06b40fedd354d560d1b95377fb46bf0`|
|`/tmp/hp1020-entry-startup-draft-20261003/README.md`|`249fffbc53d705704461cad08203ccc9ff1d95e0afb07f561bd04c5dc758d839`|
|`/tmp/hp1020-entry-startup-draft-20261003/REVIEW.md`|`309767977cd20aa6b85027e4bb0616c04a1addf70cfaf7732adfa55e87dc3a24`|
|`/tmp/hp1020-entry-cpu-contract-review-20261003.md`|`52da0feb834455c18c5581c1058a4107b4619f24328ec78297b14a011c9c5054`|
|`/tmp/hp1020-entry-layout-review-20261003.md`|`9f5d2d4c52f9174aa0f4b878ee9bad84db8b24e7e2390d85ddfaf71d0c18f4ac`|
|`/tmp/hp1020-entry-workload-draft-20261003/hp1020_entry_workload.h`|`8602f2588f768c694fdbace5923ab785149eba4f25bb2c8f9414ed47b6773287`|

The independent CPU note pins the original ELF and instruction encodings. This
review does not repeat its extraction or execute original entry/runtime code.

## Entry and CPU state

The entry island places the first direct J after0x28 padding at100167a8, inside
the exact0x60-byte island10016780..100167e0. It has no ENTRY, stack access,
indirect inherited target or borrowed return address. Its target is the new
normalizer, not the stock CPU initializer or interface table.

The normalizer uses only a2 until deterministic PS15 clears the named window,
privilege and exception fields from the supplied admissible privileged state.
RSIL15 and INTENABLE0 precede loop-register clearing and the synchronized PS
change. WINDOWBASE0 is followed by RSYNC; a2 is then explicitly reloaded with1
for WINDOWSTART. The zero value in a4 and the owned a1 stack top are loaded only
after the window switch. No stale old-window value supplies a loop bound, zero
store or stack address. SSAI0 establishes the stated initial shift witness.

The stack top is10014000,16-aligned. No startup store or load uses the inherited
a1. CALL0 hp1020_entry_c establishes its own return address; the instruction
after the call is the terminal self-J park. There is no attempt to restore or
return through incoming a0, PS, windows or stack. The inline literal words
precede their L32R uses and are separately labelled; their actual placement,
encodings, relaxation and property classification remain part of the build audit.

The documented supplied conditions are necessary: accessible owned instruction
and data RAM, privilege, PC-relative literal mode, no asynchronous/debug events,
and no incoming hardware loop ending in the initial island/prefix before LCOUNT
is cleared. This is not recovery from arbitrary CPU state or cold boot. No
LITBASE, TLB/cache, controller, timer, engine, mechanical or interrupt-acknowledge
operation is introduced.

## Exact zero ranges and data preservation

Each loop has a fixed nonempty word-aligned half-open range. a4 remains0 through
all three; each loop stores before incrementing and stops exactly at its end:

| Range | Stores | Last store |
|---|---:|---|
|state1000e000..100114b8|3374|100114b4|
|mailbox10014040..10014440|256|1001443c|
|memory10016800..10032810|28676|1003280c|

The total is32306 word stores/129224 bytes. In particular, state is not rounded
up into its40-byte upper guard. The separate memory loop starts after the entry
island and lower buffer guard; no min/max BSS sweep crosses the island. The
initialized256-byte data sentinel, stack paint, every guard and every omitted
gap lie outside these ranges. Before C, a1 is unchanged, a2/a3 equal10032810
and a4 remains0.

The three exported observer checkpoints match the intended boundaries:
after_normalization is before any BSS store; before_c is after all clears and
immediately before CALL0; park is the actual C return. They permit observation
without repairing CPU registers or memory. The independent C scan and external
before_c observation serve different roles; both should remain in validation.

## Linker and inert islands

The script's exact object sizes/starts match the public workload header. Each
mutable main region has its own explicit PT_LOAD association; initialized data
is file-backed, state/mailbox/memory and the8KiB owned stack are separate NOLOAD
sections. Code and read-only input share the24KiB budget before the data guard.
The low stock private-pointer region is left unloaded/unused rather than being
called. Reuse of later HP private runtime/ACL addresses is deliberate and remains
an unproved real-loader compatibility decision.

Vector/interface ranges stay inside the selected original declared intervals.
Contiguous kernel/user fragments share one segment; the gaps between vectors,
double vector and interface table are not turned into free buffers. Window
vectors have six64-byte local parks; advertised kernel/user/double/reset/debug
starts park without stack or inherited registers. The75 interface words point
to the new unexpected park only. Padding is zero data, not evidence that an
arbitrary vector offset is executable. None of these sections implements an
interrupt/exception ABI, window spill/fill or a path into printing.

Assertions cover vector sizes, code budget, fixed entry/island extent, exact
four C object sizes and positions, stack bounds, zero-end word alignment,
owned-start16-byte alignment, checkpoint order, and placement of both normalizer
and C entry in text. Generic data/BSS/common and unrecognized sections are caught
by asserted-empty output sections. Explicitly discarded comments/notes/unwind
metadata are excluded from that generic claim; Xtensa instruction/literal
annotations are preserved at nonloadable addresses for the later audit.

## Required build observations, not source-level defects

An unexecuted linker script cannot establish actual SHF_ALLOC/SHF_WRITE flags or
PT_LOAD file/memory extents. Root must inspect all13 generated segments and
allocated sections, including the synthesized NOLOAD stack, and require no
segment's memory/zero-fill extent to sweep across a protected gap. PHDR FLAGS
and section flags are different witnesses. Metadata must remain nonallocated;
unexpected or allocatable orphan sections must fail the audit.

Likewise, inspect every assembled instruction/literal/property and unresolved
symbol before execution: exact special-register encodings, immediate direct
entry jump, reload after WB, three store loops, CALL0 target/return and inert
parks. The source contains no helper call before the owned stack is established,
but relaxation and compiler-produced C helpers need confirmation from the linked
closure. Measure code size and stack usage rather than treating24KiB/8KiB budgets
as proved sufficient. Verify stack paint/high-water and guards during one
continuous run with no host register reset between C calls.

These are the existing planned first-build/audit gates, not new physical
requirements or reasons to expand the scope. This static pass establishes no
instruction execution, physical memory/cache/loader behavior, USB operation or
printing.
