# Entry-to-C RAM layout and footprint review

2026-10-03. Static review by `/root/adapter_review`. No candidate or original
instruction was executed; no compiler, import, build, validator, QEMU, device,
repository mutation or `.dl` change was used. This note selects no final linker
layout and contains no startup implementation. The sibling CPU review owns
instruction decoding; this review owns footprint and possible allocation.

## Decision for the lead

The unchanged receive/document/image composition fits comfortably inside the
stock-declared main memory span if the replacement uses its own layout. Keep
the full contiguous `hp1020_usb_document_memory`; neither split it nor reduce
its capacities. A clean candidate puts code, state and an owned stack below
the original entry, and the contiguous memory object immediately after it.

This requires deliberately repurposing HP's later private runtime-state,
interrupt-table and ACL-descriptor locations. Existing evidence does not prove
these are a resident loader ABI. Preserve that uncertainty: the proposed layout
is suitable for a guarded offline entry experiment, not established loader
compatibility. The old idle skeleton retained those addresses conservatively;
retaining every one would make the unchanged contiguous production object
impossible to place in the known main span.

## Byte-derived envelope and anchor distinction

The pinned original ELF hash is
`2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`.
The independent CPU review verified its main RWE PT_LOAD: file offset `0x560`,
VMA `0x10003000`, file size `0x1a640`, memory size `0x321e0`.

| Item | Exact half-open interval | Bytes |
|---|---|---:|
| Main stock-declared span | `[0x10003000,0x100351e0)` | 205280 |
| Original file-backed part | `[0x10003000,0x1001d640)` | 108096 |
| Original BSS | `[0x1001d640,0x100351e0)` | 97184 |

Literal words at `0x10005ca8` and `0x10005cac` independently name the BSS
endpoints. This is a stock-used candidate envelope, not discovered total RAM,
physical aliasing, permissions, cacheability or exclusive ownership on hardware.
Accessible, exclusively owned RAM and inherited usable mappings remain supplied.

The ELF entry `0x100167a8` is a direct header fact. Keep it for the experiment,
with a new terminal call0 entry rather than executing the stock ENTRY/runtime.
No inspected resident loader establishes that this precise address is mandatory.

Separate stock PT_LOAD ranges cover only the vector/interface intervals
`[0x10000000,0x10000184)`, `[0x10000200,0x1000023c)`,
`[0x10000270,0x10000350)`, `[0x10000370,0x1000049c)` and reset/debug intervals
`[0x10100020,0x10100304)`, `[0x10100320,0x1010032c)`. Do not use their intervening
gaps as heap, stack or buffers. Preserve selected vector/interface sections as
immutable candidate bytes; their exact contents and unexpected-vector parking
belong to the CPU/entry design. The experiment excludes asynchronous exceptions.

`analysis/boot-handoff/boot-handoff.md` explicitly leaves resident expectations
unresolved. Its runtime-pointer table and `analysis/startup-chain-report.md`
identify stock-internal links at `0x10006a14..0x10006a20` and
`0x10006a58..0x10006a6c`, pointing into private state at `0x1001d498`, the
interrupt table at `0x1001d4ac`, and HP code. The old linker reserves state
`[0x1001d498,0x1001d4ac)` and table `[0x1001d4ac,0x1001d52c)`.
The descriptor-like table at `0x1001be90` points to `0x10000350`/ACL metadata.
These observations are not evidence of an external caller accessing the same
addresses in a replacement. Nor is their absence proved harmless on hardware.
The new layout can leave the two low pointer ranges untouched as inert canary
holes, but must not claim their pointers then provide a functioning HP runtime.

No stack address follows from the allowed CPU audit: the late literal loaded
into a1 is `0x10006bb0` followed by JX a1, a jump rather than stack establishment.
Carve a new 16-byte-aligned stack inside the main span.

## Existing measured footprint, excluding synthetic test storage

`analysis/usb-path/receive-core/target/target-check.map` and `symbols.txt` are
the smallest existing linked composition containing all the required production
code. Its map includes the test fixture, complete JBIG encoder/decoder objects,
page helper, freestanding memory functions and the linked `__udivsi3` member.
Using its whole text/rodata is therefore conservative for the existing dependency
set, but is not an upper bound on an as-yet-unbuilt startup wrapper.

| Existing target item | Exact bytes | Evidence |
|---|---:|---|
| All text, literals and alignment | `0x39a0` = 14752 | map `.text` |
| All rodata and alignment | `0x422` = 1058 | map `.rodata` |
| Initialized mutable data | 0 | map `.data` |
| Production document state | `0x34b8` = 13496 | `state` symbol |
| Production contiguous memory | `0x1c010` = 114704 | `preserved_memory`; guarded actual object is `0x1c030` |
| Production state + memory | 128200 | independent sum; receive validation report agrees |

The memory structure is independently accounted for by current headers:
four 1024-byte receive slots = 4096; compressed chunk 65552 + history4096 +
band8192 = 77840; four 8192-byte output slots =32768. Total114704. The capacities
remain unchanged even though the chosen first input produces only 32 output bytes.
The current production dependencies contribute no other nonzero global BSS in
this map; their objects are caller-owned. The new wrapper's globals still need
measurement.

Do not use the fixture's total `0x80ecc` BSS as the production requirement. It
contains a second114704-byte memory image, a preserved output state, 262144-byte
pixel capture, 8192-byte receive capture, input/statistics/ticket arrays and
other independent witnesses. Those belong in the external runner, not this
startup image. Likewise, the complete acquisition target contains unrelated
USB/controller fixtures and is not the minimum workload.

The production memory alone exceeds original BSS by 17520 bytes. Keeping BSS at
its stock start cannot work. Preserving the entry and both later private-runtime
holes also leaves no contiguous114704-byte interval within the main span.
Expanding beyond the observed PT_LOAD or reducing/splitting this object is not
a justified remedy.

## One feasible new layout, pending measurements and lead approval

These are address budgets, not a linker script or measured candidate. All ends
are exclusive. The explicit entry island prevents BSS zeroing from sweeping
across executable bytes.

| Region | Candidate interval | Contract |
|---|---|---|
| Reserved low main area | `[0x10003000,0x10007000)` | Immutable candidate padding/metadata; low legacy pointer holes may remain inert |
| Text, literals, rodata, fixed input | `[0x10007000,0x1000d000)` | 24KiB budget; existing entire linked text+rodata uses15810, leaving8766 for startup/workload/input changes |
| Data lower guard | `[0x1000d000,0x1000d020)` |32 immutable canary bytes |
| Initialized data | `[0x1000d020,0x1000d120)` |256-byte budget, including nonzero sentinel; never cleared by BSS loop |
| Data upper guard | `[0x1000d120,0x1000d140)` |32 canary bytes |
| State lower guard | `[0x1000dfe0,0x1000e000)` |32 canary bytes |
| Production document state | `[0x1000e000,0x100114b8)` |Current exact13496 bytes,16-aligned start |
| State upper guard/padding | `[0x100114b8,0x100114e0)` |40 unchanged bytes |
| Stack lower guard | `[0x10011fe0,0x10012000)` |32 unchanged bytes |
| Owned downward stack | `[0x10012000,0x10014000)` |8KiB budget; initial a1=`0x10014000` |
| Stack upper guard | `[0x10014000,0x10014020)` |32 unchanged bytes |
| Mailbox lower guard | `[0x10014020,0x10014040)` |32 unchanged bytes |
| Mailbox/workload counters | `[0x10014040,0x10014440)` |1KiB budget, including exact32-byte pixel witness and original document identity |
| Mailbox upper guard | `[0x10014440,0x10014460)` |32 unchanged bytes |
| Immutable entry island | `[0x10016780,0x100167e0)` |Fixed entry at167a8; short stack-free transfer to normalizer, literals and padding; must fit before buffer guard |
| Buffer lower guard | `[0x100167e0,0x10016800)` |32 unchanged bytes |
| Contiguous production memory | `[0x10016800,0x10032810)` |Unchanged114704 bytes,16-aligned start |
| Buffer upper guard | `[0x10032810,0x10032830)` |32 unchanged bytes |
| Remaining main tail | `[0x10032830,0x100351e0)` |Unused/canary, not a hidden heap |

All omitted gaps stay unused and immutable in the experiment. Text/state/buffer
are stationary and disjoint; no full fixture copy is needed. This retains the
entry/vector/interface address convention while deliberately reusing the old
later HP private runtime/ACL addresses within the buffer. If lead instead wants
to keep every old private hole immutable, report this workload as not fitting
under that restriction; do not silently downgrade it to stream-only decoding.

Startup should clear only explicitly owned state, document memory and mailbox
ranges. Do not derive a single min/max BSS span across the entry island or stack.
Do not rely on an ELF loader zeroing NOBITS: the external test poisons all owned
BSS after loading, enters once, and verifies the entry cleared it before C.
Preserve initialized data, all input/literal bytes, guard regions and all other
main bytes. The stack should remain independently painted for high-water checks,
not be hidden inside the BSS-zero allowance.

The candidate may use explicit zero-range sections. If an ELF segment has
file-backed code after an earlier NOLOAD state section, inspect its actual
file/memory mapping rather than assuming the old one-tail-BSS shape. Multiple
main subsegments are a new packaging choice, not automatically loader-compatible.
This is an offline ELF experiment only; retain the existing upload assets.

## Stack evidence and what must be measured

Current `.su` records are all static for the inspected production functions.
The largest relevant local frame is `chunk_in`256; image init96, decoder64/80,
semantic feed/complete48 each, document pump48, output boundary64, and small
ring/memory helpers. One source-consistent decode chain sums608 bytes before
the new caller: pump48 + output-feed16 + semantic-feed48 + complete-chunk48 +
chunk-in256 + image-feed32 + jbg85-dec-in64 + decode-pscd80 + arith-decode16.
This is an illustrative retained-frame sum, not a proven linked maximum. Tail
calls/inlining change it; callback paths and the new wrapper need separate
inspection. The consumer must obey existing nonreentry rules and use only ring
peek/accept/complete, with no recursive document feeding.

Root needs these measurements before making the addresses final:

1. Build the minimal exact closure with unchanged compiler/profile gates, then
   record every allocatable section, PT_LOAD range, symbol size/alignment,
   literal relocation, helper and undefined-symbol check. Assert the expected
   production object sizes instead of trusting this historical map.
2. Record actual new startup/wrapper/input/mailbox sizes and all input hashes.
   Use the existing small black fixture, preserve its independently expected
   32 `ff` output bytes and one document event. Exact input construction is an
   external build-time action, not an on-target generator or runtime import.
3. Inspect the linked call graph plus all new `.su` outputs, including consumer
   callbacks and libgcc. Audit the complete instruction closure, including
   relocations caused by the new layout. An 8KiB budget is provisional.
4. In continuous execution, establish stack once in the real entry, record a1
   high-water/allowed accesses and stack paint, check both stack guards and all
   protected spans, and reach the terminal mailbox/park without a host CPU or
   stack reset at each C call. Supply dirty but admissible CPU state as defined
   by the independent CPU note, not an arbitrary physically unreachable state.
5. Confirm BSS was cleared before the C initializer's own memset could mask a
   broken entry. A pre-C BSS scan or separately untouched BSS sentinel is needed;
   final pixels alone cannot establish startup initialization. Nonzero data and
   immutable gaps must survive. Failure/guard controls must stop without any
   hardware access.

This can remove the existing per-call supplied-stack/CPU/BSS dependency. It does
not establish actual ROM handoff, memory attributes/cache behavior, controller
readiness, USB events, physical settlement, engine operation or printing.

## Exact preserved inputs

The 42 repository inputs are copied, without execution, under
`/tmp/hp1020-entry-layout-inputs-20261003/repository/`, with original relative
paths listed in `repository-files.txt`. They include the original ELF, existing
map/symbol/disassembly/stack-use outputs, layouts, component structures and
selected source contracts. `SOURCES.sha256` identifies the exact inspected
copies, independent of later full-suite regeneration.

| Important input | SHA256 |
|---|---|
| Input manifest `SOURCES.sha256` | `75c24748a97f07562372a96baa53ef8c5f4482f76be981a69ab888ff6841c380` |
| Receive target map | `d9811fd2d55b774152935bec914e94cdd6352ad47b9a7d618e6fcfc22b8ddecc` |
| Receive target symbols | `f0f073933fab44142b3ffea31f1db47c961d995724fe3bc458f323c2bdf531d1` |
| Document header | `a6a966892400f431293f5ac94b487426f2211fdb3ea65df306f10ce96f88e8b7` |
| Existing idle linker | `c41373794e0316eafba1edb907083daef7d0bcf8d1f4809b8a15d9a378b12587` |
| Independent CPU review | `52da0feb834455c18c5581c1058a4107b4619f24328ec78297b14a011c9c5054` |
| Earlier next-step recommendation | `9be28e8f51ea2602621ff8535ad3bccc95c4e9f9e120a3b0c05a53d2464709a7` |

The two sibling `/tmp` notes are copied beside the manifest. The CPU review has
its own exact ELF-byte/tool provenance and is not re-decoded here. No physical
layout claim is added to it.
