# Entry-to-C audit draft

Unexecuted, unimported and unparsed draft, 2026-10-03. Parent owns first build,
audit and all target execution. No repository source was changed by this draft.

`hp1020_entry_audit.audit_target(path, prefix, stock_path)` returns `(program,
audit)` and writes nothing. The prefix names the corrected Xtensa binutils
without the `-objdump` suffix. The target's directory must contain the fourteen
compiler `.su` outputs from the frozen builder. All three inputs, shared decoder
sources, the linked ELF and its source closure must be preserved by the caller
before any execution; the returned disassembly string also needs preservation.

The Program is constructed without its historical whole-section fallback. It
contains only exact byte-matched modern `.xt.prop` instruction annotations from
the complete linked image. The recognized libgcc division-by-zero trap is
reported but removed from its instruction map and execution ranges. An attempt
to fetch the trap, literals, fixed inert padding or another unknown byte must
fail. Static direct targets still include that recognized trap as an explicit
excluded destination; indirect control and actual data accesses remain runtime
checks, not a static no-MMIO claim.

The audit validates 13 exact PT_LOADs and 18 nonempty allocated sections, the
full production state/memory objects, mailbox, immutable initialized sentinel
and owned 8192-byte stack. Its 18 `entry_read_spans` entries use **start, byte
count**. `write_ranges` and `execute_ranges` use **start, exclusive end**.
The four write ranges are state, stack, mailbox and memory only. `.entry_data`
is deliberately not writable at runtime despite its ELF SHF_WRITE flag. Guard
holes and the larger backing capture/paint envelopes are never permissions.

Original stock bytes anchor the small added normalization ISA. The prefix,
three exact ordinary BSS loops, own CALL0 return park, inert vector parks and
75-word new interface table have separate literal/control-flow checks. L32R
targets are recomputed from actual BE instruction bytes in supplied PC-relative
mode. No ENTRY, windowed call, hardware LOOP, exception return, cache/TLB,
unknown/custom or additional special-register instruction is admitted.

Every executable-section byte must be accounted for as annotated instruction,
literal or DATA, the seven approved startup words, fixed zero padding, or a
bounded property-declared alignment gap. Noninstruction bytes are never
promoted to executable code. Actual assembler flags, property boundaries,
alignment padding, relaxation and libgcc layout remain first-build questions.
The audit intentionally fails for an unreviewed difference; no output exists
yet that can justify relaxing a check.

Stack-use files record each compiler frame, exact raw file hash and largest
individual frame. They do not establish total nested/callback depth or the
assembly/libgcc contribution. The runtime must enforce the owned stack, exact
instruction boundaries, all read ranges and phase-specific writes. It must
remove the shared interpreter's historical external stack and preserve dirty
incoming memory until the startup itself clears its three spans.

Privileges, usable mapped RAM, inactive absolute-literal mode, no asynchronous
or debug exceptions, and an incoming hardware-loop endpoint outside the initial
entry/prefix are supplied conditions. These checks do not establish physical
loader compatibility, cache/memory attributes, boot, USB or printing.

`BASELINE.paths` maps exact read inputs to `baseline/`; `BASELINE.sha256` is
relative to that directory. `author-initial.py` preserves the first unexecuted
source before the explicit L32R displacement cross-check and parentheses
clarification. `author-before-find-fix.py` preserves the next unexecuted source
before the author reread corrected the bytearray search argument to `b'\0'`.
`DRAFT.sha256` seals the final draft and these records. All source versions
remain unexecuted.
