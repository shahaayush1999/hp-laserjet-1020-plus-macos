# Author static review

This is an author contract reread, not independent validation. No Python parser,
import, build, compiler, validator or target execution was used.

The audit checks both section extents and program headers independently. It
rejects unexpected allocated storage, undefined/common symbols, dynamic or
relocation sections, writable globals outside the four exact C objects, and
any load tail across a protected guard. File-backed initialized data is kept
out of runtime write permissions. A returned Program cannot use lazy decoding
because its annotated-code field is always populated.

Modern property flags and alignment semantics come from the pinned
`include/elf/xtensa.h` copy. The original annotated-byte sources anchor WSR,
RSIL, synchronization and shift forms. The SRC source tuple `(4,4,5)` is
independently derived from pinned `bfd/xtensa-modules.c`: base0x18, r bits11:8,
s bits15:12 and t bits19:16 in original0x054418. Corrected objdump must agree
when the parent later runs this audit. The historical wrong decoder output
was not used as an opcode oracle.

All stores before C are constrained by the literal seven-word pool and the
three exact loops. The stack pointer literal is loaded only after WB0/WS1 and
fresh constants; no old register or return address carries across the window
normalization. The entry and unexpected vectors execute only new local jumps.
The interface table points only at the new inert park. These assertions retain
address conventions without transplanting HP executable content.

Direct target admission is static; indirect CALLX0/JX/RET and actual load/store
addresses require parent runtime guards. The compiler's possible zero-divide
ILL is retained as evidence, excluded from execution. A normal direct branch
to that known trap is visible in the audit and fails if reached. No wrapper
silently skips it or declares a target run successful.

The first build may reveal legitimate tool-output differences, especially the
linker-created NOLOAD stack flags, `.xt.prop` DATA/padding annotations and
instruction relaxation. Preserve a failed build/audit before making a reviewed
source/generator correction. Do not alter an old report's claimed source hash
or label this draft executed because a different component has passed.
