"""Read stopped RAM-only QEMU's own register description; no target execution."""
from pathlib import Path
import hashlib,json,sys
import xml.etree.ElementTree as ET
ROOT=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
sys.path.insert(0,str(ROOT/'scripts'))
from hp1020_qemu_ram import QemuRAM
OUT=Path('/tmp/hp1020-entry-qemu-registers-20261003')
assert not OUT.exists();OUT.mkdir()
record={'status':'started','target_instructions_executed':0,'no_usb_or_network_devices':True}
try:
 with QemuRAM() as q:
  record['qemu_version']=q.version;record['qemu_binary']=q.binary
  record['qemu_binary_sha256']=hashlib.sha256(Path(q.binary).read_bytes()).hexdigest()
  record['supported']=q.command('qSupported'); documents={};registers={};next_register=0
  def fetch(name):
   assert name.replace('-','').replace('_','').replace('.','').isalnum() and '/' not in name
   raw=b''
   while True:
    reply=q.command(f'qXfer:features:read:{name}:{len(raw):x},fff')
    assert reply and reply[0] in 'ml',('missing target description',name,reply)
    raw+=reply[1:].encode('ascii')
    assert len(raw)<100000
    if reply[0]=='l':break
   (OUT/name).write_bytes(raw);documents[name]=hashlib.sha256(raw).hexdigest()
   return ET.fromstring(raw)
  def traverse(element):
   global next_register
   for child in element:
    tag=child.tag.rsplit('}',1)[-1]
    if tag=='include':traverse(fetch(child.attrib['href']))
    elif tag=='reg':
     n=int(child.attrib.get('regnum',str(next_register)),0)
     assert child.attrib['name'] not in registers
     registers[child.attrib['name']]={**child.attrib,'number':n};next_register=n+1
    else:traverse(child)
  traverse(fetch('target.xml'))
  required=('pc','ar0','ar31','lbeg','lend','lcount','sar','litbase','windowbase','windowstart','ps','intenable')
  assert all(n in registers for n in required),sorted(registers)
  record['registers']=registers;record['description_sha256']=documents
  record['selected_initial_values']={n:q.reg(registers[n]['number']) for n in required}
  record['status']='pass'
except BaseException as error:
 record['status']='failed';record['error']=repr(error)
 raise
finally:
 (OUT/'register-description.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:record[k] for k in ('status','qemu_version','supported','error') if k in record},indent=2))
