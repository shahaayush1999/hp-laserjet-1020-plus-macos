# Entry-to-C document workload — unexecuted draft

This package contains only a small call0 C workload and its mailbox contract.
It has not been parsed, imported, compiled, built or executed by its author.
No repository source was edited. The separate startup/linker author owns CPU,
stack, zero loops, vector islands and entry/park markers; root owns integration,
instruction audit, external guards, independent oracles and all later execution.
The first generated input header is deliberately absent until root creates and
freezes it with the exact build closure.

The workload adds exactly four writable objects. GCC section attributes and
target-only static assertions enforce these sizes:

| Symbol/section | Exact bytes | Proposed address |
|---|---:|---|
|hp1020_entry_state / .entry_state|13496|1000e000|
|hp1020_entry_memory / .entry_memory|114704|10016800|
|hp1020_entry_mailbox / .entry_mailbox|1024|10014040|
|hp1020_entry_data / .entry_data|256|1000d020|

The full existing production receive/document/image capacities are retained:
four1024-byte receive slots,65552-byte chunk,4096-byte history,8192-byte band,
four8192-byte output slots. There is no duplicate memory image, large trace,
history array, USB/TinyUSB/controller model, allocator or mutable static callback
state. The only witness buffer is the mailbox's32 actual output bytes.

## Before any initializer or mailbox store

Startup must enter hp1020_entry_c with its own8KiB stack and the three explicit
zero sections cleared. C first reads ALL bytes of state, mailbox and memory
through volatile character pointers, then all256 initialized sentinel bytes.
Character access safely inspects object representations without dereferencing
uninitialized production pointer fields. Only bounded local counters/addresses
and the owned stack are used until every scan completes. First bad addresses
and bad-byte counts are retained separately for zero spans and sentinel; the
total zero extent is129224 bytes. No early failure skips a later scan.

The sentinel repeats sixteen copies of bytes
`31 52 73 94 b5 d6 f7 18 39 5a 7b 9c bd de ff 20`.
Every byte is nonzero; expected byte i is
`(31 + 21 * (i & 15)) & ff`, with hexadecimal constants. It is file-backed
initialized data and is never rewritten by the workload. It is checked again
before terminal success. An empty compiler memory barrier before the first
mailbox store emits no cache/MMIO/CPU instruction and does not replace a
hardware ordering promise.

On failed precheck, C writes only mailbox words0..13 and61, sets FAIL and the
first error, and returns. It does not call an initializer or repair/zero any
owned span. The external runner must separately inspect at startup's
hp1020_entry_before_c checkpoint, so even this scan cannot conceal a faulty
startup initializer. Stack high-water/paint, immutable gaps and all guards are
external witnesses; this C code does not invent their successful status.

## Fixed input derivation, still awaiting a generated header

Use the existing unchanged `image_documents` builder in
scripts/validate-hp1020-tinyusb-printer.py. Its source SHA256 is
`1b7030af58f3a855fa5f58e8996eaf354a6f0a0007db60e474c321f124e92afa`.
It uses the saved sample header/items, changes width32/height8 and copies1,
and substitutes the saved small JBIG bytes. Exact reused fixtures are:

| Input | SHA256 |
|---|---|
|analysis/samples/generated/matrix-a4_default.zjs|8c6aa75a8c967897e72673e585c8ae862004e6e1c2b22118943ead4070e96206|
|analysis/open-firmware-model/image-core/fixtures/32x8-stripe4-black.jbg|78744d4c1f1f3ac06000192663330834b02b277df26f790aaa340ac322e9cf99|

Static byte accounting is352 bytes: magic4, START_DOC52, START_PAGE172,
BIH36, padded BID40, END_JBIG16, END_PAGE16, END_DOC16. The saved JBIG is26
bytes, so its6 coded bytes receive18 padding bytes. This is a derivation from
already checked fixtures, not a claim that root has generated a new input.
The generated hp1020_entry_input.h must provide HP1020_ENTRY_INPUT_BYTES and a
static const uint8_t hp1020_entry_input[array size] containing those exact bytes.
It belongs in read-only text/rodata. Static bounds cap input at1024; runtime
requires this first profile's352-byte extent. Root must preserve the exact
generated header, raw document and hashes before compiling/executing.

## One continuous software lifecycle

After prechecks, C calls the existing document initializer once. It reserves64
bytes per transfer, checks exact original G1 tickets1..6 and actual slot pointers,
then copies lengths64,64,64,64,64,32 directly from the constant stream. Each
reservation gets an explicitly supplied normalized complete_data followed by
one pump. The copied data is synthetic input; no raw descriptor or real DMA
completion is fabricated. Only the exact reserved bytes are written, preserving
all unused receive tails and all capacities.

The output callback is synchronous and uses only ring_peek, ring_accept and
ring_complete. It validates the actual ring/plan/context, original view address,
strict row order and32-byte witness bounds before accepting, then copies the
actual accepted bytes and immediately reports software completion. It supplies
no expected FF pixels. It does not recursively call the document/output parser,
change generation, acknowledge quiescence or interact with output hardware.

The document callback copies the original generation/document/page event by
value. A second callback fails before overwriting that first identity. The
expected first profile has one final eight-row view, stride4, one output
callback/accept/complete and one event(1,1,0,1). Independent pixel/event checking
belongs to the external oracle. Both callbacks reject if explicit finish has
already started. Before finish C requires pixels and END_DOC already observed
during pumping. It then closes its finite synthetic sender locally and calls
finish once; a short fragment is never interpreted as EOF. Final receive state
is stopped1/finished1, generation1, issued=consumed6,count0,quiescent0, with no
output-quiescence promise. Startup parks after C returns; no inherited caller
or stack is resumed.

The header defines all64 named BE words,32 pixels at offset256 and736 untouched
reserved bytes. Word7 retains the last mutating ring operation's result (OK0);
word55 is output.error. Word57 hashes all4096 receive bytes and word58 hashes all
32768 output-slot bytes. Generation/counter/state snapshots are taken only at
the end. At the real hp1020_usb_document_finish entry, the external runner can
check the existing event/pixels plus live production state before closure.

## Preserved provenance and remaining limits

`inputs/` preserves the relevant unchanged production C/headers, fixture bytes,
existing document-builder source and independent CPU/layout notes; INPUTS.sha256
seals them. These are read/derivation references, not the entire future linked
closure. Root must additionally capture the pinned compiler profile, JBIG,
freestanding helpers, libgcc, startup/linker, generated input and resulting ELF
and audit them as one build. DRAFT.sha256 seals this package's authored files.

The C source has no startup instructions, peripheral accesses, cache primitives,
hardware IRQ producer or physical consumer. Address placement repurposes later
HP private runtime locations under the separate layout review's explicit
uncertainty. Successful future execution could establish only entry normalization,
owned stack/BSS/data handling and continuous RAM document processing under the
supplied initial CPU/RAM conditions. It cannot establish loader compatibility,
physical mapping/cache coherence, USB operation or printing.
