# Independent static review of the entry builder

Reviewed only as source, 2026-10-03. No shell syntax parser, Python import,
compiler, build, audit or target execution was run. No repository source changed.

The inspected current builder is
`/tmp/hp1020-entry-integration-20261003/build-hp1020-entry-ram-target.sh`,
SHA256 `891d55135f70e7a8df21cb7af4b69e4c27efbc2e31e6c75a06e8ce5c84045ffe`.
Its exact copy is `baseline/build-hp1020-entry-ram-target-v2.sh`. The unchanged
compiler-profile gate and linker/startup/workload inputs are also copied and
hashed in `BASELINE.sha256`. The witness C/header hashes are respectively
`7e28ba53b54c168b3ed4b1d217922666eee895aca980f7a77d57721247983e05` and
`10d6bbab21eac5a4d570c80229499fa7226893bdbf1d19f2c7ca4e1ae19cd96b`.

No new consequential source-level blocker was found within the stated offline
profile. The script is intended to be installed under repository `scripts/`;
running it from its draft directory would compute the wrong repository root.

## Dependencies and provenance

`-MD -MF "${obj%.o}.d"` is on the same invocation that compiles each actual C
translation unit. Unlike `-MMD`, `-MD` includes system headers. Each of the15
units has a distinct basename, so its `.d`, `.su` and `.o` names do not collide.
The generated ZjStream header is emitted before compilation, belongs to the
ordinary include path, and should appear in the workload's dependency record.
The const witness uses the real production headers and does not depend on that
generated input or on the workload header.

Dependency files do not capture the standalone `startup.S`, `entry.ld`, selected
libgcc archive, compiler/assembler/linker binaries, built-in configuration, or
build environment. Those remain explicit provenance inputs. The two-toolchain
arrangement is inherited: startup uses the explicit corrected BIN_PREFIX
assembler, while GCC invokes its configured assembler/linker for C and linking.
Parent must preserve the actual resolved tools and libgcc selected for this
build, not assume BIN_PREFIX also selects GCC's subordinate programs. The
linked map identifies pulled archive members; their frames have no generated
application `.su` row.

The script overwrites each dependency/stack-use output on successful compilation
and stops on any error. A stopped build is not a successful fresh closure; old
artifacts in the directory must not be mistaken for a new target. Parent owns
the pre-execution source/dependency snapshot, success checks and exact target
hash. The audit rejects an unexpected `.su` filename but does not by itself
prove freshness of a retained same-name artifact.

## Compiler and linker profile

The compiler-profile gate precedes generation/compilation. It requires GCC14.3.0,
big-endian call0 and the bounded feature macros, with windowed calls, hardware
loops, FP, unsupported divide and other optional operations disabled. The new
compile flags preserve that gate's defaults; none reverses the ABI/profile.
`-ffreestanding -fno-builtin -fno-common`, no loop-to-library pattern rewriting,
function/data sections and text-section literals match the existing component
build. `-fstack-usage` remains enabled for every C unit. Empty `-DNDEBUG=`
retains the repository's existing assertion policy; it is not an error return
or hardware safety proof.

`-nostdlib` plus the explicit linker script and `-lgcc` prevents an implicit C
runtime/start file or host stack. It does not remove the need to audit libgcc.
No garbage collection flag is present, so the used const layout witness is
retained through ordinary `.rodata.*` collection without a new KEEP or runtime
reference. All linked code, including unused helpers, stays subject to the
whole-image instruction audit. The current linker bounds code plus rodata below
the initialized-data guard; the additional260 witness bytes consume that same
budget. It cannot change state/memory capacities or silently spill into a guard.

The builder checks undefined symbols and saves the ELF/map/disassembly/symbols/
section program headers, then removes `.o` files. Those outputs are not a
substitute for the later annotation/byte/layout audit. If object-level witness
proof is needed, preserve objects before that removal or inspect the final
symbol and containing allocation; no extra object audit is claimed here.

## Stack and first-build review obligations

The 8192-byte stack is an explicit budget carved from the new owned RAM layout,
not a compiler promise or observed high-water mark. No large production state
or image allocation is moved to the stack: the named objects retain their exact
13496/114704/1024/256 sizes. However, compiler `.su` rows only report individual
frames. Linked normal/callback call chains, libgcc, assembly call/return behavior
and actual prologue/callee frames must still be reviewed after the first
audit-only build. Summing every function is not a valid maximum; checking only
the largest function is not a complete bound either.

Before target execution, review the exact linked call sites reachable from
`hp1020_entry_c`, the output/document callback chains and any recursion or
indirect targets, correlate generated static frames with actual stack-adjusting
instructions, account for selected libgcc members, and check the startup
CALL0/own return park. Parent's runtime must then enforce all stack accesses
within `[10012000,10014000)`, report actual high-water use, and preserve both
guards. No linked footprint, call-depth or stack-fit result exists yet.
