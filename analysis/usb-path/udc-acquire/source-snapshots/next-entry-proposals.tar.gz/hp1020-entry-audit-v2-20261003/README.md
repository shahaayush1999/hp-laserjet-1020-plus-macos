# Entry audit V2 — unexecuted

The only Python change from the frozen V1 is adding `hp1020_entry_layout` to
the exact compiler stack-usage input names. The builder now has fifteen C
translation units; the new constant-only unit is expected to emit an empty
`hp1020_entry_layout.su`. The audit accepts empty individual files while still
requiring the exact file set and valid static rows from the other units.

The witness's sole `const uint32_t hp1020_entry_layout[65]` definition fits the
existing ordinary `.rodata` wildcard and read-only allocation rule. It does not
extend the four mutable-object list or any runtime write range. Parent's runner
must still verify the linked witness's exact symbol extent and all65 words
against its independently derived literal expectations before using offsets.
The C declaration alone is not a measured linked-layout result.

V1 is untouched at `/tmp/hp1020-entry-audit-draft-20261003/`; its source hash is
`5ca4f1672967f0606fdcbab2cfe94571076beab69cf0171ae52675afbfaf2297`.
`V1-DRAFT.sha256` retains its manifest. `changes.patch` records this one-line
change. The baseline directory retains all20 V1 source copies plus the frozen
witness C/header/expected table/note/manifest and the current reviewed builder.
The prior builder remains under its original baseline name; V2 is separate.

No source was parsed, imported, built or executed. Runtime permission units,
the 13-load/18-allocation checks, prefix, BSS, literal, branch and trap rules are
unchanged. The revised builder review is `BUILDER_REVIEW.md`. The first linked
artifact and all actual call frames still require audit and independent review.
