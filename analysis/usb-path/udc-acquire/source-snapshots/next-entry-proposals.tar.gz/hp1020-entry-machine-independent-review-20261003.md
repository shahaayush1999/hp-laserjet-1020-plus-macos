# Concrete entry interpreter: independent static review

2026-10-03. Reviewed the exact root draft below, the complete shared call0
interpreter, frozen startup/linker and independent CPU/layout/acceptance notes.
No Python import, parsing, compiler, build, validator, emulation or candidate
execution was performed. No root, repository or frozen draft file was changed.

**No blocking semantic or API defect found in this bounded source review.**
This is not a completed entry experiment. The audited Program adapter, linked
candidate closure, runner's read-only observations and QEMU path remain separate
dependencies; this review does not approve inputs not yet present in this module.

## Checked boundaries

- `EntryMachine` replaces the parent interpreter's segment list and writable
  ranges before executing anything. The inherited synthetic stack at21000000
  is not retained or added to the entry image. Only state, memory, mailbox and
  the owned8KiB stack can ever be writable through the runtime store path.
  Supplied main-envelope bytes can contain painted guards/gaps without granting
  them data-access permission: the separate audited `entry_read_spans` and phase
  store spans are checked first.
- Both load/store overrides reject an out-of-span access before calling the
  parent operation. The parent then checks full width, alignment, overflow,
  forbidden MMIO and backing storage before it reads or changes RAM. Stack reads
  and writes are forbidden before the first admitted C CALL0. Instruction fetch
  independently uses admitted executable ranges and exact property-decoded
  bytes; a poisoned region's permissive synthetic flags do not override that
  executable-range check.
- Physical AR state is preserved across the one WB change. At RSYNC, the old
  sixteen logical registers are first written back to their old physical
  indices, then the new window is loaded. Slice assignment preserves the
  parent `run()` loop's register-list reference. WSR's earlier update of the
  named special register does not accidentally retag those old logical values,
  because physical mapping uses the separate old `self.windowbase` until commit.
  The frozen startup reloads a2 after this change and loads a1 from its own
  literal, rather than depending on a preserved logical scratch/stack value.
- The only new special operations are gated to the actual normalization span.
  RSIL has exact operands, each permitted WSR has its declared final value and
  can occur once, and synchronization commits WB. The after-normalization
  checkpoint requires the complete named state, SAR0 and exact owned stack top.
  Disabling inherited loops precedes C; active loops whose endpoint could
  intercept normalization are excluded, not simulated as safely recoverable.
- Checkpoints are bound to linked symbols, distinct and observed in order.
  Startup writes only the three zero objects. The first call must be the real
  CALL0 at `hp1020_entry_before_c`, targeting `hp1020_entry_c`, after the pre-C
  observer has seen the memory. The full BSS/guard/sentinel oracle belongs to
  that observer; merely reaching the checkpoint is not asserted to prove zeros.
- Each real call records its encoded return PC and owned aligned SP. Returns
  require a recorded call, exact return PC and restored caller SP. Ordinary
  tail branches do not fabricate a call; their eventual return still matches
  the actual recorded caller. No inherited return address is used as a success
  condition. The pre-finish checkpoint is captured on arrival at the actual
  document-finish symbol, before its first instruction.
- The workload return must empty the own-call stack and arrive at the linked
  park after every earlier checkpoint. Success then requires two actual
  executions of that exact local self-branch with unchanged registers and no
  extra access/call. The synthetic STOP is returned only after those two
  iterations; arriving at a park address or reporting PASS is insufficient.
- Ordered instruction and data-access traces are streamed with digests. SP
  minimum is taken after every normalized instruction; stack-access minimum
  is independently tracked. The final SAR is allowed to differ from startup,
  consistent with ordinary compiled shifts and the independent plan.

## Integration details and limits

`program.entry_read_spans` must be an iterable of `(start, byte_count)` pairs.
The inherited `program.execute_ranges` instead uses `(start, end)` pairs.
This distinction was sent to the independent audit author; interchanging these
schemas would admit incorrect ranges. Instructions, symbols and entry use the
existing Program API. Only exact audited allocated objects should be readable;
unused main-envelope gaps and guard bytes do not become input scratch storage.

The access trace stores `[kind, pc, address, width, value]` as
`>B3xIIII`. For stores, `value` is the full source register masked to32 bits;
the parent store masks it to the specified width before writing. A byte/halfword
trace value may therefore exceed255/65535 legitimately. A trace replay/oracle
must mask to `8*width` bits; it must not equate the high source bits with extra
memory effects. Reads contain the actual unsigned loaded word at that width
(a signed16 load is extended only after this read record).

`observe` is a trusted read-only runner callback. This module passes detached
register/region snapshots, but cannot prove an arbitrary Python callback did
not retain another mutable reference or call inherited mutators. Likewise the
`host_runtime_mutations=0` evidence field is a runner contract, not a dynamic
host-intervention monitor. Root explicitly owns the independent runner audit
and seals; those checks must support that claim. The inherited `run()` should
be called with no argument-register overrides for this no-argument entry.

Initial profile ranges and all actual selected CPU/physical-AR values come from
the independent frozen plan. This is not a universal validator for arbitrary
special-register inputs. Privilege, ordinary PC-relative literals, usable loaded
RAM and absent asynchronous exceptions remain supplied. No physical cache,
mapping, HP processor, cold boot, controller or printing claim follows.

## Exact reviewed inputs

| Input | SHA256 |
|---|---|
|`/tmp/hp1020-entry-integration-20261003/hp1020_entry_machine.py`|`46cc66fc2ac1c22201ef6a33ee13eba4a54087bb416ccc1b8726aae2d2c98b07`|
|`scripts/hp1020_xtensa_call0.py`|`ed2924d8e46c0e553fe079a5ecdfff77dc40f1aa228588d9a86c39ce98769480`|
|`/tmp/hp1020-entry-startup-draft-20261003/startup.S`|`c1184dd473f513189cfbbdee6e059a1ac429bbec962ada1c048dd0a433e4433f`|
|`/tmp/hp1020-entry-startup-draft-20261003/entry.ld`|`de92c21e52ec9c250d5ced551f31d4ead06b40fedd354d560d1b95377fb46bf0`|
|`/tmp/hp1020-entry-cpu-contract-review-20261003.md`|`52da0feb834455c18c5581c1058a4107b4619f24328ec78297b14a011c9c5054`|
|`/tmp/hp1020-entry-layout-review-20261003.md`|`9f5d2d4c52f9174aa0f4b878ee9bad84db8b24e7e2390d85ddfaf71d0c18f4ac`|

The acceptance plan and root decision note were read as task context; their
exact current hashes are recorded in the adjacent input manifest. No reviewed
source is rewritten by this note.
