# New entry and fixed-layout draft — unexecuted

`startup.S` and `entry.ld` are new offline code, not an upload image or a claim
that the resident loader accepts this layout. They contain no stock instruction
body, cache/TLB/controller/MMIO operation, inherited stack use or runtime callback.
No build, assembler, import, validator or execution has been performed.

The root agent accepted the new layout described in the preserved layout review.
This keeps selected stock entry/vector/interface **addresses** as conventions and
reuses HP's private later runtime/ACL locations as ordinary owned buffer storage.
No external requirement for those private locations has been established. The
existing hardware-test images and all repository sources remain unchanged.

## C and linker contract

The workload provides exactly these mutable objects and one callable entry:

| Symbol | Input section | Size | Start/end |
|---|---|---:|---|
| `hp1020_entry_state` | `.entry_state` |13496| `1000e000..100114b8` |
| `hp1020_entry_memory` | `.entry_memory` |114704| `10016800..10032810` |
| `hp1020_entry_mailbox` | `.entry_mailbox` |1024| `10014040..10014440` |
| `hp1020_entry_data` | `.entry_data` |256| `1000d020..1000d120` |
| `hp1020_entry_c(void)` | ordinary text | measured later | `10007000..1000d000` budget |

The initialized data is file-backed and never cleared. State, memory and mailbox
are distinct NOLOAD sections/segments. The owned downward stack is
`10012000..10014000`, with a1 initialized to the exclusive end,16-aligned. No
other mutable global/BSS/common symbol is permitted. Ordinary text, literals and
rodata, including the generated constant input, share the 24KiB code budget.

The linker exposes `__hp1020_entry_{state,memory,mailbox,data,stack}_{start,end}`,
all five regions' lower/upper guard starts/ends, each vector/literal/interface
span, code/text/rodata boundaries, the entry island and the stock main envelope.
Guard symbols describe existing candidate RAM only; guards are not ELF sections
and no segment should silently initialize them. The external runner must paint
them and all unused main gaps before entry and compare them afterward.

The entry island is exactly `10016780..100167e0`; `hp1020_entry_start`/`_start`
is at `100167a8`, with one stack-free J to the new normalizer. All normalizer
literals precede their L32R uses in its text section. No address is inferred
from an inherited register, and CALL0 establishes its own return address.

## Checkpoints and permitted effects

| Symbol | Meaning before the instruction at the symbol executes |
|---|---|
| `hp1020_entry_start` | First new instruction; no initialized CPU/stack assumption beyond the stated supplied conditions |
| `hp1020_entry_normalize` | Start of the CPU normalization prefix after the literal words |
| `hp1020_entry_after_normalization` | INTENABLE0, PS15, WB0, WS1, loops0, SAR0, a1=`10014000`, a4=0; no BSS store/C call yet |
| `hp1020_entry_before_c` | Three owned zero spans cleared; no C call yet; a1 unchanged, a2/a3=`10032810`, a4=0 |
| `hp1020_entry_park` | Actual C return target, then a terminal self-loop |
| `hp1020_entry_unexpected_park` | Separate self-loop used by the new 75-entry interface table |

The zero loops perform ordinary word stores only to state, then mailbox, then
memory:3374 +256 +28676 =32306 stores,129224 bytes. There is no store to stack,
data, guards, entry, vectors or literals before C. The code does not use a
hardware LOOP. The observer may stop/read/resume at checkpoints; it must not
rewrite CPU state, zero storage, fix a0/a1, or resume directly at a C function.
Inspect exact zero bytes at `before_c`, before C's own initializers can conceal a
startup failure. Keep initialized-data and gap witnesses independent.

## Vector content and packaging limits

All vector contents are new inert instructions. The window-vector block contains
six independent local parks at 64-byte boundaries; kernel/user/double/reset/debug
section starts park locally. These are fallbacks at the advertised entry points,
not exception handling, window spilling or return paths. Padding is zero data,
not an assertion that entry into any arbitrary byte is valid. The reset-vector
park does not start the workload: this experiment enters only the ELF entry.
Literal placeholders are zero. The 75 interface words point only to the new
unexpected park, never HP code. Low legacy runtime pointer objects are not
loaded or invoked; their unused main range is externally guarded.

The draft uses 13 explicit PT_LOADs, combining only contiguous small vector
sections and keeping each main owned allocation separate. That differs from
stock's 11 headers. No `.img`, ACL wrapper, machine-id patch or `.dl` is generated.
All segments and C structures must be remeasured after actual linking.

## Supplied conditions and required review

Privilege, accessible/exclusively owned RAM, usable inherited memory attributes,
PC-relative L32R mode and absence of asynchronous/debug exceptions remain
supplied. An incoming active loop must not end anywhere in the entry/prefix
before LCOUNT is cleared; this is not arbitrary-state cold boot. Only a2 is used
before PS disables WOE/CALLINC. WINDOWBASE changes are followed by RSYNC and
fresh constants. No LITBASE, debug, timer, IRQ acknowledgement or cache/TLB state
is touched. There is no return to a caller and no retry/reset facility.

Before execution, root must assemble/link with the pinned gates, retain the
original draft, inspect actual segment VMA/PMA/file/memory ranges and section
flags, reject allocatable metadata/orphans/extra BSS, and inspect every emitted
instruction/property/literal/relocation. In particular confirm one direct entry
J within range, the low-register prefix, word-loop bounds, CALL0 target/return,
all advertised parks and the C closure. Preserve `.xt.prop`, `.xt.lit` and any
`.xt.insn`; no safety gate is weakened for startup. Linker assertions are
unexecuted proposed guards, not evidence that the syntax or layout has passed.

The 8KiB stack is still a budget. Inspect the linked call graph/stack-use outputs,
observe permitted stack writes/high-water in a continuous run, and compare all
guards. Successful software pixels/mailbox would establish only this bounded
entry-to-C path under the supplied conditions, never ROM handoff, controller
readiness, DMA settlement, physical printing or power-cycle recovery.

## Provenance and versioning

`baseline/` contains the exact accepted CPU/layout reviews, prior recommendation,
old idle source/linker for address provenance, and the coordinated C header as
read. `BASELINE.sha256` records those snapshots. `DRAFT.sha256` covers the new
files; no test result exists. Subsequent corrections must preserve this first
draft and use a separately named revision or archived version before changes.
