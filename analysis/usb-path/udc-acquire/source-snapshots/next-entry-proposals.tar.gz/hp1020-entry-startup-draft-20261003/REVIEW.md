# Author static review — no execution

The assembly follows the independently reviewed CPU prefix: interrupt/loop
normalization precedes normal privileged call0 PS; WB changes cannot supply a
stale constant because a2 is reloaded afterward. SP is established before any
stack access or CALL0. Startup holds no borrowed state and has no caller return.

Each zero range is nonempty and both endpoints are word-aligned; the state size
is deliberately not rounded up over its40-byte upper guard. The three loops
cannot cross the entry island because they load separate explicit bounds. The
initialized data remains in its own loadable segment. The mailbox and stack
guards are adjacent but disjoint; the state/memory guard endpoints agree with
the accepted layout review.

The linker matches the coordinated C header's exact object sizes and input
sections. It rejects generic data/BSS/common storage and unexpected sections,
while preserving nonallocated Xtensa annotations. No metadata is allowed to
become a new PT_LOAD. This last condition requires actual readelf/property
inspection because a script alone does not prove resulting section flags.

The address-only guard intervals are not claimed to be loader allocations.
The runner separately seeds/checks them inside the stock-declared main envelope.
The new vector sections preserve address conventions only; every advertised
entry is a new self-park and no original executable body or private pointer is
transplanted. Interrupts/exceptions are still excluded, so this is no handler ABI.

Unexecuted uncertainties: assembler special-register spelling/relaxation,
linker syntax and orphan behavior, synthesized stack section flags, exact
segment alignment/file extents, annotation classification of inline literals
and padding, final C footprint and stack high-water. These are explicit first
build/audit checks, not reported successes. No linker/source correction was
needed during this author read-through; preserve this version before any
independent-review or actual-tool correction.
