"""Preserve the three failing legacy gates before changing their source counts."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
ROOT=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
TMP=Path('/tmp');sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
for label,path in [('udc-out','hp1020-udc-out-ttd06tck'),('udc-composed','hp1020-udc-composed-n0717a6h'),('udc-offload','hp1020-udc-offload-7s_j_au0')]:
 folder=TMP/path;report=json.loads((folder/'validation.json').read_bytes())
 assert report['status']==report['target']['status']=='pass'
 assert len(report['source_sha256'])=={'udc-out':98,'udc-composed':118,'udc-offload':127}[label]
 assert 'open-firmware/udc-out/hp1020_udc_acquire.h' in report['source_sha256']
 for name,digest in report['source_sha256'].items():
  assert sha((folder/'source'/name).read_bytes())==digest==sha((ROOT/name).read_bytes())
 for p in folder.rglob('*'):
  if p.is_file():files['captures/'+label+'/'+p.relative_to(folder).as_posix()]=p
baseline=TMP/'hp1020-acquisition-baseline-20261003'
for p in baseline.rglob('*'):
 if p.is_file():files['pre-run-baselines/'+p.relative_to(baseline).as_posix()]=p
for name,path in {
 'failed-consistency.json':ROOT/'analysis/offline-consistency/offline-consistency.json',
 'failed-consistency.md':ROOT/'analysis/offline-consistency/offline-consistency.md',
 'failed-consistency-generator.py':ROOT/'scripts/check-hp1020-analysis-consistency.py',
 'full-run.log':TMP/'hp1020-full-acquisition-20261003.log',
 'case-comparison.json':TMP/'hp1020-acquisition-full-comparison-20261003.json',
 'case-comparison.py':TMP/'hp1020-compare-acquisition-full-20261003.py',
 'scope.md':TMP/'hp1020-udc-acquire-2gdl6ewq/FIRST-FULL-STOP.md',
 'archive-check.py':Path(__file__),
}.items():files[name]=path
failed=json.loads(files['failed-consistency.json'].read_bytes())
assert failed['check_count']==131 and failed['fail_count']==3
payloads={name:p.read_bytes() for name,p in files.items()}
buf=io.BytesIO()
with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w') as tf:
  for name,raw in sorted(payloads.items()):
   assert '..' not in Path(name).parts and not Path(name).is_absolute()
   i=tarfile.TarInfo(name);i.mode=0o644;i.mtime=0;i.size=len(raw);tf.addfile(i,io.BytesIO(raw))
blob=buf.getvalue()
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as tf:
 assert set(tf.getnames())==set(payloads)
 for name,raw in payloads.items():assert tf.extractfile(name).read()==raw
metadata=dict(status='all component executions passed; full suite stopped at three legacy source-count gates',
 archive_sha256=sha(blob),archive_bytes=len(blob),member_count=len(payloads),
 expected_counts_before=[97,117,126],actual_counts=[98,118,127],
 additional_dependency='open-firmware/udc-out/hp1020_udc_acquire.h',
 no_report_hashes_hand_edited=True,
 member_sha256={n:sha(b) for n,b in sorted(payloads.items())})
for suffix,data in [('.tar.gz',blob),('.json',(json.dumps(metadata,indent=2)+'\n').encode())]:
 p=ROOT/'analysis/usb-path/udc-acquire/source-snapshots'/('legacy-count-consistency-stop'+suffix)
 assert not p.exists();p.write_bytes(data)
print(json.dumps({k:metadata[k] for k in ('archive_sha256','archive_bytes','member_count')},indent=2))
