# Acquisition integration: narrow legacy source-count review

2026-10-03. Independent reviewer `/root/usb_reference_contract`. Read-only
source inspection and JSON-data comparison with `jq`; no candidate, checker,
generator, import, build, validator, QEMU or hardware execution. No repository
files were edited. The entry acceptance plan/oracle were frozen before this
separate task; no candidate entry implementation was read.

## Conclusion

The proposed checker-only correction is justified: source counts OUT97→98,
composed117→118 and offload126→127. Add the explicit new-header membership
requirement to OUT and offload. Keep composed's exact union, all existing
source/artifact hashes, semantic oracles and case counts. No production,
fixture, generator, expected-result or report-hash correction is warranted by
this mismatch. This conclusion does not relabel the first stopped aggregate
run as a pass; the lead owns its archived outcome and subsequent validation.

## Independent observations

Compared baseline files under `/tmp/hp1020-acquisition-baseline-20261003/`
against current reports. In **each** of the three source dictionaries the sole
added key is `open-firmware/udc-out/hp1020_udc_acquire.h`; no keys were removed.
All three contain its exact frozen V2 SHA256
`e073d84e4f0223e07997a3cce5125a420591317681f80c7b80a5b2adc0bfc653`, which also
matches the current header file. Complete host `cases` arrays and complete
target `cases` arrays compare equal to their corresponding baselines, including
every recorded event, diagnostic row, expected semantic record and raw capture
hash embedded in them. This review compared those three affected components,
not all eleven regression reports and not independently re-read raw captures.

| Component | Baseline/current sources | Host/target cases | Added keys | Removed keys |
|---|---:|---:|---:|---:|
|udc-out|97/98|34/34|one header|none|
|udc-composed|117/118|62/62|one header|none|
|udc-offload|126/127|58/58|one header|none|

The addition follows an actual source dependency, not merely a manifest label:
`open-firmware/udc-out/hp1020_udc_out.c:3` includes that header.
`scripts/validate-hp1020-udc-out.py:422` includes the component's `*.[ch]`;
`validate-hp1020-udc-composed.py:1011–1015` joins the OUT closure; and
`validate-hp1020-udc-offload.py:153–160` extends the composed closure. These
generators already saved the needed header without hand-patching reports.

Reviewed pre-correction checker SHA256
`c1fa1307a355ee251baf7b09c8bea989b7ea8a4ded79c92f8a989d86c0292997`.
Its stale exact counts are at lines1678 (offload),4833 (OUT),5231 (composed).
OUT still seals every recorded source/fixture at4874–4875; add header membership
beside the count so swapping it for an unrelated extra file cannot pass.
Offload's required set at1541–1565 should explicitly include the header; its
source/fixture byte-hash loop at1575–1582 remains unchanged.
Composed constructs its exact source union at5243–5249 and requires equality
at5534; the OUT union already contains the new header. Its per-source hashes
at5542–5543 must remain intact. Updating only its count preserves those checks.

Target ELF/artifact hashes can legitimately differ after relinking the expanded
OUT translation unit; equality of case/capture arrays is not a claim that old
and new ELF files are identical. Existing exact current artifact sealing remains
required. No broad relaxed source-count range or disabled hash check is needed.

## Reviewed report identities

| Report | Baseline SHA256 | Current SHA256 at review |
|---|---|---|
|udc-out/validation.json|68f38779e4ed715bf5ca62fddb84873955f256ae15f834c3fe4a5d0ac9169dd6|694ba88a9bfe41cc726573d12a166ce8ae244bce810e80bac44533d6a6ec9508|
|udc-composed/validation.json|c9e9de43728375e0d150b592fe1ae3ebdbd60e6a5e82d5a33d201172a7073b1a|a764b3e5ab01d3c94af4c957fb144113279581804308f2ac3b2827cd54b7b12a|
|udc-offload/validation.json|3dfa43cf99629e5d879310bd65ccf3a7a9037df1f6a8aa29078defc06b8f3a06|c46cacb4bc98882253afc9a2f56f47e9a603866d2a10b27c58357685b70a27c7|

I sent the affirmative narrow finding to the lead before finalizing this note.
While the note was being finalized, the shared aggregate report changed to
131/pass under lead ownership. I did not run that checker, inspect its new
execution log or use the later pass to derive the proposed correction.
