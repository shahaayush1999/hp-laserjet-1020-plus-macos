# First full acquisition regression: consistency stop

All execution stages, including32 paired acquisition cases, passed. The final
consistency gate found exactly3 failures among131checks. Three earlier component
source-count expectations omitted the newly included hp1020_udc_acquire.h.
Recorded source closure grew97→98,117→118,126→127 respectively; no member was
removed. Every host/target case array and raw capture identity for all11components
matched the pre-run baseline exactly. The independent acquisition V2 raw gate
passed unchanged. The driver-behavior suite was not reached. This archive must
not be described as a successful full suite. Preserve this evidence before any
count-expectation correction; regenerate reports using their generators only.
