"""Compare completed acquisition checkpoint evidence, never execute candidates."""
from pathlib import Path
import hashlib
import json

ROOT=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
BASE=Path('/tmp/hp1020-acquisition-baseline-20261003')
OUTPUT=Path('/tmp/hp1020-acquisition-full-comparison-20261003.json')
assert not OUTPUT.exists()
expected={'continuous-printer':34,'printer-class':82,'receive-core':75,
          'tinyusb-printer':132,'udc-out':34,'udc-ep0':50,'udc-composed':62,
          'udc-offload':58,'udc-program':28,'udc-publish':40,'udc-acquire':32}
rows=[]
for old_path in sorted(BASE.rglob('validation.json')):
    new_path=ROOT/old_path.relative_to(BASE)
    name=old_path.parent.name
    a,b=json.loads(old_path.read_text()),json.loads(new_path.read_text())
    assert a['status']==b['status']=='pass',name
    assert len(a['cases'])==expected[name]
    assert a['cases']==b['cases'],(name,'host case behavior/captures changed')
    at,bt=a.get('target'),b.get('target')
    assert bool(at)==bool(bt)
    if at:
        assert at['status']==bt['status']=='pass'
        assert at['cases']==bt['cases'],(name,'target case behavior/captures changed')
    rows.append(dict(component=name,host_cases=len(a['cases']),
        target_cases=len(at['cases']) if at else 0,all_case_rows_oracles_and_capture_hashes_equal=True,
        baseline_report_sha256=hashlib.sha256(old_path.read_bytes()).hexdigest(),
        current_report_sha256=hashlib.sha256(new_path.read_bytes()).hexdigest()))
assert {row['component'] for row in rows}==set(expected)
result=dict(status='pass',comparison='publication checkpoint and first acquisition versus full acquisition suite',
    scope='Case behavior and capture identities only; source/tool/build metadata may change.',components=rows)
OUTPUT.write_text(json.dumps(result,indent=2)+'\n')
print('All eleven host/target component case arrays and capture identities are unchanged.')
