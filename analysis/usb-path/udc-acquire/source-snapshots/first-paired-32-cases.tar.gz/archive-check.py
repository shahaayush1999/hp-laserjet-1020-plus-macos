"""Seal an already-completed acquisition run; does not execute candidates."""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import struct
import tarfile

ROOT = Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
parser = argparse.ArgumentParser()
parser.add_argument('capture', type=Path)
parser.add_argument('label')
parser.add_argument('--log', type=Path, required=True)
args = parser.parse_args()
assert args.label.replace('-', '').isalnum()
capture = args.capture.resolve()
raw = (capture/'validation.json').read_bytes()
report = json.loads(raw)
assert raw == (ROOT/'analysis/usb-path/udc-acquire/validation.json').read_bytes()
assert report['status'] == report['target']['status'] == 'pass'
assert len(report['cases']) == len(report['target']['cases']) == 32
for group, folder in [('source_sha256', 'source'), ('fixture_sha256', 'tested-fixtures')]:
    for name, digest in report[group].items():
        assert sha((capture/folder/name).read_bytes()) == digest
        assert sha((ROOT/name).read_bytes()) == digest
fields = ('', '_ep0', '_bulk', '_setup', '_offload', '_program', '_publish', '_acquire')
steps = ('steps', 'ep0_steps', 'bulk_steps', 'setup_steps', 'offload_steps', 'program_steps', 'publish_steps', 'acquire_steps')
names = {'pixels':'pixels', 'wire':'wire', 'receive':'receive', 'output':'output',
         'documents':'documents', 'ep0':'output.ep0-descriptors',
         'bulk_descriptor':'output.udc-descriptor', 'setup_record':'output.setup-record',
         'program_reads':'output.program-read-script', 'program_trace':'output.program-trace',
         'program_storage':'output.program-storage', 'acquire_device':'output.acquire-device'}
total = 0
for index, (case, target) in enumerate(zip(report['cases'], report['target']['cases'])):
    directory = capture/f'case-{index:03}'
    assert (directory/'case-name').read_text().strip() == case['case'] == target['case']
    rows = [sum((case['initial'+field] for field in fields), [])]
    assert len({len(case[field]) for field in ('events',)+steps}) == 1
    rows += [sum((list(part) for part in parts), []) for parts in zip(*(case[field] for field in steps))]
    assert [json.loads(line) for line in (directory/'raw-stdout').read_text().splitlines()] == rows
    native = [json.loads(line) for line in (directory/'target-steps.jsonl').read_text().splitlines()]
    assert len(native) == len(rows)-1
    sizes = target['component_and_allocation_bytes']
    for host, row in zip(rows[1:], native):
        assert len(host) == len(row) == 576
        assert [v for i,v in enumerate(host) if i not in (59,425,490,555)] == [v for i,v in enumerate(row) if i not in (59,425,490,555)]
        assert row[59] == target['adapter_state_and_memory_bytes']
        assert row[425] == sizes['program'] and row[490] == sizes['publisher'] and row[555] == sizes['acquisition']
    encoded = b''
    for event in case['events']:
        data = bytes.fromhex(event['data_hex'])
        encoded += struct.pack('>6I', *event['words'], len(data)) + data
    assert encoded == (directory/'events.bin').read_bytes()
    for name, local in names.items():
        data = (directory/local).read_bytes()
        assert sha(data) == case['capture_sha256'][name] == target['capture_sha256'][name]
        assert data == (directory/('target-'+name)).read_bytes()
    total += len(native)
files = {p.relative_to(capture).as_posix():p for p in capture.rglob('*') if p.is_file()}
files.update({'run.log':args.log, 'archive-check.py':Path(__file__)})
content = {name:path.read_bytes() for name,path in files.items()}
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w') as archive:
        for name, data in sorted(content.items()):
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            info=tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info,io.BytesIO(data))
payload=buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as archive:
    assert set(archive.getnames()) == set(content)
    for name,data in content.items(): assert archive.extractfile(name).read() == data
out=ROOT/'analysis/usb-path/udc-acquire/source-snapshots'
out.mkdir(parents=True,exist_ok=True)
metadata=dict(status='32 sanitized host and 32 audited QEMU cases passed; recording I/O/visibility hooks only',
    archive_sha256=sha(payload),archive_bytes=len(payload),member_count=len(content),
    report_sha256=sha(raw),source_files=len(report['source_sha256']),fixture_files=len(report['fixture_sha256']),
    verified_event_pairs=total,verified_raw_capture_pairs=32*12,
    limits=report['limits'],member_sha256={name:sha(data) for name,data in sorted(content.items())})
for suffix,data in [('.tar.gz',payload),('.json',(json.dumps(metadata,indent=2)+'\n').encode())]:
    path=out/(args.label+suffix)
    assert not path.exists(),path
    path.write_bytes(data)
print(json.dumps({name:metadata[name] for name in ('archive_sha256','archive_bytes','member_count','verified_event_pairs')},indent=2))
