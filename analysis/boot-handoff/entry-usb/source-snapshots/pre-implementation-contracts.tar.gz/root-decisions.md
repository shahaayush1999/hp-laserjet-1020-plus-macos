# Root decisions before USB runtime implementation

The entry checkpoint bc4338447dfa11331f8486b406e7d9af40147743 was committed,
pushed and verified synchronized/clean. Its six paired cases,132-check complete
regression,37 copied controls and30 isolated guards remain distinct. The new
USB runtime is still unimplemented/unbuilt/unexecuted.

Accepted frozen split layout/startup (c8271b.../096597...) and independently read
its no-blocker static review. All actual linked counts, input NOLOAD contents,
closed global allowlist, source closure, exact ISA/callbacks and new nested frame
bound remain required. The authored builder draft is
/tmp/build-hp1020-entry-usb-target-draft-20261003.sh; it must live under scripts
before execution, and its names/includes await the approved public header.
It deliberately retains input objects to reject lost nonzero NOLOAD initializers.
No candidate source/build/run is credited to this shell draft.

Use separate experimental open-firmware/entry-usb-test source and
analysis/boot-handoff/entry-usb output; keep all accepted entry-ram and production
components unchanged. The provider/header is being frozen independently of C.
Root approves it before the original independent oracle author writes an
addendum for the exact mailbox/witness/padding/core fields and observation plan.
Only then assign runtime/provider C implementations in separate scratch folders.

The six ordered observer stops are after-normalization, pre-C, first actual
close_input entry, next publish_service entry after final acquisition, first
adapter_finish entry after service/pump, own park. No service may intervene
between close and final supplied acquisition. Earlier ordinary service calls
remain legitimate; activate that observer checkpoint only after close.
Independently count all actual close/finish entries (including tail entries).
These are read-only observations, never new C marker repairs.

Require raw private _usbd_dev bytes from independently derived target32 offsets
alongside actual adapter/OUT state. Getter observations are secondary. The
independent author is sealing source/old emitted-getter evidence (size68,
ep_status offset52; OUT1+54, BUSY1/CLAIMED4). Exact new linked symbol/getter bytes
still must agree before those raw measurements are accepted.

Safe unchanged helper boundaries are recorded in
/tmp/hp1020-usb-runtime-harness-adaptation-20261003.md. No global monkey-patching:
new profile-specific layout/property/startup audit; new owned-span interpreter
policy; QEMU subclass strict checkpoint command guard plus new local orchestration.
The inherited source copier seals old library source honestly, with the new
adapter/orchestrator additionally sealed under its own name. Source snapshots
and report hashes never relabel past runs.

Reported component storage includes some dedicated buffers. Actual symbols are
SETUP80 plus16-byte record, OUT64 plus16-byte descriptor, EP0136 plus160-byte
memory; aggregate totals96/80/296 are not sizeof(component). Acquirer152,
publisher140,program88,class56,adapter332,document13496 are actual object sizes.
The previous aggregate footprint arithmetic already included those buffers.

This remains a RAM-only supplied-platform experiment, without USB contact,
physical cache/mapping/settlement or engine operations. The existing working
installed printer and public repository visibility remain unchanged.
