# USB-runtime harness adaptation — static review

2026-10-03, `/root/adapter_review`. Read-only source review; no candidate import,
parse, build, validator, instruction execution, hardware contact or repository
edit. The frozen layout package remains unchanged. This note specifies changes
for a separate future target; it does not claim they are implemented or tested.

The existing shared `Program.parse`, conservative instruction executor and
`QemuRAM` transport can remain unchanged. The entry-specific wrappers cannot be
reused by merely replacing the ELF: they hard-code the old allocations, mutable
objects, three clears, C symbol, checkpoint names/counts and source closure.
Use one explicit new audited profile and thin target-specific orchestration,
sharing neutral parsing/capture/transport primitives. Do not monkey-patch the
accepted modules' globals or audit the old layout and replace its permissions
afterward. Any extraction of common policy helpers needs separate review and old
profile regression; it is not permission to widen the accepted old contract.

## Reuse and replace

| Boundary | Safe reusable behavior | Required separate assertions |
|---|---|---|
| ELF/property audit | bounded ELF parsing, exact decoded-byte match, stock anchors, ordinary ISA set, complete annotation coverage, source-backed alignment, static targets/L32R, excluded known DIV0 trap | new sections/segments, closed global list, startup literals/four loops, own C target, new complete compiler/frame closure |
| Interpreter | exact annotated fetch, ordinary instruction semantics, CPU normalization, own-call/return ledger, full access/step traces, no external stack, two real park jumps | actual spans/stack, six staged checkpoints, recurring service-entry handling, new first C symbol and phase writes |
| Direct QEMU observer | sealed backend/version/register map, one seed then command lock, ordered breakpoints, full physical/logical registers and seven memory captures, partial failures/cleanup | new actual mutable spans, code bounds/loop exclusion, six checkpoint names/counts, own source identity |
| Runner/publication | detached snapshots before checking, file-byte-only initial overlay, source/tool/header seals, new empty capture directory, independent capture gate before atomic report publication | new source/output paths and schema, compiler layout witness, two-document/owner/trace oracle, six-stop pairing/report counts |

Prefer a small explicit layout/policy boundary to another copied general runner.
Neutral helper reuse must not mutate module globals used by the old profile.
The shared interpreter and QEMU backend have no need for new USB instructions,
MMIO permission, external callbacks or per-event register setup.

Concrete unchanged-library reuse confirmed with the lead: audit `read_elf`,
`file_bytes`, `check_stock`, `disassemble`, `linker_fill_evidence` and
`classify_code` can be called from a new local audit. The last helper accepts its
literal-pool range and keeps the same narrow relative libgcc marker rule.
`read_properties` is not neutral because it pins old CALL0 bytes; neither are
layout/startup/stack-closure checks. A new QEMU subclass can inherit
ObservedQemu's constructor, seed, command bookkeeping and cleanup, overriding
only post-lock Z/z/c/s checkpoint admission/count; other commands retain the
original fail-closed guard. Use local strict normalization/protection/execution
orchestration plus existing snapshot/compare/partial_identity helpers. The
inherited copy_sources records the old module's real `__file__`: additionally
seal the new subclass/orchestrator by its actual filename. That library hash
alone is not the new adapter's complete source. EntryMachine's old constructor,
read/write/access and after_instruction paths still use old STACK/WRITABLE;
reuse its CPU-special semantics/snapshot logic, not those fixed-range methods.

## Layout admission before execution

`hp1020_entry_audit.py:199–289` currently requires18 nonempty allocations,
13 exact PT_LOADs and only four mutable object symbols. The new linker declares
15 segments and intends20 nonempty allocated sections: the same10 external
vector/interface sections, text/rodata, BSS, stack, mailbox, generic data,
sentinel, entry island, memory and witness. **These are new admission targets,
not observed linked output.** Require exact actual flags/types/addresses and
file/memory extents after the first link; no load may span a named guard or the
used-end-to-cap remainder.

Generic BSS starts10010000 and ends at its actual aligned used end<=10013fe0;
full document13496 must be its first separate object. Generic initialized data
starts100164a0 and uses<=96 bytes, separate from sentinel[10016500,10016600).
Witness starts10032830 with nonempty actual aligned size<=10176. The public
provider proposes9216 but that is not yet an approved object-size oracle here.
Mailbox moves to16060; stack is[10014020,10016020); full memory stays
[10016800,10032810). Keep actual ends separate from caps, including empty unused
remainders. All input alignment/internal section padding must be accounted for.

Replace the four-object mutable allowlist with a closed list derived from the
approved separate public objects plus unchanged production/TinyUSB globals.
Check each symbol's section, exact established size, range and source; cover
internal/local globals too. Do not simply accept every SHF_WRITE object. Keep
the full production buffers and reject unknown allocation families/overflow.
The linker cannot by itself prove that custom NOLOAD input objects lacked
nonzero initializers: preserve/review their input objects/declarations before
discarding them. Runtime initialization must not conceal a bad link.

Startup audit changes are small but mandatory: normalizer10003024 follows nine
words at3000; word pairs describe state, mailbox, memory and witness; exactly
four ordinary store loops connect normalization to CALL0 hp1020_usb_runtime_c.
Use actual audited ends in those words, independently checked against allocation
sizes/caps. Preserve privileged raw encodings and WB reload ordering. The old
mixed-property check at audit:308–313 pins CALL0 bytes5000d5; the new displacement
cannot retain that literal. Admit only the exact new six-byte no-transform
CALL0-to-real-C plus self-park fragment, checked against its emitted bytes and
decoded/encoded target, with original flags retained. Do not broaden DATA/INSN
or permit unannotated execution. The 75 inert table pointers target the new
unexpected park; all fixed islands and zero padding remain independently checked.

The runner still paints/captures the same **seven** backing envelopes. Fifteen
load segments must not become15 unrelated snapshots or a whole-main runtime
permission. Overlay only PT_LOAD file bytes; never zero memsz−filesz. Poison all
four actual zero spans and the owned stack. Program reads use(actual start,byte
count); write/execute ranges use(start,end). Keep guards and unused gaps absent
from permissions despite their presence in backing captures.

Before C, only state/mailbox/memory/witness may be written. During C also permit
owned stack and actual generic.data; never sentinel/code/islands/gaps. Compare
all generic.data file bytes at pre-C to the exact loaded ELF, and independently
check required TinyUSB initial fields/pointer referents against the approved
source/layout witness.29 is the known old TinyUSB input-data total, not a license
to ignore additional new initialized objects. Generic.data may legitimately
change during C; old immutable-data guards must instead target the sentinel.

## Six actual component stops, no new C markers

The lead accepted these additional evidence-only stops during this review,
pending an independent plan addendum before implementation:

1. `hp1020_entry_after_normalization`: unchanged RAM; exact normalized CPU/own SP.
2. `hp1020_entry_before_c`: every actual four-span BSS byte zero, original loaded
   data/sentinel/stack paint/gaps/islands unchanged, no initializer yet.
3. **First actual `hp1020_tusb_adapter_close_input` entry**: before its first
   instruction. It sets input_closed immediately (adapter.c:948–953), so the old
   document-finish entry is too late to prove ordinary document behavior.
4. **Next actual `hp1020_udc_publish_service` entry after that close**: final
   successful acquisition must occur first. Observe OUT FREE and original
   adapter PENDING before service is allowed to consume the notification.
5. **First actual `hp1020_tusb_adapter_finish` entry**: service and pump have
   consumed the final reservation, but finish has not set the finished/fenced
   result. No separate private workload marker substitutes for this entry.
6. Own park after return, followed by two actual self-jump executions.

Activate stop4 only after close. Earlier ordinary publish_service entries are
required legitimate work. Current EntryMachine.after_instruction loops over
*all* checkpoint addresses and rejects an early hit; adding service there
without phase gating would fail on the first normal service. QEMU naturally
arms only its next breakpoint, but its hard-coded four/count/name guards must
be replaced consistently. Independently count all actual close/finish entries,
including tail-jump entry transitions; reject premature/repeated calls. Merely
observing the expected later breakpoint is not proof no earlier call happened.

At close the independent frozen plan requires G2/issued13/consumed12/count1,
input_closed0, two original END_DOC tuples(2,1,0,1)/(2,2,1,1) and64FF actual
copied pixels. Original cookie(14,3,2,13,1) remains DCD-owned, OUT EXPOSED and core
BUSY. After final acquisition, the same adapter cookie is PENDING; OUT is FREE,
count1/consumed12 remain, and input_closed is1. After actual service+pump, pre-
finish requires owners FREE, count0/consumed13; the two documents/pixels remain
unchanged. Final park adds finished/stopped/fenced, with no generation change,
one close/finish, no cancellation or post-close arm. Do not demand owner-free
state before close or infer release merely from OUT becoming FREE.

Read these through independently verified **actual production** offsets; a
provider's copied final counters are supplementary. Validate the actual original
cookie across DCD→PENDING and the preserved final zero-length transfer; zero is
not EOF. OUT observe at out.c:198–207 schedules adapter completion and retires
only its own record. The adapter remains pending until service, and pump must
release the receive reservation. Require final cache/ordering rows and exact
input/device/CPU effects from the approved public contract. No direct normalized
bulk completion, fake cancellation or manual receive accounting can stand in.

Keep initial+six paired snapshots (seven per case), plus two QEMU park-step
captures, instead of the old hard-coded[:5]/index4/pairs5/report30 assumptions in
runner:289–315/352. The fixed6 CPU/paint cases can remain. Adopt the already
independent new dirty loop endpoints350a0/350e0; the old profiles overlap the
larger code/prefix. Recheck actual prefix nonintersection before executing.
Do not silently enlarge instruction/time/trace limits after an overrun.

## Whole closure and evidence, not a fixture replay

Source selection at runner:59–79 currently omits the USB closure. Seal the new
runtime/provider/layout/header/input generator, independent literal/addendum/
capture checker, startup/linker and harness before build; add printer/adapter,
SETUP/EP0/OUT-acquisition/program/publisher, unchanged TinyUSB config, pinned
upstream/patch/preparation gates, effective generated TinyUSB source, all linked
receive/image/semantic/JBIG/freestanding files. Preserve -MD/-MF dependencies for
every C translation unit, effective-source manifest, target headers and actual
compiler/subordinate/linker/assembler/libgcc identities. Include generated input
and object bytes, map, properties and assembly dependencies. Historical70-source
or15-C-unit counts cannot become acceptance thresholds for this new closure.

The acquisition builder shows the useful production source list/patch gates;
do not copy its nested fixture or missing -MD behavior. Keep all new target,
capture, archive and report paths separate from entry-ram and component reports.
Preserve each build/audit stop before repair; require the frozen independent raw
capture gate before publishing success. Old accepted hashes are never relabeled.

Audit every linked annotated instruction, static target and literal, not only
visited functions. Keep shared ISA/MMIO restrictions. Resolve all actual new
dynamic class, DCD, recording/cache, document and output callback targets against
the approved tables/objects and annotated function entries. Source/frame review
must include TinyUSB service→class/control→adapter/DCD callbacks, program and
publish hooks, acquisition/observe, parser/output callbacks and libgcc. Per-unit
.su frames alone are not a nested bound. The old784 static/720 observed figures
do not apply; recompute whole-call/callback bounds, observe actual SP/access
low-water and enforce the retained8KiB budget continuously. No host call helper
or CPU/stack reseed between supplied RAM events is allowed.

## Outstanding gates

The layout is unbuilt. Actual20-section/15-load shape, generic global manifest,
new footprints/initializers, instruction properties, direct/callback targets,
new frame bound and concrete stack use are not yet established. The public
provider/header, source-padding/CPU-span/trace/layout addendum and the six-stop
independent acceptance addendum require lead approval before runtime C begins.
Those are concrete prerequisites, not reasons to invent success or widen RAM.
Nothing here establishes physical USB, cache, interrupt provenance, settlement,
controller/engine behavior, loader compatibility or printing.

## Exact inspected input hashes

Paths without a leading slash are relative to the repository. No file below
was imported or executed by this review.

```text
2f990f9f57731c49d8931138d32ce100fecd1d2fed722354f6c01117e52042eb scripts/hp1020_entry_audit.py
46cc66fc2ac1c22201ef6a33ee13eba4a54087bb416ccc1b8726aae2d2c98b07 scripts/hp1020_entry_machine.py
4ef9ffcfac58a326b68df526c8ddec93868cf18cf85eae76682a30ab9cf9d080 scripts/hp1020_entry_qemu.py
f61fe39ae28a48bd8712e62c2fa4afa7c6688cdfb8fcd66f80a618a6d5f7f216 scripts/validate-hp1020-entry-ram.py
ed2924d8e46c0e553fe079a5ecdfff77dc40f1aa228588d9a86c39ce98769480 scripts/hp1020_xtensa_call0.py
8fe170ab6161d47d17ef93eb6c25622878e00dc2d4747cfd70073a0fd777b5e2 scripts/hp1020_qemu_ram.py
891d55135f70e7a8df21cb7af4b69e4c27efbc2e31e6c75a06e8ce5c84045ffe scripts/build-hp1020-entry-ram-target.sh
cc66a3a70fe9e6f4b4164b52dcaab35fc4985426decb1c590d6ffca7f167f349 scripts/build-hp1020-udc-acquire-target.sh
a5bb1d281dd7226f9346e0dce3b13a475ac25320cf6b276f39d539d78584c3d7 open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.c
0f809b1ac03f5fb96d8524cab2e5cf18d5ad8d9fe6348e50ae4b2d6d2509e5bf open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.h
63361d26de832654eeb75f3a87248d1badb08d074419ff870880127e6d7ba91c open-firmware/udc-out/hp1020_udc_out.c
e073d84e4f0223e07997a3cce5125a420591317681f80c7b80a5b2adc0bfc653 open-firmware/udc-out/hp1020_udc_acquire.h
4818e02254d64a799a1909e0af9a7fcc89a3df11a926b3be4164a366ef22677f open-firmware/udc-publish/hp1020_udc_publish.h
c8271bbea0fdc7ed4ffb4c18469a15d91170d26c948d41e3706e8ed95922bad6 /tmp/hp1020-usb-runtime-layout-draft-20261003/startup.S
096597da3ccce35a61f0e9edb1ea7ebd87765764d900f26fca0c2d25e63bb073 /tmp/hp1020-usb-runtime-layout-draft-20261003/runtime.ld
d48939d773c7075856a5e466ece32522c5adbd0761c47f3eca00c6b151a71dd8 /tmp/hp1020-usb-runtime-layout-draft-20261003/DRAFT.sha256
7818a09ed83fbfedc1b39b35524e1fc0f11a3b4480d0a5a8e2fe1970e84adac4 /tmp/hp1020-entry-usb-independent-plan-20261003.md
13194a8d608de407cf9c513f59cf5b1a80a1c3cdeac4ea08b71ebb9602272b95 /tmp/hp1020-entry-usb-independent-literals-20261003.py
```
