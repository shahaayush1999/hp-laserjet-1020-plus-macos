# Independent static review: split-object USB runtime entry/layout

2026-10-03. Author: `/root/usb_reference_contract`. This reviews the frozen
layout package before any new runtime C implementation, assembly, link or
candidate execution. No candidate/validator import, parse, build, test, original
instruction execution, repository edit, device operation or external download
was performed. Only source reads, exact copying, SHA256 verification, static
ELF-byte inspection and interval arithmetic were used.

## Result

**No blocking source-level defect found in this bounded layout/startup review.**
The package satisfies the independently frozen initialization and placement
contract, subject to the explicitly pending first-link/audit conditions below.
This is not a successful build, emitted-layout result, stack-sufficiency result,
loader/physical-memory proof or an executed USB lifetime.

The complete reviewed package, including its original ELF and all baseline
inputs, is copied without changes into `inputs/layout-package/`. The earlier
independent plan, literal oracle and source manifest are copied into
`inputs/independent/`. `INPUTS.sha256` seals all 23 copied inputs. Both original
package manifests were independently checked successfully; no generated report
or source hash was modified. The exact package source hashes are:

| Input | SHA256 |
|---|---|
| startup.S | c8271bbea0fdc7ed4ffb4c18469a15d91170d26c948d41e3706e8ed95922bad6 |
| runtime.ld | 096597da3ccce35a61f0e9edb1ea7ebd87765764d900f26fca0c2d25e63bb073 |
| README.md | 58360c4380e597ef17c1011058c6a28781c6d2b1d09f267186c1a70b49dd7871 |
| changes.patch | c6437db4ae4699284668044d346fd68cafbe35d323a33e39b86895ea0943b1f5 |
| DRAFT.sha256 | d48939d773c7075856a5e466ece32522c5adbd0761c47f3eca00c6b151a71dd8 |

Independent plan SHA256 is
`7818a09ed83fbfedc1b39b35524e1fc0f11a3b4480d0a5a8e2fe1970e84adac4`;
independent literal oracle remains unchanged at
`13194a8d608de407cf9c513f59cf5b1a80a1c3cdeac4ea08b71ebb9602272b95`.

## Original envelope and exact placement arithmetic

The copied stock ELF is
`2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`.
Its big-endian ELF header directly gives entry `100167a8`, program-header offset
`34`, entry size `20`, and 11 entries. The main header at file offset `114`
contains `(PT_LOAD, file=560, vaddr=10003000, paddr=10003000,
filesz=1a640, memsz=321e0, flags=7, align=1)`. Thus the declared main interval is
`[10003000,100351e0)`, 205280 bytes, and its stock file-backed end is `1001d640`.
The original words at file `3208`, mapping to virtual `10005ca8`, are independently
`1001d640 100351e0`. The hex reads are preserved under `observations/`.
These are declared address bounds only; neither stock ELF permissions nor
new linker flags prove physical availability, cache attributes or exclusivity.

`runtime.ld:31–68,107–179,215–223` separates actual used spans from caps. I
independently checked the following half-open intervals and differences:

| Purpose | Interval or cap | Bytes |
|---|---|---:|
| code/constants budget | 10003000..1000ffe0 | 53216 |
| generic zero state budget | 10010000..10013fe0 | 16352 |
| owned stack | 10014020..10016020 | 8192 |
| mailbox | 10016060..10016460 | 1024 |
| initialized-data budget | 100164a0..10016500 | 96 |
| loaded sentinel | 10016500..10016600 | 256 |
| entry island | 10016780..100167e0 | 96 |
| full document memory | 10016800..10032810 | 114704 |
| bounded witness budget | 10032830..10034ff0 | 10176 |
| witness window including its two guards | 10032810..10035010 | 10240 |
| final protected tail | 10035010..100351e0 | 464 |

These spans do not overlap. The large memory object is separate from document,
adapter and controller state; it cannot cross the entry island as the old
fixture aggregate would. Exact full document/memory sizes are required at
`runtime.ld:261–264,285–290`; the state budget leaves 2856 bytes after the
13496-byte document before other ordinary globals. The prior map's complete
15082 smaller-BSS estimate leaves 1270 bytes, while its 45338 production
text/literal/rodata sum leaves 7878 code bytes. Those are **budget differences**,
not a measurement of new runtime/provider code or object alignment. Overflow
must be a build failure, not justification to shrink production buffers.

All fixed guards and used-end-to-cap intervals remain outside zero loops and
ordinary runtime permissions. In particular memory's high guard is witness's
low guard, while code's high guard is state's low guard. No output section is
deliberately padded to a cap. The 352-byte pre-island gap and unused generic-data
tail remain protected even though they are inside the main loaded envelope.

## Initialized data and four exact clears

`runtime.ld:126–179` puts actual `.bss/.sbss/COMMON` in the generic state span,
and puts memory, mailbox and bounded evidence in three separate NOLOAD spans.
Ordinary `.data/.data.*/.sdata/.sdata.*` is deliberately file-backed at `164a0`
with its own segment, separate from the immutable 256-byte sentinel at `16500`.
This fixes the relevant obstacle in the old entry layout: TinyUSB's initialized
globals must survive startup. They are runtime-writable after C begins, whereas
the sentinel remains logically immutable even though its segment has RW flags.
Runtime access policy must enforce that distinction, rather than infer it from
segment flags alone. The README already requires this.

Startup lines 65–91 clear in order: actual state, actual mailbox, full memory,
actual witness. Each loop stores one four-byte zero then increments and compares
against its exclusive end. The unconditional first store is safe under the
linker's explicit nonempty/fixed-size and word-alignment assertions
(`runtime.ld:257–274,285–312`). State/witness trailing alignment is at most three
bytes and belongs to the actual zero span; cap remainder does not. No loop uses
a budget cap. Stack, loaded generic data, sentinel, entry, code and all gaps are
outside these four intervals. The after-normalization checkpoint precedes every
zero store; before-C follows all four loops before any C initializer can hide an
initialization error.

The new experiment must count zero bytes from **emitted actual section ends**.
The former fixed total129224 and old state placement are obsolete for this new
profile. A proposed 9216-byte witness would fit its budget, but no provider
implementation or emitted object is accepted by this review.

## CPU normalization, entry and stack

`startup.S:38–57` uses the already independently reviewed standard sequence:
RSIL15, INTENABLE0, LCOUNT/LBEG/LEND0, ISYNC, PS15, RSYNC, WINDOWBASE0, RSYNC,
reload1, WINDOWSTART1, RSYNC, SSAI0, and a1 from the owned-stack literal. It uses
only low registers before disabling windowed-call state, has no ENTRY or stack
access before establishing SP, and reloads values after changing WINDOWBASE.
The old and new normalizer instructions in this prefix are textually identical;
the preserved diff shows only extra witness literals/loop, C target and comments.
No new optional CPU/cache/TLB/debug/controller instruction is introduced.

The copied CPU review records original byte-backed special-register identities:
INTENABLE SR228, PS SR230, WINDOWBASE SR72, WINDOWSTART SR73, loops SR2/0/1;
RSYNC `010200`, ISYNC `000200`, SSAI0 `000404`. Original RSIL/PS values differ;
level15 and PS15 are the **new** deterministic offline contract, not a claim
about HP's original prefix. The existing pinned ISA/call0 review supports the
16-byte SP alignment and ordinary CALL0 return convention. The stack top
`10016020` satisfies alignment and is separated from BSS and mailbox by guards.

There are exactly nine literal words before normalizer `10003024`, enforced
by `runtime.ld:239–240`. The entry island places its plain J at `100167a8`;
the nominal address difference to normalizer is -79748 bytes, within the known
ordinary J range. The backwards local L32R literals are close to the prefix,
and CALL0 stays within the 53216-byte code budget. Actual emitted relocations,
operand alignment, instruction bytes and targets still require the first-link
audit. The narrow no-transform region covers pre-C CALL0 plus its adjacent
park (`startup.S:96–110`; linker assertion244–246), preserving the prior GAS
correction without enabling a long-call fallback. The future C entry takes no
arguments; CALL0 establishes a0 and must return only to the owned self-park.

The independently frozen dirty LENDs are `100350a0` and `100350e0`, in the
protected tail after witness guard `10035010`, outside the new prefix and entry
island. They cannot intercept initial normalization before LCOUNT is cleared.
The source deliberately does not claim safety for arbitrary incoming loop ends
or asynchronous/NMI/debug events. It also does not supply privilege, physical
RAM mapping or an HP optional literal-mode register. The six external immutable
vector/interface unions match the original declared ranges; their newly inert
parks are not interrupt/exception handling or physical reset-entry support.

## Admission and still-required first-build evidence

No new correction is requested before the first build. The following are
mandatory checks already called out by the package, not results of this review:

1. Audit all actual emitted PT_LOAD file/memory extents and allocated section
   flags. There are 15 declared segments, but linker declarations alone do not
   establish actual load count/padding. No segment may absorb a guard/unused
   gap; loading file bytes must not silently zero memsz tails before entry.
2. Audit each exact custom C object size and unique placement. Review every
   custom NOLOAD initializer/input section: nonzero initializers must not be
   silently discarded. Whole-output-section size assertions alone cannot prove
   an individual global's correct declaration or absence of a hidden neighbor.
3. Keep `.unexpected` nonempty as a hard failure (`runtime.ld:210–212,315`).
   Named metadata is outside PT_LOADs and still must be nonallocated. Discarding
   `.comment/.note.GNU-stack` does not authorize allocated content hidden under
   those names. New unwind, TLS, constructors, linkonce/dynamic sections must not
   be accepted by broadening permissions to the whole main interval.
4. Re-audit the complete new instruction/callback/libgcc closure and exact
   direct CALL0/park/entry bytes. Recompute the USB workload's linked frame bound
   and observed low SP: the earlier 784-byte bound does not apply. Eight KiB is
   an allocation, not yet a sufficiency result for the new loop and callbacks.
5. At pre-C, independently compare every actual loaded initialized byte,
   sentinel, guard/gap/island and stack paint; require all four actual zero spans
   to be zero. At runtime, allow only actual data/state/memory/mailbox/witness
   objects and owned stack, with no post-entry CPU or memory repair.

The public provider/header contract, exact witness serialization, production
member-offset witness and runtime C implementation remain outside this review.
Their cache/mapping/settlement, reset/SETUP and logical bus behavior remain
supplied; this layout removes none of those physical-hardware prerequisites.

