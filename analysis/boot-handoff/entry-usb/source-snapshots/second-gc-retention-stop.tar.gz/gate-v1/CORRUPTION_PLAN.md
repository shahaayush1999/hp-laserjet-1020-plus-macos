# Bounded copied-evidence controls (planned, unexecuted)

Use a copied complete capture only after the unchanged gate passes. Where
applicable mutate both model/native raw images, snapshot hashes/embedded rows,
corresponding GDB read replies and final report metadata consistently, so the
intended semantic check — not a superficial seal mismatch — rejects it. Do not
change the frozen gate or independent source bytes to admit a bad control.

1. Paired final pixel change, preserving production/witness/digest consistency:
   reject literal64 FF and production full32768 oracle.
2. Re-tag the retained device12 image as the new owner13 at pre-close, leaving
   current actual owner healthy: reject independent old-image identity.
3. Clear actual private OUT1 BUSY at the PENDING pre-final-service checkpoint,
   matching secondary getter diagnostics: reject full actual endpoint array.
4. Release final adapter owner/receive reservation at close or immediately on
   acquisition, keeping mailbox internally consistent: reject original DCD /
   PENDING / count1 actual state and no-early-release entry sequence.
5. Alter final ZLP's backing padding or one unused960-byte receive tail in all
   later snapshots: reject exact full4096 bytes despite actual_count0.
6. Change descriptor status/count or asymmetric DMA body coherently with the
   acquisition diagnostic: reject original descriptor/witness command literals.
7. Change CNAK/RDE attempt in trace, update trace digest/log counters and both
   engines consistently: reject exact ordered240 logical command rows.
8. Change one range CPU pointer/cookie consistently with its diagnostic but
   keep actual adapter/object memory correct: reject independently resolved
   original owner/range identities and immutable bind table.
9. Insert a service entry between close and final acquisition with raw step/
   natural-entry metadata changes: reject NEXT-service natural order. Removing
   an actual load/store record separately tests complete replay, not this case.
10. Change final copied event first_page from1 to0 and update document counters
    and event witnesses coherently: reject two original event tuples.
11. Add a post-lock M/P/G or addressed-c debugger request/reply while preserving
    ledger sealing/indexing: reject exact allowed one-seed transcript.
12. Corrupt an untouched initialized-data byte at pre-C or a capacity-gap guard
    in both engines, maintaining seals: reject immutable loaded bytes/fullzero
    versus initialized-data distinction. A separate source/target seal control
    can corrupt a preserved .o or effective header without updating the seal.

Controls above are evidence-validation failures, not new firmware lifecycles,
new physical failure modes or proof of hardware safety. The author has not run
this plan, inspected candidate outcomes or adapted expectations to results.
