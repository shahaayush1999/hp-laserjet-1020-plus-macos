from pathlib import Path
import json
p=Path('/tmp/hp1020-entry-usb-gate-draft-20261003')
old=(p/'inputs/check-hp1020-entry-ram.py').read_text()
add=(p/'inputs/addendum/literal-addendum.py').read_text()
layout=json.loads((p/'inputs/addendum/expected-layout.json').read_text())
imports=old[:old.index('MAIN =')]
imports=imports.replace('Independent capture-only entry checker','Independent capture-only continuous USB-entry checker')
constants='''MAIN = 0x10003000
ENTRY = 0x100167a8
DOCUMENT = (0x10010000, 13496)
MEMORY = (0x10016800, 114704)
MAILBOX = (0x10016060, 1024)
STACK = (0x10014020, 8192)
DATA_SENTINEL = (0x10016500, 256)
WITNESS = (0x10032830, 9216)
REGIONS = ((MAIN, 0x321e0), (0x10000000, 0x184), (0x10000200, 0x3c),
           (0x10000270, 0xe0), (0x10000370, 0x12c),
           (0x10100020, 0x2e4), (0x10100320, 0xc))
PHASES = ('initial', 'after-normalization', 'pre-c', 'pre-close',
          'pre-final-service', 'pre-finish', 'park')
QPHASES = PHASES + ('park-step-1', 'park-step-2')
CP_SYMBOLS = ('hp1020_entry_after_normalization', 'hp1020_entry_before_c',
    'hp1020_tusb_adapter_close_input', 'hp1020_udc_publish_service',
    'hp1020_tusb_adapter_finish', 'hp1020_entry_park')
CPU = (
 dict(name='ordinary-privilege',ps=0,intenable=0,windowbase=0,windowstart=1,sar=0,lbeg=0,lend=0,lcount=0),
 dict(name='dirty-window3',ps=0x70302,intenable=1,windowbase=3,windowstart=0x89,sar=37,
      lbeg=0x10035080,lend=0x100350a0,lcount=17),
 dict(name='dirty-window7-excm',ps=0x50711,intenable=2,windowbase=7,windowstart=0xc1,sar=63,
      lbeg=0x100350c0,lend=0x100350e0,lcount=65535))
PAINTS = ((0xa5,0x5a),(0xcc,0x96))
GDB = dict(pc=0,lbeg=33,lend=34,lcount=35,sar=36,windowbase=38,windowstart=39,ps=42,intenable=110)
SENTINEL = bytes.fromhex('31527394b5d6f718395a7b9cbddeff20') * 16
BIE = bytes.fromhex('000001000000002000000008000000041000035cfd98ff02ff02')
BACKEND_HASH = '8fe170ab6161d47d17ef93eb6c25622878e00dc2d4747cfd70073a0fd777b5e2'
ORACLE_HASH = '13194a8d608de407cf9c513f59cf5b1a80a1c3cdeac4ea08b71ebb9602272b95'
ADDENDUM_HASH = '1bee3ad2136fc8c88ae661a783220705ec9514767a87cb7457ea1dc4664295b6'
LAYOUT_HASH = '2bcf65553e3bf8f6d9cbd03d962141615e8bb4d0fddbead6bd641cc5dffbf0dc'
HEADER_HASH = '25f5e76cff3633d6e3ab85f4e9adfc2e94edcc02e2cfe0b7d7d2bafea2e82995'
EFFECTIVE_USBD_HASH = '8bf699c1522d65301a4c63e2bfa529d302d3955b8cd18dd1602d7ace441a62dc'
'''
constants+=old[old.index('PRIMARY ='):old.index('LAYOUT_RECORDS =')]
constants+='OBJECTS = '+repr(tuple((r['id'],r['symbol'],r['size'],r['alignment']) for r in layout['objects']))+'\n'
constants+='FIELDS = '+repr(tuple((r['id'],r['object'],r['member'],r['offset'],r['width']) for r in layout['fields']))+'\n'
constants+='LAYOUT_WORDS = (0x4850554c,1,457,16,101)+tuple(v for i,n,z,a in OBJECTS for v in (i,z,a))+tuple(v for i,o,n,a,z in FIELDS for v in (i,o,a,z))\n'
fixed=old[old.index('FIXED ='):old.index('\n\ndef need')]
fixed=fixed.replace("    '.entry_data': (*DATA, 1, 3), '.entry_state': (*STATE, 8, 3),\n    '.entry_stack': (*STACK, 8, 3), '.entry_mailbox': (*MAILBOX, 8, 3),\n    '.entry_island': (0x10016780, 0x60, 1, 6), '.entry_memory': (*MEMORY, 8, 3),", "    '.runtime_sentinel': (*DATA_SENTINEL,1,3), '.runtime_stack': (*STACK,8,3),\n    '.runtime_mailbox': (*MAILBOX,8,3), '.runtime_memory': (*MEMORY,8,3),\n    '.runtime_witness': (*WITNESS,8,3), '.entry_island': (0x10016780,0x60,1,6),")
base=old[old.index('def need'):old.index('def receive_literal')]
helpers=add[add.index('STREAM_SHA256 ='):]
helpers=helpers.replace('STACK = (0x10014020, 0x10016020)\n','')
# These functions/constants are copied from the sealed independent addendum,
# not imported or evaluated, and precede the future checker implementation.
elf=old[old.index('class Elf:'):old.index('def make_initial')]
elf=elf.replace("set(FIXED) | {'.text', '.rodata'}", "set(FIXED) | {'.text', '.rodata', '.bss', '.data'}")
elf=elf.replace("t[3] == 0x10007000", "t[3] == 0x10003000")
elf=elf.replace("r[3] + r[5] <= 0x1000d000", "r[3] + r[5] <= 0x1000ffe0")
insert='''        b, d = self.alloc['.bss'], self.alloc['.data']
        need(b[3] == 0x10010000 and 13496 <= b[5] <= 16352 and b[5]%4 == 0 and
             (b[1],b[2]) == (8,3), 'actual bounded generic BSS extent')
        need(d[3] == 0x100164a0 and 0 < d[5] <= 96 and
             (d[1],d[2]) == (1,3), 'actual bounded generic initialized data')
        self.zero = ((b[3],b[5]),MAILBOX,MEMORY,WITNESS)
        self.initialized_data = (d[3],d[5])
        self.mutable = self.zero+(STACK,self.initialized_data)
'''
elf=elf.replace('        spans = sorted',insert+'        spans = sorted',1)
elf=elf.replace("len(self.loads) == 13, 'exact thirteen load segments'", "len(self.loads) == 15, 'exact fifteen load segments'")
elf=elf.replace("self.file(*DATA) == SENTINEL", "self.file(*DATA_SENTINEL) == SENTINEL")
elf=elf.replace("'hp1020_entry_c'", "'hp1020_usb_runtime_c'")
registers=old[old.index('def cpu_initial'):old.index('def semantic_snapshots')]
# Same exact QEMU transcript, now six stages and an extra adapter source.
ledger=old[old.index('class Ledger:'):old.index('def check_capture')]
ledger=ledger.replace("'hp1020_entry_qemu.py': source_map['scripts/hp1020_entry_qemu.py'],", "'hp1020_entry_qemu.py': source_map['scripts/hp1020_entry_qemu.py'],\n                        'hp1020_entry_usb_qemu.py': source_map['scripts/hp1020_entry_usb_qemu.py'],")
ledger=ledger.replace("q['snapshots'][1:5]", "q['snapshots'][1:7]").replace("q['snapshots'][5:]", "q['snapshots'][7:]")
# Runtime write policy is an independently bounded ELF-derived property.
ledger=ledger.replace('def qemu_ledger(folder, q, images, supplied, checkpoints, source_map):','def qemu_ledger(folder, q, images, supplied, checkpoints, source_map, elf):')
ledger=ledger.replace("    need(q['status']", "    need(q['runtime_write_spans'] == [[a,a+n] for a,n in elf.mutable], 'QEMU exact split write policy')\n    need(q['elapsed_seconds'] <= 125, 'bounded QEMU deadline plus cleanup observation')\n    need(q['status']",1)
(p/'check-hp1020-entry-usb.py').write_text(imports+constants+fixed+'\n\n'+base+'\n'+helpers+'\n\n'+elf+'\n'+registers+'\n'+ledger)
