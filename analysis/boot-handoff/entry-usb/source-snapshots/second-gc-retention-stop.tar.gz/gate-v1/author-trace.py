from pathlib import Path
p=Path('/tmp/hp1020-entry-usb-gate-draft-20261003')
old=(p/'inputs/check-hp1020-entry-ram.py').read_text()
s=old[old.index('def gunzip'):old.index('class Ledger:')]
s=s.replace('def model_trace(folder, model, images, elf, cps):','def model_trace(folder, model, images, elf, cps, addresses, source):')
s=s.replace("         all(pcs.count(at) == (2 if name == 'park' else 1) for name, at in cps.items()),\n         'one entry, four unique checkpoints and two actual park iterations')", "         all(pcs.count(at) == (2 if name == 'park' else 1) for name, at in cps.items()\n             if name != 'pre-final-service'),\n         'one entry, unique close/finish and two actual park iterations')")
s=s.replace('    call_index = 0; call_stack = []','''    call_index = 0; call_stack = []
    entry_cursor=0; selected={elf.symbol(n):n for n in ENTRY_NAMES}
    need(len(selected)==len(ENTRY_NAMES),'unambiguous selected actual function entries')
    entries=model['actual_entry_events']; acquired=0; awaiting_service=False
    checkpoints_index={}
    prior_entry_names=[]
    service_indices=[]; acquire_indices=[]; pump_indices=[]
    counts_at={}; entry_counts=Counter()
''')
s=s.replace("        for label, at in cps.items():\n            if pc == at and label not in seen:", """        if i and pc in selected:
            need(entry_cursor<len(entries),'missing actual selected function-entry event')
            event=entries[entry_cursor];entry_cursor+=1;name=selected[pc]
            need(event['name']==name and event['pc']==pcs[i-1] and event['target']==pc and
                 event['instruction']==i and STACK[0]<=event['sp']<=sum(STACK) and event['sp']%16==0 and
                 len(event['arguments'])==6 and all(type(x)is int and 0<=x<=0xffffffff for x in event['arguments']),
                 'actual natural function-entry event tied to raw instruction transition')
            check_entry(event,ram,addresses,source,entry_counts,acquired,awaiting_service)
            entry_counts[name]+=1;prior_entry_names.append(name)
            if name=='hp1020_udc_acquire_packet':
                acquired+=1;awaiting_service=True;acquire_indices.append(i)
            if name=='hp1020_udc_publish_service':
                service_indices.append(i)
                if awaiting_service:awaiting_service=False
            if name=='hp1020_tusb_adapter_pump':pump_indices.append(i)
        for label, at in cps.items():
            if label=='pre-final-service' and 'pre-close' not in seen:continue
            if pc == at and label not in seen:""")
s=s.replace('                seen.append(label)','''                seen.append(label)
                checkpoints_index[label]=i
                counts_at[label]=entry_counts.copy()
''',1)
s=s.replace('allowed = MUTABLE if started else ZERO if', 'allowed = elf.mutable if started else elf.zero if')
s=s.replace("elf.symbol('hp1020_entry_c')", "elf.symbol('hp1020_usb_runtime_c')")
s=s.replace("'all four actual trace checkpoints'", "'all six staged actual trace checkpoints'")
add='''    need(entry_cursor==len(entries) and not awaiting_service and acquired==13,
         'complete original entry/acquisition/service evidence')
    need(model['actual_close_entries']==model['actual_finish_entries']==1 and
         model['zero_spans']==[list(x) for x in elf.zero] and
         model['owned_stack']==list(STACK) and model['initialized_data_span']==list(elf.initialized_data),
         'model declared entries and dynamic exact memory policy')
    close=checkpoints_index['pre-close'];service=checkpoints_index['pre-final-service']
    finish=checkpoints_index['pre-finish']
    need(acquire_indices[-2]<close<acquire_indices[-1]<service<finish and
         not any(close<x<service for x in service_indices) and
         any(service<x<finish for x in pump_indices),
         'natural close then final original acquisition then NEXT service then empty pump/finish')
    expected_counts={'hp1020_usb_runtime_c':1,'hp1020_usb_document_init_documents':1,
        'hp1020_tusb_adapter_init':1,'hp1020_udc_setup_bus_reset':1,
        'hp1020_udc_setup_offer':1,'hp1020_udc_setup_dispatch':1,
        'hp1020_udc_ep0_take_submission':1,'hp1020_udc_ep0_observe':1,
        'hp1020_tusb_adapter_ack_reset':3,'hp1020_tusb_adapter_finish_reset':1,
        'hp1020_usb_document_restart':1,'tusb_rhport_init':1,
        'hp1020_udc_publish_arm_out':13,'hp1020_udc_acquire_packet':13,
        'hp1020_tusb_adapter_close_input':1,'hp1020_tusb_adapter_finish':1}
    for name,n in expected_counts.items():need(entry_counts[name]==n,'natural call count: '+name)
    need(entry_counts['hp1020_usb_document_init']<=1 and
         1<=entry_counts['hp1020_tusb_adapter_pending_reset']<=256,
         'single document initialization and bounded recovery query')
    need(16<=entry_counts['hp1020_udc_publish_service']<=256 and
         13<=entry_counts['hp1020_tusb_adapter_pump']<=256,
         'bounded complete ordinary service/pump schedule')
    for stage in ('pre-close','pre-final-service','pre-finish','park'):
        w=struct.unpack('>256I',part(images[stage],*MAILBOX));seen_counts=counts_at[stage]
        # Counters count returned calls; the actual observed entry has not run.
        pending_service=int(stage=='pre-final-service')
        need(w[20]==seen_counts['hp1020_udc_publish_service']-pending_service and
             w[21]==seen_counts['hp1020_tusb_adapter_pump'],
             stage+': mailbox actual service/pump returns match entry trace')
'''
s=s.replace("    special = [('intenable'",add+"    special = [('intenable'",1)
with (p/'check-hp1020-entry-usb.py').open('a') as f:f.write('\n\n'+s)
