# Independent continuous USB-entry raw gate — frozen, unexecuted

Author: `/root/usb_reference_contract`, 2026-10-03. Intended repository filename
`scripts/check-hp1020-entry-usb.py`; public API
`check_capture(capture_root, source_root=None) -> (bool, detail)`.
Only stdlib is imported. No producer, oracle, audit, machine or candidate module
is imported. Raw files are read only; no mutation, executable, debugger, target
or hardware call occurs. This draft was not parsed, imported or executed.
Root alone owns subsequent static review and all sequential execution.

The first plan/literal source and additive acceptance package are retained
unchanged under `inputs/addendum/`. The new runtime/provider implementation was
not read. Expectations were frozen before that implementation began. The raw
format was read from root's unexecuted observer/runner drafts, also copied in
`inputs/`; build-unit names came from the public builder. OPEN_MASK's previously
unspecified diagnostic encoding is separately recorded in the approved small
clarification. Production program masks are unchanged.

## Review map

The accepted old `check-hp1020-entry-ram.py` is copied with its exact input hash.
`old-to-new.diff` is a review aid, not an executable patch dependency.

- Retained neutral readers: safe relative paths, bounded reads/JSON/seals,
  region slicing, complete register/window alias and snapshot validation,
  protected-byte checks, literal input352, bounded compressed trace readers,
  actual instruction-width/property reader, coarse load/store decoder, signed
  J/CALL decoder, exact GDB request/reply ledger class.
- Updated ELF admission:15 actual PT_LOADs;20 allocated sections; separate
  bounded generic `.bss` and initialized `.data`; full document memory,
  own stack/mailbox/witness/sentinel and immutable islands. Only actual file
  bytes overlay the paint. NOLOAD zeroing is never inferred from ELF memsz.
- Independent public layout: all457 compiler-emitted words compared with the
  embedded manual16-object/101-field table; actual symbol addresses, sizes,
  alignment and nonaliasing are separately checked. The private core68 and
  actual getter load52/mask1/base literal are independently admitted.
- New literal RAM checks: generation2, original EP0 and bulk identities,
  separate retained image-cookie vs current owner, exact4096 receive bytes,
  full32768 output slots, descriptor16, EP0 memory160, SETUP16, complete witness
  9216 (all240 commands,65 ranges,14 binds, guards/padding, two real event rows
  and64 FF), receive/ring metadata and actual private endpoint bytes.
  Mailbox/provider counters never replace actual component reads.
- New continuous replay: six natural stages and the service stop enabled only
  after first close; exact initial source/CPU; memory access record per actual
  load/store and replay through all seven captured images; call/return stack;
  natural selected API transitions including tail jumps; real cookie arguments
  and API-entry RAM ownership; all13 poison→acquire→PENDING service lifetimes;
  no service between close and final acquisition; one final document EOF.
  Every BSS/sentinel/initialized-data byte must have been read by actual C
  before its first non-stack write. All initial paints/unused gaps stay checked.
- Retained debugger anti-repair proof, enlarged only to six ordered stages:
  one exact initial seed, WB before all32 distinct physical ARs, full readback,
  six Z0/current-PC continue/full capture/z0 sequences and two real self-steps.
  All request/reply bytes are tied to raw snapshots. No addressed continue,
  post-lock write, helper call, hidden CPU reset or extra debugger traffic.
- Source/tool closure: exact frozen independent/public/shared/primary inputs,
 26 compiler dependency/object/stack-use groups plus startup, actual subordinate
  tools and captured external headers/effective TinyUSB bytes. The old observer
  still enforces120s/4096-command/16MiB bounds; instruction replay caps10million.

One ABI detail was checked against already saved acquisition ELF bytes, not
new results: a three-byte BE struct argument is right-justified in its call0
argument word. SETUP facts are a4 low24; acquisition's stack facts occupy
incoming SP+5..7, after endpoint_fault at SP+0. The complete20-byte cookie retains
its endpoint in the high byte of its fifth word. Relevant old disassembly is
already sealed in the private-core input package: acquire at20007ab4, dispatch
at2000d63c, and observe at2000765c. No new target execution was used.

## Limits and first-run policy

This checker is not a second general Xtensa emulator. It independently decodes
instruction lengths, memory widths, literals, direct calls/jumps and actual
record ordering, replays the complete RAM transcript, and compares native state;
it does not recompute all ALU/conditional-branch results. Selected API argument
records are tied to exact raw instruction transitions; native checkpoints also
verify original close/service/finish pointer registers. Root's separate whole
linked opcode/ABI/property and source-bound stack audit remains required.
Neither the model nor QEMU supplies physical CPU/RAM/USB/cache/settlement,
controller initialization, IN wire ACK, engine output or printing evidence.

Both loops, maps and all events are supplied offline. The first larger linked
closure may fail admission or execution. Preserve this exact gate and first
captures before correcting any gate/candidate mismatch; no hash normalization
or retroactive passing outcome is permitted.
