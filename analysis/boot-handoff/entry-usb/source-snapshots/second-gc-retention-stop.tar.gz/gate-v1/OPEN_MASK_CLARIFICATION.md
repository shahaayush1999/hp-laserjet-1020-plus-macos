# Public diagnostic clarification before execution

2026-10-03. Root approved this clarification while the gate/provider were still
being drafted, before any candidate build or execution. The original independent
oracle and additive package remain unchanged.

Provider and mailbox OPEN_MASK use the actual DCD-open diagnostic convention:
bit0 EP0 OUT, bit1 EP0 IN, bit2 bulk OUT1, bit3 bulk IN1. Initialization is3;
successful configuration is15. This is separate from the unchanged production
program component's completed_mask/selection_mask, whose bulk-only value is3.
The frozen public header named the diagnostic but did not specify its bit order.
The clarification introduces no controller command, endpoint owner or hardware
promise and is not derived from observed candidate results.
