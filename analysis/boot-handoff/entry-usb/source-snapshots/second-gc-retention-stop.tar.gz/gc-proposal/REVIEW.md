# Static review: conservative section garbage collection

2026-10-03, independent review. **Unapplied/unexecuted proposal** only. No build,
candidate script import, parser, validator or target execution was performed.
The original failed first link remains preserved in
`/tmp/hp1020-entry-usb-fowelz80`; it did not execute target instructions.

## Recommendation

Use ordinary `--gc-sections` with the already emitted function/data sections,
explicit observation roots, and retained evidence/mutable allocations. Do not
change source C, production buffers, alignment, ABI or any fixed RAM/code cap.
`changes.patch` changes only the linker script and link command; copies of both
exact first-failed-build originals are in `original/`.

The failed map reports `.text` start10003000/size0xd4b5, then `.rodata`
start100104b8/size0xf08, ending100113c0. The code/constant cap remains1000ffe0:
the failed output exceeds it by0x13e0=5088 bytes. No memory budget or expected
layout table is reinterpreted to accommodate this. A fresh link must measure
whether GC is enough; this review does not promise the resulting size.

The failed map includes whole unused surfaces such as JBIG encoder functions,
`hp1020_udc_program_grant`, typed-selection and cleanup APIs, TinyUSB endpoint
stream/FIFO helpers, and overridden weak callback bodies. Example retained
sections before GC: program grant0x376, complete_selection0x22d,
publisher pending_cleanup0x5b/ack_cleanup0x137, JBIG lineout0x568. These are
examples of possible unreachable sections, not a manually selected removal list
or an independently proven aggregate saving. The relocation graph decides.

## Exact retention policy

- `ENTRY(hp1020_entry_start)` and all existing `KEEP` startup/vector/interface/
  sentinel/memory/mailbox/witness sections remain unchanged. Startup's literal
  references and C CALL0 retain the actual entry path; vector targets stay inert.
- `EXTERN(...)` lists exactly the20 named entries observed by the frozen machine.
  Most are already reached by C. `hp1020_usb_document_init` is deliberately kept
  even though this profile uses `_init_documents`: a real named entry with zero
  invocations is required, not a missing symbol interpreted as zero.
- `KEEP(*(.rodata.hp1020_usb_runtime_layout))` retains the1828-byte const witness
  even though target C does not read it. Its values remain actual
  sizeof/alignof/offsetof expressions. Input352, facts40 and raw SETUP16 are
  ordinary actual referenced constants and remain in the reachable graph.
- All ordinary `.bss/.bss.*/.sbss/.sbss.*`, `COMMON` and initialized
  `.data/.data.*/.sdata/.sdata.*` inputs are retained. With the existing custom
  object KEEP rules, all29 public/private mutable objects remain mandatory:
  sixteen public objects, sentinel, twelve private TinyUSB/adapter objects.
  The existing input-object and linked mutable closure checks remain strict;
  an unknown object is rejected, not excused as unused.
- `KEEP(*(*))` in `.unexpected` preserves the prior unknown-input failure
  intent under GC. Without it, a new orphan could be discarded before the
  existing zero-size ASSERT sees it. This does not retain text/data already
  matched by earlier output patterns.
- Keep the current `.xt.prop/.xt.lit/.xt.insn/.xtensa.info` metadata rules and
  ordinary debug families. Do not turn all text/rodata into KEEP or enable
  `--gc-keep-exported`; that would defeat the bounded relocation closure.

## Xtensa properties and callbacks

Pinned primary BFD source `bfd/elf32-xtensa.c` has exact SHA256
`7b39140c5c2f5d59c12da1f1c843cb20399a693a9d0848090cbca4068b504040`.
At1254..1281, `elf_xtensa_gc_mark_hook` explicitly declines to follow property
section relocations: kept property tables do not keep every described function.
The accompanying comments require `elf_xtensa_discard_info` to remove entries
for discarded sections; its concrete loop and relocation adjustment are
at3480..3630. Thus no speculative removal of architecture metadata is needed.
The linked audit must still inspect the newly emitted property entries, literal
ranges, alignment/fill and all direct/dynamic branch boundaries.

The actual custom class-driver table, synchronous output/document callbacks,
program I/O/cache hooks, cancellation callback and TinyUSB OSAL interrupt
callback are kept through real pointer relocations from reachable initialization
or retained initialized data. No plugin/dlsym/string-resolved function is used.
Weak TinyUSB defaults should be discarded after normal strong-symbol resolution,
while the application's actual strong DCD callbacks remain whenever reached.
Do not manufacture direct calls to keep indirect callbacks or root all functions
in a translation unit. New linked function-pointer/indirect-call review remains
necessary; unchanged C does not imply unchanged literal addresses or byte layout.

`usbd_edpt_busy` is reached by actual production/provider calls and its exact
size/load-offset/mask audit stays mandatory. All20 observed names must exist as
real function symbols in the new ELF. Retain every26 C input object, startup.o,
all26 `.su` files, map, emitted assembly, build log and source closure even when
some input functions are discarded. Input metadata is evidence, not execution
permission. Existing stack-use collection accepts input-only functions and
does not demand that every .su record remain linked; a new reachable callback
stack analysis is still required before execution.

## Inputs

- First map SHA256 `2e3db9d3bc92260b810b3cdb9396cb1ee2bfcb87ec53783f6ee3f956b4eed91f`.
- First build log `e95e06108520a08aac05c954cdbdb7de1b525fb8c6c19a274ef4cc3fa67f4fa1`.
- Original linker `096597da3ccce35a61f0e9edb1ea7ebd87765764d900f26fca0c2d25e63bb073`.
- Original builder `e2897952cdfc2c0212d266464082e696aec60b0bdc13c26bb8cec998da548b1d`.
- Frozen machine `377cdd771447a4d69040a5624ef1fafc7593fea50fc471ccd7f8a0ff1077466a`.
- Frozen audit `43147ff89049c2006194921350901bc5ffce926919bb8792ea1fa1bff185b959`.

All copied inputs are in this package and sealed. Root owns application, the
next audit-only link, any discovered linker/audit correction and all execution.
