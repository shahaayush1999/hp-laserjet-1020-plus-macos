# V2: one pre-execution source-closure path correction

2026-10-03. V1 remains unchanged at
/tmp/hp1020-entry-usb-gate-draft-20261003/check-hp1020-entry-usb.py,
SHA256 f60498578bc3159e7473f645e4e143dc69ee8b04674c00c4dd959c2ba93bbb3d.
Its full source copies, independent oracle/addendum, review map and planned
controls remain sealed by DRAFT.sha256
a9593677f3f4fef6199a25a0978cfd28bd5817932a1343fd49933e6421b6b8f6.

Root's static review identified the incorrect required-source pathname:
open-firmware/tinyusb-device/protocol-compatibility.patch.
The actual pinned input and existing runner source collector use
open-firmware/tinyusb-device/patches/protocol-compatibility.patch.
V2 changes this one string only. It does not change expectations, input bytes,
semantics, admission, effect interpretation or source hashes. No candidate result
was consulted, and no gate parse/import/execution/build/test was performed.
Root approved this narrow correction before the first audit-only target build.
