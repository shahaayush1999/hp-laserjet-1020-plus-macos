# Independent static provider review

2026-10-03. Scope: the frozen RAM provider and compiler layout witness for the
single approved entry-owned USB runtime. This is a source-level review, not a
build, import, parse, audit execution or candidate run. The reviewer made no
repository or provider-source changes and performed no hardware operations.

No concrete blocking defect was found in this fixed healthy schedule. The
separate initial link-budget stop does not validate or invalidate its behavior:
the lead reported a build-only stop before any target instruction executed.

## Exact reviewed inputs

The package includes unchanged source copies and `INPUTS.sha256`. Original
provider source directory is `/tmp/hp1020-usb-runtime-provider-draft-20261003/`.
Contract, production and orchestrator copies came from the repository's
`open-firmware/` tree. Key frozen hashes:

- `hp1020_usb_runtime_ram.c`: `f0af91498c209854245727afca963184238c1005e55bdcf05a963a18956e3302`
- `hp1020_usb_runtime_layout.c`: `fa447a205b9305343adc3bad2ff4aa1273df038ae05b340e7365d9527cf7f02a`
- Provider `DRAFT.sha256`: `d285cade0a032b88ab77ff6bce266ec34acb1f0346199ff4811d2c74f868b80b`

All provider and layout source was read. Production reads were targeted to the
actual initialization, bind, arm/unwind, publication, acquisition, retirement,
pump and finish contracts; this is not a new whole-production-code review.

## Consequential checks

`ram_init` preserves the root's completed initial scan and first step. It writes
only the eight declared witness guards, then calls real initializers in their
required order before TinyUSB can call the DCD. All writable objects are the
approved stationary public objects, including the unchanged full document
memory. The layout translation unit has only its const 457-word table; its
records use compiler `sizeof`, `_Alignof` and `offsetof`, with no runtime writes
or implementation-derived expected addresses.

The before-device cache hooks correctly inspect the actual adapter owner inside
the synchronous DCD callback. The adapter deliberately keeps `prepared` and
`stack_active` set until that callback returns. The provider does not require a
retained record that cannot exist yet. Exact cookie, selected receive pointer,
64-byte range, mapping and literal prepared descriptor are checked before a
cache-intent row is accepted. Payload bytes are compared to the genuine DCD
entry snapshot. No descriptor or payload visibility is claimed from a write.

After `prepare_and_publish` or EP0 preparation returns, `bind_record` saves the
actual bound owner before any later cookie/result check. Thus a post-bind false
return still leaves an original-cookie record for the adapter's cancellation
request after unwinding. The cancellation callback records only that request;
it neither calls a component recursively nor releases borrowed storage. This
schedule fails on cancellation rather than pretending to exercise recovery.

Bulk source installation requires the original retained image/owner identity,
EXPOSED component, exact mapping and no active adapter operation before changing
either image or CPU storage. The 16-byte descriptor and 64-byte payload source
are distinct from the CPU destinations. Acquisition hooks recheck the actual
owner and original image independently, while the production OUT component is
locked. Only successful range hooks copy their prescribed spans; the production
observer then reads the acquired descriptor after the ordering hook. Moving to
a new scope invalidates the prior image without restamping its original cookie.

`ram_retired` accepts only original-cookie SUCCESS with matching actual length,
component FREE and adapter PENDING. It clears the provider's live byte only;
cookie, pointer, requested length and the adapter notification remain intact.
The same path covers the final supplied ZLP without introducing EOF,
cancellation, receive release or fake TinyUSB completion. EP0 uses the genuine
NULL/zero-length original borrow and separately allocated staging; its supplied
low-ffff descriptor field is not used as actual IN length.

Register reads consume independent immutable observations in the frozen order.
Writes and barriers only record attempted arguments. Kind3 uses `UINT32_MAX`
and kind8 uses zero, matching the independently frozen distinction. The scope
read count must be exhausted before the next scope; no write feeds a read back.

Output validates the actual ring and storage bounds, accepts the returned slot,
copies its actual bytes, then completes that same slot. Document callbacks copy
the real event fields. Neither callback contains expected pixels or identities.
Both reject callbacks after the explicit close phase and avoid USB stack
reentry. `ram_note` records state and full-storage hashes without servicing,
acquiring, retiring or repairing any owner. Acceptance must continue to inspect
raw state, rather than treating these secondary snapshots as authority.

The root-approved OPEN_MASK clarification is consistent with actual callbacks:
EP0 initialization contributes bits0/1; successful bulk opens add bits2/3.
The program component's independent two-bulk-endpoint mask is unchanged.

## Limits and next required evidence

The provider intentionally implements one fully supplied healthy experiment.
Unexpected requests, DCD operations and cancellation fail that experiment;
this review does not establish general USB/DCD behavior or recovery. CPU/DMA
mapping, global receive readiness, cache effects, physical settlement and the
three reset promises remain explicit supplied facts. No hardware ACK, physical
register effect, interrupt provenance or printer behavior follows from a log.

Actual target layout, retained static constants, whole annotated instruction
closure, initialized TinyUSB pointers and linked callback frames still require
the lead's successful build/audit. The preceding document-only 784-byte bound
does not apply. Compiler garbage collection may remove dead functions, but it
must preserve every fixed public/private mutable object and required observation
entry. Full ET_REL source/initializer inspection and linked executable/property
inspection remain separate gates; discarded code must not cause unannotated
linked bytes, unresolved callback targets or broadened writable spans to pass.

No correction to the frozen provider C or layout C is recommended by this
bounded read-through.
