# Approved public capture schema and independent pins

2026-10-03. Schema supplied by `/root/printer_class_reuse` and approved by root
before candidate execution. Root requested a provenance-only V3 and confirmed
that `tool_closure.libgcc` remains its existing path/sha256 pair.

All four files are relative to `target/libgcc/`, with no extra member files:

```json
{
  "schema": "hp1020-entry-usb-libgcc-v1",
  "archive": {
    "file": "libgcc.a",
    "original_path": "<canonical actual compiler-selected absolute path>",
    "sha256": "e57e97f0f5679a83f5a394d94fe024973f05d32be292293b247e647e567c4e32",
    "bytes": 878846
  },
  "members": {
    "_udivsi3.o": {
      "file": "_udivsi3.o",
      "sha256": "6e2ed6774b25c833f8071872d6f7b699838e22f625bdb215cd21eea34a96814a",
      "bytes": 2612
    },
    "_umodsi3.o": {
      "file": "_umodsi3.o",
      "sha256": "f7cb9b22bf91ae5b5f40f06a9c2ad1d4e16ea5a7e7be8631e7f2595d89c3e5ee",
      "bytes": 2368
    }
  }
}
```

The author separately confirmed this pinned archive is ordinary GNU ar:
`!<arch>\n`, short `name/` headers, optional `//` long-name table and decimal
name offsets; no BSD extended-name support is required. V3 decodes actual
container bytes independently and checks exact member payload equality.

Selected members are derived from actual `target/entry-usb.map`, not a new
manifest label. Original26 C/one startup objects remain at target root; only
the two specifically named object files are allowed beneath this subtree.

This schema note records pre-execution source/tool provenance supplied for
the independent gate. It is not an observed lifecycle or successful admission
result. Neither the helper nor candidate implementation was imported/executed.
