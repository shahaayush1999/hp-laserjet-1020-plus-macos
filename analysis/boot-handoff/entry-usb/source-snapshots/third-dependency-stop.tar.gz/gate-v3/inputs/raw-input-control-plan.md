# Independent raw-input admission controls — planned, unexecuted

2026-10-03, `/root/usb_reference_contract`. Root owns all future execution.
No candidate C, target result, import, build or validator was inspected/executed
for this plan. These are bounded mutations of private copied raw ET_REL objects
(and the copied input-file set), never changes to source or accepted captures.
The original semantic gate V2 remains unchanged.

## Public admission contract

Author's stable helper API is `check_raw_input_sections(unit, sections)`, where
`sections` is output of the existing independently bounded `read_relocatable`
reader. Every input section is examined, including empty and nonallocated rows;
only the explicitly listed observed name-family/type/flags/alignment/entsize
combinations are admitted. This precedes ordinary linker garbage collection.
Existing exact27 compiler/startup input closure,29 mutable-object closure and
NOLOAD initializer/relocation checks remain separate and required. Exactly two
selected libgcc member files are added: `_udivsi3.o` and `_umodsi3.o`.
No instruction execution is part of any control below.

Before each mutation, the future driver must read a fresh copied object, assert
its ELF32BE/EM_XTENSA/ET_REL header, locate the named section by its actual
shstrtab and record the complete original and changed file SHA256. It must
validate its own changed ELF offsets/lengths and mutation before calling the
admission API. Never mutate the originals or relax admission on a negative.
The unchanged copy must pass the same entry point first.

## Six mutations and intended rejection boundary

1. **Unreachable executable family with wrong flags.** In a compiler object's
   existing `.text.<name>` PROGBITS section, preferably the unused public
   `hp1020_udc_ep0_cancelled`, change only sh_flags from6 to2. Keep size, type,
   bytes, relocations and all other header fields exact. This is still a bounded
   object; the raw family contract must reject missing SHF_EXECINSTR even if GC
   would discard the routine. Select an actual existing symbol/section instead
   of assuming its index. Intended error: code family flags/type.
2. **Unknown empty, nonallocated section.** Append a valid zero-size PROGBITS
   section named `.hp1020_unadmitted`, flags0/address0/alignment1/entsize0. Extend
   a copied shstrtab and section table correctly, leaving every original row and
   byte unchanged except the required table-location/count fields. This exercises
   the easy-to-miss empty/nonalloc case; no final output section is needed.
   Intended error: unknown raw section family, not generic malformed bounds.
3. **Hidden nonzero NOLOAD initializer.** In a custom writable input allocation
   that the existing object gate expects to be zero (for example
   `.runtime_memory`), set one file-backed zero byte to1, preserving the admitted
   family/type/flags and exact object symbol/extent. Prefer an existing PROGBITS
   custom allocation so one byte suffices; do not change a NOBITS section merely
   to make the fixture work. Intended error: the retained original mutable-object
   check detects an initializer that final NOLOAD would discard. The family-only
   helper is not falsely credited for this older, separate obligation.
4. **Invalid relocation target.** In an existing nonempty SHT_RELA row, change
   only sh_info to0, preserving contents, valid symbol-table link and table
   bounds. The original parser must reject the target before family admission
   or linking; no malformed relocation can hide in a discarded input section.
   Intended error: original relocation target/shape. Do not report this as a new
   opcode safety test or a family-only rejection.
5. **Unknown selected-libgcc allocated family.** In copied `_udivsi3.o` or
   `_umodsi3.o`, change only the section-name string of an existing nonempty
   `.literal` or `.text` family to an equal-length unknown family (for example
   `.literal`→`.xiteral`). Preserve type/flags/raw bytes/symbols/relocations.
   Invoke the raw object/family gate directly so the negative tests admission,
   not the expected top-level archive hash mismatch. The driver should separately
   show that full provenance rejects a modified extracted member. Intended
   semantic error: no special library exemption for unknown raw families.
6. **Extra selected-member input.** Add an untouched third actual ET_REL member
   from the copied same libgcc archive (e.g. `_divsi3.o`) to the supplied extracted
   member set, while leaving the two expected member bytes exact. For the
   closure-level call, describe the three-file set honestly rather than passing
   stale hashes. The admission must reject selected names other than exactly
   `_udivsi3.o`/`_umodsi3.o`, regardless of the third member's otherwise valid
   sections. Intended error: selected-member closure, not unknown archive content
   (the complete archive legitimately contains many unselected members).

One mutation per isolated copy; stop if its precondition is absent and choose
another existing section with the same documented role. Never silently switch
the intended rejection mechanism. Record the exact API layer and exception/
reason for every rejection. Controls1,2,5 are new all-section-family controls;
3 preserves existing NOLOAD safety,4 preserves original parser safety,6 checks
new selected-library closure. Passing these controls establishes only that
these copied invalid inputs are rejected; it is not a new firmware lifecycle,
physical boot result or proof of DMA/USB/printing safety.

## Narrow raw-capture provenance change

The new immutable capture subtree is `target/libgcc/` with exactly four files:
`libgcc.a`, `_udivsi3.o`, `_umodsi3.o`, `manifest.json`. The manifest schema is
`hp1020-entry-usb-libgcc-v1`; archive/member entries contain file,bytes,sha256,
with archive also containing original_path. The complete archive must hash to
both its manifest and the recorded actual `tool_closure.libgcc`; the original
path must match that actual tool identity. Independently decode the bounded ar
headers and compare the two extracted byte payloads, not just their labels.
Derive selected member names from actual `entry-usb.map` references.

Raw-gate V2's26 C .d/.su sets stay unchanged. Its .o set expands only by the two
explicit `libgcc/<name>.o` paths; the original27 top-level .o files stay exact.
Source/code semantics, CPU/register/memory evidence and literal expectations
must remain byte-identical. A separate V3 with a small diff and provenance note
is appropriate; no post-execution semantic adjustment is authorized by this plan.
