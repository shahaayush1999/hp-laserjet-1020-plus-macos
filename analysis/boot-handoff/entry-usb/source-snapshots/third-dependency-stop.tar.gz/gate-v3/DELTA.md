# V3: captured compiler-library provenance only

2026-10-03, `/root/usb_reference_contract`. Frozen for root review before any
continuous USB-runtime candidate instruction. No checker parse/import/run,
build, candidate C inspection or result-based adjustment was performed here.

V2 remains byte-identical at
`/tmp/hp1020-entry-usb-gate-v2-20261003/check-hp1020-entry-usb.py`, SHA256
`6f3d84609aa1572fd7fdc765d4de2566ecc7008826bf3e44ab5d38287628f868`.
Its exact checker is also retained as `checker-v2.py`; its manifest is copied
under `inputs/`. V1, original plan/literals, additive literals/manual layout,
all CPU/ownership/pixel/event expectations and their fixed hashes are unchanged.

Root approved preserving complete compiler-library bytes while allowing normal
garbage collection, with an independent pre-link raw-input admission check.
The initial `KEEP(*(*))` accidentally rooted otherwise unused inputs. The new
raw-input helper is separately authored/reviewed; V3 does not duplicate it or
weaken the existing linked/source-bound admission obligation.

This checker delta adds only:

1. The exact independently supplied library archive/member lengths and SHA256s.
2. An exact four-file `target/libgcc/` subtree and provenance-manifest check.
3. A bounded ordinary GNU ar reader, with short names and its `//`/offset long
   names. It invokes no external `ar` program and admits no BSD/thin encoding.
   The two captured object files must be byte-identical to their archive payloads.
4. Actual linker-map member references must select exactly `_udivsi3.o` and
   `_umodsi3.o` from the same recorded original library. Saved `/tmp`/`/var`
   spellings are normalized lexically to macOS `/private` aliases; no original
   disposable path is opened or resolved during evidence recovery.
5. The object-file set expands only by `libgcc/_udivsi3.o` and
   `libgcc/_umodsi3.o`. The original27 top-level objects and26 `.d`/`.su` sets
   remain exact. Every new archive/member/manifest byte is still covered by the
   existing complete target-tree seal.

The existing `tool_closure.libgcc` schema stays `path`/`sha256`. Archive length
is independently measured and required to be878846; the manifest must name
that exact length/hash and the same canonical original path. No new runner
field is required. The full archive can legitimately contain unselected
members; the selected captured/link-map closure remains exactly two.

`v2-to-v3.diff` is the complete reviewable code delta. The independent six-control
plan is copied under `inputs/`; it is unexecuted, and the raw-family, NOLOAD,
relocation and closure rejection mechanisms are explicitly kept distinct.
Root alone owns subsequent syntax review, integration, builds and execution.

This provenance check does not establish target execution, physical boot,
controller support, DMA/cache effects, host acknowledgement or printed output.
