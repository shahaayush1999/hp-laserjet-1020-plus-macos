from pathlib import Path
import sys,json,hashlib,importlib.util
root=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('usb_audit_inventory',root/'scripts/hp1020_entry_usb_audit.py')
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
cap=Path('/tmp/hp1020-entry-usb-4pwujqqp')
out=Path('/tmp/hp1020-entry-usb-raw-input-inventory-20261003');out.mkdir(exist_ok=False)
report=json.loads((cap/'validation.json').read_text())
lib=Path(report['tool_closure']['libgcc']['path']);archive=lib.read_bytes()
assert hashlib.sha256(archive).hexdigest()==report['tool_closure']['libgcc']['sha256']
assert archive[:8]==b'!<arch>\n'
members={};long=b'';off=8
while off<len(archive):
 hdr=archive[off:off+60];assert len(hdr)==60 and hdr[58:]==b'`\n'
 name=hdr[:16].decode('ascii').strip();n=int(hdr[48:58]);body=archive[off+60:off+60+n];assert len(body)==n
 if name=='//':long=body
 elif name.startswith('/') and name[1:].isdigit():
  name=long[int(name[1:]):].split(b'/\n',1)[0].decode('ascii');assert name not in members;members[name]=body
 elif name not in ('/','/SYM64/'):
  name=name.removesuffix('/');assert name not in members;members[name]=body
 off+=60+n+(n&1)
assert off==len(archive)
inputs={p.name:p.read_bytes() for p in sorted((cap/'target').glob('*.o'))}
for name in ('_udivsi3.o','_umodsi3.o'):
 inputs['libgcc/'+name]=members[name]
rows={}
for name,body in inputs.items():
 p=out/name;p.parent.mkdir(exist_ok=True);p.write_bytes(body)
 sections,symbols,relocs=a.read_relocatable(body)
 rows[name]={'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body),'sections':sections,'symbols':symbols,'relocations':relocs}
(out/'inventory.json').write_text(json.dumps({'libgcc_path':str(lib),'libgcc_sha256':hashlib.sha256(archive).hexdigest(),'inputs':rows,'status':'read-only-input-inventory-no-target-execution'},indent=2)+'\n')
family={}
for name,row in rows.items():
 for s in row['sections']:
  key=(s['name'].split('.',2)[1] if s['name'].startswith('.') else s['name'],s['type'],s['flags'])
  family.setdefault(str(key),set()).add(s['name'])
print(json.dumps({k:sorted(v)[:7] for k,v in sorted(family.items())},indent=2))
print(out)
