# V2 integration points

Authored 2026-10-03; this package has not been imported, parsed, built or run.
Root owns integration, audit-only checks and all subsequent execution. It is a
replacement for the erroneous catch-all KEEP part of V1, not a replacement for
the full current audit module. Preserve V1 and both failed link captures.

1. Apply only `linker.patch` to the second-failed linker. Root has already made
   this single-line change for a separate link-only diagnostic. The resulting
   linker SHA256 is `235934f043f7b18741a1db960fd8a129d64e5075dad55b8aca87c2988348d74d`.
   Update the USB audit's linker pin only as part of the complete new admission
   integration; do not claim that the successful diagnostic link passed audit.
2. Add `import re` and the definitions from `raw_input_gate.py.txt` to the current
   USB audit. This is an insertion fragment: do not overwrite the module or its
   separate in-progress local libgcc trap/marker classification correction.
3. In `check_input_objects`, immediately after the existing call to
   `read_relocatable(raw)`, set
   `file_row['raw_sections'] = check_raw_input_sections(path.stem, sections)`.
   It must run for every one of the 27 objects before skipping zero-size or
   non-writable sections. Preserve all existing mutable-object, exact source
   unit, zero-input/relocation, 29-object and linked closure checks unchanged.
4. In `audit_target`, after ordinary input checks, call
   `selected_libgcc = check_selected_libgcc(path.parent / 'libgcc', path.with_suffix('.map'))`.
   Add `selected_libgcc=selected_libgcc` to the audit result. All copied selected
   members undergo the same raw section classifier, including their nonalloc
   sections, before target admission. No linked-ELF-only substitute is allowed.
5. Have the builder/runner preserve the exact compiler-selected full archive
   and selected member bytes under `target/libgcc/` before audit. The original
   archive must already match the captured tool closure. Archive and selected
   bytes are never regenerated from headers, disassembly or reports. The
   existing 27 top-level `.o` and 26 each `.d`/`.su` sets remain unchanged.
6. Extend target artifact capture and independent raw-gate provenance to seal
   the full four-file subtree, bind its archive path/hash to tool_closure.libgcc,
   and require its map-selection set. The audit fragment uses saved bytes only;
   it does not reopen the disposable toolchain archive. Preserve the raw inputs,
   map, GC log and emitted linked instructions even if the audit later stops.
7. Run the static copied-input admission controls separately before any target
   instructions. Keep the independently specified control plan's different
   assertions distinguishable: section admission versus original-byte seal.
   Existing NOLOAD-byte and relocation controls are still required. A semantic
   mutated-member classifier probe may directly call the raw-section helper;
   the actual complete audit must additionally enforce the fixed archive pin.

The exact manifest object is:

```json
{
  "schema": "hp1020-entry-usb-libgcc-v1",
  "archive": {
    "file": "libgcc.a",
    "original_path": "/private/tmp/hp1020-xtensa-gcc14/lib/gcc/xtensa-fsf-elf/14.3.0/libgcc.a",
    "sha256": "e57e97f0f5679a83f5a394d94fe024973f05d32be292293b247e647e567c4e32",
    "bytes": 878846
  },
  "members": {
    "_udivsi3.o": {
      "file": "_udivsi3.o",
      "sha256": "6e2ed6774b25c833f8071872d6f7b699838e22f625bdb215cd21eea34a96814a",
      "bytes": 2612
    },
    "_umodsi3.o": {
      "file": "_umodsi3.o",
      "sha256": "f7cb9b22bf91ae5b5f40f06a9c2ad1d4e16ea5a7e7be8631e7f2595d89c3e5ee",
      "bytes": 2368
    }
  }
}
```

All `file` members are relative to `target/libgcc`. Exact subtree files are
libgcc.a, _udivsi3.o, _umodsi3.o, manifest.json. No other file or symlink is admitted.
The original path is provenance and must agree with the map/tool closure; it is
not a request to read a live path during copied-evidence checking. Member names
selected by the actual map are derived independently, not asserted by a manifest
label. If a future legitimate build selects another helper, stop for review of
its raw bytes/source/semantics; do not silently widen this bounded profile.
