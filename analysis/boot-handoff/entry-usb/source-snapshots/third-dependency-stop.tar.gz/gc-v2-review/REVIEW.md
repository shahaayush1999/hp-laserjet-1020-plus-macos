# V2: admit raw selected inputs, then allow ordinary section GC

Static review only, 2026-10-03. No build, audit, parser import, validation or
target execution was performed by this agent. Existing objects were inspected
read-only and copied. Root performed separate failed links and a successful
link-only diagnostic; those are not evidence of an audit pass or runtime result.

The prior V1 review was wrong when it claimed that earlier output matching kept
`KEEP(*(*))` from retaining already matched inputs. Preserve that review and its
patch unchanged. The second failed link reproduced the same 5088-byte overflow.
The remedy is narrow: restore `.unexpected 0 : { *(*) } :NONE`, retain the
intentionally rooted startup/20 observed entries/layout witness/all mutable
allocations, and reject unknown raw input sections independently of whether GC
later removes them. Production buffers, fixed caps and workload expectations
remain unchanged. No manually chosen function or source module is removed.

## Primary source explanation

The exact local pinned binutils sources are preserved in this package:

- `ld/ldlang.c`, SHA256
  `9c99a96f22f286a74b0e5cf3cfcf83e679b4cc41773a6fbbdade40b548e9fd70`.
  `gc_section_callback` at6773..6783 sets SEC_KEEP for each wildcard match.
  `lang_gc_sections_1` at6788..6803 walks every wildcard before GC, rather than
  asking which earlier output assignment consumed a section. Therefore the
  catch-all KEEP rooted all text, including unreachable code.
- `bfd/elflink.c`, SHA256
  `bea81cd7566225178a82c4f7ce2890439810a88dd6f9ed93b35c12a55cd8c036`.
  `_bfd_elf_gc_keep` at13325 retains entry/undefined command roots. The ordinary
  mark/sweep at13381..13483 follows retained references. `elf_gc_sweep`
  at13132..13180 marks unretained sections SEC_EXCLUDE before output and only
  prints nonzero-size removals. The extra-section pass at13028..13128 can omit
  debug/special sections from an input with no retained non-note allocation.
  Thus neither the output `.unexpected` assertion nor discarded-section log
  alone establishes absence of unknown raw zero-size/nonalloc inputs.
- `bfd/elf32-xtensa.c`, SHA256
  `7b39140c5c2f5d59c12da1f1c843cb20399a693a9d0848090cbca4068b504040`.
  The property hook at1254..1281 declines to retain referenced code solely due
  to `.xt.prop`/`.xt.lit` metadata. Discard-information processing at3480..3630
  removes the corresponding property entries. Existing KEEP rules for that
  metadata remain appropriate; actual linked properties still require audit.

## Closed raw admission

Root's exact29-input inventory comes from second-run retained26 C units,
startup.o and the two actually selected libgcc members. The helper's families
are derived from those raw section headers, not from a successful output ELF.
Every header, including zero-sized placeholders, is classified. Type, complete
flags, alignment, entry size and auxiliary fields are checked; duplicate names
are rejected. Relocation sections must be RELA/I/12-byte, name their actual
independently admitted target, and link the one ordinary symbol table.

Admitted compiler families are PROGBITS AX text/literals, PROGBITS A rodata,
two actual one-byte merge-string names, NOBITS WA BSS, PROGBITS WA data, compiler
comment, exact Xtensa note/properties and ordinary symbol/string tables. Exact
custom startup sections are restricted to startup.o; the five custom mutable
families are restricted to the RAM provider. Only selected libgcc may contain
the five observed DWARF names, with their actual flags/alignment. Raw custom
zero-initialized allocations are still PROGBITS: existing actual zero-byte and
no-relocation checks must run before NOLOAD can discard their contents.

This deliberately rejects new unwind, TLS, constructors, linkonce/group, LTO,
compressed, dynamic, REL, arbitrary notes/debug families and unusual flags.
It also does not pre-admit unobserved `.sdata`, `.sbss`, `.xt.insn` or
`.note.GNU-stack` merely because broad linker patterns mention them. A later
toolchain/profile change needs a reviewed admission update. Family admission
does not prove instruction semantics; the separate linked byte/control-flow
audit and exact source closure remain mandatory.

Selected libgcc provenance is closed over the actual878846-byte archive with
SHA256 `e57e97f0f5679a83f5a394d94fe024973f05d32be292293b247e647e567c4e32`,
exact copied members `_udivsi3.o` and `_umodsi3.o`, the original map and the
runner's tool closure. Both members have19 raw sections and no nonempty mutable
allocation. Their map-selected names, complete bytes and section headers are
checked; diagnostic strings alone are insufficient. Every other archive member
is preserved in the full original archive but is not claimed as a selected
input or part of the target execution closure.

## Scope after correction

Root reported that a separate link-only diagnostic with the single KEEP fix
fits the existing cap:46320 code/rodata bytes and6896 headroom. This package
does not reproduce that link or turn it into a passing audit. The fresh linked
callback/stack proof, both compiler division helpers' inert trap/marker audit,
unknown-section controls, all raw admission checks and runtime validation remain
root-owned. The original public29-object closure,16-object457-word const layout
witness, full capacities, immutable acceptance literals and selected observation
entry roots must all continue to be required.

`raw_input_gate.py.txt` is an unexecuted insertion fragment, not a replacement
audit or another target model. `INTEGRATION.md` specifies the exact hooks and
four-file library capture schema. Inputs, predecessor versions and this review
are sealed separately; no historical report hash is rewritten.
