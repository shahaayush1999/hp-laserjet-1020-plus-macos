# Independent static review: exact-five GC shortcut proof

2026-10-03, `/root/adapter_review`.

No concrete blocker found in the saved diagnosis or frozen V5 delta. This is a
static source/evidence review, not an executed checker result. I did not import,
parse or run the checker, execute a candidate, rebuild a target, inspect the six
runtime-case outcomes, or change repository sources or the original failed
capture. The inspected files are copied under `inputs/` and sealed in
`INPUTS.sha256`; the diagnosis package retains all27 original input objects.

## Exact inputs

- V5 checker: `38f520c5d23834532806821d14ce9e5a8c3703d57935bcc923e453b43dece277`.
- V4 checker: `e6feb02335ef56b496dec4d1974e2866e18939a7be407a2346dfc8f28640bf2c`.
- V4-to-V5 diff: `eff1db82ddb6c31a15887760c3a7839c8833e118f3e726c2fedd7ff7ba66a59c`.
- Static diagnosis: `290d57408444c696d32769e7a0a9969c29910934a81fb2ca7773279c67085d58`.
- Original linked ELF: `5d20ef15633de527aaa2d92001c6e910006e3a26eefadd0512a1594884eddf3b`.
- Original map: `fd71ce444abd1dc78f0b61a71b2419b2c7214caf4d91a1759a3bfaf68ebc381e`.

The source packages are `/tmp/hp1020-entry-usb-gate-v5-20261003/` and
`/tmp/hp1020-entry-usb-gc-symbol-review-20261003/`. The accompanying full static
symbol/section listing agrees with each named original definition and the map
rows, independently of any producer execution summary.

## Diagnosis and correction

The V4 failure follows directly from its strict `Elf.symbol(name)` call before
the forbidden-PC predicate. All five named implementations have original input
definitions but no linked symbol; their map records are within the discarded
block. This explains the presence failure without treating it as proof that
the execution was otherwise correct.

V5 keeps the exception closed over the same five names. It reads every one of
the27 sealed ordinary ET_REL inputs, ignores undefined references, and requires
exactly one defined GLOBAL/FUNC record in the expected input object and exact
`.text.<name>` section. The original defining bytes, positive symbol size,
bounded symbol extent, section type/flags/address/alignment and object hash are
checked or recorded. A duplicate definition or definition in a different unit
cannot silently satisfy the lookup.

For a missing linked name, the helper requires the original object's unique
LOAD identity and exactly one matching zero-address discarded section row. The
discarded block has unique explicit start/end markers; a same row outside that
block or a duplicate matching row fails. The comparison uses raw section size.
In particular, `hp1020_tusb_adapter_take_auto_status` starts at offset4 and has
symbol size443 in a447-byte section: the raw input listing, map extent0x1bf,
and V5 `section_bytes` comparison agree. Substituting443 is not accepted by the
written predicate.

For a linked name, V5 still requires an actual defined function at an admitted
instruction and rejects conflicting discarded evidence. Every model trace
then rejects visiting that retained entry. General `Elf.symbol` lookup remains
strict; there is no general missing-symbol skip or new EXTERN root.

The helper is called after the existing source/target seals, exact ordinary
object closure, library/member closure and LOAD checks. Its ordinary object
names come from the unchanged closed UNITS set. It does not use the producer's
summary of discarded functions as proof. The added output records are derived
from the raw original tables and map and are deterministic for a saved capture.

## Integration and limits

The delta adds only the exact-five policy, threads it into `model_trace`, and
returns that proof in successful gate details. The existing CPU, RAM, pixels,
wire/event/cookie schedule, debugger restrictions and other symbol requirements
are unchanged. This preserves the shared archive reader's deterministic
saved-result comparison for a newly accepted V5 capture.

The checker still pins its own source bytes through `check_sources`. Therefore
the original V4 stopped capture cannot become an accepted V5 report merely by
running a newer checker on it. Root must retain that failure and create the
separately source-sealed checkpoint. Our copied-capture negative driver likewise
must wait for that accepted baseline with its matching checker.

The proposed controls correctly distinguish whole static-input proof from the
retained-entry predicate's supplied-policy unit test. This actual ELF has no
retained member of the five, so the latter must not be labelled a positive
retained-target provenance test. No controls ran in this review.

The proof remains about original named input sections and the linked image.
It does not establish hardware behavior or exclude arbitrary equivalent logic
under another name; the unchanged independent state, event, source and trace
checks address their existing bounded responsibilities. Dynamic control and
fresh full-gate results remain root-owned next steps.
