# V5: explicit original-input proof for five GC-discarded shortcuts

2026-10-03, `/root/usb_reference_contract`. V4 and the original six-case stopped
capture remain unchanged. This separate gate draft has not been imported,
parsed, executed or run against a candidate capture. Root owns review and all
future execution. Original CPU/RAM outcomes were not consulted in drafting it.

V4 SHA256 is `e6feb02335ef56b496dec4d1974e2866e18939a7be407a2346dfc8f28640bf2c`.
Its exact file and manifest are preserved here. The static diagnosis and its
complete27-object/ELF/map manifest are copied under inputs; the complete static
evidence package remains `/tmp/hp1020-entry-usb-gc-symbol-review-20261003/`.

The earlier presence call failed before the forbidden-entry assertion because
all five unused functions were garbage-collected. V5 adds an explicit closed
policy for those same five names, without weakening general symbol lookup:

1. Read original ET_REL section/string/symbol tables independently from all27
   already sealed ordinary objects. Require one nonzero GLOBAL/FUNC definition
   in the exact expected unit and `.text.<name>` section, bounded original bytes
   and actual symbol extent. Undefined references do not count as definitions.
2. If the name is retained in the linked ELF, require an actual defined function
   at an admitted instruction and no conflicting discarded row. Reject its
   entry in the visited PC list exactly as before.
3. If the name is absent from the linked symbol table, require one matching
   original-object LOAD and one exact zero-address discarded row inside the
   uniquely bounded Discarded-input block. Compare the raw **section** extent,
   not symbol size. Duplicate/wrong/missing definitions, owners, rows or extents
   fail. No other absent symbol gains this alternative.

The input-policy proof is computed once before runtime-case processing. Each
trace retains the no-entry check for every retained name. Successful gate
details now include the independently reconstructed five proof records; these
are diagnostic output, not producer labels used as truth.

All literal input bytes, CPU profiles, register/memory/pixel/event/cookie
expectations, command schedule, checkpoints, original ABI/source pins and
QEMU anti-repair checks remain unchanged. The original failing report cannot be
retroactively treated as a V5 pass: its saved source includes V4, while this gate
continues to bind its own exact source hash. A newly source-sealed run is needed
for a new full checkpoint. Narrow static helper controls may use private copies
of the earlier static input bytes without modifying that report.

See CONTROLS.md for the intended negative rejection mechanisms and the explicit
limit of the retained-entry predicate control. The scope remains original
named-section provenance plus no entry; this is not proof against arbitrary
semantically equivalent code under other names or proof of physical hardware.
