# V4 shortcut-symbol / garbage-collection assumption

2026-10-03, independent static review by `/root/usb_reference_contract`.
The original failed capture is `/tmp/hp1020-entry-usb-zs_nvshl`; it remains
untouched. This review reads only the saved ELF/map/input objects and frozen
checker, not the six cases' CPU/RAM/trace outcomes. No candidate instruction,
project-module import, audit, validator, build or repair was executed. The
only binary inspection was read-only pinned `xtensa-fsf-elf-readelf -Ws -S`;
its SHA256 matches the original tool record:
`8754a9b059c9044fd62fb8ddfe4bf9ae5d7693dbe5bebf5812b0a178d2649089`.

## Finding

V4 `model_trace`, lines1080–1084, calls `elf.symbol(name)` unconditionally for
five forbidden shortcut entries. `Elf.symbol`, lines500–505, requires a named
linked symbol before it can reject that entry in the PC trace. Normal section
garbage collection removes all five unused implementations from this target.
Thus the late failure is the checker's presence assumption; it is not evidence
that a forbidden entry ran. This review makes no independent execution claim.

The linked ELF's entire static symbol table contains none of the five names.
All27 captured ordinary input objects were inspected, and each has exactly one
original defined GLOBAL/FUNC record in its expected input unit. The map places
the matching nonempty section in `Discarded input sections`, before the
`Memory Configuration` boundary. The original inputs remain part of the
sealed source/target closure and were admitted by the separate raw-input gate.

| Function | Original object / section index | File offset | Section size | Symbol offset / size | Discarded map lines |
|---|---|---:|---:|---:|---:|
| hp1020_udc_setup_offer_offload | hp1020_udc_setup.o /30 | 0x394 | 0xaa | 0 /170 |321–322|
| hp1020_udc_setup_dispatch_offload | hp1020_udc_setup.o /32 | 0x440 | 0x112 | 0 /274 |323–324|
| hp1020_tusb_adapter_take_auto_status | hp1020_tusb_adapter.o /114 | 0x1008 | 0x1bf | 4 /443 |429–430|
| hp1020_udc_out_cancelled | hp1020_udc_out.o /51 | 0x738 | 0x97 | 0 /151 |293–294|
| hp1020_udc_ep0_cancelled | hp1020_udc_ep0.o /38 | 0x800 | 0xab | 0 /171 |250–251|

Every defining section is `.text.<exact function name>`, PROGBITS/AX, alignment4,
and each symbol lies wholly within its original section. One undefined input
reference to `hp1020_tusb_adapter_take_auto_status` remains in setup.o; it is not
a second definition and does not imply a linked implementation. In particular,
the adapter function starts at offset4 of its447-byte section. A new proof must
compare the map extent to **section size**, not assume symbol offset0 or use its
443-byte symbol size as the complete section extent.

Exact linked ELF SHA256:
`5d20ef15633de527aaa2d92001c6e910006e3a26eefadd0512a1594884eddf3b`.
Exact map SHA256:
`fd71ce444abd1dc78f0b61a71b2419b2c7214caf4d91a1759a3bfaf68ebc381e`.
Frozen V4 checker SHA256:
`e6feb02335ef56b496dec4d1974e2866e18939a7be407a2346dfc8f28640bf2c`.
The full27 objects, ELF, map, exact checker and static inspection output are
copied beside this review and individually sealed by its manifest.

## Recommended bounded correction

For these exact five names only, independently parse the already sealed27 raw
ET_REL objects and require exactly one original, nonzero GLOBAL/FUNC definition
in the expected unit and `.text.<name>` section, bounded original bytes and
symbol extent. Do not use producer summary labels as that proof.

- If the name is linked, retain the existing visited-entry rejection. Do not
  interpret its absence from a producer event list as sufficient.
- If it is absent from the full linked symbol table, require one exact
  zero-address/nonzero-size discarded map row for that defining section and
  original object's actual LOAD identity. The map extent must equal the raw
  input section extent. Reject missing, duplicate, malformed, mismatched or
  non-discarded rows, missing input definitions and duplicate definitions.
- Keep every other required linked symbol strict. Preserve complete trace
  admission, actual PC bounds and no-shortcut semantics. This is explicit
  evidence for an implementation removed from this target, not a general rule
  that any missing name is harmless.

Root approved this direction in preference to adding EXTERN roots for unused
forbidden functions. Artificially retaining them would change the target and
pull their dependencies into this small runtime solely to satisfy a checker
assumption. No existing functional expectation requires those unused routines
to be present. Source/literal/identity/CPU/pixel expectations remain unchanged.

## Proposed copied-evidence controls

Preserve V4 and this original stopped result before any V5 call. Controls for
the new static helper should include: no original definition, absent or wrong
discarded-row size/object/boundary, duplicate original definition or map row,
and a retained function whose entry is present in the supplied visited-PC list.
For retained functions, also show an unchanged nonvisited entry passes that
same narrow helper. Reseal copied evidence where appropriate so failures prove
the added obligation rather than only a report/hash mismatch. Root owns future
execution; no control has run here.

This is proof about named original input sections and this linked image. It
does not establish hardware behavior or rule out arbitrary semantically similar
code under other names. Existing exact runtime state, events, commands and
source-bound execution checks retain those separate responsibilities.
