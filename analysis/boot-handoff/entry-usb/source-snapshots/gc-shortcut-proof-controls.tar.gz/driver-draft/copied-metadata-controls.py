#!/usr/bin/env python3
"""Unexecuted draft: three copied V5 GC-proof negatives and one predicate test.

Load only the exact pinned stdlib-only V5 checker, and call its static helpers.
Never call check_capture, a target, a build, a debugger or an external command.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import sys
import tempfile
import traceback


GATE_SHA = '38f520c5d23834532806821d14ce9e5a8c3703d57935bcc923e453b43dece277'
PIN_TEXT = '''
5d20ef15633de527aaa2d92001c6e910006e3a26eefadd0512a1594884eddf3b entry-usb.elf
fd71ce444abd1dc78f0b61a71b2419b2c7214caf4d91a1759a3bfaf68ebc381e entry-usb.map
3cc752161b34db00b3dbcac1c955e934434f96255b777baa3afa6f3d1c9f6732 hp1020_image.o
e3b73c5c1701353e9212e13b68d658e41b5687b57f048b5ea0bfd55b4243d3e1 hp1020_image_output.o
16b3c01b83b704559349e7cc2b4ee0fe62ef25b4344a82afff4d258b23c61614 hp1020_image_page.o
ab096e223b7ea5e40cb504b8e5860bf731ba85300382286fd869ab419bb528d1 hp1020_image_ring.o
7185e55aeb06cc3d17fa8a84acd85eef8ea9e0d86df4d1df44749f54f7783897 hp1020_image_stream.o
f9ffcf9d434e898c54504a25b0199bfbfac262c2bfe8333bb2e066fccfa7fada hp1020_page_plan.o
6bddb5940db324de7f3037761f2ddc7a32ad765ec7f200d5c0a6a19341a90843 hp1020_semantic.o
f237b1b1cbb2b3cd991b1cbf67e5b6fcdf4ac8242ee2d215db98e4fa65c6e9a2 hp1020_tusb_adapter.o
05a4f5d033d2712daefe2178fdb10810a2d8a0ae6742f08eefd2c269c6147260 hp1020_udc_ep0.o
06019399de625438b138036eccc08a5d9f5b465e29e43bd840daa2fee548d0ac hp1020_udc_out.o
81d698effd76e0e19dd587f75203f1360f59acc6d1a8f3a32f748e55d2fc0c8e hp1020_udc_program.o
47f069c2f4219d76b7a364bbed03e33bd2bd300a57cca001f821b3905263c109 hp1020_udc_publish.o
586760ecb488f5b736af608114cefc5353366728d9ba17d783c7304cae15a998 hp1020_udc_setup.o
1c23d18bc17790130554411e93a2a32f963babe9b3d30a95027cff53d14ce4ff hp1020_usb_document.o
f0ff5dfd812dc9e038893308260b8ef30d053996de4c20b2df798236ca825f81 hp1020_usb_printer.o
723bc1debb2eaff3a0753772e656c87ce79f0f26656f2bdc76047f3301cb6f05 hp1020_usb_receive.o
614773f6a2a591ef0bc3f1179d9f826bf2bd27643d5cd6c6d183f43a23dd8450 hp1020_usb_runtime.o
ab26e8a35e6f0ef7c004e81d7b78336b07d044d47bc0cdc54a2d635fe35de6a0 hp1020_usb_runtime_layout.o
27b167a1745b44d3a36de8599717533d35a78a408d42487f93f1861e77583944 hp1020_usb_runtime_ram.o
0d7a5bc0af126f06c5951460e6299f6a6a5d1d587f3eb7b8e95f3991f04a3b7e jbig85.o
3ce2022f4d7e6626c85cc7a88f6f0e1449f39be94c92a11bab25a8b68f1f5bdd jbig_ar.o
950a0a8f6d98ac77b4986e3644de97fc8b975dbe1e472b38951a81dfe64ad348 memory.o
d922697e181a31ba55e5d5a92df8ac1dffa499b2f32a2090d14ac819d12cccf3 startup.o
7dccd598989621aaa5734f2e8ab3e1c3bd84f37b37744ab4a6cd7a881f50b0e0 target-memory.o
fe2d8006263fd1776cb299b797b3d464bee292bbf4bf2372da5689388aa262e7 tusb.o
1ab3cf56c4631c6b36d232a453546cb605bcc218a149783dfb121805b4c9df7a tusb_fifo.o
b9ca5f5f0272da5a73fbb3c7e2fdbd912e2165f18bf05a554900daabbda59b39 usbd.o
'''
PINS = {'target/' + name: digest for digest, name in (line.split() for line in PIN_TEXT.splitlines() if line)}
OFFER = 'hp1020_udc_setup_offer_offload'
AUTO = 'hp1020_tusb_adapter_take_auto_status'


def need(ok, text):
    if not ok:
        raise RuntimeError(text)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(root, name):
    path = root / name
    need(not Path(name).is_absolute() and path.resolve().is_relative_to(root.resolve()) and
         not path.is_symlink() and path.is_file() and path.stat().st_size <= 16 * 1024 * 1024,
         'bounded ordinary copied/static input: ' + name)
    return path.read_bytes()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def seal(root):
    return {name: dict(bytes=len(data), sha256=sha(data)) for name in sorted(PINS)
            for data in (read(root, name),)}


def copy_inputs(root, inputs):
    for name, data in inputs.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        need(not path.exists(), 'never overwrite original control input')
        path.write_bytes(data)


def symbol_names(data):
    need(len(data) >= 52 and data[:7] == b'\x7fELF\x01\x02\x01', 'raw input ELF32BE')
    h = struct.unpack_from('>HHIIIIIHHHHHH', data, 16)
    need(h[0:4] == (1, 94, 1, 0) and h[8] in (0, 32) and h[9] == 0 and h[10] == 40,
         'raw input ET_REL header')
    so, count = h[5], h[11]
    need(0 < count < 4096 and so >= 52 and so + 40 * count <= len(data), 'raw section envelope')
    headers = [struct.unpack_from('>10I', data, so + 40 * i) for i in range(count)]
    tables = [row for row in headers if row[1] == 2]
    need(len(tables) == 1, 'one original symbol table')
    table = tables[0]
    need(table[9] == 16 and table[5] % 16 == 0 and table[4] + table[5] <= len(data) and table[6] < count,
         'raw symbol table bounds')
    strings = headers[table[6]]
    need(strings[1] == 3 and strings[4] + strings[5] <= len(data), 'raw symbol string bounds')
    names = data[strings[4]:strings[4] + strings[5]]
    rows = []
    for offset in range(table[4], table[4] + table[5], 16):
        ni, value, size, info, other, index = struct.unpack_from('>IIIBBH', data, offset)
        need(ni < len(names), 'symbol name in original table')
        end = names.find(b'\0', ni)
        need(end >= ni, 'terminated original symbol name')
        rows.append(dict(name=names[ni:end].decode('ascii'), string_offset=strings[4] + ni,
                         value=value, size=size, info=info, other=other, section=index))
    return rows


def remove_definition(root):
    relative = 'target/hp1020_udc_setup.o'
    original = read(root, relative)
    rows = symbol_names(original)
    matches = [i for i, r in enumerate(rows) if r['name'] == OFFER and r['info'] == 0x12 and r['section'] > 0]
    need(len(matches) == 1, 'one actual original forbidden symbol')
    chosen = matches[0]
    offset = rows[chosen]['string_offset']
    need(original[offset] == ord('h'), 'original first character')
    changed = original[:offset] + b'x' + original[offset + 1:]
    new = symbol_names(changed)
    expected = [dict(row) for row in rows]
    expected[chosen]['name'] = 'x' + OFFER[1:]
    need(new == expected and sum(a != b for a, b in zip(original, changed)) == 1,
         'one symbol name only; no shared suffix/header changes')
    (root / relative).write_bytes(changed)
    return dict(file=relative, byte_offset=offset, before_name=OFFER, after_name=expected[chosen]['name'])


def selected_map_row(raw):
    lines = raw.splitlines(keepends=True)
    needle = (' .text.' + AUTO + '\n').encode()
    indices = [i for i, line in enumerate(lines) if line == needle]
    need(len(indices) == 1, 'one exact original discarded function row')
    i = indices[0]
    need(i + 1 < len(lines), 'original row continuation')
    fields = lines[i + 1].split()
    need(len(fields) == 3 and int(fields[0], 16) == 0 and int(fields[1], 16) == 447 and
         fields[2].endswith(b'/hp1020_tusb_adapter.o'), 'original section extent/owner is 447 bytes')
    begin = sum(map(len, lines[:i]))
    end = begin + len(lines[i]) + len(lines[i + 1])
    need(raw.index(b'Discarded input sections\n') < begin < end < raw.index(b'Memory Configuration\n'),
         'actual original row lies strictly in discarded block')
    return begin, end, lines[i] + lines[i + 1]


def wrong_extent(root):
    relative = 'target/entry-usb.map'
    raw = read(root, relative)
    begin, end, row = selected_map_row(raw)
    need(row.count(b'0x1bf') == 1, 'exact section-size token')
    replacement = row.replace(b'0x1bf', b'0x1bb')
    changed = raw[:begin] + replacement + raw[end:]
    need(len(changed) == len(raw) and sum(a != b for a, b in zip(raw, changed)) == 1,
         'only section extent token changes')
    (root / relative).write_bytes(changed)
    return dict(file=relative, function=AUTO, original_section_bytes=447,
                substituted_symbol_bytes=443, symbol_offset=4)


def move_outside(root):
    relative = 'target/entry-usb.map'
    raw = read(root, relative)
    begin, end, row = selected_map_row(raw)
    remaining = raw[:begin] + raw[end:]
    boundary = b'Memory Configuration\n'
    need(remaining.count(boundary) == 1, 'single original map boundary')
    at = remaining.index(boundary) + len(boundary)
    changed = remaining[:at] + row + remaining[at:]
    need(len(changed) == len(raw) and changed.count(row) == 1 and
         changed.index(row) > changed.index(boundary), 'same exact row moved beyond discarded block')
    (root / relative).write_bytes(changed)
    return dict(file=relative, function=AUTO, original_offset=begin, moved_offset=at,
                unchanged_row_sha256=sha(row), mutation='same row outside discarded block')


def deny_external(event, arguments):
    if event in ('subprocess.Popen', 'os.system', 'os.exec', 'os.spawn', 'os.posix_spawn') or event.startswith('socket.'):
        raise RuntimeError('static control forbids external process/network action: ' + event)


def rejection(call, expected):
    try:
        call()
    except ValueError as error:
        need(str(error) == expected, 'wrong rejection obligation: ' + str(error))
        return dict(type=type(error).__name__, message=str(error))
    raise RuntimeError('copied corruption was unexpectedly accepted')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('capture', type=Path)
    parser.add_argument('--gate', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    capture = args.capture.resolve()
    if args.output is None:
        output = Path(tempfile.mkdtemp(prefix='hp1020-entry-usb-gc-controls-', dir='/tmp')).resolve()
    else:
        output = args.output.resolve()
        need(output.is_relative_to(Path('/tmp').resolve()) and not output.exists(), 'new private /tmp output required')
        output.mkdir(parents=True)
    need(not output.is_relative_to(capture) and not capture.is_relative_to(output), 'disjoint original/output paths')
    report = dict(schema='hp1020-entry-usb-gc-controls-v1', status='fail', controls=[],
                  target_execution=False, full_capture_gate_called=False,
                  capture=str(capture), output=str(output), gate_sha256=GATE_SHA,
                  driver_sha256=sha(Path(__file__).read_bytes()))
    originals = {}
    gate_path = args.gate.resolve()
    try:
        gate_data = gate_path.read_bytes()
        need(sha(gate_data) == GATE_SHA, 'exact frozen V5 source')
        need(len(PINS) == 29 and sum(n.endswith('.o') for n in PINS) == 27, 'exact pinned static input set')
        for name, digest in PINS.items():
            data = read(capture, name)
            need(sha(data) == digest, 'exact independently reviewed static input: ' + name)
            originals[name] = data
        copy_inputs(output / 'baseline', originals)
        (output / 'checker-v5.py').write_bytes(gate_data)
        save(output / 'input-sha256.json', PINS)
        sys.dont_write_bytecode = True
        sys.addaudithook(deny_external)
        spec = importlib.util.spec_from_file_location('hp1020_gc_controls_pinned_v5', output / 'checker-v5.py')
        need(spec is not None and spec.loader is not None, 'captured checker loader')
        gate = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(gate)
        elf = gate.Elf(originals['target/entry-usb.elf'])
        baseline_policy = gate.forbidden_shortcut_policy(output / 'baseline', elf)
        need(len(baseline_policy) == 5 and all(r['disposition'] == 'discarded' for r in baseline_policy.values()),
             'exact static baseline has all five proven discarded implementations')
        save(output / 'baseline-policy.json', baseline_policy)
        expected = 'absent shortcut requires exact original discarded section: ' + AUTO
        for label, mutate, reason in (
                ('01-no-original-definition', remove_definition, 'one original shortcut definition: ' + OFFER),
                ('02-symbol-size-is-not-section-size', wrong_extent, expected),
                ('03-row-outside-discarded-block', move_outside, expected)):
            directory = output / label
            copy_inputs(directory / 'before', originals)
            copy_inputs(directory / 'after', originals)
            result = dict(label=label, scope='copied-raw-static-helper', status='fail', expected_rejection=reason)
            report['controls'].append(result)
            try:
                result['before'] = seal(directory / 'before')
                same = gate.forbidden_shortcut_policy(directory / 'before', elf)
                need(same == baseline_policy and seal(directory / 'before') == result['before'], 'unchanged same-API baseline')
                result['baseline'] = 'pass'
                result['mutation'] = mutate(directory / 'after')
                result['after'] = seal(directory / 'after')
                need(result['after'] != result['before'], 'copied metadata actually changed')
                result['rejection'] = rejection(lambda: gate.forbidden_shortcut_policy(directory / 'after', elf), reason)
                need(seal(directory / 'after') == result['after'], 'helper did not modify copied evidence')
                result['status'] = 'pass'
            finally:
                save(directory / 'control.json', result)
                save(output / 'result.json', report)
        # Explicit predicate-only control, not fabricated retained-ELF provenance.
        supplied = json.loads(json.dumps(baseline_policy))
        entry = elf.symbol('hp1020_udc_setup_offer')
        need(entry in elf.instructions, 'supplied predicate address is an actual admitted instruction')
        supplied[OFFER]['disposition'] = 'retained'
        supplied[OFFER]['entry'] = entry
        directory = output / '04-retained-entry-predicate-only'
        save(directory / 'before.json', dict(pcs=[], supplied_policy=supplied))
        save(directory / 'after.json', dict(pcs=[entry], supplied_policy=supplied))
        result = dict(label=directory.name, scope='predicate-only-supplied-policy', status='fail',
                      original_input_policy_revalidated=False, supplied_entry=entry,
                      no_claim_of_retained_function_in_this_elf=True)
        report['controls'].append(result)
        try:
            gate.check_forbidden_entries([], supplied)
            result['baseline'] = 'pass'
            result['rejection'] = rejection(lambda: gate.check_forbidden_entries([entry], supplied),
                'no typed offload/auto ACK/cancel shortcut: ' + OFFER)
            result['status'] = 'pass'
        finally:
            save(directory / 'control.json', result)
        need(len(report['controls']) == 4 and all(r['status'] == 'pass' for r in report['controls']), 'all four bounded controls')
        report['status'] = 'pass'
    except BaseException as error:
        report['error'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
    finally:
        changes = []
        for name, data in originals.items():
            try:
                need(read(capture, name) == data, 'original static bytes changed')
            except Exception as error:
                changes.append(dict(file=name, error=str(error)))
        try:
            need(sha(gate_path.read_bytes()) == GATE_SHA, 'original V5 source changed')
        except Exception as error:
            changes.append(dict(file=str(gate_path), error=str(error)))
        report['originals_unchanged'] = not changes
        if changes:
            report['status'] = 'fail'
            report['original_changes'] = changes
        save(output / 'result.json', report)
    print(json.dumps(dict(status=report['status'], output=str(output)), sort_keys=True))
    return 0 if report['status'] == 'pass' else 1


if __name__ == '__main__':
    raise SystemExit(main())
