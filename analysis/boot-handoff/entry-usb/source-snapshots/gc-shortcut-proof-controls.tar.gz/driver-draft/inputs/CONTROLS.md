# Proposed bounded V5 controls — unexecuted

Root executes only after preserving the original V4 stop and reviewing V5.
Every static helper negative uses a fresh copy of the27 objects, map and linked
ELF; first show the unchanged same-helper baseline succeeds. Preserve exact
before/after bytes, hashes and failure reason. Do not claim a whole-capture gate
pass on relabelled V4 results; these controls are explicitly static/helper tests.

Public narrow helpers are:

- `forbidden_shortcut_policy(root, elf)`, with `elf = Elf(actual_elf_bytes)`.
  It reads original tables itself; no producer audit imports are needed.
- `check_forbidden_entries(pcs, policy)`, the same entry predicate used by every
  full trace after that policy was independently established.

1. **No original definition.** In the copied defining object's actual symbol
   string table, change the first character of one forbidden GLOBAL/FUNC name
   to an equal-length distinct name; preserve section names and all metadata.
   If symbol strings share suffixes, prove only that selected full name changes.
   The unchanged linked ELF is still missing the forbidden symbol, and its
   discarded map row remains intact. The helper must reject `one original
   shortcut definition`, not accept a missing linked name on its own.
2. **Wrong discarded extent.** Change only one selected discarded row's nonzero
   hexadecimal extent by one while preserving object, name and block. The helper
   must reject `absent shortcut requires exact original discarded section`.
   In particular use take_auto_status to exercise447 section bytes versus443
   symbol bytes/offset4; substituting443 must not pass.
3. **Outside the discarded block.** Move one selected exact row beyond the
   Memory Configuration boundary, leaving its bytes/name/object/extent otherwise
   intact. It must be rejected as no matching discarded proof. An optional
   duplicate-row variant should likewise fail cardinality rather than first-hit
   matching. Invalid header bounds are a different rejection and must not be
   substituted for this test.
4. **Retained-entry predicate (honest unit scope).** This target has none of the
   five retained functions, so do not pretend it supplies a retained positive
   ELF case. For this small predicate only, copy a valid five-record policy and
   replace one record with a labelled supplied retained entry at an existing
   admitted instruction address. Show a PC list excluding that address passes,
   then include exactly that address and require `no typed offload/auto ACK/
   cancel shortcut`. This tests the unchanged retained-entry refusal logic;
   it is not a claim that the constructed policy passes original-input/ELF
   provenance. A fully retained function target would require a separate link
   and independent linked audit, outside this narrow correction.

For full raw-gate copied-evidence controls, update only copied target/report
seals to reflect a mutation where necessary, so semantic failures cannot be
mistaken for simple hash mismatches. No original source, capture or report is
modified. None of these controls executes a target instruction or supplies a
new hardware/USB/printing observation.
