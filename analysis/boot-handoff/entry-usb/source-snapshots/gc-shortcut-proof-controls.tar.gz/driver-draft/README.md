# Frozen V5 copied-metadata controls — unexecuted

Future invocation, owned by root:

```sh
python3 copied-metadata-controls.py /tmp/hp1020-entry-usb-zs_nvshl \
  --gate /tmp/hp1020-entry-usb-gate-v5-20261003/check-hp1020-entry-usb.py
```

Optional `--output` must be a new directory below `/tmp`. The driver pins exact
V5 plus the original static ELF/map/all27 object hashes. It preserves copies,
baseline policy, mutation bytes/hashes and intended specific errors; it checks
the originals remain unchanged. The embedded29-file pin table was compared
textually against the frozen static-review manifest, without importing/parsing
or executing either checker or driver.

Three negatives call only the copied static-policy helper: missing original
symbol definition;447-byte discarded extent changed to443; same exact row moved
outside the discarded block. Each first calls the unchanged same API. The fourth
control is explicitly predicate-only: a supplied retained entry is excluded,
then included, in a small PC list. It does not claim this ELF contains that
retained shortcut or that the supplied policy passed raw provenance.

The checker is imported only by the future root-owned execution after its exact
source pin is checked. No whole-capture gate, target instructions, compiler,
debugger, process or network calls are permitted. No runtime C or CPU/RAM case
outcomes are read. The original failed report is neither read nor relabelled.
This draft has not been parsed, imported or executed; V4/V5 and literal evidence
remain unchanged. First-run failures must be preserved before any correction.
