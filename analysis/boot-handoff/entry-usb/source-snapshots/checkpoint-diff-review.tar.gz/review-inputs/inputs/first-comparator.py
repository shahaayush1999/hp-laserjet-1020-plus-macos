"""Compare exact old component cases and both entry experiments after full success."""
from pathlib import Path
import copy,gzip,hashlib,json,re
ROOT=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
BEFORE=Path('/tmp/hp1020-entry-usb-before-full-baseline-20261003')
OUT=Path('/tmp/hp1020-full-entry-usb-comparison-20261003.json')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda p:json.loads(p.read_text())
assert 'All offline checks passed. No printer was contacted.' in Path('/tmp/hp1020-full-entry-usb-20261003.log').read_text()
assert not OUT.exists()
result=dict(status='pass',components=[],entries=[],source='exact independently accepted reports and original captured bytes')
for before in sorted((BEFORE/'analysis/usb-path').glob('*/validation.json')):
 after=ROOT/before.relative_to(BEFORE);a,b=load(before),load(after)
 assert a['status']==b['status']=='pass'
 assert a['cases']==b['cases'] and a['target']['cases']==b['target']['cases'],before
 result['components'].append(dict(name=before.parent.name,host_cases=len(b['cases']),target_cases=len(b['target']['cases']),
  complete_case_arrays_unchanged=True,before_sha256=sha(before.read_bytes()),after_sha256=sha(after.read_bytes())))
assert len(result['components'])==11
for name,old_report in (('entry-ram',BEFORE/'analysis/boot-handoff/entry-ram/validation.json'),
                        ('entry-usb',Path('/tmp/hp1020-entry-usb-hjxqsyjw/validation.json'))):
 a=load(old_report);new_report=ROOT/'analysis/boot-handoff'/name/'validation.json';b=load(new_report)
 A=Path(a['capture']);B=Path(b['capture']);assert A!=B and a['status']==b['status']=='pass'
 assert load(A/'independent-gate.json')['ok'] and load(B/'independent-gate.json')['ok']
 assert a['source_sha256']==b['source_sha256'],name+' changed tested sources'
 assert a['target_sha256'].keys()==b['target_sha256'].keys()
 metadata=[]
 for n in a['target_sha256']:
  x=(A/'target'/n).read_bytes();y=(B/'target'/n).read_bytes()
  if x==y:continue
  assert name=='entry-usb' and n.endswith(('.d','.su')),n
  pattern=rb'hp1020-entry-usb-source\.[A-Za-z0-9]{6}'
  xs=set(re.findall(pattern,x));ys=set(re.findall(pattern,y));assert len(xs)==len(ys)==1
  left=next(iter(xs));right=next(iter(ys));assert x.replace(left,right)==y
  metadata.append(dict(file=n,before_prefix=left.decode(),after_prefix=right.decode()))
 rows=[]
 for old,new in zip(a['cases'],b['cases']):
  assert old['case']==new['case'];case=old['case'];x=copy.deepcopy(old);y=copy.deepcopy(new)
  for root,row in ((A,x),(B,y)):
   q=row['qemu'];assert q['cleanup']['returncode']==0 and not q['cleanup']['still_running']
   q['cleanup'].pop('pid');q.pop('elapsed_seconds');q['host_intervention_ledger'].pop('sha256')
   sock=q['qemu']['args'][18];assert re.fullmatch(r'unix:/tmp/hp1020-qemu-[^/]+/gdb\.sock,server=on,wait=off',sock)
   q['qemu']['args'][18]='same private socket shape'
  assert x==y,(name,case)
  ledgers=[]
  for root in (A,B):
   ledger=[json.loads(z) for z in (root/'cases'/case/'qemu/host-interventions.jsonl').read_text().splitlines()]
   assert sum(z.get('kind')=='process-cleanup' for z in ledger)==1
   next(z for z in ledger if z.get('kind')=='process-cleanup').pop('pid');ledgers.append(ledger)
  assert ledgers[0]==ledgers[1]
  for trace in ('accesses.bin.gz','steps.bin.gz'):
   assert gzip.decompress((A/'cases'/case/'model/traces'/trace).read_bytes())==gzip.decompress((B/'cases'/case/'model/traces'/trace).read_bytes())
  rows.append(dict(case=case,complete_state_and_actual_trace_bytes_unchanged=True,actual_debugger_commands_and_replies_unchanged_except_cleanup_pid=True))
 assert len(rows)==len(a['cases'])==len(b['cases'])==6
 result['entries'].append(dict(name=name,old_capture=str(A),new_capture=str(B),tested_sources_unchanged=True,
  target_code_and_objects_unchanged=True,temporary_metadata_differences=metadata,cases=rows))
OUT.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print('Eleven component case arrays and both six-case entry experiments match their prior accepted results; only documented temporary build/process/time/socket identities differ.')
