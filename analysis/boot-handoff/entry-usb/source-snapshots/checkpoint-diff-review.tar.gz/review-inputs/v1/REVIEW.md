# USB-entry checkpoint diff review, 2026-10-03

Read-only independent inspection of the current checkpoint. No project import,
audit, build, validator, target execution, device contact or repository edit was
performed. The lead reports both full suites passed with 133 consistency rows;
this review does not substitute for that execution or the lead's post-run raw
comparison.

No actionable unexpected change was found within the requested scope.

- The 30 modified TinyUSB `.su` files have only disposable source-directory
  token changes. Word-level inspection found no changed function, source-line,
  frame-size or stack-class token outside those prefixes.
- The seven compact component report deltas contain capture/artifact seals:
  the packet-fault capture directory, the three path-bearing `.su` digests, and
  path-specific annotated-disassembly digests. The latter are produced after
  copying the target into its per-run capture, as shown in the unchanged
  packet-fault and acquisition generators. No case/event/oracle/target-code
  change appeared in the complete word-level deltas.
- The existing entry-RAM report changes are the new capture path, cleanup PIDs,
  elapsed times, private sockets and resulting ledger digests. Its manifest
  changes correspond to those case/result/report seals and QEMU termination
  stderr. The inspected stderr differs only in the parent process PID.
- The new consistency row is the USB-entry raw-evidence check; the old rows
  remain unchanged. Shared integration is exactly the previously reviewed
  closed two-profile archive selector plus one sequential run and syntax inputs.
  Current checker SHA256 is
  `37b2226d632e2b5b139a41dfebaa8c730b30a5284748667985e1d28f7f81d5cf`;
  offline script SHA256 is
  `c8f28890751153152fd56b3557b2975fbb715bcf750bc34e2f79c01ce1a7dfc5`.
- The saved first post-full comparison stop identifies exactly six USB ledger
  byte counts growing by one. Its comparator removed the PID and ledger hash
  before comparing report objects, but retained the byte count. A cleanup PID
  changing decimal width can explain this mismatch; it must be proved from
  raw ledger bytes, not fixed by editing reports or generally ignoring lengths.
  The lead owns that repair and execution; this review did not rerun it.

The new published target inventory contains the intended big-endian Xtensa
ELF, 27 build objects, dependency/stack-use records, map, generated input,
effective-source seal, and compiler-selected libgcc archive plus two selected
members. The linked ELF is unchanged at
`5d20ef15633de527aaa2d92001c6e910006e3a26eefadd0512a1594884eddf3b`.
No printer upload image, macOS installer/host executable, symlink or unrelated
personal-file path was found in the inspected inventory. Archive member-name
inspection found no `.git`, SSH/AWS credential directory, environment file,
private-key filename, `.dl`, `.pkg` or `.dmg`; a bounded plain-text key/token
scan also had no matches. Existing absolute repository and disposable tool paths
are evidence provenance. This is an inventory review, not an exhaustive secret
audit of arbitrary binary data.

The added NOTICE accurately points to the original GCC 14.3.0 helper source,
GPLv3 text, Runtime Library Exception, complete upstream source-archive hash and
pinned recovery script. The intentionally retained failure/success/negative
control archives are individually below 24 MB in this snapshot. They distinguish
failed attempts from accepted evidence; no failed report was relabeled.

Exact read-time file hashes, inventory, selected raw diffs and the preserved
first comparison stop are under
`/tmp/hp1020-entry-usb-checkpoint-diff-review-20261003/inputs/`, sealed by that
directory's `INPUTS.sha256`. Handoff prose was still being updated by the lead;
the hash inventory identifies the exact reviewed snapshot rather than claiming
later edits were reviewed. No physical boot, USB or printing claim follows.
