# Staging-race evidence supplement

The initial review used live `git diff` output before the lead staged the
checkpoint. Staging occurred before the later preservation commands, so several
unstaged-only diff/inventory files in the final V1/V2 input set are empty. The
earlier inspected deltas and findings were real, but those empty members were
not durable proof of their contents. Existing review and manifests are preserved
unchanged rather than retroactively replacing their inputs.

This separate read-only supplement explicitly captures staged plus unstaged
changes with `git diff HEAD`, saves the actual HEAD and reviewed file hashes,
and separately inventories staged paths. Compact component reports use complete
word-level changed-token output; their large one-line contents are not printed
or rewritten. Shared integration, attributes/notices, entry-RAM metadata and all
30 stack-usage deltas are saved directly. This corrects capture timing only; no
runtime source, report, validation or target execution changed.
