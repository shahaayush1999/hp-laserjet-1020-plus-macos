from pathlib import Path
import importlib.util,sys,tempfile,shutil,json,traceback
root=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('link_only_helpers',root/'scripts/validate-hp1020-entry-usb.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
cap=Path(tempfile.mkdtemp(prefix='hp1020-entry-usb-link-only-',dir='/tmp'))
print(cap,flush=True)
report={'status':'fail','candidate_execution':False,'linked_audit_performed':False,'scope':'Link-only diagnostic to inspect actual section-GC output; new complete raw-input gate remains pending. Never an admitted execution result.'}
sources={};target=v.OUT/'target'
try:
 sources=v.seal_sources(cap,True);report['source_sha256']=sources
 if target.exists():shutil.copytree(target,cap/'target-before-build');shutil.rmtree(target)
 v.command(['bash',root/'scripts/build-hp1020-entry-usb-target.sh'],cap/'build.log')
 report['status']='link-only-pass-unadmitted'
except BaseException as error:
 report['error']={'message':str(error),'traceback':traceback.format_exc()};raise
finally:
 if target.exists():shutil.copytree(target,cap/'target')
 try:report['tool_closure']=v.tool_closure(cap)
 except Exception as error:report['tool_closure_error']=str(error)
 if sources:v.verify_source_seal(sources)
 v.save(cap/'link-only.json',report)
