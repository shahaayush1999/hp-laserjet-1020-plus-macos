# Correction to the separate static GC assessment

2026-10-03. The frozen provider/layout source review remains unchanged. This note
corrects my later chat assessment of the first linker-GC proposal, not a claim
about provider behavior.

I incorrectly said that `KEEP(*(*))` in the final `.unexpected` output section
would retain only inputs left unmatched by earlier text/rodata patterns. I
withdraw that statement. Output allocation order does not limit the earlier
SEC_KEEP marking pass. The lead's second audit-only build stopped at the same
code budget, and the lead checked pinned `ld/ldlang.c`, including
`gc_section_callback` near line6773: the catch-all KEEP roots all inputs before
allocation. This is a material correction to my static opinion.

The evaluated patch was
`/tmp/hp1020-entry-usb-gc-review-20261003/changes.patch`, SHA256
`c43e0c7cf23bfab10fa6c48e1487b9bff8a9638fe4786a13f65143ec61584667`.
The reported second capture is `/tmp/hp1020-entry-usb-4pwujqqp`. Neither link
attempt executed target instructions. The lead owns those exact failure
captures and their durable preservation.

The provider author now owns the narrow correction: remove broad KEEP and
retain a strict complete input/removed-section gate so unknown sections,
including selected libgcc members, cannot disappear silently through GC. I
have not independently executed or duplicated that investigation. A future
successful emitted link, full source/section audit and new linked call/frame
review remain required; the earlier optimistic static sentence is not evidence
that GC worked or that an unknown-input rejection survived it.
