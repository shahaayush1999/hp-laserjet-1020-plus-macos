# V4: complete linker-input provenance closure

2026-10-03, `/root/usb_reference_contract`. Root authorized this narrow follow-up
after an independent static review of V3; no audit or candidate instructions had
executed. This draft was not parsed, imported, executed or used to inspect
candidate results. All edits are isolated under `/tmp`.

V3 remains unchanged at
`/tmp/hp1020-entry-usb-gate-v3-20261003/check-hp1020-entry-usb.py`, SHA256
`a7a58485ef588bbb36bcc46870f2180e2736e9a65e3d50221430a330f9196ce4`.
An exact copy is `checker-v3.py`; its complete manifest is retained under
`inputs/`. Earlier gate/oracle packages remain unchanged.

The V3 archive/member pins, independent ar extraction, four-file capture set,
original tool binding and two additional `.o` paths were correct, but its map
expression recognized only `libgcc.a(member)` references. A differently named
archive and extra `LOAD` records could therefore escape that independent map
check. The separate linked audit already checks these; V4 makes the raw gate's
own input-provenance claim equally explicit without importing that audit.

Only the linker-map block changes:

- Recognize every `.a(member)` selection, with no unrecognized `.a(` occurrence.
  The complete set must be the recorded original libgcc path paired with exactly
  `_udivsi3.o` and `_umodsi3.o`; another named archive is rejected.
- Parse every actual `LOAD` line and require28 unique normalized absolute names:
  the26 original C objects, `startup.o`, and the original library. The ordinary
  objects must have the exact expected basenames and one common original target
  directory. No additional archive, object or other LOAD type is admitted.
- The already-reviewed lexical `/tmp`/`/var` to `/private` alias handling remains
  unchanged; stale original paths are never opened or resolved during recovery.

`v3-to-v4.diff` is the complete delta. No positive runtime expectation,
instruction/memory/CPU check, buffer, original identity, source pin, checkpoint,
pixel/event oracle, permission or supplied-hardware condition changes.

Two useful copied-map negatives for root's later controls are an additional
`other.a(member.o)` selection and an additional or substituted `LOAD` input.
Reseal copied report/target hashes when testing their semantic rejection, so
the failure is not merely a stale hash. These controls remain unexecuted here.
