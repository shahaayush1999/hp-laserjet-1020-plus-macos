"""Readback-verified immutable entry evidence package; never execute targets."""
from pathlib import Path
import argparse,gzip,hashlib,io,json,tarfile

ap=argparse.ArgumentParser();ap.add_argument('spec',type=Path);a=ap.parse_args()
spec=json.loads(a.spec.read_text());root=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
sha=lambda b:hashlib.sha256(b).hexdigest()
files={'archive.py':Path(__file__),'archive-inputs.json':a.spec}
for prefix,name in spec['inputs'].items():
 p=Path(name);assert p.exists(),p
 if p.is_dir():
  for f in p.rglob('*'):
   if f.is_file() and '__pycache__' not in f.parts:files[prefix+'/'+str(f.relative_to(p))]=f
 else:files[prefix]=p
raw={n:p.read_bytes() for n,p in files.items()}
buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w') as tf:
  for n,value in sorted(raw.items()):
   assert not Path(n).is_absolute() and '..' not in Path(n).parts
   item=tarfile.TarInfo(n);item.mode=0o644;item.mtime=0;item.size=len(value)
   tf.addfile(item,io.BytesIO(value))
payload=buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tf:
 assert len(tf.getnames())==len(raw) and set(tf.getnames())==set(raw)
 for n,v in raw.items():assert tf.extractfile(n).read()==v
result=dict(status=spec['status'],scope=spec['scope'],archive_bytes=len(payload),
 archive_sha256=sha(payload),members=len(raw),member_sha256={n:sha(v) for n,v in sorted(raw.items())})
out=root/'analysis/boot-handoff/entry-usb/source-snapshots';label=spec['label']
assert label.replace('-','').isalnum()
for suffix,v in (('.tar.gz',payload),('.json',(json.dumps(result,indent=2)+'\n').encode())):
 p=out/(label+suffix);assert not p.exists(),p;p.write_bytes(v)
print(json.dumps({k:v for k,v in result.items() if k!='member_sha256'},indent=2))
