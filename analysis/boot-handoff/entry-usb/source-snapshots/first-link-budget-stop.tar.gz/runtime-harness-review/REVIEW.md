# Continuous USB runtime/harness integration: static review

2026-10-03. Read-only review by `/root/adapter_review`. No imports, parsing,
builds, tests, validators, interpreter/QEMU execution, repo edits or hardware.
The six exact inspected source files are preserved alongside this note and in
INPUTS.sha256. This is independent of root's runtime and harness implementation;
my separately authored new audit is not independently reviewed by this note.

No concrete integration blocker was found in these inspected revisions. The
provider/layout C and independent raw checker were still being authored and are
outside this review; no passing execution or emitted-layout claim is made.

## Boundaries checked

The orchestrator's first C work scans actual generic BSS, full memory, mailbox,
witness and nonzero sentinel with volatile byte accesses before any initializer,
guard installation or mailbox write. Its locals/own stack are intentionally in
use during this scan. The actual initialized-data span is read into a local hash
without changing its bytes; independent pre-C evidence, rather than that hash,
is the source-byte oracle.

The control path uses actual bus reset and immutable raw SETUP ingress, then
actual TinyUSB endpoint callbacks. It settles the original NULL/zero-length EP0
owner through its component after service has returned, and services the real
completion before supplying the three separate recovery promises. No typed
notification/CSR_DONE/extra status path appears in this workload. Positive APIs
use their own zero-success result domains, with any WAIT/error ending this fixed
fully supplied schedule rather than inventing progress.

Each document uses offsets0,64,128,192,256,320 into the same352-byte source and
lengths64,64,64,64,64,32. Actual publication provides the retained cookie; the
loop index never reconstructs a completion identity. Every acquisition is
followed by publisher service, adapter pump and eager next reservation. At the
first close entry the thirteenth packet remains outstanding. After close, the
explicit same-cookie zero-length acquisition precedes the next actual service
entry, then the empty reservation is pumped before one actual finish. This
matches the approved natural-checkpoint order and introduces no EOF inference.
The provider still must verify every original-cookie/range/copy effect as its
separate frozen contract requires.

The new model replaces the shared historical stack, overrides read/write/access
logging with the new owned spans, and gates the first C call on the new symbol.
Inherited normalization/snapshot/trace-close helpers contain no stale address
policy used by those overridden methods. Inherited evidence reports8192 stack
bytes, which remains the same size; it does not carry over the old stack address
or old measured-depth claim. Calls check actual audited STT_FUNC entries and
aligned own stack, while returns match recorded return PC and original SP.
The service checkpoint is inactive before close; it cannot mistake ordinary
initial and per-packet service calls for the final-owner checkpoint. Actual
close/finish entry counts and ordered checkpoint checks reject repeats.

The new QEMU observer overrides its command guard for six checkpoints, while
inherited constructor/seed/command/cleanup methods use instance checkpoint data
and do not impose the old four-checkpoint count. Every breakpoint is installed
only after the preceding one was consumed and removed. Thus the service
breakpoint is first installed at the pre-close stop, after earlier service
calls. There is still one initial seed, no post-lock write/PC repair/per-call
helper, and two terminal self-jump steps. Its broad mutable-span preservation
check is intentionally supplemented by root's stronger phase checks and the
model's per-access policy; it is not a standalone instruction/data-access proof.

The runner retains targets even on build failure, copies sources before the
build, captures actual compiler dependencies, verifies the linked input against
the independent literal stream, and seals sources before execution and again at
completion. The new audit's source dependencies remain tied to original build
paths while the raw capture additionally preserves their content. Full initial
and six-checkpoint CPU/RAM comparisons precede publication; the independent raw
gate runs before public success artifacts are replaced. Earlier artifacts remain
separate failure history. No tested old source is relabelled as new evidence.

## First emitted/observed facts still required

The layout and exact mutable/NOLOAD initializer checks, modern annotations,
private getter relocation, concrete C callback closure and nested/libgcc stack
bound are first-build obligations. The old784-byte bound/720-byte observation
must not be reused. The observed QEMU command budget/timeout may bound a run, but
no claim about its success or performance is made here. The separately frozen
raw gate must independently verify the planned32/64-pixel, original-identity,
source-image/cache-range and PENDING-before-final-service evidence.

This review adds no physical boot, RAM-attribute, cache coherence, IRQ/event,
controller or printing evidence.
