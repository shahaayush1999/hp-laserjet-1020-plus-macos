# USB runtime public contract — unexecuted

This package contains a C header, contract and manually derived target32 layout
tables only. It contains no runtime implementation, generated executable or
execution result. No candidate was imported, parsed, compiled or run, and no
repository source was changed. All copies/hashes below preserve static inputs.

- `hp1020_usb_runtime_contract.h`: stationary declarations, helper signatures,
  fixed1024-byte mailbox,9216-byte witness,204-byte target32 provider and schemas.
- `CONTRACT.md`: exact input/owner/hook/schedule/initialization obligations,
  including first-close → final acquisition → next-service → first-finish.
- `layout-objects.tsv` and `layout-fields.tsv`: independent manual expectations
  for16 objects/101 fields. The future const C witness must use actual
  sizeof/alignof/offsetof, then be compared against these literals before use.
- `inputs/`, `SOURCE_ORIGINS.tsv`, `INPUTS.sha256`: exact relevant existing
  primary sources, independently frozen plan/literals and layout proposal.
- `DRAFT.sha256`: package seal excluding itself.

The planned integration folder is `open-firmware/entry-usb-test`, with separate
orchestrator, explicit RAM provider, const compiler witness and this public
header. Existing production/fixture/entry-ram files remain unchanged. Root must
approve this package and obtain the separately frozen independent addendum before
any implementation. Linker fit, C/ABI agreement, call graph, stack and execution
are all pending; the old784-byte stack bound does not apply.

The capture-only evidence does not establish hardware/register/cache/DMA/USB
completion, cold boot or physical printing. The first profile's two pages are
software output from supplied events, and the final ZLP is explicitly supplied.

One small pre-freeze refinement increased the provisional provider180 to204 bytes:
it retains the source image's own original cookie/slot, distinct from the current
DCD record, so a new arm invalidates image readiness without relabeling an old
image. The full204-byte extent remains below the approved384-byte cap. No source
or run was previously frozen using the provisional size.
