# Split-object USB runtime layout — unexecuted draft

2026-10-03. `startup.S` and `runtime.ld` are a separate proposed offline target.
They have not been assembled, linked, imported, parsed by a validator or executed.
No runtime C implementation is included. No repository file was changed. The
lead owns review, future build/audit, execution and integration. The accepted
entry-to-document target and its existing symbols/files remain unchanged.

This layout removes a real capacity/initialization obstacle to running the
existing USB components continuously from entry: their ordinary initialized
TinyUSB globals must survive startup, all actual BSS must be cleared, and the
large production memory object must not be inside an aggregate crossing the
entry island. It does not implement a physical controller, cache or interrupt
source, loader, hardware startup, output engine or printing path.

## Exact input and address evidence

`INPUTS.sha256` seals the copied baseline inputs; `SOURCE_ORIGINS.tsv` maps those
copies to their original paths. `DRAFT.sha256` seals the complete new package
apart from itself. `changes.patch` shows the two source deltas against the exact
prior entry sources, for review only; it is not a request to replace those files.

The pinned original ELF is SHA256
`2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`.
Its main PT_LOAD covers `[0x10003000,0x100351e0)`, 205280 bytes. Its file-backed
end is `0x1001d640`; literal words at `0x10005ca8/0x10005cac` independently name
original BSS `[0x1001d640,0x100351e0)`. These bound a new offline placement, not
physical memory size, mapping, cacheability, exclusivity or loader compatibility.
The new program deliberately reuses stock private runtime addresses. No evidence
requires reproducing the HP private aggregate or runtime callback addresses.

The independent CPU review in `baseline/cpu-contract-review.md` preserves exact
stock standard-operation anchors: RSIL at `0x100167ab`; INTENABLE/PS writes at
`0x100167b0/0x100167b5`; RSYNC at `0x100167b8`; WINDOWBASE/WINDOWSTART writes at
`0x10006cd8/0x10006cfa`; LCOUNT/LBEG/LEND writes at
`0x10006d00/0x10006d03/0x10006d06`; ISYNC at `0x10006d0c`; SSAI0 at
`0x10006d29`. This draft uses the previously reviewed *new* normalizer sequence,
not those stock instructions or its windowed ENTRY/TLB/cache continuation.

The actual ELF entry address convention `0x100167a8` and six small external
vector/interface ranges remain. Their contents are new inert parks/zero literals
and the existing new park-pointer table, not HP vector or interface code:

| Immutable external range | Bytes |
|---|---:|
| `[0x10000000,0x10000184)` |388|
| `[0x10000200,0x1000023c)` |60|
| `[0x10000270,0x10000350)` |224|
| `[0x10000370,0x1000049c)` |300|
| `[0x10100020,0x10100304)` |740|
| `[0x10100320,0x1010032c)` |12|

These are preserved address conventions only. Unexpected advertised vectors
park; they do not handle exceptions or prove usable asynchronous execution.

## New section and C symbol contract

All intervals are half-open. A cap is a budget, never an instruction to pad,
load, zero or allow accesses through unused capacity. Actual used ends are
exported separately; their remaining gaps must stay byte-for-byte unchanged.

| Output section / purpose | Start | Used size / exclusive cap |
|---|---|---|
| `.text` + `.rodata`, input and const layout witness |`0x10003000`|cap `0x1000ffe0` (53216)|
| `.bss`, named document then generic globals |`0x10010000`|actual aligned end <= `0x10013fe0` (16352)|
| `.runtime_stack` |`0x10014020`|exact8192; end `0x10016020`|
| `.runtime_mailbox` |`0x10016060`|exact1024; end `0x10016460`|
| `.data`, actual initialized compiler objects |`0x100164a0`|actual end <= `0x10016500` (96)|
| `.runtime_sentinel`, initialized immutable witness |`0x10016500`|exact256; end `0x10016600`|
| `.entry_island` |`0x10016780`|exact96; entry `0x100167a8`, end `0x100167e0`|
| `.runtime_memory` |`0x10016800`|exact114704; end `0x10032810`|
| `.runtime_witness`, bounded test evidence |`0x10032830`|nonempty actual aligned end <= `0x10034ff0` (10176)|

Future C must provide the following separate global symbols. Use the unchanged
production document/memory types and target static assertions; no nested fixture
aggregate, reduced receive/output buffers, heap, extra queue or identity allocator.

| Symbol | Input section | Required contract |
|---|---|---|
| `hp1020_usb_runtime_document` |`.runtime_document`|one full document, exact13496; first object in `.bss`|
| `hp1020_usb_runtime_memory` |`.runtime_memory`|one full contiguous document memory, exact114704|
| `hp1020_usb_runtime_mailbox` |`.runtime_mailbox`|exact1024, layout separately agreed|
| `hp1020_usb_runtime_sentinel` |`.runtime_sentinel`|exact256 nonzero initialized bytes; experiment never writes it|
| `hp1020_usb_runtime_witness` |`.runtime_witness`|one nonempty bounded object; exact C size remains to be selected/measured|
| `hp1020_usb_runtime_c(void)` |ordinary `.text.*`|called once, no arguments, returns only to owned park|

Class, adapter, descriptor, EP0 storage, SETUP, program, publisher, acquisition and
provider state remain independent ordinary `.bss/.sbss` objects. Production source
globals (including TinyUSB and the bound-adapter pointer) enter the same area.
Read-only event inputs and compiler layout witness enter `.rodata[.*]`. Custom
NOLOAD objects must be uninitialized or zero initialized; their declarations and
actual input-section contents require review so NOLOAD cannot hide lost nonzero
initializers. Exact global symbol sizes/unique placement must be audited after
link in addition to the linker's whole-section assertions.

The existing acquisition map sums production text/literals/rodata to45338 and
smaller BSS to15082. Those figures leave7878 code and1270 state bytes before this
new glue/alignment, not proof of its future fit. The known initialized TinyUSB
data totals29 before alignment. No new compiler footprint is claimed. Overflow
must fail; do not shrink production capacities or extend the stock envelope.

## Startup and runtime permissions

The entry's stack-free J targets the normalizer after its nine literal words.
The prefix is unchanged from the reviewed prior target: RSIL15, INTENABLE0,
LCOUNT/LBEG/LEND0, ISYNC, PS15, RSYNC, WINDOWBASE0, RSYNC, a newly reloaded
WINDOWSTART1, RSYNC, SSAI0, owned aligned SP and zero value. No inherited stack,
return address or logical register contents are used. The extra two literals
point to the actual witness span. Linker symbols expose every region and cap.

At `hp1020_entry_after_normalization`, no BSS store/C call has happened. Four
ordinary loops then clear exactly the actual `.bss`, mailbox, full memory and
witness spans. Each span is nonempty and word aligned by contract. BSS/witness
trailing alignment is at most3 bytes, admitted inside the actual zero section.
The unused cap remainder is outside it. The stack is not cleared. Generic
initialized data and sentinel are untouched before C; the future runtime must
also check actual loaded initialized bytes before an initializer can mask a bug.

`hp1020_entry_before_c` immediately precedes a direct three-byte CALL0. The local
no-transform region retains the previously source-verified GAS fix and includes
its immediate `hp1020_entry_park` return. Both actual encodings/target ranges
must be reaudited at new addresses. Two park self-jumps should later execute in
both engines. `hp1020_entry_unexpected_park` remains a distinct inert target.

The future runtime's writable ranges are only actual BSS, owned stack, mailbox,
actual generic initialized data, full memory and actual witness. The sentinel,
entry/islands, code/constants, all guards and every unused gap are immutable.
Before C only the four exact zero spans may be written. No old workload span
list, fixed zero byte total or784-byte stack proof carries over to this target.

## Guard and section admission

`runtime.ld` exports32-byte fixed guards around state/stack/mailbox/data and at
the entry-to-memory boundary. Memory's high guard is witness's low guard. The
witness's entire reserved window, from `0x10032810` through `0x10035010`, is
exactly10KiB including its two32-byte guards. The remaining main tail through
`0x100351e0` stays protected. The code/state/data/witness used-end-to-cap gaps
have separate exported symbols, including the potentially empty cases.

Only ordinary `.literal[.*]`, `.text[.*]`, `.rodata[.*]`, `.data[.*]`,
`.sdata[.*]`, `.bss[.*]`, `.sbss[.*]`, COMMON and the exact custom sections are
admitted. The existing instruction metadata and five known nonallocated libgcc
DWARF sections stay at address0 outside PT_LOADs. Only `.comment` and
`.note.GNU-stack` are discarded. Unknown nonempty inputs, including unwind,
constructors, TLS, dynamic and new allocation families, fail `.unexpected`.

Separate PHDRs prevent a generic-data tail reaching the sentinel and a memory
tail reaching the witness. The linker declares15 PT_LOADs, but actual file/mem
extents, all allocated section flags and linker-added alignment remain *pending
first-build facts*. The future audit must reject an unexpected allocation, an
allocated metadata/discarded input, a load crossing a guard, a hidden writable
object, an unresolved symbol or a byte outside the allowed envelopes. Declaring
a segment alone does not grant an unused gap runtime permission.

## Integration obligations, still unexecuted

Keep this a new target rather than modifying the old entry workload/report.
Choose and review the runtime/header/provider independently, freeze literal
event/command/wire/pixel expectations, then build once with the same pinned
compiler/profile/property gates and full source/dependency snapshots. Inspect
the actual emitted sections, symbols, map, literals, direct calls, callbacks,
libgcc closure, instruction bytes/properties and stack-use files before running.
The old audit's exact padding/addresses must not be blindly loosened or reused.

The read-only observer can retain entry/after-normalization/pre-C/park symbol
names, but needs this profile's actual allocations, writable generic data,
four zero spans and new guard layout. Paint the whole declared envelopes for
capture while granting reads/writes/fetch only to actual admitted spans; do not
let PT_LOAD mem tails prezero BSS. Check every gap, all original initialized bytes
at pre-C, immutable sentinel/islands, actual output and uninterrupted CPU state.
Recompute linked frame/callback bounds and measure the concrete minimum SP; the
retained8KiB stack is a budget, not a verified sufficiency result for USB code.

Supplied privilege, PC-relative literal mode, accessible/exclusive loaded RAM,
safe nonintersecting incoming loop endpoints and absence of asynchronous/debug
exceptions remain explicit. There is no LITBASE/cache/TLB/debug/controller/engine
instruction or live peripheral binding here. No physical or loader proof is
created by any future RAM-only success.
