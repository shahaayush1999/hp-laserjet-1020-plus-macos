# Entry layout witness — unexecuted draft

This is one compiler-layout witness for the first call to
`hp1020_usb_document_finish`. It adds a 260-byte const table only. It does not add
runtime instructions, another workload, writable storage, pointers, input bytes
or an observed-result oracle. No source was compiled, imported or executed while
preparing this package. Repository and other frozen drafts were not changed.

`hp1020_entry_layout.c` includes the actual production headers; offsets and widths
use `offsetof` and `sizeof`, not the literal expected values. The independent
`expected-target32.json` was written from the header arithmetic below. Its numbers
are an unexecuted expectation, not measurements from a compiler. Only the linked
table can establish what this compiler actually emitted.

## Public schema and integration

`hp1020_entry_layout.h` names every word/record. The exported symbol is
`const uint32_t hp1020_entry_layout[65]`, ordinary rodata with no custom section.
Header words0..4 are `[version=1, word_count=65, field_count=20, state_bytes,
memory_bytes]`. Record i occupies words `5+3*i` through `7+3*i` and stores
`[base, offset, width]`. Base1 means the actual `hp1020_entry_state` symbol;
base2 means `hp1020_entry_memory`. All offsets and widths are bytes. Width1 fields
must be read as bytes, independently of adjacent flags.

Compile this additional translation unit with the exact entry target profile and
the unchanged production include directories. It needs no generated input header
and does not include the workload header. The eleven transitive project/vendor
headers are copied under `inputs/`; the compiler's standard headers/toolchain
remain the parent build's pinned provenance, not replaced by this package.
`used` preserves the constant at compilation. If section garbage collection is
enabled, retain the symbol explicitly at link time; do not silently omit it.

Before executing C or using any offset, the parent runner should independently
read the symbol from the audited ELF, require its exact260-byte extent, decode
all65 words as big-endian uint32 and compare the entire table against the literal
expectation. Reject any mismatch. Audit the witness object/linked sections for
read-only allocation and no additional nonempty code or writable sections. These
are pending build checks, not claims established by this source-only draft.

At the first actual finish-entry breakpoint, inspect the production objects
directly using the verified layout. The layout table contains no expected live
state, and it must not substitute mailbox snapshots for production reads. The
separate acceptance plan owns pre-finish and post-finish behavioral expectations.
The frozen linker places state at0x1000e000 and memory at0x10016800; those symbols
and extents must also match the linked ELF before either span is read. This says
nothing about a physical HP memory map, loader compatibility or physical output.

## Independent target32 derivation

Assume the pinned big-endian target32 ABI: byte1, uint16 size/alignment2,
int/uint32/long/size_t/data and function pointers/enums size/alignment4.
Ordinary structs round up to their maximum member alignment; receive memory is
explicitly aligned16. Big-endian order changes scalar bytes, not these offsets.
The C witness asserts the scalar sizes and rejects a host/short-enum profile; it
intentionally does not assert the hand-derived structure offsets.

The JBIG arithmetic decoder has4096 status bytes followed by seven four-byte
members: `c,a,pscd_ptr,pscd_end,ct,startup,nopadding`; total4124.
`jbg85_dec_state` has48 bytes before that decoder. Its tail starts at4172:
`bie_len`4, `buffer`20, then eighteen four-byte fields/elements through
`end_of_bie` (the one-element `at_line`/`at_tx` arrays each count once).
Thus `48+4124+4+20+18*4=4268`. `hp1020_image` adds one pointer, seven uint32,
one int, one enum and three flags plus one padding byte:44, total4312.

`hp1020_page` starts with sixteen uint32 (64); two byte flags reach66, three
uint16 reach72,24uint32 reach168, two byte flags and20 BIH bytes reach190, then
two alignment bytes make192. `hp1020_raster` is12. The semantic parser starts
with16pages +128rasters =4608. Its arena pointer ends4612; five uint32 place
`documents` at4628. Error plus nine following uint32 end4672; header16 and
metadata4096 end8784. Three byte flags plus one pad reach8788; two pointers give
8796.

The page plan is eight uint32,32 bytes. The stream is parser8796 +image4312 +
plan32 =13140, followed by four pointers (end13156). `pages` is at13156; six
uint32, two enums, two flags and two padding bytes make total13192.
The output ring is one pointer +ten uint32 +one enum +four16-byte slots =112.
Output therefore has stream13192 +ring112 +plan32 =13336 before five pointers,
ending13356. `page_index` is at13356, `pages_drained`13360,
`documents_completed`13364 and `document_first_page`13368. Error13372, active13376,
finished13377 and two padding bytes give13380.

Receive state is one pointer +four16-byte slots =68 before generation. Generation,
issued,consumed,count,error are at68,72,76,80,84. Stopped/quiescent at88/89 plus
two padding bytes make92. Document output begins92, so add92 to all relative
output/stream/parser offsets. Document output ends13472. Memory pointer13472,
document callback13476, context13480, feed_generation13484, payload_error13488,
finished13492, output_quiescent13493, feeding13494 and one padding byte end13496.

Memory receive data is4*1024=4096 with alignment16. Stream memory is
65552+4096+8192=77840 bytes. Output memory adds4*8192=32768 slots, totaling110608.
Within document memory, output stream starts4096 and output slots start
`4096+77840=81936`; document memory ends114704, already a multiple of16. No
additional array tail/padding exists between the selected storage spans.

## Exact input provenance

`INPUTS.sha256` seals the copied eleven transitive production/vendor headers and
four context-only files. The root for `inputs/open-firmware` and `inputs/vendor`
is the shared repository. The context-only workload header and linker script came
from the existing frozen entry draft packages; CPU/layout notes came from their
named `/tmp` files. No copy is used to overwrite a production or frozen source.
`DRAFT.sha256` seals this source/header, literal arithmetic table, note and input
manifest. No build products or execution results belong to this draft.
