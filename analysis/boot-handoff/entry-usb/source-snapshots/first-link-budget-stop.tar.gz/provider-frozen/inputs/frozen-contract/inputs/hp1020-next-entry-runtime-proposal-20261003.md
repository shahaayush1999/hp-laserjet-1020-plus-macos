# Next step after entry-owned document execution — static proposal, 2026-10-03

**Recommendation:** build one small, stationary USB runtime that starts once at the new entry, runs the existing TinyUSB printer/control and retained OUT publication/acquisition components, and drains production document/output work from a bounded RAM event source. Link the production components unchanged. Put the synthetic platform provider and its acceptance witnesses in separate test files; do not include the nested test fixtures.

This removes a real integration boundary: the current entry workload calls receive/document functions directly, while the USB experiments retain their C state but obtain each API invocation and CPU call setup from a host harness. The new program would itself order ingress, exact-cookie settlement, TinyUSB service, parsing, publication, and recovery for its entire lifetime. It would still be an offline ELF, with no controller or printing claim.

## Measured footprint and feasible placement

These are sums of **existing** target map input sections, not an estimate of source lines and not a new link result. The acquisition map is `analysis/usb-path/udc-acquire/target/target-check.map` (SHA256 `f4a5d2a0a2effaeffae02c988d3a3d5c20e8d6fbd4e4a8bfd57b591c9c233a13`). Its whole text output is 70,296 bytes; input text/literal sums are 69,659, including 25,565 from fixture.o. Input contributions excluding fixture.o:

| Existing objects | Text and literals |
|---|---:|
| OUT/acquisition, EP0, SETUP, program, publisher | 15,126 |
| TinyUSB adapter and printer class | 9,257 |
| Receive/document, image/semantic/page plan, freestanding memory | 7,529 |
| JBIG codec | 5,212 |
| TinyUSB tusb/usbd/fifo | 6,894 |
| libgcc unsigned divide | 76 |
| **Total** | **44,094** |

Their rodata contributes another **1,244**, so existing production text/literals/rodata sum to **45,338 bytes**, excluding input-section alignment, new startup, descriptors, event inputs and runtime/platform glue. Full map text padding is 637 bytes; rodata padding is 11. This map did not use section garbage collection, so this is a useful conservative starting closure, not proof of the eventual linked size. The current entry image uses 16,858 text/rodata bytes, but its code region admits only 24,576: it cannot simply absorb this closure.

Target storage from map lines2801–2980 and existing sizeof witnesses:

| Stationary production allocation | Bytes |
|---|---:|
| Full document memory (receive/decoder/output storage) | 114,704 |
| Document state + printer + adapter | 13,496 + 56 + 332 = 13,884 |
| OUT plus descriptor; EP0 plus owned storage; SETUP plus capture | 80 + 296 + 96 = 472 |
| Program; publisher; acquisition | 88 + 140 + 152 = 380 |
| Other linked BSS: TinyUSB342 + adapter bound pointer4 | 346 |
| TinyUSB initialized data | 29 |

Thus existing production mutable/file-backed data totals **129,815** before alignment. Adding the retained 8,192-byte stack, 1,024-byte mailbox, 256-byte initialized sentinel, and 45,338-byte code/rodata gives **184,625**. The declared main span used by the accepted entry audit, `[0x10003000,0x100351e0)`, is **205,280** bytes: **20,655** remain before new glue/input/witnesses, alignment, guards and the entry island. Exact per-object sums are in the accompanying JSON.

**Objects must be split.** A contiguous 128,588-byte adapter/class/document-plus-memory allocation cannot fit after the retained entry island. `0x100351e0 - 0x100167e0 = 125,440`; starting at0x10016800 leaves125,408. The existing APIs use pointers and permit a separate 114,704-byte document-memory object at `[0x10016800,0x10032810)`, while all smaller stationary objects live below the island. This leaves10,704 bytes above document memory. Do not copy fixture.o's protected-memory duplicate, 4,096-cookie history, 512-document log, 262,144-byte pixel capture, 32,768-byte wire capture, or27,712-byte trace/read storage: those dominate its700,016-byte input BSS and are test infrastructure.

A **provisional budget**, not an implemented linker script:

| Use | Candidate range / capacity |
|---|---|
| New text/literals/rodata/event constants | 0x10003000..0x1000ffe0;53,216 bytes |
| Guard then admitted zero-initialized state/globals | 0x10010000..0x10013fe0;16,352 bytes |
| Guarded8KiB stack | 0x10014020..0x10016020 |
| Guarded1KiB mailbox | 0x10016060..0x10016460 |
| File-backed data/sentinel, separately guarded | 0x100164a0..0x10016600;352 bytes |
| Preserved new entry island | 0x10016780..0x100167e0, entry0x100167a8 |
| Full document memory | 0x10016800..0x10032810 |
| Optional bounded logical-I/O witness | remaining upper gap, at most10KiB including explicit guard plan |

The smaller production state/BSS sum is15,082 excluding the29 initialized bytes, leaving1,270 bytes in that proposed zero-state budget for compact runtime/platform state and alignment. Code budget leaves7,878 bytes beyond existing code/rodata for new code, constants and padding. This is plausible but tight enough that **actual linked bounds are an admission gate**, not a promise. Overflow must stop the experiment; do not reduce production buffers or silently extend declared RAM. Reuse the six isolated vector/interface islands as new immutable parking bytes, not stock handlers.

## Minimal new runtime, existing ownership

Keep separate stationary objects for document, memory, printer, adapter, SETUP, EP0, OUT/acquisition, publisher and program. Reuse the pinned patched TinyUSB source closure and `tusb_config.h` unchanged: OS_NONE, full-speed, EP0/packet64, queue16, custom application class. No heap, RTOS, second receive queue or identity allocator.

New runtime state should need only an event cursor/bounded work counter, first-error/stop state, three current DCD packet records containing **copied original cookies**, a bounded pending cancellation mask, and the current original recovery ticket. A test-only saved retired cookie/snapshot is enough for the one late-event control. Device/configuration/ID bytes and the input stream can be const. A bounded independent logical-I/O trace and final real pixels belong to the platform fixture, not to production receive storage.

The loop should:
1. Admit at most one immutable supplied ingress/settlement event, retaining WAIT events and their original identities.
2. Permit exact-cookie acquisition/cancellation and actual reset ingress even while ordinary progress is blocked. Cache/order hooks remain synchronous and cannot recurse into the adapter.
3. Use `hp1020_udc_publish_service()` for actual TinyUSB task/control dispatch; never call dcd_event_* directly around the adapter. Use combined progress bits before pump/arm/finish_reset/finish, respecting the existing SERVICE-only reset-drain exception.
4. Pump ready document data and call the sole `hp1020_udc_publish_arm_out()` wrapper for the next64-byte packet. The genuine DCD callback binds once through prepare_and_publish; post-bind failure retains its original cookie even when returning false.
5. Drain cancellation requests outside callbacks; supply each recovery acknowledgment only from its corresponding explicit event. No memset/init during recovery, no owner-bit-derived settlement, no EOF from ZLP/short packet.
6. Finish only at explicit scenario end, after END_DOC notifications and ownership drains; park once.

The platform seam supplies recording register operations, DMA labels/cache copies, SETUP capture facts, EP0/DCD callbacks, cancellation settlement and output completion. Reuse the existing component policies instead of cloning their validators' op-code switch trees. In particular, keep the actual received source separate from CPU receive storage until acquisition hooks run. The first schedule below needs only initial binding recovery; retaining the normal cancellation/recovery routes in the runtime is not a claim that later interruption variants have been tested.

**Startup change needed:** current entry.ld:169–175/224 rejects generic.data/.bss; startup.S only clears the three old spans. TinyUSB contributes real initialized objects (`_usbd_qdef`20,`_usbd_spin`8,`_usbd_rhport`1) plus globals. The new linker/startup must explicitly admit all of them, preserve loaded initialized bytes, and zero BSS exactly once before any adapter/TinyUSB call. It must not blanket-zero TinyUSB.data. Reinitialize neither stack nor CPU between events. The prior784-byte stack bound applies only to the old workload; repeat whole-closure/property/call-graph and concrete-stack audits for the new one.

## One first bounded experiment

Use one fixed event schedule and the existing352-byte small-black stream; all device-side events are supplied in RAM, never by host writes after entry:

- Supplied bus reset, canonical **raw** SET_CONFIGURATION1 through SETUP/actual TinyUSB, original EP0 status completion, then the three independent binding-recovery promises. Use the existing recording program/publisher path. Raw configuration keeps this first test from choosing an unproved HP dynamic-CSR/offload mode; it is explicitly a supplied software control-delivery profile.
- Two complete documents back-to-back in the same receive generation, each split64/64/64/64/64/32. Expect exactly two distinct END_DOC events and64 literal0xff pixel bytes, before any finish/EOF.
- Explicitly end input once, finish, drain, park. Compare complete RAM/CPU/call/access evidence in the independent interpreter and direct QEMU, with no call0 helper or writes/re-zeroing after initial seed. Preserve original cookies and exact actual output, not reconstructed counters.

Freeze literal wire/event/pixel and command-order expectations before implementing this schedule; first run may expose an integration defect and must remain a separate captured outcome. Retain nonzero BSS/stack paint, every admitted linked span, both real park steps, and bounded event/trace overflow failure. There is no per-document close, finish or reinitialization. These two normal END_DOC boundaries are the smallest useful first oracle; do not port the huge component adversarial matrices into the target.

After this first integration is established, the next variant can interrupt a third document with canonical SOFT_RESET while an original OUT cookie is held, settle it and supply the three promises separately, then reject one old-cookie replay after descriptor reuse before decoding a fresh page. That variant is proposed only: it is not part of the first workload or its acceptance claims.

## Benefit and limits

This would supply the missing application-side scheduler/lifetime/startup integration and demonstrate reusable USB-to-page execution entirely inside one running target program. It does not establish USB interrupt production, real register effects, controller startup, DMA mapping/cache capability, SETUP overwrite/stall-clear safety, cancellation quiescence, IN wire ACK/length, HP CSR mode, a physical output consumer, print-engine behavior, loader compatibility or cold boot. Those facts remain visible external inputs; the recording provider must not convert successful hook calls or descriptor bits into physical proof.

No source was compiled/imported/executed or modified in the repository for this proposal. Static map/data reads only. Source hashes are in the companion manifest; the lead owns all subsequent implementation and execution decisions.
