# Approved pre-execution diagnostic clarification

Root approved this clarification2026-10-03 before the first new build/execution.
The public contract/header and their hashes remain untouched.

Provider `open_mask` and mailbox `OPEN_MASK` use the existing actual-DCD-open
diagnostic convention: bit0 EP0 OUT, bit1 EP0 IN, bit2 bulk OUT1, bit3 bulk IN1.
Successful logical DCD init records3; actual successful OUT1 then IN1 opens
produce7 then15. This is a provider callback observation, not physical endpoint
state. Production program `completed_mask`/`selection_mask` keep their distinct
two-bulk-endpoint convention; the successful completed mask is3.

Provider `read_cursor`/mailbox `READ_CURSOR` count successful supplied read
consumptions cumulatively. `scope_read_cursor` resets only on an admitted new
scope. Thus the supplied healthy schedule ends at cumulative74, final scope5.
Neither count is updated from a write or diagnostic expected trace.
