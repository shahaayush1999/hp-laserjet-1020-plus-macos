# RAM provider and const layout draft

Authored2026-10-03, **unexecuted**. No compiler, candidate import, validator,
target run, USB call or repository modification was performed by this author.
Root owns integration and all execution. The approved public header/contract
remain unchanged and are copied under `inputs/frozen-contract/`; independent
acceptance was frozen before these C implementations were written.

The two new source files are `hp1020_usb_runtime_ram.c` (stationary objects,
one bounded supplied RAM provider, callbacks and the approved `ram_*` helpers)
and `hp1020_usb_runtime_layout.c` (const-only457-word compiler layout witness).
The root-owned `hp1020_usb_runtime.c` supplies orchestration, step/fail and scans.
All production components remain unchanged. No fixture source is included.

Build integration requires the unchanged public header and generated
`hp1020_usb_runtime_input.h`. Only ram.c includes that generated definition of
the single external const352-byte input; layout.c emits no instructions or RW
state and never includes the input. The root builder must preserve all objects,
verify NOLOAD input initializers, linked sizes/ranges and every layout word,
then review the newly emitted code and actual stack/callback closure. This draft
has not measured any code size, stack bound or successful lifecycle. The narrow
remaining code budget is a real link gate, not permission to shrink production
memory or expand the accepted RAM map.

Initialization installs only the eight A7 witness guards and invokes the actual
first-use production initializers/TinyUSB. It does not erase provider/mailbox/
witness, the root's first INIT step, or any root-owned counters. Runtime owns all
later admissions, service, EP0 proposal/observation, three recovery promises,
arm/acquire/pump/close/finish. `ram_retired` checks actual FREE/PENDING states and
only clears its own live byte; original cookie/pointer/length remain retained.

The DCD captures actual adapter ownership after a real bind, including a later
publication failure. Before-device hooks run while the publisher is still
unwinding, so they validate against the actual adapter owner, never an as-yet
unwritten provider record. Cancellation callbacks mark only the original
retained record and fail this healthy schedule; they do not settle/release it.
After-device hooks verify both current retained and original image identity
before copying only descriptor16/prefix64. Reads use the supplied immutable
script; writes/order only record attempts. There is no hardware side effect,
automatic readback or reconstruction of an event from today's generation.
The existing kind3 register-order diagnostic uses argument `UINT32_MAX`, while
kind8 acquire-order uses argument0. Root caught that distinction during static
integration review; it was corrected before this first source freeze/build.

Output copies actual accepted ring bytes and records actual document callback
fields; the implementation contains no expected FF output, expected event IDs,
expected cookies or complete expected trace. The independent raw gate owns
those assertions. `ram_note` updates secondary actual-state/FNV observations at
each named checkpoint; it cannot service, acquire, retire or change a component.
Raw linked component/private TinyUSB state remains the independent authority.

The device18/configuration32 descriptors retain the existing fixture's bytes.
The approved minimal immutable class ID is `{0,2}` because GET_DEVICE_ID content
is outside this raw-configuration-only profile. Unsupported DCD entry points
fail without creating a control response or physical action. OSAL interrupt
brackets and the permitted logical init/connect/SOF-disable callbacks are
explicit recording-provider no-ops, not interrupt/pullup implementations.

`OPEN_MASK-CLARIFICATION.md` records the one root-approved field-semantic
clarification made before any build/execution; it changes no frozen ABI byte.
Input copies and source origins are sealed separately. Source snapshots include
the read-only fixture references used for existing descriptor/constants only;
none is compiled by this provider.
