# USB runtime audit draft

2026-10-03. **Unexecuted and unparsed.** No Python import, compiler, assembler,
validator, interpreter, QEMU or device operation was run to prepare this package.
Only text reads, independent source reasoning, copies, hashes and writing this
new script were performed. Root owns first build, artifact review and execution.
This adds a new audit file; it does not edit the accepted entry audit/interpreter,
production components, builder, runtime provider or any repository source.

API: `audit_target(path, prefix, stock_path) -> (Program, audit)`. Integrate the
script at `scripts/hp1020_entry_usb_audit.py`. The stock path is the repository's
`analysis/sihp1020.elf`; the five frozen contract/layout files are read from
`open-firmware/entry-usb-test`. The unchanged neutral module and shared Program
parser are source-hash-bound. New source, layout and property checks are local.

## Exact admission

- Twenty allocated sections and fifteen complete PT_LOADs must match the frozen
  split-object layout. Generic BSS/data use actual ends within their caps. Public
  witness is exactly9216; full production memory remains114704. Six inert external
  islands and the original entry address convention remain, with new bytes only.
  No file or memory tail may span a fixed guard or unused capacity.
- The public manually frozen16-object/101-field tables are hash-bound before
  being read. The actual1828-byte compiler table must equal their457 literal
  words. Each actual object symbol must have its approved size, allocation and
  alignment; the352-byte source and16-byte raw SETUP source are independently
  byte/hash checked. No expected layout is learned from the candidate.
- Mutable closure is those16 public objects, the256-byte sentinel and twelve
  existing adapter/TinyUSB objects. All27 retained input objects are inspected
  as ET_REL. A writable input section must contain exactly its approved object.
  Every object sent to NOLOAD must contain only zero bytes and no relocation;
  a zero raw pointer with a relocation is not accepted as zero initialization.
  The const layout unit cannot contain functions or writable storage.
- Three ordinary initialized TinyUSB objects are independently checked: queue20
  (actual interrupt callback, item size12, actual192-byte buffer, depth192, zero
  indices/flags/padding), spin8 (same callback, zero nesting), rhport1 (FF).
  Their actual relocated bytes are preserved by startup, then may change in C.
  The separate sentinel remains immutable despite its ELF SHF_WRITE flag.
- Actual private `_usbd_dev` is68 bytes. The getter must remain the independently
  reviewed25-byte shape, including byte52, endpoint*2/direction calculation,
  bit0 extraction and a newly relocated literal to the actual core object.
  No prior fixture address is reused and no target getter is invoked by audit.
- Whole modern instruction annotations are decoded against exact ELF bytes.
  The only special operations are the reviewed normalizer's exact standard
  encodings. All direct targets require annotated boundaries, all CALL0 targets
  require actual function entries, all L32R words require annotated/fixed
  literals and independently recomputed BE displacements. Dynamic targets stay
  a runtime obligation. ENTRY/windowed calls/hardware loops/cache/TLB/custom
  instructions are not admitted. The known libgcc ILL is excluded from execute
  ranges; its exact DIV0 marker is classified as data, never decoded as code.
- The new nine-word startup pool and four actual-used clear loops are checked
  locally. The mixed DATA/INSN no-transform annotation is allowed only for the
  exact six-byte new CALL0/park fragment. The CALL0 is checked against the new
  C entry; old linked CALL0 bytes are never transplanted.
- All26 `.d` and26 `.su` files plus27 `.o` files are required. Dependencies bind
  the actual production/runtime source paths and include system headers. All19
  effective TinyUSB files are rehashed against the unchanged pinned upstream
  and local patch manifest. `.d` output targets may be the fixed builder output
  directory or the audited capture directory; both declared and retained paths
  are reported. Dependency source paths must still be accessible for audit.

## Runtime policy interface

`entry_read_spans` and `entry_zero_spans` use `(start, BYTE_COUNT)`.
`write_ranges` and `execute_ranges` use `(start, END)`.

Zero-span order is generic BSS, mailbox, full memory, witness, matching the four
startup loops. Write-range order is those four, then the owned8192-byte stack,
then actual generic.data. Sentinel is never writable. Root's model must apply
phase restrictions: no stores before normalization; only four zero spans while
clearing; then four spans/stack/data in C, with exact natural call checkpoints.
`entry_function_starts` contains every actual nonempty STT_FUNC entry.
`symbol_records` are the original linked symbol records, not names regenerated
from the manual layout. The return Program forbids lazy decoding.

The audit emits exact section/load/annotation/register-literal/call source
facts, object/dependency/stack-use hashes, input-zero evidence, raw symbols,
actual initialized bytes, and the compiled/manual table comparison. Root must
preserve these alongside tool/profile/libgcc/build evidence and complete source
snapshots before target execution.

## Still requires first-build evidence

No emitted ELF, annotation, input-object form, frame record or new runtime has
been inspected with this script. The first build may fail a narrow assumption:
actual section flags, a compiler input section form, a different getter encoding,
a named source path, or bounded alignment. Preserve such failure first and
review original bytes before changing a rule. Do not relabel an unrun draft as
validated, infer completion from a passing audit, or change prior report hashes.

Individual `.su` frames are only one part of stack evidence. A new linked call/
callback/libgcc review and measured runtime depth are still required. The prior
784-byte conservative bound and720-byte observation do not transfer. This audit
makes no physical boot/RAM/cache/IRQ/USB/printing compatibility claim.
