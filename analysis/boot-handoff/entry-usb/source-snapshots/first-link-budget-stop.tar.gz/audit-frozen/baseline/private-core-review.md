# Private TinyUSB state: independent target32 layout and BUSY witness

2026-10-03. Author `/root/usb_reference_contract`. Static preparation only,
before new runtime implementation/execution. No compiler, assembler, candidate,
validator, interpreter, QEMU, source import, source patch, repository edit or
device operation was run. This note uses exact existing source copies, manual
ABI arithmetic, saved prior target symbols/disassembly, and raw ELF hex reads.
It leaves the first independent runtime plan/oracle unchanged. The provider
contract and additive checkpoint schema remain separately pending approval.

## Result and exact source binding

For the current **patched** TinyUSB0.21.0 source and the selected configuration,
`usbd_control_xfer_t` is24 bytes/alignment4 and `usbd_device_t` is68 bytes/alignment4.
The private static symbol `_usbd_dev` therefore has expected size `0x44`.
Its `ep_status[8][2]` begins at byte52. Bulk endpoint1 OUT status is byte54
(`0x36`); IN1 is55; EP0 OUT/IN are52/53.

**These endpoint fields are ordinary volatile uint8_t bytes, not C bitfields.**
`TU_EDPT_STATE_BUSY=0x01`, STALLED=`0x02`, CLAIMED=`0x04` are explicit masks.
No host bitfield allocation or endian convention is used for these masks.

`inputs/effective/` is an exact copy of the already preserved effective source
at `/tmp/hp1020-udc-acquire-2gdl6ewq/effective-source/`. All19 files were hashed
and matched against its `effective-source.json` without executing source.
Their original provenance remains pinned upstream commit
`dae3f9a366bfcddbf9dcf1b48d7500286a849539`, plus the preserved local patch.
The relevant hashes are:

| Input | SHA256 |
|---|---|
| effective src/device/usbd.c | 8bf699c1522d65301a4c63e2bfa529d302d3955b8cd18dd1602d7ace441a62dc |
| selected tusb_config.h | 895c6599700b09f84be46ce74ac75f3974ce3b277d98f233134a54aea637616a |
| existing acquisition target ELF | 21fa86a1411647667e9183b63e107c66787abf09e9223d0a8c0e4bb09e0cf610 |
| existing target symbols | 4a5daa316cdb983007b4ee96b6bbf3e06e97643801a930f81c559627947a64cf |
| existing target disassembly | 28ccc4295412b67d28b6e2b5b176e103c643fa28ce215b76c321fda015cdc0b4 |

The copied prior target's effective-source manifest has the same source hashes.
`INPUTS.sha256` additionally seals config, patch/manifest, adapter, build/profile
sources, GCC ABI source and complete existing ELF/map/symbols/disassembly. All
addresses from that earlier fixture are **cross-checks only**: the new runtime
must locate its own symbols and cannot reuse `200bc90c` as an address.

## Manual layout arithmetic

Effective `usbd.c:127–134` declares the control structure. Effective
`tusb_types.h:540–565` defines the packed8-byte request and statically asserts
its size. Effective `usbd_pvt.h:78` defines the completion function pointer.
Selected `tusb_config.h:15–17` sets interfaces4 and endpoints8. There is no
conditional member between these declarations in the selected source.

The copied GCC14.3.0 `xtensa.h:112–143,642–646` specifies four-byte words,
16-bit short,32-bit int/long,32-bit pointer alignment and SImode pointers/function
addresses; copied `defaults.h:484–493,754–760` gives the default one-byte bool
and word-sized pointer. The existing builder has no `-fpack-struct` or unusual
ABI override. Packed request is8 bytes; the enclosing structures are not packed.
Thus:

| Control member | Offset | Bytes |
|---|---:|---:|
| request |0|8|
| buffer pointer |8|4|
| data_len |12|2|
| total_xferred |14|2|
| failed bool |16|1|
| alignment padding |17|3|
| complete_cb pointer |20|4|
| total, alignment4 |24| |

Effective `usbd.c:136–158` then gives:

| Device member | Offset | Bytes |
|---|---:|---:|
| ctrl_xfer |0|24|
| connected |24|1|
| addressed |25|1|
| suspended |26|1|
| self_powered |27|1|
| remote_wakeup_en |28|1|
| cfg_num |29|1|
| speed |30|1|
| sof_consumer |31|1|
| itf2drv[4] |32|4|
| ep2drv[8][2] |36|16|
| ep_status[8][2] |52|16|
| total, already multiple4 |68| |

The local compatibility patch matters to this calculation: it adds `failed`
and replaces the original compiler-dependent device-status bitfield union with
two ordinary logical bytes. Offsets derived from untouched upstream would be
wrong. The separate endpoint status array itself is already bare bytes.

`expected-target32.json` is manually authored literal data, not compiler output
or data copied from a forthcoming runtime result. It freezes sizes, member
offsets, masks, existing instruction evidence and selected checkpoint values.

## Existing emitted getter independently corroborates the byte offset/mask

Saved target symbols show `_usbd_dev` at `200bc90c`, size `44`, and
`usbd_edpt_busy` at `2000b0e8`, size `19` (25 bytes). The saved map separately
has `.bss._usbd_dev` of size `44`. The getter's whole instruction bytes read
directly from the sealed ELF are:

`1afe15 030943 0a9909 037340 a399 0c0200 229034 020240 d00f`

The ELF header's single PT_LOAD maps file `1000` to virtual `20000000`;
therefore the getter is file `c0e8` and its literal is file `b93c`.
That literal's exact bytes are `200bc90c`, the saved object address. Raw header,
getter and literal hex reads are preserved under `observations/`.

| Address | Exact bytes | Existing decoded operation |
|---|---|---|
|2000b0e8|1afe15|L32R a10,2000a93c -> actual `_usbd_dev` literal|
|2000b0eb|030943|EXTUI a9,a3,0,4 -> endpoint low nibble|
|2000b0ee|0a9909|ADDX2 a9,a9,a10 -> base +2*endpoint|
|2000b0f1|037340|EXTUI a3,a3,7,1 -> direction|
|2000b0f4|a399|ADD.N a9,a9,a3|
|2000b0f6|0c0200|MEMW for the volatile load|
|2000b0f9|229034|L8UI a2,a9,52|
|2000b0fc|020240|EXTUI a2,a2,0,1|
|2000b0ff|d00f|RET.N|

This is a byte load and explicit low-bit extraction on the selected BE target,
independently agreeing with offset `52 +2*epnum +direction` and mask1. There is
no endian-dependent word or bitfield extraction to infer. For endpoint `0x01`,
the effective byte address is `_usbd_dev+54`; for `0x81`, it is+55.
The exact source counterpart is effective `usbd.c:1683–1689`, using endpoint
number/direction helpers from `tusb_types.h:572–576`.

The new linked target must repeat the **static** binding check against its own
ELF: local object symbol size68, actual object address within admitted BSS,
getter symbol/instruction boundaries, literal target to that same object,
index calculation, L8UI offset52, mask1 and no unexpected write/call. Do not
call the getter from a debugger or patch production C to expose the private
type. An ordinary target-side getter observation can be a secondary witness;
the independent gate must read the actual private byte in each RAM capture.

## Selected healthy-path values and additional natural observations

Copied adapter `hp1020_tusb_adapter.c:901–934` first calls
`usbd_edpt_claim`, then submits `usbd_edpt_xfer`. Effective `tusb.c:227–241`
sets CLAIMED (`04`); effective `usbd.c:1625–1636` sets BUSY (`01`) before the
DCD callback. A successful arm thus leaves OUT1's actual byte **05**, not just
a true getter result. No selected scenario stalls or uses bulk IN.

Adapter `complete_locked:649–673` merely changes its exact original owner
DCD -> PENDING on successful acquisition. It does not enqueue/deliver the
TinyUSB event or clear core bits. `deliver:738–757`, called through service,
later queues the original completion and drains TinyUSB. Effective
`usbd.c:760–778` then clears BUSY|CLAIMED **before** the class callback.
This gives the expected actual16-byte endpoint-state array:

| Actual observation | ep_status bytes | Meaning |
|---|---|---|
| before C | sixteen00, and all68 device bytes00 | startup zeroed the actual generic BSS |
| first close_input entry, before its first instruction | `00000500000000000000000000000000` | final cookie14 DCD-owned; sequence13 reserved |
| NEXT publish_service entry after close and final acquisition | `00000500000000000000000000000000` | same cookie PENDING; OUT component FREE; reservation still count1/consumed12 |
| FIRST adapter_finish entry after service + empty pump | `00000000000000000000000000000000` | core completion delivered; count0/consumed13 |
| final park | `00000000000000000000000000000000` | no new submission after close |

The accepted additional ordering is explicit: after first actual close_input,
there is **no intervening service poll** before final successful acquisition13.
Therefore the next actual `hp1020_udc_publish_service` entry captures PENDING
before delivery. Earlier ordinary service invocations remain legitimate. The
first actual adapter_finish entry is after service and the empty reservation
pump, with no EOF-caused output. These are read-only observations at existing
symbols, not C marker functions or host-injected state. This note records the
source-derived addition; it does not mutate the frozen first plan/oracle.

All EP0 transfers in the selected schedule have already completed normally
before bulk begins. Thus no other endpoint state byte is nonzero at these
checkpoints. The complete private object is not generally allzero during USB
operation; only the endpoint array is asserted here. The source/pointer/control
fields must not be replaced by a guessed whole-object constant.

BUSY and CLAIMED remain **software bookkeeping**, not physical USB ACK, DMA
retirement or cache-visibility proof. Real descriptor acquisition and reset
promises remain supplied in this RAM-only experiment. Admission of these raw
private fields does not broaden any hardware or memory permission.

