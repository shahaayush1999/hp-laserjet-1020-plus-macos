# Static addendum: V4 closes the provenance finding

2026-10-03. The V3 review remains unchanged at
`/tmp/hp1020-entry-usb-gate-v3-independent-review-20261003.md`, SHA256
`65d24e834298d06b332c877f6299c4902f96a29b135313ae15b0cdcab75cf537`.

Read V4's exact map-only delta. It recognizes every `.a(member)` occurrence,
requires the original archive paired with exactly the two preserved member
names, and rejects additional/differently named selections. It also requires
exactly28 unique normalized absolute LOAD paths:27 known object basenames in
one original target directory and the one original compiler library. This
closes the V3 finding without requiring discarded temporary paths to exist.
No further static schema/path/closure incompatibility was found.

V4 preserves the independently pinned full archive/member bytes, actual ar
extraction, four-file subtree, old26 `.d`/`.su` sets and all positive workload
expectations. Root owns application and evidence-control execution. No checker
was parsed/imported/run, no candidate/build was executed, and no repository file
was changed by this review.

Separately reviewed root's narrow dependency-reader correction after the third
audit-only stop. It preserves all GCC-declared dependency occurrences and
records explicit duplicate counts, seals each distinct resolved input, and
retains the one-C-source-per-unit/actual unit location and effective-source
checks. A repeated identical header is no longer incorrectly rejected merely
for appearing twice. This is not a target semantic change or a target result;
the historical failed admission remains distinct.

Reviewed exact inputs:

- V4 checker:
  `/tmp/hp1020-entry-usb-gate-v4-20261003/check-hp1020-entry-usb.py`,
  SHA256 `e6feb02335ef56b496dec4d1974e2866e18939a7be407a2346dfc8f28640bf2c`.
- V4 complete delta, same package `v3-to-v4.diff`,
  SHA256 `93311fde0296661f2fca6cd43621edfe85a2e33b7beef15b1591fe6d0f0f2fbe`.
- Repository USB audit at the dependency-only review,
  `scripts/hp1020_entry_usb_audit.py`,
  SHA256 `a1544c2e1b155dcb70b1b12b1d0be99f1558799a2e56b697a4477c9a7e259f22`.

The existing static scope limitations and pending linked stack/callback proof
remain unchanged. This addendum does not claim audit or execution success.
