# Frozen API cross-check — no execution

2026-10-03. The independently drafted `PLAN.md` remains unchanged at SHA256
`50e727ff27f30ccc33f4b970cd5aa20c75109fc6149bf287e3f8626b81bb7244`.
After that plan was frozen, the author supplied the completed integration
fragment `raw_input_gate.py.txt`, SHA256
`f4c26e646d81534e07f9664b337f392df2d3fde397fc0afa34b2a9b6fb181765`.
An exact copy accompanies this note. Its package manifest is
`8e819d7c8f5019dbbbdc24d826651e4d4b6f5680f5d7d3dcdd8b8bea6bc078ad`.

A bounded static read confirms the six planned controls have distinct public
or existing admission paths:

- Controls1/2 enter `read_relocatable` then
  `check_raw_input_sections(<actual C unit>, sections)`. The helper requires
  `.text.*` type1/flags6 and explicitly rejects an unclassified empty or
  nonallocated row. Unknown input cannot be ignored just because it is unused.
- Control3 enters the retained complete `check_input_objects` path, after
  family admission. The helper's custom `.runtime_memory` shape is file-backed
  PROGBITS/type1, flags3, alignment16, making the one-byte hidden-initializer
  mutation coherent. Its rejection remains the older mutable-object obligation.
- Control4 enters `read_relocatable` directly. A target0 RELA is rejected there;
  the new helper also requires a nonzero target and exact target/name agreement.
- Control5 enters `read_relocatable` then
  `check_raw_input_sections('libgcc/_udivsi3.o', sections)` (or the other
  selected member). The complete `check_selected_libgcc` also calls the family
  helper before its extracted-member equality check. The future driver must
  account for shared section-name string suffixes so its mutation cannot
  accidentally substitute a relocation-name mismatch for the intended unknown
  family rejection. Keep the exact changed-name/header preconditions visible.
- Control6 enters `check_selected_libgcc(directory, map_path)` with the copied
  four-file set plus one actual third member. The first exact-file-set check
  rejects it; do not invoke the unrelated member hash check and claim closure
  coverage. An archive's ordinary unselected members remain legitimate.

No change to the frozen control plan or semantic gate follows from this review.
The full audit helper, control driver and candidate remain unexecuted here.
Only the helper's public admission fragment was read; new runtime/provider C
and candidate result captures were not inspected. Root owns all future calls.
