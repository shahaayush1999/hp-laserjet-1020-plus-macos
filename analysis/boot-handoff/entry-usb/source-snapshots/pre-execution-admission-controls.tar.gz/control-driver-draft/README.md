# Copied-input controls — frozen unexecuted draft

2026-10-03, independently authored by `/root/usb_reference_contract` from the
previously frozen PLAN/API addendum. No import, syntax parse, build, target
execution or test has been performed by the author. Root owns the first run.

Future invocation: `python3 copied-input-controls.py <accepted-audit-only-capture>`.
Optional `--output` must name a new private `/tmp` directory. The accepted input
must say audit-only-pass, zero candidate execution and no cases. The captured
audit source is independently pinned to `a1544c2e...`, its neutral helper to
`2f990f9f...`; exact copies are under inputs. Only the four named static admission
APIs are invoked, with a passing unchanged baseline before each mutation. A
process/network audit hook blocks external tool or device operations.

There are six structural negatives plus separate5b selected-member byte-seal
assertion. Unknown exception types, wrong rejection reasons, failed baselines,
unexpected acceptance and changed original inputs fail the run. Before/after
raw files, hashes, mutation metadata, exact source/linked evidence, baseline
returns and rejection messages are preserved; no accepted capture is edited.

Control5 has an explicit root-approved pre-execution amendment. The preserved
19-section inventory proves neither selected member has optional .literal or
.text.*; renaming mandatory .text would only test base closure. Instead append
one valid unknown AX/alignment4 PROGBITS section with four copied original text
bytes, preserving every original name/row and payload. It therefore tests the
intended unknown-family obligation. Original PLAN.md stays unchanged. Control5b
separately changes one actual .text payload byte and requires archive/member
identity rejection; neither case executes those bytes.

The runner reads only accepted static ELF/object/library/audit/source evidence,
not new runtime/provider C or CPU/RAM result cases. It has no firmware lifecycle
or hardware success claim. Any first-run correction must preserve this draft
and all stopped output separately.
