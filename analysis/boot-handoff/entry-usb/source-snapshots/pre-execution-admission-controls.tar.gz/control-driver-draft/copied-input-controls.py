#!/usr/bin/env python3
"""Six copied ET_REL negatives plus a separate selected-member byte-seal check.

This driver invokes only captured, pinned host-side admission functions. It
never calls audit_target, a compiler, a linker, an emulator or target code.
The draft is unexecuted. Root owns the first execution and preserves its result.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import struct
import sys
import tempfile
import traceback


AUDIT_SHA = 'a1544c2e1b155dcb70b1b12b1d0be99f1558799a2e56b697a4477c9a7e259f22'
NEUTRAL_SHA = '2f990f9f57731c49d8931138d32ce100fecd1d2fed722354f6c01117e52042eb'
ARCHIVE_SHA = 'e57e97f0f5679a83f5a394d94fe024973f05d32be292293b247e647e567c4e32'
ARCHIVE_BYTES = 878846
MEMBERS = {
    '_udivsi3.o': (2612, '6e2ed6774b25c833f8071872d6f7b699838e22f625bdb215cd21eea34a96814a'),
    '_umodsi3.o': (2368, 'f7cb9b22bf91ae5b5f40f06a9c2ad1d4e16ea5a7e7be8631e7f2595d89c3e5ee'),
}
UNITS = {
    'hp1020_usb_runtime', 'hp1020_usb_runtime_ram', 'hp1020_usb_runtime_layout',
    'hp1020_udc_publish', 'hp1020_udc_program', 'hp1020_udc_ep0', 'hp1020_udc_out',
    'hp1020_udc_setup', 'hp1020_tusb_adapter', 'hp1020_usb_printer',
    'hp1020_usb_receive', 'hp1020_usb_document', 'hp1020_image', 'hp1020_image_page',
    'hp1020_image_stream', 'hp1020_image_ring', 'hp1020_image_output',
    'hp1020_semantic', 'hp1020_page_plan', 'target-memory', 'memory',
    'jbig85', 'jbig_ar', 'tusb', 'usbd', 'tusb_fifo',
}
OBJECTS = {name + '.o' for name in UNITS | {'startup'}}
MAX_FILE = 16 * 1024 * 1024


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(root, relative):
    need(isinstance(relative, str) and relative and not Path(relative).is_absolute(),
         'relative evidence path required')
    path = root / relative
    need(path.resolve().is_relative_to(root.resolve()) and not path.is_symlink() and
         path.is_file() and path.stat().st_size <= MAX_FILE,
         'bounded ordinary evidence file required: ' + relative)
    return path.read_bytes()


def write(root, relative, data):
    path = root / relative
    need(path.resolve().is_relative_to(root.resolve()), 'output path escapes new directory')
    path.parent.mkdir(parents=True, exist_ok=True)
    need(not path.exists(), 'refuse to overwrite preserved output: ' + str(path))
    path.write_bytes(data)


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def tree(root):
    result = {}
    for path in sorted(root.rglob('*')):
        if path.is_file():
            relative = str(path.relative_to(root))
            data = read(root, relative)
            result[relative] = dict(bytes=len(data), sha256=sha(data))
    return result


def etrel(data):
    """Independent bounded header/string reader used only to construct mutations."""
    need(len(data) >= 52 and data[:7] == b'\x7fELF\x01\x02\x01', 'mutation input ELF32BE')
    header = struct.unpack_from('>HHIIIIIHHHHHH', data, 16)
    typ, machine, version, entry, phoff, shoff, flags, ehsize, phsize, phnum, shsize, count, strings = header
    need((typ, machine, version, entry, phoff, phnum, ehsize, shsize) == (1, 94, 1, 0, 0, 0, 52, 40),
         'mutation input must be actual Xtensa relocatable')
    need(phsize in (0, 32) and flags & ~0x300 == 0 and 0 < count < 4095 and
         strings < count and shoff >= 52 and shoff + count * 40 <= len(data),
         'mutation input section-table envelope')
    rows = [struct.unpack_from('>10I', data, shoff + i * 40) for i in range(count)]
    need(rows[0] == (0,) * 10, 'mutation input null header')
    ns = rows[strings]
    need(ns[1] == 3 and ns[4] + ns[5] <= len(data), 'mutation name table bounds')
    names = data[ns[4]:ns[4] + ns[5]]
    sections = []
    for index, row in enumerate(rows):
        need(row[0] < len(names), 'mutation section-name offset')
        end = names.find(b'\0', row[0])
        need(end >= row[0], 'mutation terminated section name')
        name = names[row[0]:end].decode('ascii')
        need(row[3] == 0 and (row[1] == 8 or row[4] + row[5] <= len(data)),
             'mutation section address/file bounds')
        sections.append(dict(index=index, name=name, row=row, header_offset=shoff + index * 40))
    need(len({s['name'] for s in sections}) == len(sections), 'mutation original names unique')
    return dict(header=header, shoff=shoff, shstr=strings, rows=rows, names=names, sections=sections)


def section(data, name):
    parsed = etrel(data)
    rows = [s for s in parsed['sections'] if s['name'] == name]
    need(len(rows) == 1, 'one actual input section required: ' + name)
    return parsed, rows[0]


def change_header(data, name, column, value):
    parsed, selected = section(data, name)
    before = selected['row'][column]
    need(before != value, 'header mutation must change its field')
    result = bytearray(data)
    offset = selected['header_offset'] + column * 4
    struct.pack_into('>I', result, offset, value)
    changed = bytes(result)
    new = etrel(changed)
    expected = [list(row) for row in parsed['rows']]
    expected[selected['index']][column] = value
    need(new['rows'] == [tuple(row) for row in expected] and
         data[:offset] == changed[:offset] and data[offset + 4:] == changed[offset + 4:],
         'exactly the intended raw header field changed')
    return changed, dict(section=name, section_index=selected['index'],
                        byte_offset=offset, header_column=column, before=before, after=value)


def append_section(data, name, flags, alignment, payload):
    parsed = etrel(data)
    need(name not in {s['name'] for s in parsed['sections']} and name.startswith('.hp1020_'),
         'new independent unknown section name')
    need(flags in (0, 6) and alignment in (1, 4) and len(payload) in (0, 4),
         'bounded unknown-section mutation profile')
    result = bytearray(data)
    result.extend(bytes((-len(result)) % alignment))
    payload_offset = len(result)
    result.extend(payload)
    names_offset = len(result)
    names = parsed['names'] + name.encode('ascii') + b'\0'
    result.extend(names)
    result.extend(bytes((-len(result)) % 4))
    table_offset = len(result)
    rows = [list(row) for row in parsed['rows']]
    rows[parsed['shstr']][4:6] = [names_offset, len(names)]
    rows.append([len(parsed['names']), 1, flags, 0, payload_offset, len(payload), 0, 0, alignment, 0])
    result.extend(b''.join(struct.pack('>10I', *row) for row in rows))
    struct.pack_into('>I', result, 32, table_offset)
    struct.pack_into('>H', result, 48, len(rows))
    changed = bytes(result)
    new = etrel(changed)
    expected_prefix = bytearray(data)
    struct.pack_into('>I', expected_prefix, 32, table_offset)
    struct.pack_into('>H', expected_prefix, 48, len(rows))
    need(changed[:len(data)] == expected_prefix and new['rows'] == [tuple(row) for row in rows],
         'append preserves all original bytes except table location/count')
    need([s['name'] for s in new['sections'][:-1]] == [s['name'] for s in parsed['sections']] and
         changed[payload_offset:payload_offset + len(payload)] == payload,
         'append preserves existing names/sections and exact new payload')
    for index, old in enumerate(parsed['rows']):
        if index != parsed['shstr']:
            need(new['rows'][index] == old, 'append altered an unrelated original row')
    return changed, dict(section=name, flags=flags, alignment=alignment,
                        payload_offset=payload_offset, payload_hex=payload.hex(),
                        old_sections=len(parsed['rows']), new_sections=len(rows),
                        old_bytes=len(data), new_bytes=len(changed),
                        old_shstr_sha256=sha(parsed['names']))


def change_payload(data, name, relative, value):
    parsed, selected = section(data, name)
    row = selected['row']
    need(row[1] == 1 and 0 <= relative < row[5] and 0 <= value <= 255,
         'one file-backed payload byte required')
    offset = row[4] + relative
    need(offset >= 52 and data[offset] != value and
         not parsed['shoff'] <= offset < parsed['shoff'] + 40 * len(parsed['rows']),
         'payload change cannot touch header/section-table metadata')
    changed = data[:offset] + bytes([value]) + data[offset + 1:]
    need(etrel(changed)['rows'] == parsed['rows'] and
         sum(a != b for a, b in zip(data, changed)) == 1,
         'exact one payload byte, no section metadata mutation')
    return changed, dict(section=name, section_index=selected['index'],
                        byte_offset=offset, payload_offset=relative,
                        before=data[offset], after=value)


def ar_members(data):
    """Extract private byte strings, never archive paths or external commands."""
    need(len(data) == ARCHIVE_BYTES and sha(data) == ARCHIVE_SHA and data[:8] == b'!<arch>\n',
         'unchanged independently pinned GNU compiler archive')
    pos = 8
    names = None
    members = {}
    count = 0
    while pos < len(data):
        count += 1
        need(count <= 4096 and pos + 60 <= len(data), 'bounded ar table')
        header = data[pos:pos + 60]
        need(header[58:] == b'`\n' and re.fullmatch(rb'[0-9]+', header[48:58].strip()),
             'ordinary decimal ar header')
        size = int(header[48:58].strip())
        start, end = pos + 60, pos + 60 + size
        need(end <= len(data), 'ar member inside original archive')
        body, name = data[start:end], header[:16].rstrip(b' ')
        if name == b'//':
            need(names is None, 'one ar name table')
            names = body
        elif name not in (b'/', b'/SYM64/'):
            if name.startswith(b'/'):
                need(names is not None and re.fullmatch(rb'/[0-9]+', name), 'GNU ar long-name reference')
                at = int(name[1:])
                need(at < len(names) and (at == 0 or names[at - 1] == 10), 'ar name boundary')
                finish = names.find(b'/\n', at)
                need(finish >= at, 'ar long-name termination')
                name = names[at:finish]
            else:
                need(name.endswith(b'/'), 'GNU ar short-name format')
                name = name[:-1]
            decoded = name.decode('ascii')
            need(decoded not in members and decoded not in ('', '.', '..') and
                 '/' not in decoded and '\\' not in decoded, 'unique safe member basename')
            members[decoded] = body
        pos = end
        if size & 1:
            need(data[pos:pos + 1] == b'\n', 'ar padding')
            pos += 1
    need(pos == len(data), 'complete archive envelope')
    return members


def forbid_process_or_network(event, arguments):
    if event in ('subprocess.Popen', 'os.system', 'os.exec', 'os.spawn', 'os.posix_spawn') or event.startswith('socket.'):
        raise RuntimeError('copied-input controls forbid process/network action: ' + event)


def load_snapshot(root, name, expected):
    relative = 'source/scripts/' + name + '.py'
    data = read(root, relative)
    need(sha(data) == expected, 'reviewed captured source pin: ' + relative)
    need(name not in sys.modules, 'refuse an existing module instead of sealed snapshot: ' + name)
    spec = importlib.util.spec_from_file_location(name, root / relative)
    need(spec is not None and spec.loader is not None, 'captured module loader')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def family_api(audit, unit, file):
    def invoke(directory):
        sections, records, relocations = audit.read_relocatable(read(directory, file))
        return audit.check_raw_input_sections(unit, sections)
    return invoke


class Controls:
    def __init__(self, output, report):
        self.output, self.report = output, report

    def run(self, label, role, files, api_name, api, mutate, expected_reason):
        directory = self.output / 'controls' / label
        before, after = directory / 'before', directory / 'after'
        before.mkdir(parents=True)
        after.mkdir()
        for name, data in files.items():
            write(before, name, data)
            write(after, name, data)
        result = dict(label=label, role=role, status='fail', api=api_name,
                      expected_rejection=expected_reason,
                      before=tree(before), baseline='not-run')
        self.report['controls'].append(result)
        try:
            baseline = api(before)
            save(directory / 'baseline-result.json', baseline)
            need(tree(before) == result['before'], 'baseline API changed copied inputs')
            result['baseline'] = 'pass'
            result['baseline_result_sha256'] = sha((directory / 'baseline-result.json').read_bytes())
            result['mutation'] = mutate(after)
            result['after'] = tree(after)
            need(result['after'] != result['before'], 'negative input must actually differ')
            try:
                api(after)
            except ValueError as error:
                result['observed_exception'] = dict(type=type(error).__name__, message=str(error))
                detail = error.args[0] if error.args else None
                need(isinstance(detail, tuple) and len(detail) >= 2 and
                     detail[0] == 'entry ELF audit' and detail[1] == expected_reason,
                     'rejection did not reach the intended admission obligation')
            else:
                raise RuntimeError('mutated copied input was unexpectedly accepted')
            need(tree(after) == result['after'], 'rejecting API changed copied inputs')
            need(tree(before) == result['before'], 'negative API altered baseline copy')
            result['status'] = 'pass'
            result['target_instructions'] = 0
        except BaseException as error:
            result['error'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
            raise
        finally:
            for label, path in (('before', before), ('after', after)):
                try:
                    result['preserved_' + label] = tree(path)
                except Exception as error:
                    result['status'] = 'fail'
                    result['preservation_error_' + label] = str(error)
            save(directory / 'control.json', result)
            save(self.output / 'result.json', self.report)


def replace_file(directory, name, change):
    before = read(directory, name)
    after, note = change(before)
    need(before != after, 'mutation must alter exact original bytes')
    (directory / name).write_bytes(after)
    return dict(file=name, before_sha256=sha(before), after_sha256=sha(after), **note)


def collect_capture(capture, output):
    report = json.loads(read(capture, 'validation.json'))
    need(report.get('status') == 'audit-only-pass' and report.get('candidate_execution') is False and
         report.get('cases') == [] and not any(k in report for k in ('error', 'source_seal_error')),
         'require an accepted audit-only capture with zero candidate cases')
    source = json.loads(read(capture, 'source-sha256.json'))
    linked = json.loads(read(capture, 'linked-audit.json'))
    need(source == report['source_sha256'] and linked == report['linked_audit'],
         'accepted linked/source report binding')
    need(source['scripts/hp1020_entry_usb_audit.py'] == linked['audit_source_sha256'] == AUDIT_SHA and
         source['scripts/hp1020_entry_audit.py'] == NEUTRAL_SHA,
         'accepted source snapshot agrees with separately reviewed audit pins')
    target = report['target_sha256']
    need({n for n in target if n.endswith('.o')} == OBJECTS | {'libgcc/' + n for n in MEMBERS},
         'accepted exact ordinary/selected input-object closure')
    keep = ['validation.json', 'source-sha256.json', 'linked-audit.json', 'tool-closure.json',
            'source/scripts/hp1020_entry_usb_audit.py', 'source/scripts/hp1020_entry_audit.py',
            'target/entry-usb.elf', 'target/entry-usb.map']
    keep += ['target/' + n for n in sorted(OBJECTS)]
    keep += ['target/libgcc/' + n for n in ('libgcc.a', 'manifest.json', *MEMBERS)]
    preserved = {}
    for relative in keep:
        data = read(capture, relative)
        if relative.startswith('target/'):
            need(sha(data) == target[relative[7:]], 'accepted target input seal: ' + relative)
        if relative.startswith('source/'):
            need(sha(data) == source[relative[7:]], 'accepted source input seal: ' + relative)
        preserved[relative] = dict(bytes=len(data), sha256=sha(data))
        write(output / 'baseline', relative, data)
    need(preserved['target/entry-usb.elf']['sha256'] == linked['target_sha256'],
         'linked audit refers to the preserved actual ELF')
    save(output / 'baseline-inputs.json', preserved)
    return report, linked, preserved


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('capture', type=Path, help='complete accepted audit-only capture')
    parser.add_argument('--output', type=Path, help='new directory beneath /tmp (must not exist)')
    args = parser.parse_args()
    capture = args.capture.resolve()
    if args.output is None:
        output = Path(tempfile.mkdtemp(prefix='hp1020-entry-usb-input-controls-', dir='/tmp')).resolve()
    else:
        output = args.output.resolve()
        need(output.is_relative_to(Path('/tmp').resolve()) and not output.exists(),
             'output must be a new private /tmp directory')
        output.mkdir(parents=True)
    need(not output.is_relative_to(capture) and not capture.is_relative_to(output),
         'original evidence and new control output must be disjoint')
    result = dict(schema='hp1020-entry-usb-copied-input-controls-v1', status='fail',
                  capture=str(capture), output=str(output),
                  driver_sha256=sha(Path(__file__).read_bytes()),
                  audit_source_sha256=AUDIT_SHA, neutral_source_sha256=NEUTRAL_SHA,
                  planned_mutations=6, separate_provenance_assertions=1,
                  candidate_execution=False, controls=[])
    protected = {}
    try:
        accepted, linked, protected = collect_capture(capture, output)
        result['input_sha256'] = protected
        baseline = output / 'baseline'
        sys.dont_write_bytecode = True
        sys.addaudithook(forbid_process_or_network)
        load_snapshot(baseline, 'hp1020_entry_audit', NEUTRAL_SHA)
        audit = load_snapshot(baseline, 'hp1020_entry_usb_audit', AUDIT_SHA)
        need(audit.C_UNITS == UNITS, 'reviewed ordinary unit set unchanged')
        objects = linked['public_layout']['objects']
        mutable = {row['name']: row for row in linked['mutable_objects']}
        need(len(objects) == 16 and len(mutable) == len(linked['mutable_objects']) == 29,
             'actual linked public/mutable object closure')
        ordinary = {name: read(baseline, 'target/' + name) for name in sorted(OBJECTS)}
        library = {'libgcc/' + name: read(baseline, 'target/libgcc/' + name)
                   for name in ('libgcc.a', 'manifest.json', *MEMBERS)}
        library['entry-usb.map'] = read(baseline, 'target/entry-usb.map')
        controls = Controls(output, result)

        #1: choose an actual discarded routine, rather than guess its index.
        linked_names = {row['name'] for row in linked['function_symbols']}
        candidates = []
        for filename, data in ordinary.items():
            parsed = etrel(data)
            for selected in parsed['sections']:
                row, name = selected['row'], selected['name']
                if name.startswith('.text.') and row[1] == 1 and row[2] == 6 and row[5] > 0:
                    functions = [r for r in linked['object_inputs']['function_symbols']
                                 if r['file'] == filename and r['section'] == selected['index']]
                    if functions and all(r['name'] not in linked_names for r in functions):
                        priority = 0 if name == '.text.hp1020_udc_ep0_cancelled' else 1
                        candidates.append((priority, filename, name, [r['name'] for r in functions]))
        need(candidates, 'control1 requires actual discarded function bytes')
        _, filename, name, discarded = sorted(candidates)[0]
        controls.run('01-discarded-text-flags', 'planned-mutation', {filename: ordinary[filename]},
                     'read_relocatable + check_raw_input_sections',
                     family_api(audit, Path(filename).stem, filename),
                     lambda d: dict(replace_file(d, filename, lambda b: change_header(b, name, 2, 2)),
                                    discarded_function_names=discarded),
                     'raw input section type/flags/shape')

        #2: a well-formed empty/nonalloc section must still be classified.
        filename = 'hp1020_udc_ep0.o'
        controls.run('02-empty-unknown-section', 'planned-mutation', {filename: ordinary[filename]},
                     'read_relocatable + check_raw_input_sections',
                     family_api(audit, 'hp1020_udc_ep0', filename),
                     lambda d: replace_file(d, filename, lambda b: append_section(
                         b, '.hp1020_unadmitted', 0, 1, b'')),
                     'unknown raw input section family')

        #3: keep the separate existing NOLOAD initializer obligation observable.
        def noload(directory):
            filename = 'hp1020_usb_runtime_ram.o'
            data = read(directory, filename)
            _, selected = section(data, '.runtime_memory')
            row = selected['row']
            need((row[1], row[2], row[5], row[8]) == (1, 3, 114704, 16) and
                 data[row[4]:row[4] + row[5]] == bytes(row[5]), 'original custom allocation is file-backed zero')
            return replace_file(directory, filename, lambda b: change_payload(b, '.runtime_memory', row[5] // 2, 1))
        controls.run('03-hidden-noload-initializer', 'planned-mutation', ordinary,
                     'check_input_objects', lambda d: audit.check_input_objects(d, objects, mutable),
                     noload, 'NOLOAD would discard initializer/relocation')

        #4: malformed target is the original parser's rejection, not family coverage.
        filename = 'hp1020_udc_ep0.o'
        rows = [s for s in etrel(ordinary[filename])['sections']
                if s['row'][1] == 4 and s['row'][5] > 0 and s['row'][7] > 0]
        need(rows, 'control4 requires an existing nonempty RELA')
        relocation = sorted(rows, key=lambda s: s['index'])[0]['name']
        controls.run('04-invalid-rela-target', 'planned-mutation', {filename: ordinary[filename]},
                     'read_relocatable', lambda d: audit.read_relocatable(read(d, filename)),
                     lambda d: replace_file(d, filename, lambda b: change_header(b, relocation, 7, 0)),
                     'input relocation shape')

        #5: approved pre-execution amendment; preserve mandatory .text and all names.
        filename = '_udivsi3.o'
        original = library['libgcc/' + filename]
        _, text = section(original, '.text')
        need(text['row'][1:3] == (1, 6) and text['row'][5] >= 4,
             'selected library has original executable bytes for copied payload')
        payload = original[text['row'][4]:text['row'][4] + 4]
        controls.run('05-library-unknown-allocated-section', 'planned-mutation', {filename: original},
                     'read_relocatable + check_raw_input_sections',
                     family_api(audit, 'libgcc/' + filename, filename),
                     lambda d: replace_file(d, filename, lambda b: append_section(
                         b, '.hp1020_library_unadmitted', 6, 4, payload)),
                     'unknown raw input section family')

        #5b is a provenance assertion, distinct from the six structural mutations.
        def member_byte(directory):
            relative = 'libgcc/_udivsi3.o'
            data = read(directory, relative)
            _, selected = section(data, '.text')
            offset = selected['row'][4] + selected['row'][5] // 2
            return replace_file(directory, relative, lambda b: change_payload(
                b, '.text', selected['row'][5] // 2, data[offset] ^ 1))
        selected_api = lambda d: audit.check_selected_libgcc(d / 'libgcc', d / 'entry-usb.map')
        controls.run('05b-library-member-byte-seal', 'separate-provenance-assertion', library,
                     'check_selected_libgcc', selected_api, member_byte,
                     'captured selected libgcc member bytes')

        #6: copy an exact third member; report the changed set honestly.
        archive_members = ar_members(library['libgcc/libgcc.a'])
        extra_names = [n for n in sorted(archive_members) if n.endswith('.o') and n not in MEMBERS and
                       archive_members[n][:7] == b'\x7fELF\x01\x02\x01']
        need(extra_names, 'control6 requires a real third target ELF member')
        extra = '_divsi3.o' if '_divsi3.o' in extra_names else extra_names[0]
        etrel(archive_members[extra])
        def add_member(directory):
            data = archive_members[extra]
            write(directory, 'libgcc/' + extra, data)
            manifest_path = directory / 'libgcc/manifest.json'
            manifest = json.loads(manifest_path.read_bytes())
            manifest['members'][extra] = dict(file=extra, bytes=len(data), sha256=sha(data))
            save(manifest_path, manifest)
            return dict(added_member=extra, bytes=len(data), sha256=sha(data),
                        archive_sha256=ARCHIVE_SHA, unchanged_original_members=sorted(MEMBERS),
                        manifest_describes_all_three_copied_members=True)
        controls.run('06-extra-selected-member', 'planned-mutation', library,
                     'check_selected_libgcc', selected_api, add_member,
                     'exact captured libgcc file closure')

        need(len(result['controls']) == 7 and all(c['status'] == 'pass' for c in result['controls']) and
             sum(c['role'] == 'planned-mutation' for c in result['controls']) == 6,
             'all six planned mutations and separate provenance assertion required')
        result['status'] = 'pass'
    except BaseException as error:
        result['error'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
    finally:
        changed = []
        for name, seal in protected.items():
            try:
                need(sha(read(capture, name)) == seal['sha256'], 'original input changed')
            except Exception as error:
                changed.append(dict(file=name, error=str(error)))
        result['original_inputs_unchanged'] = (not changed) if protected else None
        if changed:
            result['status'] = 'fail'
            result['original_input_changes'] = changed
        save(output / 'result.json', result)
    print(json.dumps(dict(status=result['status'], output=str(output),
                          completed=sum(c['status'] == 'pass' for c in result['controls'])), sort_keys=True))
    return 0 if result['status'] == 'pass' else 1


if __name__ == '__main__':
    raise SystemExit(main())
