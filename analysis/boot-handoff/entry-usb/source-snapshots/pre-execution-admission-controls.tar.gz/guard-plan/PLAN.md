# Focused EntryUSBMachine guard plan

2026-10-03. **Unexecuted static plan.** No machine was instantiated, no parser or
candidate module was imported, and no target/build/validator was run. Root owns
all later probes, after the continuous positive cases and in a separate capture.
These controls are isolated policy checks, never new firmware lifecycles.

## What is new and what is inherited

The unchanged base `Machine` still owns instruction decoding, full backing-span
and alignment checks, actual CALL0/CALLX0 effects, and byte execution checks.
The unchanged `EntryMachine` supplies physical-window normalization, special-op
restriction, trace lifetime and success-evidence closure. Its old30 controls
remain evidence for those exact mechanics; do not blindly rerun that whole
matrix or substitute old addresses/ELF pins.

`EntryUSBMachine` adds the actual four zero spans, distinct initialized writable
data, the new owned stack, actual function-entry admission for calls,20 observed
entries, and the six-stage order
`after-normalization → pre-c → pre-close → pre-final-service → pre-finish → park`.
An ordinary publisher-service entry before close is allowed and is not the
final-service checkpoint. After first close, the next such entry is mandatory
before finish. These changed boundaries are the useful new controls.

Use the *accepted new* audited Program and independently saved initial images.
Seal target, audit, source, Program instructions/permissions/function starts and
all original region bytes. The plan does not choose addresses from the old ELF.
Obtain the four actual used spans, initialized-data used span, function symbols,
excluded trap PCs and original instruction bytes from that frozen linked audit;
cross-check its fixed objects against the unchanged public contract before use.

The stack is `[0x10014020,0x10016020)`, not the previous entry stack. In particular,
`0x10012000` is now valid generic BSS and is **not** a forbidden-memory control.
The base interpreter's synthetic stack at `0x21000000` must remain absent.
Both facts should be stated explicitly in the report.

## Supplied isolated contexts and evidence

Fresh machine per probe; context seeding is an explicit test fixture, not a
claim that startup, initialization or a USB/document prefix executed.

- **N:** initial phase, no stores admitted, C not started.
- **Z:** normalized CPU and owned SP, `seen=['after-normalization']`, only the
  four audited zero spans writable; no stack access or initialized-data write.
- **C:** first C call already admitted in the supplied context; normalized CPU,
  owned aligned SP, first two checkpoints seen; the four zero spans, owned stack
  and actual initialized-data span are writable.
- **After-close:** C plus `close_entries=1`, `finish_entries=0`, first three
  checkpoints seen. This does not fabricate a completed transfer or USB owner.
- **After-final-service:** C plus close1/finish0 and first four checkpoints seen.

Do not edit the Program, its decoded instructions, function-start set, read/write
permissions or source bytes to cause a rejection. A private detached machine may
receive explicit register/phase/call contexts, but never use `put()` or `run(args)`
as a disguised runtime intervention. No provider, TinyUSB, document or DMA state
is invented for these policy-only checks. Real lifecycle state remains the
independent positive capture's responsibility.

Save before/after **all** RAM images and modeled state: logical/physical ARs,
window shadow/pending window, specials/SAR/PC, dispatch/visited/opcode state,
phase permissions, zero/data/stack spans, seen checkpoints, call ledger/stack,
special writes, entry-event ledger, close/finish counters, park state, SP minima,
access counters/widths/digests, step digest and external observer invocations.
Close trace files and compare complete decompressed access and step bytes to
literal expected records. Forbid unexpected observations even when the final
exception text is correct. Preserve exact exception text and rejection timing.
The detached observer records events only; do not apply a positive runtime-state
oracle to these explicitly seeded, unexecuted phase contexts.

The essential smaller matrix is below. Read/write pairs may be grouped in the
report, but each attempted operation should start from a fresh detached context
unless the plan explicitly calls for a valid read followed by a refused store.

## A. Changed RAM permissions

| Probe | Supplied context and operation | Independent expected result |
|---|---|---|
| `data-before-c` | Z: read one actual initialized `.data` byte, then attempt to write a different byte value at the same address. | Read equals the saved linked-file byte and adds one read trace only. Write fails `forbidden phase store`; no write or other effect. |
| `data-in-c` | C: write/read one byte in actual `.data`, using old byte XOR0xff. | Exactly that byte changes, one full source-value write trace and one read trace; no event/call/step. This deliberately differs from old immutable-data policy. |
| `four-zero-spans` | Z: separate one-word store/read at the last complete word of each of the four actual zero spans. | All four are permitted, including witness; exactly four selected words in independent copies change. No capacity-gap byte changes. This tests real used ends rather than buffer cap constants. |
| `early-witness-store` | N: attempt a word store to the new witness start. | Forbidden phase store before every RAM/register/access/step effect. |
| `actual-used-end` | C: one-byte read and store at each actual generic-BSS used end and witness used end. | Each rejects before effect although backing initial RAM includes the byte. Do not substitute the larger caps. |
| `data-full-width-edge` | C: use an aligned word beginning at the last aligned address below actual data end, where only1..3 bytes remain; attempt read and store. | Complete-span rejection before alignment/data access, with no partial byte effect. The current approved private data objects occupy29 bytes, so the last byte itself remains valid for a one-byte control. |
| `separate-sentinel` | C: read the first sentinel byte0x31; then attempt a store there. | Read succeeds; store rejects. Writable `.data` does not imply permission for the nearby file-backed256-byte sentinel. |
| `omitted-gap` | C: one-byte read/store at0x10016620 (the explicit pre-island gap). | Both reject despite main-envelope backing. This exercises the new gap layout, not a synthetic unmapped-address failure. |
| `new-stack-phase` | Z: read a word at0x1001601c; C: separate word store/read at that same last owned stack word. | Z read fails the explicit pre-C stack check before logging. C operations succeed and update minimum_stack_access to that actual address, without touching the upper guard. |
| `no-inherited-stack` | C: one-byte read/store at0x21000000. | Both reject via actual read/phase ranges; no extra backing segment or hidden synthetic stack is present. |

The `actual-used-end` controls are distinct from an optional generic named-guard
smoke probe. Do not expand every fixed guard/read/write/width into a Cartesian
matrix. Whole immutable/gap bytes are already compared in every positive raw
snapshot; the above targeted probes establish that the permission mechanisms
reject the newly meaningful boundaries.

## B. Actual private callback entries and new call policy

Select one **unchanged original CALLX0** instruction from the new audit's dynamic
sites, and preserve its raw bytes/register operand. Use a supplied C context,
aligned new-stack SP and `run` budget exactly one instruction. Do not patch a
direct CALL0 operand or instruction dictionary to make the target vary.

1. `callback-entry`: target the actual retained function start of one real RAM
   provider callback, e.g. `dcd_edpt_xfer`, independently identified in the linked
   symbols and callback proof. The call is accepted, produces its original return
   PC and one call-ledger row, but the callee executes **zero** instructions before
   the one-step budget stop. This is an admission positive, not a DCD lifecycle.
2. `callback-interior`: target a different **admitted instruction boundary** inside
   that same function which is absent from `entry_function_starts`. Expect
   `call target outside audited original function entries`. This is specifically
   the new check: a mere valid annotated PC used to be enough in the old model.
3. `callback-old-stack-top`: use the valid callback target with SP0x10014000,
   which is aligned but below the new owned stack. Expect
   `call SP outside owned aligned stack`. The old stack top is not valid here.
   One separate misaligned-SP value (new top minus4) may be retained as an
   inherited predicate smoke check; the old full three-value matrix is not needed.
4. `first-c-missing-zero-checkpoint`: execute the original fixed pre-C CALL0
   with normalized CPU/valid SP, but the supplied seen list lacks `pre-c`.
   Expect `first call follows complete BSS witness`; C must remain unstarted.
   This is checkpoint admission only; it does not prove actual zero bytes.

For CALL0/CALLX0 rejections, the base instruction has already written a0 and
dispatch bookkeeping, and `after_instruction` has appended the instruction's
step record. The machine PC is still the call PC because the hook raised before
`run` assigned its returned successor. **No callee fetch, call-ledger push or
C-start permission change occurs** for the listed rejected calls. Preserve that
exact prefix; do not assert total state equality or claim rejection before all
instruction effects. Set the supplied minimum_sp coherently to the supplied SP
so unrelated minimum bookkeeping does not obscure the intended boundary.

There is no per-callsite typed callback whitelist in this machine. Any admitted
function start can pass this call-target predicate; the real callback provenance,
arguments and allowed lifecycle come from the linked review and independent
continuous trace gate. Likewise JX tail branches do not push a new call ledger.
Do not label a different valid function entry as an expected CFI rejection.

## C. Close/service/finish order

Reuse the one original CALLX0 control site to enter actual observed function
starts without executing their bodies. Each one-step probe is a deliberately
supplied policy context, not a reachable production callback invocation.

| Probe | Context and original target | Required result |
|---|---|---|
| `early-service-is-ordinary` | C/close0, target actual publisher service. | Call/event recorded; no new checkpoint and no observer callback. One-step budget stop only. |
| `finish-before-close` | C/close0, target actual adapter finish. | `one actual finish entry after close`; retain finish counter1 and its event/call prefix. |
| `finish-before-final-service` | After-close, target actual adapter finish. | `checkpoint order changed`; final-service observation is not invented. Retain finish counter1 and event/call prefix; seen remains the first3. |
| `next-service-after-close` | After-close, target actual publisher service. | Exactly `pre-final-service` appended and one observer callback, with no finish entry; one-step budget stop only. |
| `repeat-close` | After-close, target actual close_input. | `one actual close entry before one finish`; counter reaches2 and event/call prefix remains, but no second checkpoint is accepted. |
| `repeat-final-service` | After-final-service, target actual publisher service. | `repeated checkpoint`; no second observer callback or seen entry. Ordinary event/call prefix remains recorded. |

All these original-call probes increment dispatch/step state and a0 first.
For accepted-call but rejected-entry/order cases, `calls`/`call_stack` have already
grown before the event/order guard. Entry-event append and close/finish count
increments also precede their particular checks. The diagnostic must preserve
these effects accurately rather than rollback or relabel them as pre-effect
rejections. No target API body runs, so no real owner, recovery promise, pixel or
document counter should change.

One useful final closure negative is `evidence()` with all six seen checkpoints
and two park iterations supplied but close_entries0 or finish_entries0. It must
reject `exactly one original close and finish entry` without effect. This tests
the USB-specific evidence predicate only; fixture-supplied completed state must
never be represented as an executed positive lifecycle.

## D. One newly relevant excluded-code check

At the exact excluded `__umodsi3` ILL address from the new linked helper proof,
attempt one-instruction execution with unchanged Program/image. Expect the
annotated-boundary failure before dispatch, any step trace or target instruction
effect because that trap is absent from `program.instructions`. The trap byte
sequence still exists in read-only loaded code; a one-byte data read is permitted.
This guards the newly linked second helper's separation of readable bytes from
admitted execution. Do not execute ILL or claim division-by-zero emulation.

The old unexpected-park, terminal-after-effect detector, physical-WB and special
normalization controls need no duplication for this minimal new matrix. Positive
USB captures still require the new actual park twice and all CPU/memory seals.

## Freeze and later execution conditions

Before implementing/running, root should freeze concrete selected instruction
PCs/bytes, private callback start/interior target and actual used ends from the
accepted new ELF. Do not infer them from this plan or earlier failed/audit-only
outputs. Fail the control's preconditions if an original site is absent; report
that precise scope rather than substituting modified instructions.

Keep each invalid copy isolated, source/Program/initial image seals unchanged,
and exact before/after state plus raw trace records. Reports should separate
direct memory refusals, permitted operations, one original instruction followed
by a policy/budget refusal, and evidence-only rejection. None establishes physical
CPU faults, USB, cache, DMA, printing or recovery after a power cycle.

Reviewed source identities (copies in `inputs/`):

- EntryUSBMachine: `377cdd771447a4d69040a5624ef1fafc7593fea50fc471ccd7f8a0ff1077466a`.
- Inherited EntryMachine: `46cc66fc2ac1c22201ef6a33ee13eba4a54087bb416ccc1b8726aae2d2c98b07`.
- Base Machine: `ed2924d8e46c0e553fe079a5ecdfff77dc40f1aa228588d9a86c39ce98769480`.
- USB audit at read time: `a1544c2e1b155dcb70b1b12b1d0be99f1558799a2e56b697a4477c9a7e259f22`.
- Public contract: `18864eee6bb95581e99429da8d2fac039e635ef365ce02f91a8d1d122c17a123`.
- Public header: `25f5e76cff3633d6e3ab85f4e9adfc2e94edcc02e2cfe0b7d7d2bafea2e82995`.
- Old guard source, consulted for effect-timing/capture only:
  `7fe9bea14b742f7a6027178acc1116e7f3663c5a253452e324b38bdbe7f5f776`.
