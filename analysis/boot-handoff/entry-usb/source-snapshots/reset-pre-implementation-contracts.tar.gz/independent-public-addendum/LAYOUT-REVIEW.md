# Manual target32 public-layout review

Static review,2026-10-03. New public declarations and old production headers were
read; no compiler, source import, parser or candidate execution was used.

Target ABI remains four-byte uint32/pointer, one-byte uint8/bool, and the admitted
aggregate alignment. A cookie is four uint32 plus endpoint plus three padding
bytes =20. The retained provider record adds pointer4, requested4 and four flag
bytes =32. Two records64 plus recovery8 gives72. Four scope/read words give88;
callback_depth/open/stall/steps give104; source offset/length give112; four flags
give116; callback_before64 gives180; image_cookie20 gives200; image_slot4 gives204;
new reset_cookie20 gives224. No new pointer/buffer owner is embedded in the copy.

Witness arithmetic is independent of compiler output:

-16 head bytes;240*24 trace bytes end5776;guard16 ends5792.
-65*36 ranges end8132;padding12 ends8144;guard16 ends8160.
-15*36 binds end8700;padding4 ends8704;guard16 ends8720.
-device144 ends8864;pixels64 ends8928;2*20 events end8968.
-6*36 checks end9184;reserved32 ends9216.

Device sublayout remains guard0@0/16, descriptor@16/16, guard1@32/16,
guard2@48/16, payload@64/64, guard3@128/16. For the relocated parent this puts
descriptor at witness8736 and payload8784; these are source-image bytes, not the
stationary production descriptor or receive slot. None may alias the production
allocations. Pixel/event/check capacities overlap neither each other nor guards.

All16 object sizes match the old manual table except provider204→224. For fields
1..101 only binds width changes504→540 and device/pixels/documents offsets shift
by36. Fields102..106 directly address the new cookie. Field107 points to the
second retained record's cancel byte32+29=61. Field108 uses OUT.cancel_requested59.
Field109 is the six checked-return rows8968/216.

For the332-byte adapter, owner0 starts20 and each owner is40 bytes. Owner2 starts
100: cookie20, buffer4, actual4, length2, state1, result1, cancel1, expected_cancel1,
core_was_busy1, packet_fault1, auto_status1, status_granted1, padding2. Thus existing
state130 and new cancel132/expected133 are distinct from component cancellation.
Adapter result enum words are at304/308 and byte flags begin312; deferred324.
The public new last_class_result308/4 and deferred324/1 therefore agree.

Printer starts with document pointer4, then config12 (pointer4, length2, three
one-byte fields and three alignment bytes), then reset ticket8. These reach
last_request_id24/current_request_id28/ep0_request_id32/last_recovery_id36/
reset_request_id40/requested_length44. Initialized46/exhausted47/action48/issued49/
reset_active50/parts51/ep0_live52 agree with the new historical-state fields.
Only actual ep0_live/response ownership may block release; last request/action
history must not be mistaken for a live packet.

The public constant table has five header words,48 object words and472 field
words, totaling525 words. Actual target32 sizes and offsetof/sizeof must later
match all manual rows; the table cannot certify itself or supply runtime addresses.
Symbols and no-overlap proofs come from the linked ELF and raw input admission.

The independent private-core proof is copied separately. Its source-derived
_usbd_dev68/endpoint offset52 and masks1/2/4 are not part of the public layout
table. New target getter bytes/literal and the actual private symbol must be
checked again before applying those offsets. The prior proof's old addresses
and prior healthy checkpoint identities are not reset-profile expectations.

The two new helpers and const reset16 are contract declarations only. Existing
entry/startup/linker budgets are unchanged; actual generic BSS, code, rodata,
initialized data and stack need new build admission. The review does not infer
that an extra20 provider bytes is the whole new BSS or code cost.
