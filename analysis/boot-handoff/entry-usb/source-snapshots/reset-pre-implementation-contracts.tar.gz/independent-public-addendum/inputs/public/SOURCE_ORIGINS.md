# Read-time source identities

All source bytes are copied without edits into `inputs/` and individually sealed
by this package's `DRAFT.sha256`. The repository root used for those reads is
`/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos`.

`inputs/baseline/` contains these existing files from
`open-firmware/entry-usb-test/`: `hp1020_usb_runtime_contract.h`, `CONTRACT.md`,
`layout-objects.tsv`, `layout-fields.tsv`, `expected-layout.json`,
`hp1020_usb_runtime.c`, `hp1020_usb_runtime_ram.c`,
`hp1020_usb_runtime_layout.c`. The C files are preserved inputs, **not** a new
reset implementation. The proposed copies exist only under `draft/`.

`inputs/production/` contains:

- `open-firmware/tinyusb-printer-adapter/hp1020_tusb_adapter.{h,c}`;
- `open-firmware/usb-printer-class/hp1020_usb_printer.{h,c}`;
- `open-firmware/udc-out/hp1020_udc_out.{h,c}` and `hp1020_udc_acquire.h`;
- `open-firmware/usb-receive-core/hp1020_usb_document.{h,c}` and
  `hp1020_usb_receive.{h,c}`.

`inputs/ordinary-cpu-oracle.py` is the unexecuted read-time copy of
`open-firmware/entry-ram-test/literal-oracle.py`; only ordinary CPU profile0 and
the two nonzero paint pairs are selected. It was not imported or evaluated.

`inputs/reset-plan.md` is the unchanged
`/tmp/hp1020-entry-usb-reset-plan-20261003/PLAN.md`, SHA256
`b810f5b58ca52ec96191a09d2ca017b49839348d0fb37f23af41ec1e0b0439ca`.

`inputs/independent-v1/` preserves three files from
`/tmp/hp1020-entry-usb-reset-independent-20261003/`: `ACCEPTANCE.md`,
`literals.py` and its original `DRAFT.sha256`. This is a **partial copy for
provenance**, not a claim that its separate larger manifest's entire closure is
included here. Its acceptance hash is
`7a6dbcafab15b0069e3723612dde0cae9e0a45cad6d5686e36ed35e766ce1253`;
literals hash is `d230a495ff51cf0edd4920e8b621000c43efcb2df0556c253d03ee1597c49ba8`.

Static reconciliation found V1 `cpu_poison` used decimal29/17, while the existing
public contract and actual provider use hexadecimal0x29/0x17. Root approved a
separate independent V2 correction before any new C/execution. This public
amendment explicitly retains hexadecimal0x29/0x17; V1 remains unaltered evidence
of the caught draft mismatch, not authoritative poison bytes. Root also approved
the new final ZLP's explicit source_offset352/count0. No input byte is read for
that zero count; all64 bytes use the same nonzero padding formula.

The other V1 wording correction is that the stale/reused cookies differ in their
first four fields while both endpoint fields remain1. The original identities
in this public header/amendment are unchanged. Subsequent independent additive
layout/checkpoint acceptance must be sealed separately, rather than modifying
the already-frozen independent V1 or this package silently.
