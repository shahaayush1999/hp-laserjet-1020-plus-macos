# Reset profile contract draft

Static/unexecuted, 2026-10-03. Root owns all integration and execution. This package
contains a proposed sibling profile header, manual target32 layout tables and
the public amendment only. `inputs/` holds exact read-time baseline/source bytes;
it does not contain a complete future build closure. No new implementation C,
compiler layout result, generated fixture, validator or executable is included.

- `AMENDMENT.md`: bounded schedule, state/cancellation semantics, public helpers,
  six expected-return records, exact memory deltas and observation meanings.
- `draft/open-firmware/entry-usb-reset-test/`: proposed header and manual tables.
- `*-changes.diff`: review deltas against exact saved healthy-profile files.
- `SOURCE_ORIGINS.md`: source paths and the independent draft correction.
- `DRAFT.sha256`: seal of every other member. Hash readback is archive integrity,
  not compilation, runtime validation or hardware evidence.

Root and the independent acceptance author must approve the frozen public ABI
before implementation. New C belongs in a separate profile; never overwrite
the accepted entry-usb-test contract. The exact linked observation-address/return
selection and raw capture schema remain a separate harness amendment. No proposed
new checkpoint has been executed, and no old stack/call admission is inherited.
