# Reset observation design V2: capture the pre-admission cut

2026-10-03, `/root/adapter_review`. Static source-order review only. No new C,
imports, parsing, builds, audits, target/checker execution or repository changes.
This amends the candidate sequence in design SHA256
`b49481ca3921c20f3295b0bc03804f48f50f7f3040e6b3db16a6752882ee9d8c`.
Exact inputs are copied/sealed in the matching `/tmp/...observation-v2.../` directory.

The added prefix is sound under the unchanged initial configuration path:

`pre-C → next hp1020_udc_ep0_take_submission (initial configuration status)
→ next hp1020_udc_setup_offer (sequence3, pre-reset admission)
→ first hp1020_udc_out_request_cancel → existing reset sequence`.

The accepted runtime's `configure()` calls the initial sequence2 offer at
`hp1020_usb_runtime.c:138`, dispatch at141, then service at145, before taking
the genuine initial EP0 proposal at149. Its top-level entry at203 returns from
configure before initial recovery and the old packet loop. Consequently the
initial offer has already executed when the first status-take breakpoint is
observed. Arming setup_offer only then reaches the proposed sequence3 reset
offer, with no initial-offer stop, skipped hit or debugger state repair.

The new public contract requires reset_observation to prepare/copy sequence3
only at the old320-byte/held-packet6 cut; it does not itself offer, fence or
cancel. At setup_offer entry the request has not yet been admitted. Its original
argument, old reservation/output state and lack of installed image6 must be
checked independently. Merely seeing that function or the secondary note is
insufficient. The final additive oracle owns exact labels, counts and states.

Two context clarifications apply to the existing sequence:

- Both fresh `arm_out` stops mean **hp1020_udc_publish_arm_out**, the outer entry
  before preflight and receive reservation, not the nested adapter arm callback.
- EP0 `take_submission` is outer orchestration after the DCD callback unwinds.
  Current `dcd_edpt_xfer` at `hp1020_usb_runtime_ram.c:221–252` invokes
  `hp1020_udc_ep0_prepare`, retains the original bound owner and returns; it does
  not call take_submission. Initial status take occurs after service returns;
  the proposed deferred reset status take likewise follows finish_reset return.
  Provider callback_depth and adapter busy/stack_active are therefore clear at
  these proposed take stops. The independent reviewer was informed before its
  oracle freeze; do not inherit an inside-DCD busy1 expectation.

This adds two explicit natural boundaries and no new execution permission.
Successive stopped PCs remain different, although some addresses recur later.
The new local observer/gate must capture every actual resume/removal and match
the frozen order; hidden skips, arbitrary steps and post-seed writes remain
forbidden. RAM, code, stack and instruction budgets are unchanged. A future
implementation must still prove this exact order in its real PC/access trace;
no new reset runtime exists or has been executed in this review.

Source anchors: accepted runtime C SHA256
`1e41bc95035ec54346352e748aed59523c48cc808abc66f0991b9603bec84a68`;
provider C `f0af91498c209854245727afca963184238c1005e55bdcf05a963a18956e3302`;
proposed public header
`a73a3904b094126e811f6d26249ab93d3d71cae7f5e0c00cedd10e77addc4679`.
