# Two pre-implementation review corrections

2026-10-03. No reset runtime/provider C exists or has been executed for this
proposal. No candidate/oracle imports, parsing, builds, target execution or
repository edits occurred in this independent revision.

The immutable V1 package remains at
`/tmp/hp1020-entry-usb-reset-independent-20261003/`, manifest SHA256
`ef9d77f1defd48fa116fc8ccd82b93513a9e6be004e95775d41290d840eb1db5`.
The original literal SHA is
`d230a495ff51cf0edd4920e8b621000c43efcb2df0556c253d03ee1597c49ba8`;
the original ACCEPTANCE SHA is
`7a6dbcafab15b0069e3723612dde0cae9e0a45cad6d5686e36ed35e766ce1253`.
Copies and the original manifest are retained in `inputs/v1/`; the complete
42-input source closure remains in that unchanged V1 package.

1. The public-contract author independently found a poison-formula transcription
   error. V1's `cpu_poison` used decimal29/17, whereas the already approved
   original public CONTRACT.md:187 and frozen additive literal:84 specify
   `slot*0x29` and `i*0x17`. The unchanged old provider:430 independently confirms
   the same hex constants. This V2 changes that one expression, preserving all
   three read-time inputs under `inputs/prior-contract/`. It restores the
   established synthetic source/CPU distinction; it is not inferred from new
   runtime outputs, and no acceptance result is retrospectively relabelled.
2. Root found paragraph9's statement that all cookie fields differ too broad:
   old `(7,3,2,6,1)` and new `(10,4,3,2,1)` differ in their first four fields,
   while endpoint remains1. The tuples were already correct. V2 corrects only
   that prose; no cookie, sequence, memory, event, count, CPU or trace expectation
   changes.

Separately, root explicitly accepted final ZLP source offset352/count0 as this
new profile's diagnostic metadata. The old provider used0/count0; both imply
no source payload read. V1 already freezes352 and V2 leaves it unchanged. The
new public amendment must state352 and must reject any attempt to read source
bytes for that zero count; synthetic64-byte nonzero padding is still supplied.

Public witness offsets, refusal-row serialization and natural-stop selectors
remain a forthcoming additive contract. They are not silently filled from a
new implementation. `V1-to-V2.patch` contains the complete two-file delta.
