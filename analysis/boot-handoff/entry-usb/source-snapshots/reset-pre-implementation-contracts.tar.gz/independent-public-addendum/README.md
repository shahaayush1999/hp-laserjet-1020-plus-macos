# Independent reset-profile additive acceptance

Static and unexecuted,2026-10-03. `ADDENDUM.md` owns the exact20-stop contract,
`LAYOUT-REVIEW.md` owns the manual new-layout arithmetic, and
`literal-addendum.py` is matching literal data without imports or entry point.
This package supplements, and does not replace, the frozen semantic V2.

`inputs/public/` is an exact complete copy of the frozen33-member public
proposal, including its manifest. All33 original members were SHA256-readback
verified. Its `inputs/independent-v1/` retains the original literal/prose mistake;
`inputs/semantic-v2/` preserves the separately corrected acceptance/literals,
the exact patch and historical manifest. No original package was modified.

`inputs/observations/` preserves both arrangement proposals. The newer
observation note and parent decision add the initial status-take and true
pre-reset offer, producing20 explicit stops. `inputs/observers/` contains only
existing observer source read for geometry/ledger limits. `inputs/private-core/`
retains the prior source-derived manual proof/table, its historical input
manifest, exact effective usbd.c and config; the historical manifest references
the separately preserved old proof package, not missing files claimed as part
of this smaller copy. `inputs/remaining-production/` supplements the full public
package's exact production C/H copies used for source-flow review.

No new runtime/provider implementation or new result capture supplied any
expected value. No Python import/parse, compiler, audit, checker, validator,
target instruction or hardware operation was run. Shell file copies/hash reads
alone verify this package's provenance. `DRAFT.sha256` includes every file except
itself, including nested historical manifests. Parent owns future integration,
fresh source admission and all sequential execution.
