# One continuous reset race, followed by a fresh document

2026-10-03. Static proposal only. No implementation, candidate import, parser,
build, audit, validator, target/QEMU execution or hardware operation was performed
for this plan. It follows the current entry-USB schedule; root must first accept
that schedule with its independent raw gate. This is not a result or a claim of
printing, physical reset or DMA correctness.

## Recommendation

Add one separate continuous profile: **canonical printer SOFT_RESET while the
last packet of a document remains owned; that old packet completes successfully
after reset admission; then recover and complete one fresh document.** Replay
the saved old cookie only after its exact receive buffer has actually been reused.
Keep startup, all production components, full buffers, stack and RAM caps intact.
Two existing paint variants with ordinary normalized CPU state are sufficient
for this new schedule; the earlier six startup profiles remain separate evidence.

Use raw SOFT_RESET here rather than another bus reset/configuration cycle. It is
the smaller useful path: the current binding remains configured, the class has
an actual deferred status reply, and the experiment exercises receive/output
recovery without adding another endpoint programming lifecycle. Bus-reset
reconfiguration, failed cancellation and asynchronously owned output are distinct
later profiles, not implicit coverage of this one.

The proposed race uses a **late successful completion**, not a fabricated aborted
transfer. A cancellation request does not prove that it won the race. Existing
APIs permit the original transfer to settle successfully while input is fenced;
the real TinyUSB callback must then discard it before parser admission.

## Exact useful cut

Reuse the unchanged 352-byte small-black stream, SHA256
`ad339333c0d37ee41da13849184caebec4b55d8f913eb30f9565e30cd33a062d`.
The independently specified chunk construction gives these half-open byte spans:

| Bytes | Input |
|---|---|
| 0..4 | stream magic |
| 4..56 | START_DOC: header16 + three items36 |
| 56..228 | START_PAGE: header16 + thirteen items156 |
| 228..264 | BIH: header16 +20 bytes |
| 264..304 | BID: header16 +6 encoded bytes +18 padding bytes |
| 304..320 | END_JBIG |
| 320..336 | END_PAGE |
| 336..352 | END_DOC |

After ordinary initialization/configuration/recovery, consume five 64-byte
packets through publication, acquisition, actual TinyUSB service and document
pump, then eagerly arm packet6. Freeze the reset cut **before** installing or
acquiring packet6's device image. The parser has consumed exactly320 bytes.

At this cut generation2 has issued6/consumed5/count1. Its sixth reservation is
unready and its DCD/OUT owner remains retained. The decoded old page can already
have one READY ring slot: eight rows, stride4,32 FF bytes, copied_rows8 but
accepted_rows/completed_rows0. END_PAGE has not been validated, so stream.pages,
pages_drained, completed-document count and actual output/document callbacks
are all0. The semantic parser's `documents` counter is1 because it counts
START_DOC; it is **not** a completion counter.

This cut is more useful than an empty/header-only document: restart must discard
real pending software page state. It still makes the output-quiescence promise
truthful without inventing an external hardware owner: nothing was accepted by
the output consumer, and this serialized provider has no asynchronous consumer.

## Bounded schedule and expected distinctions

1. **Retain the original owner.** Copy the packet6 cookie by value from the real
   DCD bind before any reset. Also preserve its actual CPU pointer, fixed DMA
   label and descriptor identity for read-only evidence. Neither current
   generation nor a descriptor address may later reconstruct this cookie.

2. **Admit the real class request.** Use original ingress sequence3, after the
   initial reset1/configuration2, and immutable SETUP16
   `80000000000000002102000000000000`. The unchanged eight wire bytes are
   `21 02 00 00 00 00 00 00`. Supply the existing capture/stall facts explicitly.
   Offer must precede dispatch; no ordinary service/pump occurs while this new
   record is held. Dispatch fences receive immediately and queues one cancellation
   request carrying packet6's original cookie. It does not retire either owner,
   clear READY output, reset counters or submit a status packet.

3. **Drain the queued request without claiming settlement.** After dispatch and
   its callbacks have returned, call `hp1020_udc_out_request_cancel(old_cookie)`.
   It only marks the existing OUT owner. Service the admitted SOFT_RESET through
   `hp1020_udc_publish_service`. Expected result is **OK**, even with the old bulk
   owner retained: SOFT_RESET fences immediately but is not the adapter's
   endpoint-changing `pending_destructive` path. It begins the new class recovery
   and defers its ACK. Save the actual pending reset ticket. A finish-reset attempt
   now returns WAIT; no new EP0 owner or reply exists. An early receive promise
   likewise must WAIT while bulk ownership remains.

4. **Let the original packet win the cancellation race.** With the old cookie
   still retained, install its explicitly supplied successful device image for
   input bytes320..352, count32. Use the same separate guarded device images,
   nonzero64-byte padding, poisoned CPU descriptor/prefix and actual range hooks.
   Supply settled/mapping/cache facts for this original transfer. Acquire through
   `hp1020_udc_acquire_packet(old_cookie, 0, facts)`; expect OK. The component
   becomes FREE, but the adapter remains PENDING with that same old identity,
   result SUCCESS/actual32 and its original buffer. Core bulk BUSY remains set
   until service. A receive-promise attempt here must still WAIT: acquisition
   alone has not drained the callback.

5. **Drain the actual old callback before the generation promise.** The next
   publisher service dispatches that PENDING completion through TinyUSB, clears
   BUSY and retires the adapter owner. `driver_xfer` must see the stop fence and
   omit `receive_complete_data`; thus the old reservation stays unready,
   issued6/consumed5/count1. Its final32 bytes are CPU-visible but never reach
   END_PAGE/END_DOC. No old output or document notification occurs. Do not pump
   those32 bytes, mark them consumed, release the reservation manually or invent
   an ABORTED result. No cancellation settlement API is used in this profile.

6. **Supply three distinct truthful promises.** Only after all old transfer
   writes and the actual callback are settled, acknowledge RECEIVE for the saved
   recovery ticket. Independently acknowledge OUTPUT after establishing that no
   consumer can access the old READY slot. A finish attempt with those two parts
   alone must WAIT with generation2/storage retained and no status owner. Then
   supply TRANSPORT, covering the adapter's conservative bulk-IN/halt/toggle and
   endpoint-default contract; empty software queues or a reset SETUP do not prove
   it. Finish the recovery exactly once. It advances to generation3, resets
   receive/parser/ring bookkeeping through `document_restart`, preserves both
   callback/context pairs, and binds one genuine deferred EP0 IN status ZLP.
   Observe/publish/settle/service that original status owner through the existing
   EP0 component. No reply is inferred from the recovery return value alone.

7. **Test stale identity at exact buffer reuse.** Start the fresh document normally.
   Complete/pump its first64 bytes and arm its second packet. The current packet
   now uses the exact CPU prefix/DMA slot and common descriptor previously owned
   by old packet6, but a different original cookie. Before installing the current
   device image, call acquisition once with the saved old cookie and otherwise
   valid facts. It must return STALE before any visibility hook, snapshot, payload
   read/copy or fault; current owner, descriptor/prefix, generation, counters and
   acquisition diagnostics remain unchanged. A delayed queued
   `out_request_cancel(old_cookie)` may be included once at the same cut and must
   also be STALE without touching the new owner. Do not mutate individual cookie
   fields or add the existing component matrices again.

8. **Finish a real new document.** Continue the fresh352 bytes through all normal
   paths. Observe exactly32 actual FF output bytes and one event
   `(generation3, document_id1, first_page0, pages1)`, before shutdown. Eagerly arm
   its seventh OUT. At the first actual close-input entry that packet remains
   owned. Close once, supply its successful ZLP, observe the PENDING owner before
   the next service, service/pump the empty reservation, finish once and park.
   No per-document finish, direct receive restart, reinitialization or host repair
   is allowed. The ZLP is still not EOF; the explicit close supplies that boundary.

## Original identities and independent final expectations

These are source-derived predictions to freeze independently before execution,
not cookies to manufacture in the provider. Every actual bind must be compared
to the predictions while retaining its own returned cookie.

| Binding | `(id, epoch, generation, sequence, endpoint)` |
|---|---|
| Initial configuration status | `(1,2,1,0,0x80)` |
| Old packet q, q=1..6 | `(q+1,3,2,q,1)` |
| Held old packet6 | `(7,3,2,6,1)` |
| SOFT_RESET status, after restart | `(8,3,3,0,0x80)` |
| New packet q, q=1..7 | `(q+8,4,3,q,1)` |
| Exact reused slot1 packet | `(10,4,3,2,1)` |
| Final retained/ZLP packet | `(15,4,3,7,1)` |

Initial recovery remains `(id1,generation1)`; the SOFT_RESET recovery is
`(id2,generation2)`. It stays that original ticket after generation advances.
Control epoch becomes3 at reset admission; current transport epoch becomes4,
while active transport epoch stays3 until successful recovery. A retained old
cookie does not become stale merely because the current epoch has advanced:
its genuine late settlement must remain possible before restart.

The first old page never has an accepted output row or END_DOC notification.
At park the new generation has issued=consumed7/count0, stopped1/quiescent0/error0,
document/output finished1, no owner, no active recovery and no class response
storage retained. Control epochs are3, transport epochs4, submission ID15.
There is one bus-reset observation, two raw SETUPs, two recovery finishes,
two actual EP0 status settlements, one cancellation request and **zero** ABORTED
cancellation settlements. Device payload acquisition totals704 bytes, while
parser admission totals672: old320 + new352. The discarded32 must not be counted
as consumed. Successful bulk acquisitions total13, including the final ZLP;
the single stale acquisition adds an attempted call but no successful acquisition.

Do not expect memory zeroing on recovery. Receive restart clears slot metadata,
not its4096-byte storage; output restart clears state, not all output storage.
After final ZLP, receive prefixes are independently reconstructible:

- slot0: new input256..320;
- slot1: new input320..352, then the approved nonzero padding for indices32..63;
- slot2: the approved full64-byte count0 padding;
- slot3: new input192..256.

Every receive tail64..1024 remains untouched. The actual output slot storage
retains32 FF bytes and untouched remainder; the output witness contains32 FF
followed by32 zero bytes, and only its first document row is used. An old READY
slot and a new successfully delivered page may have the same pixels, so byte
equality alone is insufficient: actual accept/complete callbacks, new feed bytes
and the original generation3 document event must all agree.

## Truthful quiescence and the stale replay

There are two different events, deliberately separated:

- The genuine late SUCCESS is delivered and its actual callback drained **before**
  RECEIVE is acknowledged. Its original buffer remains valid until then.
- The post-restart stale call is adversarial replay of a saved, inert identity.
  It is not an undispatched live DMA callback that the provider falsely claimed
  to have drained. It performs no source-image installation or DMA write. The
  contract to be proved is rejection before dereferencing the reused allocation.

If a real platform could still write through an old descriptor or invoke a
callback that touches retired storage, the receive promise would be false and
restart must remain blocked. Software generation checks cannot repair that
violation. Similarly the old READY output can be abandoned only because this
profile has no accepted/asynchronous output consumer; no already delivered page
is retracted. Mapping/cache safety, all old callbacks, bulk-IN/default state and
physical controller stop still require external platform evidence.

One important scope limit: an actual nonzero fault of the still-retained old
owner before recovery may invalidate the pending reset, since its active binding
still exists. Do not assume every old-looking fault is STALE or silently reuse
that recovery ticket. This profile uses valid late SUCCESS and tests stale
metadata only after real retirement and exact-address reuse.

## Required integration changes; no production API gap identified

The existing production APIs provide this path without new owners, queues,
generation setters, descriptor policy or protocol emulation. The current
experimental provider is intentionally healthy-only and needs a separate
reviewed profile amendment:

1. `request_cancel` currently records the real cookie and then fails the profile.
   The new variant must record this one expected request without recursion or
   settlement. Its orchestrator drains that recorded request after callback return.
2. SETUP helper only installs initial configuration/sequence2. Add the exact
   immutable SOFT_RESET record/sequence3; preserve its original copy and shared
   monotonic ingress. `dcd_edpt0_status_complete` currently rejects any second or
   non-configuration status; the new profile must admit exactly the two actual
   request-linked status completions, without inventing a status callback.
3. Current `result()` treats every nonzero return as fatal. The new bounded
   schedule needs explicit separately recorded WAIT/STALE expectations, without
   changing production APIs or accepting a surprising result as progress.
4. There are still13 bulk publication/acquisition scopes and65 range-hook rows.
   No second configuration or program/grant I/O is warranted. With the same
   explicit read inputs, logical I/O remains19 +13*(14+3)=240 rows. Scope is a
   monotonic diagnostic label, **not** the receive sequence after restart.
   There are now15 real DCD bindings, exceeding the current14-row witness cap.
   A minimal separate schema can use15 bind rows, four rather than eight bytes
   of alignment padding, move later witness members32 bytes, and reduce final
   reserved storage32 bytes. Total witness9216 and its10176 cap remain unchanged.
   Freeze the amended manual/compiler layout and independent oracle before C.
5. Keep one old cookie by value for the replay, not a second live owner or large
   transfer history. Existing retained records, original range witnesses,
   guarded device image and actual adapter/core state remain authoritative.
   Re-audit the changed call graph/stack and exact source closure; do not inherit
   the old fixed-workload ceiling or weaken no-shortcut checks indiscriminately.

Useful full paired observation boundaries are reset admission with the old DCD
owner, late acquisition before callback service (PENDING), drained old callback
before promises, actual second document restart, exact buffer reuse before/after
stale ingress, and the existing close/final-service/finish/park boundaries.
Use natural production calls and explicit ordinal/generation conditions, not
new host writes or state-only labels. The independent gate must also observe
actual absence of receive completion for the discarded tail and no pre-reset
output callback; mailbox counters alone are insufficient.

Do not expand this into malformed SETUPs, reset storms, counter exhaustion,
every acquisition failure, offload grant or bus-reset matrix. Those have separate
component evidence. This proposal adds one continuous cancellation race and one
successful recovery with an actual fresh document, with narrow stale replay.

## Source basis

Exact read-time inputs are copied in `inputs/` and sealed in `DRAFT.sha256`.
This is a design-source subset, not the complete future executable closure.
Important anchors in those copies:

- `hp1020_tusb_adapter.c`: admission/fence96..110,449..468; class reset
  dispatch303..322; fenced successful bulk callback339..369; pending-owner
  delivery739..790; service818..898; recovery gates970..1043.
- `hp1020_udc_out.c`: immutable current-cookie checks47..55; original late
  completion168..205; queued cancellation216..239; acquisition303..389.
- `hp1020_usb_printer.c`: separate recovery identity44..72; required three-part
  ACK204..257; restart/deferred response generation260..289.
- `hp1020_usb_document.c`: pump stop gate30..46 and callback-preserving
  restart62..74. `hp1020_usb_receive.c`: metadata-only generation restart.
- `hp1020_image_stream.c`: END_JBIG versus END_PAGE boundaries;
  `hp1020_image_output.c`29..55 and59..78: no drain before validated END_PAGE;
  `hp1020_image_ring.c`: READY, accept and completion are distinct.
- Current `hp1020_usb_runtime.c`, provider and public contract identify the
  intentionally restricted helper/status/bind capacity that needs amendment.
- Existing independent stream construction and USB literal/addendum files
  establish the input, fixed DMA labels, poisoned CPU/source padding and prior
  identity schedule; no helper was imported or executed to produce this note.
