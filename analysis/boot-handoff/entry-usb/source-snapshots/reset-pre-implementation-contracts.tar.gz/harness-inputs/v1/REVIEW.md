# Separate continuous reset profile: validation arrangement

2026-10-03, `/root/adapter_review`. Static design only: no imports, parsing,
builds, audits, checker/target execution or repository changes. Read-time inputs
are copied and hashed under `/tmp/hp1020-entry-usb-reset-harness-design-20261003/`.
The reset plan is SHA256
`b810f5b58ca52ec96191a09d2ca017b49839348d0fb37f23af41ec1e0b0439ca`.
This note does not replace the separately assigned public-layout or state oracle.

Use a sibling `open-firmware/entry-usb-reset-test/` and separate
`analysis/boot-handoff/entry-usb-reset/` target, captures and report. Keep the
three C basenames, exported runtime/object names and target leaf names
`entry-usb.elf`/`entry-usb.map`; the containing directory and report schema identify
the profile. The contract author confirmed unchanged unit/object names. Reuse
the exact accepted startup.S/runtime.ld from their original directory if their
unchanged assertions admit the new objects. Do not edit the accepted profile or
route the old builder through replacement globals, aliases or temporary source
overwrites. A small sibling builder retains its explicit flags/tool/source gates.

New script entry points should be `validate-hp1020-entry-usb-reset.py`,
`build-hp1020-entry-usb-reset-target.sh`, `hp1020_entry_usb_reset_audit.py`,
`hp1020_entry_usb_reset_machine.py`, `hp1020_entry_usb_reset_qemu.py` and
`check-hp1020-entry-usb-reset.py`. These are narrow profile coordinators and policy,
not six blanket copies. Do not retrofit a general multi-profile framework into
the accepted files during this experiment.

## Reuse without changing accepted modules

- **Audit:** reuse current `read_relocatable`, raw input-section and mutable-object
  checks, `check_layout`, `check_dependencies`, `read_properties`, `check_startup`,
  private getter/initialized-data checks, libgcc proof/classifier and stack-file
  reader. Their unit/symbol names, allocation caps and production ABI still fit
  the proposed variant; pass its independently frozen object table. A new local
  `contract_inputs`, public-layout/immutable-record check and `audit_target`
  coordinator bind the new header/table/source hashes and audit's own source.
  Do not call the old top-level auditor or patch its globals. Before reusing
  `check_dependencies`, locally require every declared output to be the new
  target: the old helper also admits its historical entry-usb output directory.
- **Interpreter:** subclass unchanged `EntryUSBMachine`. Its constructor can
  retain the existing exact six core checkpoints, own-stack/range/startup/call
  policy and one close/finish/park contract. Add a separate, closed reset-stop
  schedule and entry counters in the new subclass. Its `after_instruction`
  should delegate existing execution guards, then observe additional genuine
  transitions; do not weaken or repurpose the inherited six-stop ledger. Return
  both core and full ordered observation evidence and require exact completion.
  Observation predicates must not call modeled `read()` to invent trace accesses.
- **QEMU:** reuse unchanged `ObservedQemu` constructor, `command`, seed-once/lock,
  cleanup, snapshots, register reads and raw ledger utilities. New local input
  validation, command guard and observation loop admit only the frozen reset
  sequence and two terminal steps. Current `ObservedUSBQemu.guard`/`execute`
  hard-code six distinct stops and cannot be reused as the new top-level loop.
  The same split-memory `validate_policy`/`verify_protected` remain applicable.
- **Runner:** reuse `elf_loads`, `file_bytes`, `initial_regions`, `save_snapshot`,
  `snapshot_bytes`, register normalization and phase protection. Use local source
  selection, layout binding, tool closure, case orchestration and publication:
  those old functions embed SOURCE/OUT or six-case/two-document assumptions.
  Two ordinary-CPU paints are a new report, never a relabelled six-case report.
- **Independent gate:** reuse its neutral sealed-file, ELF, snapshot, protected
  memory, instruction-width/access decoding, library and `Ledger` primitives as
  an explicitly pinned independent library. Freeze new literal/state/layout,
  source binding, actual-call/access replay and exact GDB transcript policy.
  Do not call old `check_capture`, `model_trace`, `qemu_ledger` or `check_entry`:
  they encode the old schedule. The exact-five GC shortcut proof remains useful;
  this reset permits request_cancel, not out_cancelled/ep0_cancelled settlement.

Every imported old helper file must be in the new source closure with its exact
accepted hash. No globals monkey-patching, rebinding `__file__`, producer imports
in the raw checker, or fallback to old tables/report expectations.

## Concrete natural observation sequence

One candidate sequence avoids broad stop-at-every-call machinery and hidden
skips. After the existing normalization/pre-C stops, arm successive breakpoints
at these actual entries, validating the indicated role from the independently
frozen arguments/identities/state:

1. First `hp1020_udc_out_request_cancel`: reset has been admitted with old owner.
2. Next `hp1020_tusb_adapter_ack_reset`: early RECEIVE attempt with DCD owner.
3. Next `hp1020_udc_publish_service`: successful late acquisition is PENDING.
4. Next `hp1020_tusb_adapter_ack_reset`: old callback has actually drained.
5. Next `hp1020_usb_document_restart`: the second actual restart, before its body.
6. Next `hp1020_udc_ep0_take_submission`: genuine deferred reset status afterward.
7. Next arm_out, then next publish_service, then next arm_out: fresh packet1 arm,
   its pending completion/service, then packet2's arm. These explicit intervening
   observations establish which following acquisition is the inert stale replay.
8. Next `hp1020_udc_acquire_packet`: saved old cookie against the reused slot.
   Then the next `hp1020_udc_out_request_cancel` if that optional stale probe is
   frozen, or the next normal `hp1020_usb_runtime_ram_install_bulk` entry. The
   latter occurs before current image installation and can expose post-replay
   state without counting a new data operation as the stale probe.
9. Existing actual close / final-service / finish / park stops and two park steps.

This is an arrangement proposal, not a frozen state oracle. Each role has a
unique label even when its PC is reused. No two successive proposed stops use
the same PC, so no assumption about re-inserting a breakpoint at the still-held
PC is needed. If the final schedule requires an earlier occurrence, capture it
explicitly and account for its continue/remove commands; never silently skip,
step a callee, repair PC/registers or broaden post-seed writes. Core snapshots
and extra snapshots must form one independently checked total order.

The raw trace still must establish actual missing-promise WAIT results, original
callback drainage and absence of old receive/output admission; role labels or
the new diagnostic witness cannot substitute. Track stale acquisition attempts
separately from successful acquisitions: old `model_trace` marks every acquire
entry pending-service, which is specifically wrong for the no-hook STALE call.

## Remaining admission work

Freeze the new public table, source/provider contract, finite stop schedule and
independent literals before C execution. The linked audit must measure the new
generic BSS and complete code/object/dependency/libgcc closure; re-review its
actual callback graph and stack rather than transfer the old7472-byte bound.
New relocation/literal bytes and GC membership must be checked, not hash-edited.
Retain failure captures and source snapshots before any correction. Recheck raw
gate and protected-byte/command controls for the changed policy. Only then add
one separate sequential offline-suite call and one closed archive/checker
profile entry; preserve both existing accepted reports and checker self-pins.

No new production API or physical USB operation is proposed by this arrangement.
