"""Compare the new checkpoint after full validation; no target execution."""
from pathlib import Path
import copy,hashlib,json

root=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
base=Path('/tmp/hp1020-entry-full-baseline-20261003')
out=Path('/tmp/hp1020-entry-full-comparison-20261003.json');assert not out.exists()
sha=lambda b:hashlib.sha256(b).hexdigest()
expected={'continuous-printer':34,'printer-class':82,'receive-core':75,
 'tinyusb-printer':132,'udc-out':34,'udc-ep0':50,'udc-composed':62,
 'udc-offload':58,'udc-program':28,'udc-publish':40,'udc-acquire':32}
rows=[]
for oldpath in sorted(base.rglob('validation.json')):
 name=oldpath.parent.name;newpath=root/oldpath.relative_to(base)
 a,b=json.loads(oldpath.read_text()),json.loads(newpath.read_text())
 assert a['status']==b['status']=='pass' and len(a['cases'])==expected[name]
 assert a['cases']==b['cases'],(name,'host case/capture change')
 assert a['target']['status']==b['target']['status']=='pass'
 assert a['target']['cases']==b['target']['cases'],(name,'target case/capture change')
 rows.append(dict(component=name,host_cases=len(a['cases']),target_cases=len(a['target']['cases']),
  complete_case_arrays_unchanged=True,before_sha256=sha(oldpath.read_bytes()),after_sha256=sha(newpath.read_bytes())))
assert {r['component'] for r in rows}==set(expected)
first=Path('/tmp/hp1020-entry-ram-ssc7nafg')
a=json.loads((first/'validation.json').read_text())
b=json.loads((root/'analysis/boot-handoff/entry-ram/validation.json').read_text())
latest=Path(b['capture'])
assert a['status']==b['status']=='pass'
assert a['target_sha256']==b['target_sha256'],'actual target build bytes changed'
assert a['linked_audit']==b['linked_audit'] and a['input']==b['input'] and a['tool_closure']==b['tool_closure']
assert set(a['source_sha256'])==set(b['source_sha256'])
changes={n:dict(before=a['source_sha256'][n],after=b['source_sha256'][n])
 for n in a['source_sha256'] if a['source_sha256'][n]!=b['source_sha256'][n]}
assert set(changes)=={'scripts/validate-hp1020-entry-ram.py'}
assert changes['scripts/validate-hp1020-entry-ram.py']['after']=='f61fe39ae28a48bd8712e62c2fa4afa7c6688cdfb8fcd66f80a618a6d5f7f216'
cases=[]
for ca,cb in zip(a['cases'],b['cases']):
 assert ca['case']==cb['case'] and ca['status']==cb['status']=='pass'
 assert ca['model']==cb['model'],'all concrete state/access/step/call identities must agree'
 qa,qb=copy.deepcopy(ca['qemu']),copy.deepcopy(cb['qemu'])
 # Only elapsed time, OS process ID, private socket path and the ledger seal
 # containing that process ID are run identities. Their semantic ledger
 # comparison below independently checks every other command/reply byte.
 for q in (qa,qb):
  q.pop('elapsed_seconds');q['cleanup'].pop('pid');q['qemu']['args'][-1]='PRIVATE_SOCKET'
  q.pop('host_intervention_ledger')
 assert qa==qb,'full native observations or non-ephemeral metadata changed'
 ledgers=[]
 for folder,c in ((first,ca),(latest,cb)):
  raw=(folder/'cases'/c['case']/'qemu/host-interventions.jsonl').read_bytes()
  assert sha(raw)==c['qemu']['host_intervention_ledger']['sha256']
  entries=[json.loads(line) for line in raw.splitlines()]
  for row in entries:
   if row['kind']=='process-cleanup':row.pop('pid')
  ledgers.append(entries)
 assert ledgers[0]==ledgers[1],'native commands/replies differ beyond OS process ID'
 assert {k:v for k,v in ca.items() if k!='qemu'}=={k:v for k,v in cb.items() if k!='qemu'}
 cases.append(dict(case=ca['case'],exact_model_and_native_state_unchanged=True,
  exact_host_transcript_except_cleanup_pid_unchanged=True))
result=dict(status='pass',components=rows,entry_cases=cases,source_changes=changes,
 previous_entry_capture=str(first),latest_entry_capture=str(latest),
 scope='Exact byte/state/trace comparison; excludes only explicitly listed ephemeral process identity/time.')
out.write_text(json.dumps(result,indent=2)+'\n')
print('All eleven components and six continuous entry cases retain their prior behavior and raw state.')
print('Only the reviewed entry evidence-publication runner source changed.')
