# Narrow direct-CALL0 assembly correction

Static review only, 2026-10-03. No candidate build, assembler, import, validator,
target execution, hardware contact or source edit was performed. The first
actual attempt stopped in assembly before candidate execution; its unchanged
log is copied here. This note recommends a future correction, not a successful
build result.

Use a local `.begin no-transform` / `.end no-transform` region around the pre-C
checkpoint, its direct `call0 hp1020_entry_c`, and the adjacent self-park.
Place `.begin` before the pre-C label and `.end` after the park's `j`, before
the following independent alignment directive. Keep the existing global/type/
size declarations and exact CALL0 target/return address checks. This disables
transformations only for that short sequence, without changing the global
assembler settings or introducing a new literal pool/indirect call.

Do not rely on adding `--no-longcalls` alone. It is already the pinned
assembler's default and does not control the early maximum-literal reservation
that explains this failure. An underscore `_call0` also suppresses its individual
expansion, but the regional directive more directly expresses the required
CALL0-to-park adjacency. Actual emitted bytes and symbols remain to be audited.

## Exact primary-source chain

The source checkout's HEAD is
`0104f7d3c1a3e55954bf7b09fc70dd542b910714`. The three GAS files below have no
working-tree modifications and their complete hashes match `git show` at the
repository's pinned `0104f7d3c1` revision. The separate corrected BE opcode
overlay is the existing pinned `bfd/xtensa-modules.c`, not a new tool change.

- `gas/config/tc-xtensa.c:421–428` initializes longcalls false.
  `gas/doc/c-xtensa.texi:90–99` documents the same default.
- `tc-xtensa.c:5489–5525` reads an underscore opcode prefix and sets
  `is_specific_opcode = has_underbar || !use_transform()`.
- `tc-xtensa.c:6837–6904`, particularly6881–6892, handles symbolic operands.
  A relaxable, non-specific instruction obtains both maximum widened instruction
  space and `literal_space` from its expansion rules. There is no longcalls
  policy check in that reservation condition.
- `gas/config/xtensa-relax.c:448–456` provides the CALL0 alternative consisting
  of a four-byte target literal, L32R into a0 and CALLX0. `tc-xtensa.c:3164–3208`
  computes the maximum literal size from those rules.
- `tc-xtensa.c:7158–7192` reserves the instruction's relaxation space, then
  calls `xg_assemble_literal_space` whenever that precomputed size is nonzero.
  `tc-xtensa.c:4233–4262` switches to the literal fragment before reservation.
- `tc-xtensa.c:11560–11575` emits the observed message when the text-literal
  mode needs a literal fragment but there is no pool location and automatic
  pools are disabled. The later movement check at11328–11335 can emit the same
  message. The two identical log lines alone are not a traced call-stack proof
  of which one produced each message.
- Only later does `xg_symbolic_immeds_fit`, at3336–3400, optimistically accept
  a nonweak external direct-call target with longcalls disabled. That later
  decision cannot provide the missing pool location required by the earlier
  potential-expansion reservation.

Marking the actual instruction specific via the narrow no-transform region
causes the6881–6892 reservation branch to be skipped. The alternate path ends
the fragment and keeps the ordinary fixup for the direct instruction. This is
a source-derived reason for the proposal, not a claim that the proposal was
assembled or executed.

`c-xtensa.texi:631–667,719–738` documents region scope/restoration and disabling
all relaxation/optimization in such a region. Lines204–229 distinguish the
single-instruction underscore form from a protected instruction sequence.
Lines101–109 require out-of-range operands to become errors with transforms
disabled. Preserve that failure behavior rather than silently add a long call.

## Range and metadata obligations

The same manual at391–400 gives direct CALL0's approximately512KiB range in
each direction. The corrected overlay has CALL0's `soffsetx4` operand at2877–
2880; its encoding/decoding at1419–1449 uses a signed18-bit word displacement
plus4 relative to the four-byte-aligned PC. Both the startup call and target
remain in the explicitly bounded24KiB code region `[10007000,1000d000)`, so
distance is comfortably inside that range. The linked C entry still needs
the actual required alignment and the direct relocation must resolve normally.
The linker/audit must reject any out-of-range or changed target instead of
expanding or accepting an alternate handoff.

There is an expected metadata detail to review before changing the audit:
`tc-xtensa.c:12157–12176` sets `is_data` for an initially empty no-transform/
specific-opcode record, then can also set `is_insn` for the actual instruction.
`frag_flags_to_number` at12190–12212 serializes both flags plus NO_TRANSFORM.
Thus this pinned producer can emit INSN|DATA|NO_TRANSFORM (kind6, e.g.0x106)
for the exact protected instructions. Frozen auditV2 currently rejects kind6.

If the first corrected artifact confirms that combination, handle it narrowly:
admit that producer-defined mixed record only within the original symbol span
`hp1020_entry_before_c .. hp1020_entry_park+3`, with NO_TRANSFORM present and
ordinary exact-byte annotation matching. Keep the independent requirement for
one three-byte direct CALL0 to the actual C symbol immediately followed by its
three-byte self-jump park. Reject mixed records elsewhere; do not treat generic
DATA or unannotated padding as executable, and do not globally disable the
annotation checks. Record original flags even if an internal classification is
normalized. No audit source is modified by this recommendation.

The pinned linker's existing use of NO_TRANSFORM is visible at
`bfd/elf32-xtensa.c:7642` and7833–7842: it skips affected relaxation/alignment
actions. This supports preserving the short sequence, but the final byte,
target, annotation and adjacency checks remain necessary.

## Evidence preservation

`inputs/` contains the full five cited tool-source files, exact failed build
log, current integrated startup/linker/builder and unchanged binutils recovery
script. `INPUTS.sha256` is relative to `inputs/`. GAS source hashes:

- tc-xtensa.c: `adc8a0e97548e11fae18a7859418b063dd12fa31d64abea89f4899e951dc184d`
- xtensa-relax.c: `e40f520bf44cf0c75224b9fc6cf2d2f11e3da55a33f916292e886b9ad55cca84`
- c-xtensa.texi: `b89e3dd2017a33f88addbc1dfe92090fcf3e0d07a36cfe2c7c6b1f4e2f5517ce`

Original failed build log:
`e7453cf340b13d791188ccc9615e171845aa42f27e9bd3e0b0f17f41abfbfcdc`.
No report hash was edited and no success is inferred from this diagnosis.
