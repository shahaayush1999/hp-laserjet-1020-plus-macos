# Original entry and minimal call0 CPU contract

2026-10-03. Static review by `/root/usb_reference_contract`. Scope is the original
entry at100167a8, standard CPU-state prefix of10006cd0, its terminal jump and the
stock ELF memory envelope. No original/candidate instruction was executed. No
assembler/compiler/build/validator, tool recovery, hardware operation, repository
edit or external download was performed. Corrected pinned objdump/readelf were
used only to decode existing bytes; a standalone stdlib reader extracted and
checked ELF bytes. Controller, IRQ/SETUP/cancellation and engine paths were not
investigated.

## Conclusion

A small **new non-ENTRY call0 entry** is justified for the proposed RAM-only
experiment. It should establish its own interrupt/window/loop state, aligned
owned stack and BSS before calling C. Do not call10006cd0 or transplant the stock
entry: stock begins with a windowed ENTRY before its CPU normalization and later
enters TLB/cache initialization. No usable stack address is established by the
allowed stock prefix. The late write to a1 is a jump target, not a stack.

This is a loader-entry contract, not proved cold boot. Loaded accessible RAM,
privilege, PC-relative literal mode and absence of asynchronous exceptions remain
supplied conditions. Actual memory mapping/cache attributes and loader behavior
remain unresolved; no additional physical memory is inferred from the emulator.

## Exact original bytes

The ELF SHA256 is
`2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`.
Its BE ELF32 header selects entry100167a8. The corrected BE decoder gives:

| Address | Exact bytes | Instruction/data |
|---|---|---|
|100167a8|6c1002|ENTRY a1,16|
|100167ab|021600|RSIL a2,1|
|100167ae|c020|MOVI.N a2,0|
|100167b0|02e431|WSR.INTENABLE a2|
|100167b3|c121|MOVI.N a2,17|
|100167b5|02e631|WSR.PS a2|
|100167b8|010200|RSYNC|
|100167bb|13c096|L32R a3,10006a14|
|10006a14|10006cd0|The loaded word is the CPU initializer target|
|100167be|0a3000|JX a3|
|100167c1|d10f|RETW.N, not reached by the preceding unconditional jump|

The existing startup decompile omits the initial ENTRY. Older generic objdump/r2
text that calls6c10 a two-byte MOVI is not the corrected BE instruction boundary.
ENTRY uses incoming a1/windowed call state; this sequence does not demonstrate
safe entry from arbitrary PS/WINDOWBASE/WINDOWSTART or a supplied call0 ABI. The
prefix has no ordinary stack-memory load/store, so even its use of a1 is not
evidence that an inherited stack region is valid or owned.

Standard CPU prefix, preserving exact special-register identities:

| Address | Bytes | Register/instruction and observed input |
|---|---|---|
|10006cd0|c000|MOVI.N a0,0|
|10006cd2|00e431|INTENABLE (SR228/0xe4) =0|
|10006cd5|00ea31|CCOUNT (SR234/0xea) =0; not needed for this C entry|
|10006cd8|004831|WINDOWBASE (SR72/0x48) =0|
|10006cdb|010200|RSYNC before using the selected register window|
|10006cde..cf5|c004 b008 c000 c010 c020 c030 c040 c050 c060 c070 020804 650fe7|Count4; decrement into a8, clear a0..a7, ROTW2, repeat while new a0 nonzero|
|10006cf8..cfd|c011 014931 010200|a1=1; WINDOWSTART (SR73/0x49) =1; RSYNC|
|10006d00|000231|LCOUNT (SR2) =a0, now0 under the intended window loop|
|10006d03|000031|LBEG (SR0) =0|
|10006d06|000131|LEND (SR1) =0|
|10006d09..d0c|00ed31 000200|ICOUNTLEVEL (SR237/0xed) =0; ISYNC|
|10006d21..d26|c021 02e631 010200|a2=1; PS (SR230/0xe6) =1; RSYNC|
|10006d29|000404|SSAI0, the observed shift-state normalization|

The intervening d0f..d1e writes clear DBREAKC0/1, DBREAKA0/1 and IBREAKA0/1.
The d2c..d47 suffix clears exception/debug/save/timer state, writes INT CLEAR
from a literal and reaches DDR. These are not requirements of ordinary call0 C
and should not be copied just because they occur in the original runtime.

The original rotating clear intends four groups of eight ARs. That agrees with
the pinned overlay's32-register window model; it is not a runtime CPU probe.
A call0 replacement does not require this physical-register clearing loop or
any ROTW, ENTRY, CALL4/8/12, RETW or exception-return instruction.

At10006d4a, `12fbe1` loads22222222 from10005cd0 and proceeds into memory-attribute
setup; the first reachable WITLB is10006d60=`043605`. This is the exclusion
boundary. Nothing in this review licenses its TLB/cache operations. Static
inspection of the terminal pair is sufficient to identify the next transfer:
10006e52=`11fba2` loads a1 from10005cdc, whose bytes10006bb0 are followed by
10006e55=`0a1000` JX a1. **a1=10006bb0 is not an initialized SP.** No claim about
the next routine's execution or memory operations is needed here.

## Pinned encoding and ABI cross-check

Local binutils source is commit
`0104f7d3c1a3e55954bf7b09fc70dd542b910714`. Its corrected `bfd/xtensa-modules.c`
matches the exact BE overlay at commit
`1e225492405c82b0b7b9973d8f549e1411168e3d` by a no-fetch Git object/hash comparison.
The encoder's WSR bases and register-field setter establish, for these forms,
`(aN <<16) | (special-register-number <<8) | 0x31`. In particular these are WSR
special-register instructions, not WUR user-register names from decompilation.
RSIL base000600 has a-register field bits19..16 and level field15..12;
RSYNC=010200, ISYNC=000200, SSAI0=000404. Relevant overlay lines255–283,
6111–6132,6681–6760 and6825–6828 contain those encodings.

Pinned `gdb/xtensa-config.c:30–46,181–194` and
`gdb/xtensa-tdep.c:85–132` name PS fields: INTLEVEL bits3..0, EXCM bit4,
UM bit5, RING bits7..6, OWB bits11..8, CALLINC bits17..16, WOE bit18. Thus stock
17/0x11 is INTLEVEL1 plus EXCM, whereas the later value1 leaves INTLEVEL1 and
clears those other named fields. WOE is absent in both written values. The
decoder/ABI source is primary tool provenance, not an identification of every
optional feature or cache size in the physical HP core.

GCC14.3.0 `gcc/config/xtensa/xtensa.h:443–466` specifies STACK_BOUNDARY128 bits,
call0 WINDOW_SIZE0, arguments a2..a7 and outgoing return a2. Pinned GDB also states
16-byte SP alignment. The repository compiler profile disables windowed calls,
hardware loops and unsupported extensions; the eventual linked closure must
still be audited. Stock CALL0/RET.N counterparts already belong to that gate.

## Minimal proposed entry sequence and dependencies

This is a design contract for later assembly/audit, not emitted replacement code.

1. Start without ENTRY or stack access. Use low logical registers for the short
   normalization prefix. Raise interrupt level, write INTENABLE0, and clear
   LCOUNT/LBEG/LEND before normal C. Keep a reviewed instruction synchronization
   after loop-state writes. No INT CLEAR, timer or controller acknowledgement is
   needed: pending hardware events are explicitly excluded from this experiment.
2. Set a deterministic privileged PS with WOE/CALLINC/OWB/UM/RING/EXCM clear,
   followed by RSYNC. Keeping INTLEVEL15 throughout the inert workload is a
   conservative choice. RSIL15 encodes02f600 for a2 by the pinned four-bit field;
   PS0x0f and this immediate are proposed values, not claims that the selected
   stock entry writes them. The selected stock counterparts write level1 and
   PS0x11/1. No previous interrupt/window state must be restored on parking.
3. Select WINDOWBASE0, RSYNC, then **reload** constants in the new logical window;
   values carried in a-registers across that change are not reliable. Set
   WINDOWSTART1 and RSYNC if using a deterministic window witness. These two
   normalizations avoid external register-window seeding; clearing every AR is
   unnecessary for the call0 ABI. SSAI0 is a byte-backed optional deterministic
   shift-state initialization; compiled operations still own later SAR values.
4. Establish a1 at the16-byte-aligned top of an exclusively owned, bounded stack
   before any CALL0/C prologue or helper. Set actual C arguments explicitly and
   let CALL0 establish a0. Do not pass a boot-ROM return address or reuse the
   stock a1 jump literal. The entry is terminal: return goes only to our park.
5. Clear precisely the replacement's owned BSS, preserve file-backed data and
   all anchor gaps, then CALL0 the reviewed C entry. Use ordinary bounded stores
   and branches, not a hardware LOOP. Compiler/linker helpers must remain in the
   audited call0 closure. Startup, memory guards, mailbox and unexpected-vector
   park must not invoke a stock system-interface callback.

Important incoming conditions must be visible in the experiment:

- Privileged execution sufficient for the selected WSR/RSIL operations. This
  prefix is not a privilege-escalation mechanism or a user-mode recovery path.
- No asynchronous IRQ/NMI/debug exception during initial normalization or the
  workload. INTENABLE0 and a high level are not proof that all physical debug or
  nonmaskable sources are neutralized. Do not expand into debug-register setup.
- **PC-relative L32R mode.** Original entry itself uses L32R before the inspected
  initializer; neither inspected prefix writes LITBASE/SR5. The local overlay
  contains optional LITBEN/LITBADDR fields, but that does not establish HP support
  or license a new LITBASE write. Keep the appropriate inactive literal-base
  mode supplied rather than hide a QEMU default behind the startup claim.
- Incoming hardware-loop state must not redirect control before the prefix has
  disabled it. In particular do not claim arbitrary active LEND overlapping
  initial instructions is safely recoverable. A dirty-loop control can supply
  a nonintersecting LEND, then verify our own writes remove that state. All later
  execution occurs without another host register reset.
- Loaded instruction/data RAM and exclusive mutable spans already work with
  inherited mappings/cache attributes. No DMA writer or physical controller is
  modeled as concurrently accessing them. Leaving those attributes untouched is
  an explicit boundary, not evidence that startup discovered physical RAM.

## Memory envelope, not a physical memory-size claim

The raw ELF program headers independently give a main RWE PT_LOAD at10003000,
file offset560, file size1a640 and memory size321e0. It covers exactly
**[10003000,100351e0)**,205280 bytes. File-backed bytes end1001d640;
the NOBITS BSS is **[1001d640,100351e0)**,97184 bytes. Literal words10005ca8 and
10005cac independently contain those BSS endpoints. This is a useful
stock-declared candidate ownership envelope for an offline layout, not a proof
of SRAM/DRAM type, maximum RAM, cacheability or permissions after real loading.

Other PT_LOADs cover only the observed small vector/interface ranges at
10000000..10000184,10000200..1000023c,10000270..10000350,10000370..1000049c and
separate reset/debug ranges10100020..10100300,10100300..10100304,
10100320..1010032c. They do not authorize the gaps as free RAM. Preserve selected
anchor holes explicitly and carve the new stack/mailbox inside independently
justified spans. No fixed stack range follows from this audit. Footprint and
placement are the sibling layout review's responsibility.

## Exact source and extraction provenance

Repository-relative sources use the repository named in the parent task.
Static extracts are saved in
`/tmp/hp1020-entry-cpu-contract-evidence-20261003/`: bounded entry/CPU-prefix/tail
disassembly, original ELF layout, five exact byte blocks with28 checked anchors,
all11 PT_LOAD records and cited primary-tool excerpts. No generated report was
edited. Each raw block includes original file offset and its own SHA256.

| Input | SHA256 |
|---|---|
|`analysis/sihp1020.elf`|`2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`|
|`/tmp/hp1020-next-after-acquisition-review-20261003.md`|`9be28e8f51ea2602621ff8535ad3bccc95c4e9f9e120a3b0c05a53d2464709a7`|
|`analysis/startup-chain-report.md`|`a575f5bbc1d5e9bae80dc756acc926de843b29050a9c31a35821f4c39cc02df7`|
|`analysis/boot-handoff/boot-handoff.md`|`dbe02fff65dc6707260ed1ef525f18e493720311a6bab07374b2d5cefa8cf5f2`|
|`scripts/build-xtensa-binutils-manual.sh`|`d693c3324793fa1e4fc25aaefdf38e51361b8821aaf7c89033241770f481290d`|
|`scripts/build-xtensa-gcc-manual.sh`|`402344bb7b9b4b9a0e585ac5a38e712c85d927653f43fe1bbae06dcd0ea395c9`|
|`scripts/hp1020_qemu_ram.py`|`8fe170ab6161d47d17ef93eb6c25622878e00dc2d4747cfd70073a0fd777b5e2`|
|`analysis/toolchain-probe/c-compiler-profile.md`|`9ef6a21b4f210cf85dcd56a99fe1060dc8ebcb7478980836a5d12e58a1b3f05e`|
|`open-firmware/minimal-idle/idle.S`|`99c76eb2e4a0b11939b372f3b6d88e5c2059f0234afc4431c25a52c419f9ed4b`|
|`open-firmware/minimal-idle/hp1020-idle.ld`|`c41373794e0316eafba1edb907083daef7d0bcf8d1f4809b8a15d9a378b12587`|
|`/tmp/hp1020-binutils-manual-src-20261003/bfd/xtensa-modules.c`|`c9899233c5d134ad55329b57e05809b328c4a86b7455b5cbe5a56dd7ac07d29c`|
|same source tree `gdb/xtensa-tdep.c`|`d0e1ef306eae6130e0e7b69646d3484db1d6bb5e7fe6f09f91c731b495b256da`|
|same source tree `gdb/xtensa-config.c`|`5aec57601258feb68e8c1f6971f249598d1ab3fbfbc34f463a79ad85e1384552`|
|same source tree `include/xtensa-config.h`|`f874c028f3332cc8d96508a779cc971c332aff99a44d067f50deeaef1000ffae`|
|`/tmp/gcc-14.3.0/gcc/config/xtensa/xtensa.h`|`0c3174733fd5f92baa6461111f4591c821ee66278e23cb2d728ca68f6d02216f`|
|`/tmp/hp1020-xtensa-manual-systemz/bin/xtensa-fsf-elf-objdump`|`4f6eb03d39b8fbf415db6563aecdee46aebafe000ad56f978d7c73cb3a1b98c9`|
|same prefix `xtensa-fsf-elf-readelf`|`8754a9b059c9044fd62fb8ddfe4bf9ae5d7693dbe5bebf5812b0a178d2649089`|

No part of this evidence proves actual loader entry, cold boot, physical memory
attributes, interrupt safety, USB success or printing. It supports the narrower
new-entry/continuous-C experiment under the stated initial conditions.
