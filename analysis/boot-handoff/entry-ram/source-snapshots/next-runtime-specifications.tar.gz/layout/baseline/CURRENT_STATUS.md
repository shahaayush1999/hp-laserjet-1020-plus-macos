# Current handoff

Updated: 2026-10-03. **The open firmware replacement cannot print yet.** Continue
autonomously until the owner asks to yield. No USB contact/enumeration, upload,
print-driving hardware or installed-printing changes. AGENTS.md owns scope;
`analysis/README.md` is the evidence/tool-recovery map.

## Completed checkpoint

Retained-OUT acquisition passed **32 sanitized host/32 audited QEMU cases**,
3372 paired event rows and384 paired raw captures. The independently frozen V2
gate passed unchanged in report-only/raw modes; all16 copied-evidence controls
passed. Full sequential `scripts/validate.sh` retry passed **131 consistency
checks and both offline suites**. All eleven component host/target case arrays
and raw capture identities match their pre-run baselines. No production,
fixture, scenario or acquisition-checker correction followed execution.

The first full run completed execution but stopped at three legacy source counts:
OUT97→98, composed117→118, offload126→127, solely adding
`hp1020_udc_acquire.h`. Independent review supported that narrow shared-checker
correction; semantic/hash gates stayed intact. The stopped run remains separate
from the successful retry. No report hashes were edited by hand.

Acquisition verifies the original retained cookie and actual adapter owner,
requires descriptor/payload/acquire-order hooks, then copies actual CPU bytes.
Separate device images and poisoned CPU memory expose wrong sources and partial
visibility. Failures retain original identity; old settlement remains possible
while forward work is blocked. Cache/mapping/physical settlement remain supplied.
Target acquisition152 bytes, OUT80, publisher140, backend88, EP0296, SETUP96,
adapter/document128588. Publication's prior40/40 cases and ten controls remain
separate evidence; these component cases add no native or physical lifecycle.

Durable evidence: `analysis/usb-path/udc-acquire/source-snapshots/` contains first
execution, both stopped-run archives,16 controls, successful `full-suite-retry.*`
and unexecuted `next-entry-proposals.*`, each read back against its manifest.
Latest capture `/tmp/hp1020-udc-acquire-4q8orm5x`; full log
`/tmp/hp1020-full-acquisition-retry-20261003.log`, child `hp1020-validation.glwQ3y`.
The full retry and its validation processes have finished. The checkpoint is
committed/pushed as `78e9305`; main/origin sync was verified before entry work.

## In progress: one entry through a RAM document

Continue the integrated loader-entry-to-C experiment. Existing component tests
supply CPU/stack per call;
the next candidate must establish its own CPU state, stack and complete BSS,
process the existing small page continuously, and return to its own inert park.
Keep full production capacities; the new layout deliberately reuses HP private
runtime locations inside original ELF-declared spans. Loader compatibility,
actual RAM attributes and physical boot are unproved.

Root independently checked original byte/layout evidence. Assembly/linker, C
workload, compiler-layout witness, independent literal oracle and concrete/linked
audits are reviewed. **Six continuous interpreter/QEMU cases now pass, followed
by the unchanged independent capture gate.** Its first assembly stop (symbolic CALL0 relaxation),
second link stop (nonalloc libgcc DWARF) and third strict property-audit stop are
preserved under `analysis/boot-handoff/entry-ram/source-snapshots/`. Local
no-transform around CALL0/park and five explicit nonalloc metadata sections fix
the first two. The unchanged linked ELF passes13 loads/18 allocations, exact
instruction bytes and narrowly source-backed nonexecuted padding/annotation
handling. `first-linked-audit-pass.*` preserves the fourth audit-only capture
`/tmp/hp1020-entry-ram-kne0h7xl`; no execution is credited to that pass.
`next-entry-proposals.*` preserves their exact state, root runner V1/V2, QEMU
adapter V1 and reviews. A stopped debugger-description probe ran no instructions;
official QEMU11.1.1 sources establish INTENABLE110 (not the binutils map's83).
QEMU V2 cleanup/metadata corrections are integrated and independently reviewed;
the independent capture-only gate passed after peer review's one pre-execution
disassembly-seal correction. `first-six-continuous-cases.*` preserves the exact
tested70-source capture `/tmp/hp1020-entry-ram-ssc7nafg`,30 paired checkpoints and
12 actual QEMU park steps. All cases clear129224 BSS bytes, decode the literal
32-byte page, deliver the original document event before finish and return to
their own park. Concrete minimum SP uses720 bytes; static review's bound is784.
The784-byte bound is static and specific to this workload, within its8KiB stack.

Working paths: `/tmp/hp1020-entry-integration-20261003/`,
`/tmp/hp1020-entry-{startup,workload,layout-witness}-draft-20261003/`,
`/tmp/hp1020-entry-audit-v2-20261003/`,
`/tmp/hp1020-entry-qemu-adapter-v2-20261003/`. The detailed next-evidence section
owns the contract. Copied-evidence and bounded interpreter controls are being
drafted. New durable-capture publication/shared-suite edits followed the first
pass and are **not yet executed**. Publication review is complete; the full sequential suite is running
(log `/tmp/hp1020-full-entry-20261003.log`, child `hp1020-validation.UTdequ`).
The34 corruption and30 guard-control drafts await root execution afterward. Preserve first failures before repairs. Final
PASS/pixels cannot substitute for pre-C zeroing, pre-finish event/state, full
memory/stack captures or uninterrupted execution/host-command records.
Root owns sequential execution; agents stay static.

Pinned binutils/GCC were recovered with unchanged gates; disposable headers,
libgcc and subordinate tools can vanish independently. Use recovery scripts in
the map. Boot/IRQ producers, real cache/mapping/settlement, engine behavior,
physical status/printing and power-cycle recovery remain unproved. Retain the
separate26 empty-document lifecycles, six conditional null reads,28 retirement,
36 native pages with supplied completion and42 fragment/bypass cases. Do not
repeat resolved cancellation/END_DOC or original IRQ/SETUP investigations.

## Installed Mac driver (separate, preserve)

Apple's renderer, unchanged foo2zjs and a per-job CUPS backend provide the working
HP-based setup. CUPS owns copies/queueing/job lifetime. README owns clone/install/
uninstall; MANIFEST owns validation/recovery. No app/package, ZIP or Homebrew
runtime is required. Do not restore the obsolete daemon/runtime.

Support checks passed35 printing,14 setup, three sandbox and five actual macOS
scheduler cases with simulated transport. Installed signatures/ownership/bytes
matched and the queue was empty/idle; actual copies/status/recovery and fresh-Mac
installation remain unverified. `assets/macos-system-validation.json` and
`/private/tmp/hp1020-system-install-20260928-2/` hold evidence; root-only backup is
`/private/tmp/hp1020-native-migration-backup-20260928/`. System checks require
separate authorization. No physical print occurred here.
