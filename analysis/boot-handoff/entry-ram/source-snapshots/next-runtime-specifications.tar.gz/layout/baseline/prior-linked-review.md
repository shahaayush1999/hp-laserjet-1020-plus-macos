# First linked entry ELF: emitted properties and stack review

Status: static review of the third build, not target execution. No candidate,
audit module, validator or simulator was imported or executed. Only ordinary
file reads, independent stdlib ELF/metadata extraction and the pinned corrected
objdump were used. Root retains all execution and integration authority.

The inspected capture is `/tmp/hp1020-entry-ram-26izpj9h`. ELF SHA256:
`7e0cc607f02f3b28a6b585c5e689cea6d880621b80f07a06bd1ceff5edbdb11b`.
Map SHA256:
`ed29b365997fe9d44191126fcf6cb4c721e3cfddfd6caa2ac78c6aaaf7a5d2f8`.
The complete original paths, snapshot paths and hashes are in `INPUTS.json`.

## Layout and classification observations

The actual ELF contains exactly the intended 13 PT_LOADs and 18 nonempty
allocated sections. `.text` is 15,236 bytes and `.rodata` is 1,622, totaling
16,858 of the 24,576-byte code/input budget (7,718 bytes spare). State, memory,
mailbox, initialized data, entry islands and owned 8KiB stack retain their
specified locations and capacities. No actual PT_LOAD memory tail crosses a
protected gap. The stack's NOBITS section has alignment metadata 1, while its
actual start/end are 16-byte aligned and its WA flags and 8KiB extent match.
This needs no relaxed address or flag rule.

The five retained libgcc DWARF sections are nonallocated metadata (453 bytes
in total). `.debug_str` additionally has merge/string flags; it has no
write/allocate/execute flag. The current narrow metadata-name rule already
handles this without runtime permission changes.

The 1,079 modern properties include four emitted forms absent from the first
strict audit. `emitted-properties-evidence.json` records every affected byte:

* 84 nonempty kind-zero records, all flags `8`, total 116 bytes, each 1–3 zero
  bytes in `.text`. GAS's `RELAX_UNREACHABLE` fragment marks unreachable but
  not INSN or DATA. These are non-executable padding.
* One mixed DATA|INSN kind-six record: address `0x10007078`, length 6,
  flags `0x2906`, bytes `5000d563fffc`. This is the explicitly no-transform
  direct CALL0 to own C followed immediately by the self-park. GAS sets DATA
  for the no-transform fragment before adding INSN. No other DATA should be
  decoded as instructions.
* 67 otherwise unclassified linker-fill gaps, total 126 bytes. Each is exactly
  1–3 zero bytes ending at the next 4-byte boundary, with a preceding INSN
  property ending there, a zero-size UNREACHABLE marker at its start, a
  zero-size `0x2804` alignment marker at its end, and an exact saved-map
  `*fill*` entry. These remain non-executable; accepting arbitrary zero bytes
  or a map label alone would be too broad.
* Four unannotated bytes `44495630` (ASCII DIV0) at `__udivsi3+0x44`
  (`0x1000ab7c`), immediately after the exact excluded ILL at +0x41. Pinned
  libgcc source emits this exception diagnostic. It is neither an instruction
  nor a literal used by ordinary code, and must not become executable.

The separate unexecuted V3 proposal at
`/tmp/hp1020-entry-audit-emitted-v3-20261003/` implements only these forms.
Module hash `2f990f9f57731c49d8931138d32ce100fecd1d2fed722354f6c01117e52042eb`;
patch hash `55c8fcd82de342626821896952100e58ff3dde8c4854f594531d7c9e2033775b`.
It preserves original kind/flags and all prior runtime/layout/source gates.
The sibling map becomes a required hashed audit input. No audit success is
claimed before root runs it.

Pinned primary anchors: binutils commit
`0104f7d3c1a3e55954bf7b09fc70dd542b910714`,
`gas/config/tc-xtensa.c:7930–7961,12157–12176,12190–12212,12261–12326`, and
`include/elf/xtensa.h` property flags/alignment-size comment. GCC 14.3.0
`libgcc/config/xtensa/lib1funcs.S:535–599`, especially 588–593 for ILL/DIV0.
Their full source bytes are snapshotted with hashes.

## Actual instruction and control closure

Disassembly was limited to the 174 merged INSN-flagged spans, including only
that exact mixed no-transform span. It produced 5,853 annotated instructions,
14,788 bytes, including the one three-byte ILL excluded by the audit. Whole
section disassembly is not used as instruction authority because it also
interprets literal/padding bytes.

All extracted instruction bytes agree with ELF bytes. All static direct
branches target annotated instruction boundaries; all 141 direct CALL0s
point to function starts. All 86 L32R destinations agree with independently
recomputed signed BE displacements. Modern 34 literal records and the 30
legacy records merge into identical literal spans. The opcode census contains
only the existing conservative call0 profile, the exact normalization prefix,
and the excluded ILL. No ENTRY, windowed call, hardware loop, cache/TLB or
custom instruction was found. These observations supplement, not replace,
root's strict audit and runtime access checks.

The 52 non-return indirect sites consist of 13 literal tail calls, four bounded
intra-function switch tables, nine callbacks initialized by this workload, and
26 unused encoder callback sites. The four switch tables have 6,15,7,8 entries;
all entries point inside their owning function at actual instruction boundaries.
Their bounds come from the preceding unsigned range checks, not from accepting
arbitrary rodata values as targets. `dynamic-context.txt` records the relevant
instruction context, and `call-frame-evidence.json` records exact targets.

## Nested stack bound for this workload

All 15 compiler `.su` files were read; every function uses a static frame.
The empty layout-witness `.su` is expected. The largest individual frame is
`chunk_in`, 256 bytes. The ELF/map include only `_udivsi3.o` from libgcc; its
actual annotated instructions use no a1, no calls and no memory accesses, so
it adds zero stack. The source `leaf_entry` macro is not mistaken for an
emitted frame: actual bytes are authoritative.

The source-bound graph rooted at `hp1020_entry_c` contains 61 functions and no
recursive path. Its conservative maximum sum of actual compiler frames is
784 bytes, leaving 7,408 bytes inside the owned 8KiB stack. The corresponding
lower SP bound is `0x10013cf0`, starting from `0x10014000`. The summed path is:

| Function | Frame bytes |
| --- | ---: |
| hp1020_entry_c | 80 |
| hp1020_usb_document_pump | 48 |
| hp1020_image_output_feed | 16 |
| hp1020_image_stream_feed | 0 |
| hp1020_semantic_feed | 48 |
| complete_chunk | 48 |
| chunk_in | 256 |
| hp1020_image_init | 96 |
| jbg85_dec_in | 64 |
| finish_sde | 32 |
| decode_pscd | 80 |
| arith_decode | 16 |

This is intentionally an overestimate, not an observed stack maximum. It
includes a decoder-data path under image initialization even though that call
supplies only the 20-byte BIH. Tail caller frames are conservatively added even
where the emitted epilogue restores them before JX. CALL0 itself allocates no
extra hardware stack frame. Every reachable a1 write was inspected: only
constant ADDI/ADDMI frame allocation/restoration, with exact negative
allocation and positive restores matching the `.su` size. No variable frame,
alloca, foreign stack, or hidden libgcc frame was found.

The nine callback sites bind to seven actual callbacks:
`band_out→consume`, `complete_chunk→chunk_in`,
`document_out→entry_document`, `boundary_out→boundary`,
`progress→entry_output`, `boundary→document_out`, and the three
`decode_pscd→row_out` sites. The initializers in the frozen document/output/
stream/image sources set these pointers; the entry callbacks do not call back
into the parser or decoder. The remaining 26 encoder callback sites are
present in the whole linked closure but unreachable from this workload's
initializers and call graph. They are not part of the 784-byte claim.

Runtime still must verify actual a1 bounds, dynamic instruction targets,
phase-specific writable spans, sentinel/gap preservation and final return to
own park. This static bound is specific to the fixed program, callback bindings
and correctly initialized state. It is not an arbitrary corruption bound,
physical-RAM proof, exception stack budget, or hardware loader compatibility
claim. No asynchronous/debug exception or IRQ stack is included or admitted.

## Review artifacts and extraction limits

`extract.py` reads the ELF and invokes only corrected objdump on INSN spans.
`property-review.py` reads ELF/map metadata and exact bytes.
`call-frame-review.py` builds the static call graph from saved decoded bytes,
ELF symbols, compiler frames and the explicit source-bound callback mapping.
None imports the candidate/audit or runs target code. The first call-graph
extraction stopped on the intentionally overlapping normalize/park function
symbols; its source is retained as `call-frame-review-v1-overlapping-symbol-stop.py`.
The corrected extractor chooses the smaller containing named function. This
was a review-tool metadata issue, not a target execution failure.

No additional layout/property mismatch was found after accounting for the four
forms above. Root must still run the corrected audit before any execution;
this read-through does not manufacture that result.
