"""Seal an existing entry experiment capture without rerunning any target."""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import tarfile

ap=argparse.ArgumentParser()
ap.add_argument('capture',type=Path);ap.add_argument('label');ap.add_argument('--log',type=Path,required=True)
args=ap.parse_args();assert args.label.replace('-','').isalnum()
ROOT=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
report=json.loads((args.capture/'validation.json').read_bytes())
assert report['status'] in ('fail','audit-only-pass','pass')
for name,wanted in report['source_sha256'].items():
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert sha((args.capture/'source'/name).read_bytes())==wanted
files={str(p.relative_to(args.capture)):p for p in args.capture.rglob('*') if p.is_file()}
files.update({'outer-run.log':args.log,'archive-capture.py':Path(__file__)})
assert all(not p.is_symlink() for p in files.values())
raw={n:p.read_bytes() for n,p in files.items()}
buf=io.BytesIO()
with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0) as gz:
    with tarfile.open(fileobj=gz,mode='w') as tf:
        for name,data in sorted(raw.items()):
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
            tf.addfile(info,io.BytesIO(data))
payload=buf.getvalue()
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tf:
    assert set(tf.getnames())==set(raw)
    for name,data in raw.items():assert tf.extractfile(name).read()==data
out=ROOT/'analysis/boot-handoff/entry-ram/source-snapshots';out.mkdir(parents=True,exist_ok=True)
meta=dict(status=report['status'],source_files=len(report['source_sha256']),
    archive_sha256=sha(payload),archive_bytes=len(payload),members=len(raw),
    preserved_report_sha256=sha(raw['validation.json']),
    scope='Preserved exact recorded outcome; archive does not promote a failure/audit to execution success.',
    member_sha256={n:sha(data) for n,data in sorted(raw.items())})
for suffix,data in (('.tar.gz',payload),('.json',(json.dumps(meta,indent=2)+'\n').encode())):
    p=out/(args.label+suffix);assert not p.exists();p.write_bytes(data)
print(json.dumps({k:v for k,v in meta.items() if k!='member_sha256'},indent=2))
