"""Root-owned isolated guards; invoke only after the sequential full suite."""
from pathlib import Path
import hashlib,importlib.util,json,sys

root=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
sys.path.insert(0,str(root/'scripts'))
capture=Path('/tmp/hp1020-entry-ram-ssc7nafg')
destination=Path('/tmp/hp1020-entry-guard-controls-retry-20261003')
source=Path('/tmp/hp1020-entry-guard-controls-draft-20261003/hp1020_entry_guard_controls.py')
assert hashlib.sha256(source.read_bytes()).hexdigest()=='7fe9bea14b742f7a6027178acc1116e7f3663c5a253452e324b38bdbe7f5f776'
from hp1020_entry_audit import audit_target
positive=json.loads((capture/'validation.json').read_text())
target=root/'analysis/boot-handoff/entry-ram/target'
assert {str(p.relative_to(target)):hashlib.sha256(p.read_bytes()).hexdigest()
 for p in target.rglob('*') if p.is_file()}==positive['target_sha256'], 'live target must match every preserved positive target byte'
# Use the original canonical filename: objdump includes it in the exact saved
# listing. The byte seal above prevents adopting a different rebuilt target.
program,audit=audit_target(target/'entry-ram.elf',
 '/tmp/hp1020-xtensa-manual-systemz/bin/xtensa-fsf-elf',root/'analysis/sihp1020.elf')
assert json.loads(json.dumps(audit))==json.loads((capture/'linked-audit.json').read_text()),'fresh strict audit differs from saved positive audit'
folder=capture/'cases/00-ordinary-privilege-a5/model'
snapshot=json.loads((folder/'initial/snapshot.json').read_text())
regions=[]
for row in snapshot['regions']:
 raw=(folder/row['path']).read_bytes()
 assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
 regions.append((row['start'],raw))
spec=importlib.util.spec_from_file_location('entry_isolated_guards',source)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
result=module.run_guard_controls(program,audit,regions,destination)
assert result['input_regions']==[dict(start=row['start'],bytes=row['bytes'],sha256=row['sha256'])
 for row in snapshot['regions']], 'guard inputs must bind the validated initial snapshot'
(destination/'positive-initial-snapshot.json').write_bytes((folder/'initial/snapshot.json').read_bytes())
(destination/'positive-report-sha256.txt').write_text(
 hashlib.sha256((capture/'validation.json').read_bytes()).hexdigest()+'\n')
(destination/'root-runner.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({k:v for k,v in result.items() if k not in ('cases','input_regions')},indent=2))
assert result['status']=='pass'
