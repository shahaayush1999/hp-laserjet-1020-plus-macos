"""Deduplicate preserved copied controls without dropping reconstructable bytes."""
from pathlib import Path
import hashlib,json,shutil

source=Path('/tmp/hp1020-entry-negative-controls-20261003')
output=Path('/tmp/hp1020-entry-negative-controls-archive-20261003')
assert not output.exists();output.mkdir()
sha=lambda value:hashlib.sha256(value).hexdigest()
def members(folder):
    return {str(p.relative_to(folder)):sha(p.read_bytes())
            for p in folder.rglob('*') if p.is_file()}
baseline=source/'baseline-capture'
baseline_members=members(baseline)
assert baseline_members==json.loads((source/'original-members.json').read_text())
shutil.copytree(baseline,output/'baseline-capture')
for p in source.iterdir():
    if p.is_file():shutil.copyfile(p,output/p.name)
summary=json.loads((source/'negative-controls.json').read_text())
assert summary['status']=='pass' and summary['count']==34
rows=[]
for row in summary['controls']:
    # Each folder has a result and its original complete changed capture.
    matches=[p for p in source.iterdir() if p.is_dir() and (p/'result.json').is_file()
             and json.loads((p/'result.json').read_text())==row]
    assert len(matches)==1
    folder=matches[0];destination=output/folder.name;destination.mkdir()
    actual=members(folder/'capture')
    assert set(actual)==set(baseline_members)
    changed={name:value for name,value in actual.items() if value!=baseline_members[name]}
    assert set(changed)==set(row['changed_members'])
    for name,value in changed.items():
        detail=row['changed_members'][name]
        assert detail['original_sha256']==baseline_members[name]
        assert detail['modified_sha256']==value
        target=destination/'overlay'/name;target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(folder/'capture'/name,target)
        assert sha(target.read_bytes())==value
    for p in folder.rglob('*'):
        relative=p.relative_to(folder)
        if p.is_file() and relative.parts[0]!='capture':
            target=destination/relative;target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(p,target)
    # Reconstruct the complete member identity map, not just changed files.
    reconstructed=dict(baseline_members);reconstructed.update(changed)
    assert reconstructed==actual
    rows.append(dict(control=folder.name,changed_members=changed,
                     reconstructed_full_member_sha256=actual))
assert members(output/'baseline-capture')==baseline_members
assert members(baseline)==baseline_members
(output/'reconstruction.json').write_text(json.dumps(dict(status='pass',
    scope='Each copied capture is baseline-capture with the corresponding overlay applied; all complete reconstructed member identities equal the original altered capture.',
    controls=rows),indent=2)+'\n')
(output/'stage.py').write_bytes(Path(__file__).read_bytes())
print('34 exact changed captures reconstruct from one unchanged baseline and byte-for-byte overlays.')
