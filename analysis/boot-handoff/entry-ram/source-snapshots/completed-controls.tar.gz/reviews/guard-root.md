# Root review before isolated entry guards

Read the complete frozen30-control module, its README and independent review.
Guard source SHA256 `7fe9bea14b742f7a6027178acc1116e7f3663c5a253452e324b38bdbe7f5f776`.
No blocker found; exact base read/write/dispatch behavior and saved audited
permission shapes agree. No production interpreter edits are needed.

The root wrapper re-audits the preserved positive target and requires exact
equality with the saved strict audit. It reads and verifies the actual initial
snapshot's seven region hashes, passes detached bytes, then binds the guard
report's input hashes back to that snapshot and the original positive report.
The wrapper and input authority are retained with the guard output.

Pre-execution wrapper correction: objdump's exact listing contains the original
absolute target filename. Therefore re-audit the canonical target only after
every live target member hash equals the preserved positive target closure.
The complete audit can then match without normalizing or rewriting any report
hash. The earlier wrapper is preserved in pre-control-reviews; it never ran.

Only five original standard-ISA instructions are probed in isolated contexts;
the rest use explicit guard APIs. Exact pre-/post-effect distinctions are
retained, including a0 and trace changes before bad-SP rejection and one
deliberate modeled park write detected after its effect. No unsafe QEMU or
hardware instruction is executed. Run only after the current full suite ends.
