"""Three copied-byte literal controls; no target execution or original edits."""
from pathlib import Path
import copy, hashlib, importlib.util, json, os, shutil, tempfile

root=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
original=Path('/tmp/hp1020-entry-ram-ssc7nafg')
out=Path(tempfile.mkdtemp(prefix='hp1020-entry-literal-controls-',dir='/tmp'))
checker=root/'scripts/check-hp1020-entry-ram.py'
spec=importlib.util.spec_from_file_location('literal_control_gate',checker)
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
sha=lambda b:hashlib.sha256(b).hexdigest()
base=json.loads((original/'validation.json').read_text())
before={str(p.relative_to(original)):sha(p.read_bytes()) for p in original.rglob('*') if p.is_file()}

def atomic(p,raw):
 q=p.with_name(p.name+'.control-write');q.write_bytes(raw);q.replace(p)

def save(p,value):atomic(p,(json.dumps(value,indent=2,sort_keys=True)+'\n').encode())

rows=[]
for name,expected in (
 ('input-literal','independent exact input bytes'),
 ('linked-input-literal','actual linked const input'),
 ('linked-layout-word','independent literal target32 layout')):
 folder=out/name;shutil.copytree(original,folder,copy_function=os.link)
 report=copy.deepcopy(base)
 if name=='input-literal':
  p=folder/'input/small-black.zjs';data=bytearray(p.read_bytes());data[-1]^=1;atomic(p,data)
  provenance=json.loads((folder/'input/provenance.json').read_text())
  provenance['input_sha256']=sha(data);save(folder/'input/provenance.json',provenance)
  report['input']=provenance
 else:
  p=folder/'target/entry-ram.elf';data=bytearray(p.read_bytes());elf=gate.Elf(data)
  address=elf.symbol('hp1020_entry_input' if name=='linked-input-literal' else 'hp1020_entry_layout')
  section=next(s for s in elf.alloc.values() if s[3]<=address<s[3]+s[5])
  offset=section[4]+address-section[3]+(351 if name=='linked-input-literal' else 3)
  data[offset]^=1;atomic(p,data)
  report['target_sha256']['entry-ram.elf']=sha(data)
  audit=json.loads((folder/'linked-audit.json').read_text());audit['target_sha256']=sha(data)
  save(folder/'linked-audit.json',audit);report['linked_audit']=audit
 save(folder/'validation.json',report)
 ok,detail=gate.check_capture(folder)
 assert not ok and expected in detail['error'],(name,ok,detail)
 changed={}
 for rel,digest in before.items():
  p=folder/rel;raw=p.read_bytes()
  if sha(raw)!=digest:
   dest=out/'mutations'/name/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
   changed[rel]=dict(before_sha256=digest,after_sha256=sha(raw),bytes=len(raw))
 rows.append(dict(name=name,expected_rejection=expected,detail=detail,changed=changed))
 shutil.rmtree(folder)
 print(name+': rejected at intended independent literal check',flush=True)
assert before=={str(p.relative_to(original)):sha(p.read_bytes()) for p in original.rglob('*') if p.is_file()}
save(out/'controls.json',dict(status='pass',controls=rows,original_capture=str(original),
 original_report_sha256=sha((original/'validation.json').read_bytes()),checker_sha256=sha(checker.read_bytes()),
 original_bytes_unchanged=True,scope='Copied evidence corruption, never target execution; derived seals refreshed only in deliberate bad copies.'))
shutil.copy2(__file__,out/'runner.py')
print('Literal control evidence: '+str(out),flush=True)
