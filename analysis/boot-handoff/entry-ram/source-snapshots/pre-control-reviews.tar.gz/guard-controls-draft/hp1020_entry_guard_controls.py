"""UNEXECUTED interpreter guard probes; no candidate lifecycle or QEMU run.

Root supplies the unchanged strictly audited Program, its audit and a detached
validated initial region image. Every probe starts with a fresh EntryMachine.
Phase/call/park contexts are explicit isolated test fixtures, never claimed as
executed startup checkpoints. No target bytes or instruction map is mutated.
The only Machine.run calls have a one-instruction budget and use original
S32I.N, CALL0 or the original unexpected self-J bytes. No hardware is present.
"""
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path
import struct
import sys
import traceback

from hp1020_entry_machine import EntryMachine

TARGET_SHA256 = '7e0cc607f02f3b28a6b585c5e689cea6d880621b80f07a06bd1ceff5edbdb11b'
AUDIT_SHA256 = '2f990f9f57731c49d8931138d32ce100fecd1d2fed722354f6c01117e52042eb'
MACHINE_SHA256 = '46cc66fc2ac1c22201ef6a33ee13eba4a54087bb416ccc1b8726aae2d2c98b07'
BASE_SHA256 = 'ed2924d8e46c0e553fe079a5ecdfff77dc40f1aa228588d9a86c39ce98769480'
ENTRY, STORE, CALL, C_ENTRY, PARK, UNEXPECTED = (
    0x100167a8, 0x10007056, 0x10007078, 0x100073d0, 0x1000707b, 0x10007080)
STATE, MEMORY, MAILBOX, STACK = ((0x1000e000,13496), (0x10016800,114704),
                                (0x10014040,1024), (0x10012000,8192))
ZERO = (STATE,MEMORY,MAILBOX)
WRITABLE = ZERO + (STACK,)
TOP = STACK[0]+STACK[1]
CHECKPOINTS = [('after-normalization',0x10007050), ('pre-c',CALL),
               ('pre-finish',0x10009468), ('park',PARK)]
ORDER = [name for name,address in CHECKPOINTS]
ENVELOPES = ((0x10003000,0x321e0), (0x10000000,0x184), (0x10000200,0x3c),
             (0x10000270,0xe0), (0x10000370,0x12c), (0x10100020,0x2e4),
             (0x10100320,0xc))
EMPTY_SHA256 = hashlib.sha256(b'').hexdigest()
INITIAL = dict(pc=ENTRY, ps=0, intenable=0, windowbase=0, windowstart=1,
               sar=0, lbeg=0, lend=0, lcount=0,
               physical_ar=[0x8a000001+i*0x10101 for i in range(32)])


def need(value,message):
    if not value:raise ValueError(message)


def sha(raw):return hashlib.sha256(raw).hexdigest()


def save_json(path,value):
    Path(path).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')


def program_fingerprint(program):
    # Immutable instruction/permission authority must not become a fault injector.
    value=dict(symbols=program.symbols, entry=program.entry,
        instructions=[[pc,op,list(args),raw.hex()]
                      for pc,(op,args,raw) in sorted(program.instructions.items())],
        reads=program.entry_read_spans,writes=program.write_ranges,
        executes=program.execute_ranges,annotations=program.annotated_code)
    return sha(json.dumps(value,sort_keys=True,separators=(',',':')).encode())


def snapshot(machine,observations):
    """Complete modeled semantic state plus every byte of the backing images.

    File descriptors/compressor internals are resources rather than modeled
    state. Exact decompressed trace bytes are checked separately after close.
    """
    return dict(
        regions=[dict(start=a,flags=flags,raw=bytes(raw)) for a,raw,flags in machine.segments],
        initial_regions=[dict(start=a,raw=bytes(raw)) for a,raw in machine.initial_regions],
        cpu=machine.registers_at(machine.pc), physical_shadow=machine.physical.copy(),
        active_windowbase=machine.windowbase,pending_windowbase=machine.pending_windowbase,
        steps=machine.steps, visited=sorted(machine.visited), opcodes=sorted(machine.opcodes),
        branch_taken_present=hasattr(machine,'branch_taken'),
        branch_taken=getattr(machine,'branch_taken',None),
        normalized=machine.normalized,c_started=machine.c_started,
        read_spans=list(machine.read_spans),write_ranges=list(machine.write_ranges),
        allowed_write_spans=list(machine.allowed_write_spans),
        checkpoints=deepcopy(machine.checkpoints),checkpoint_order=list(machine.checkpoint_order),
        seen=list(machine.seen), minimum_sp=machine.minimum_sp,
        minimum_stack_access=machine.minimum_stack_access,
        calls=deepcopy(machine.calls), call_stack=deepcopy(machine.call_stack),
        special_writes=deepcopy(machine.special_writes), park_steps=machine.park_steps,
        park_registers=deepcopy(machine.park_registers),
        park_effect_counts=deepcopy(machine.park_effect_counts),
        access_count=machine.access_count.copy(), access_widths=machine.access_widths.copy(),
        access_digest=machine.access_digest.hexdigest(),step_digest=machine.step_digest.hexdigest(),
        observations=deepcopy(observations),closed=machine.closed)


def equal(actual,expected,reason):
    different=[key for key in expected if actual.get(key)!=expected[key]]
    extra=sorted(set(actual)-set(expected))
    need(not different and not extra,reason+': changed fields '+repr(different+extra))


def image_bytes(regions,address,count):
    for row in regions:
        if row['start']<=address and address+count<=row['start']+len(row['raw']):
            off=address-row['start'];return row['raw'][off:off+count]
    raise ValueError('guard fixture image lacks requested backed span')


def change_byte(state,address,value):
    for row in state['regions']:
        if row['start']<=address<row['start']+len(row['raw']):
            off=address-row['start'];raw=row['raw'];row['raw']=raw[:off]+bytes([value])+raw[off+1:];return
    raise ValueError('expected write lacks fixture backing')


def seed_phase(machine,phase):
    """Explicit isolated predicate contexts, not executed/accepted checkpoints."""
    if phase=='initial':return
    machine.normalized=True
    machine.special=dict(lbeg=0,lend=0,lcount=0,windowbase=0,windowstart=1,intenable=0,ps=15)
    machine.windowbase=0;machine.pending_windowbase=None;machine.sar=0
    machine.registers[1]=TOP
    machine.pc=STORE
    machine.seen=['after-normalization']
    machine.allowed_write_spans=ZERO
    if phase=='clear':return
    if phase=='pre-c':
        machine.pc=CALL;machine.seen=ORDER[:2];return
    need(phase in ('c','after-c','park'),'unknown isolated phase')
    machine.c_started=True;machine.allowed_write_spans=WRITABLE
    machine.seen=ORDER[:2]
    if phase=='c':return
    machine.seen=ORDER[:3]
    if phase=='after-c':return
    machine.pc=PARK;machine.seen=ORDER.copy()
    machine.park_registers=machine.registers_at(PARK)
    machine.park_effect_counts=(machine.access_count.copy(),len(machine.calls))


class Probe:
    def __init__(self,program,regions,folder,name,phase):
        self.folder=folder/name;self.folder.mkdir()
        self.name=name;self.phase=phase;self.observations=[]
        self.expected_access=b'';self.expected_steps=b'';self.snapshots=[];self.rejections=[]
        self.result=dict(name=name,status='fail',phase=phase,scope='isolated interpreter guard probe')
        def observe(label,regs,memory):
            self.observations.append(dict(label=label,registers=deepcopy(regs),
                regions=[[a,len(raw),sha(raw)] for a,raw in memory]))
        self.machine=EntryMachine(program,[(a,bytes(raw)) for a,raw in regions],
            deepcopy(INITIAL),CHECKPOINTS,self.folder/'traces',observe)
        seed_phase(self.machine,phase)

    def capture(self,label):
        state=snapshot(self.machine,self.observations)
        dest=self.folder/label;dest.mkdir()
        persisted=deepcopy(state)
        for group in ('regions','initial_regions'):
            persisted[group]=[]
            for row in state[group]:
                name=f'{group}-{row["start"]:08x}-{len(row["raw"]):08x}.bin'
                (dest/name).write_bytes(row['raw'])
                saved={key:value for key,value in row.items() if key!='raw'}
                saved.update(bytes=len(row['raw']),path=name,sha256=sha(row['raw']))
                persisted[group].append(saved)
        save_json(dest/'state.json',persisted)
        self.snapshots.append(dict(label=label,path=label+'/state.json',
            sha256=sha((dest/'state.json').read_bytes())))
        return state

    def rejected(self,action,reason):
        try:action()
        except ValueError as error:
            need(str(error)==reason,f'{self.name}: wrong rejection {str(error)!r}, expected {reason!r}')
            self.rejections.append(dict(type='ValueError',reason=str(error)))
            return
        raise ValueError(self.name+': expected rejection did not occur')

    def expected_step(self,state,pc):
        self.expected_steps+=struct.pack('>I',pc)
        state['step_digest']=sha(self.expected_steps)

    def expected_dispatch(self,state,pc,op):
        state['steps']+=1;state['visited']=sorted(set(state['visited'])|{pc})
        state['opcodes']=sorted(set(state['opcodes'])|{op})
        state['branch_taken_present']=True
        state['branch_taken']=op in ('call0','callx0','j','jx','ret','ret.n')

    def expected_access_record(self,state,kind,pc,address,size,value):
        self.expected_access+=struct.pack('>B3xIIII',1 if kind=='read' else 2,
                                         pc,address,size,value&0xffffffff)
        state['access_digest']=sha(self.expected_access)
        state['access_count'][kind]+=1;key=f'{kind}/{size}'
        state['access_widths'][key]=state['access_widths'].get(key,0)+1

    def finish(self):
        self.machine.close()
        access=gzip.decompress((self.folder/'traces/accesses.bin.gz').read_bytes())
        steps=gzip.decompress((self.folder/'traces/steps.bin.gz').read_bytes())
        need(access==self.expected_access,self.name+': access trace differs from independent expected records')
        need(steps==self.expected_steps,self.name+': step trace differs from independent expected records')
        self.result.update(status='pass',snapshots=self.snapshots,rejections=self.rejections,
            access_trace=dict(bytes=len(access),sha256=sha(access)),
            step_trace=dict(bytes=len(steps),sha256=sha(steps)))
        save_json(self.folder/'result.json',self.result)
        return self.result


def rejected_data(kind,address,size,phase='c'):
    def body(probe):
        machine=probe.machine;before=probe.capture('before')
        if kind=='write':
            reason=f'forbidden phase store {address:#x}+{size} at{machine.pc:#x}'
            action=lambda:machine.write(address,size,0xa55aa55a)
        else:
            reason=f'forbidden data read {address:#x}+{size} at{machine.pc:#x}'
            action=lambda:machine.read(address,size)
        probe.rejected(action,reason)
        after=probe.capture('after-rejection')
        equal(after,before,'rejected data access must precede every modeled effect')
        probe.result['rejection_timing']='before RAM/register/access/call/step change'
    return phase,body


def misaligned_data(kind):
    def body(probe):
        machine=probe.machine;address=STATE[0]+1;before=probe.capture('before')
        action=(lambda:machine.write(address,4,0xa55aa55a)) if kind=='write' else (lambda:machine.read(address,4))
        reason='unaligned store' if kind=='write' else f'unaligned load {address:#x}/4'
        probe.rejected(action,reason)
        equal(probe.capture('after-rejection'),before,'misalignment must reject before access')
        probe.result['rejection_timing']='before RAM/register/access/call/step change'
    return 'c',body


def pre_c_stack_read(probe):
    machine=probe.machine;before=probe.capture('before')
    probe.rejected(lambda:machine.read(STACK[0],4),'stack read before C CALL0')
    equal(probe.capture('after-rejection'),before,'pre-C stack read changed state')
    probe.result['rejection_timing']='before RAM/register/access/call/step change'


def original_store_to_guard(probe):
    machine=probe.machine;machine.pc=STORE;machine.registers[2]=0x1000d000
    machine.registers[4]=0x31527394
    before=probe.capture('before')
    probe.rejected(lambda:machine.run(budget=1),
        f'forbidden phase store 0x1000d000+4 at{STORE:#x}')
    expected=deepcopy(before);probe.expected_dispatch(expected,STORE,'s32i.n')
    equal(probe.capture('after-rejection'),expected,'original store rejection prefix differs')
    probe.result['rejection_timing']='after dispatch bookkeeping, before store/access log or after-instruction hook'
    probe.result['modeled_prefix']=['steps+1','visited/opcode recorded','branch_taken=false']


def bad_call_sp(sp):
    def body(probe):
        machine=probe.machine;machine.registers[1]=sp
        before=probe.capture('before')
        probe.rejected(lambda:machine.run(budget=1),'call SP outside owned aligned stack')
        expected=deepcopy(before);probe.expected_dispatch(expected,CALL,'call0')
        # The base model performs CALL0's a0 write before EntryMachine checks SP.
        expected['cpu']['logical_ar'][0]=PARK
        expected['cpu']['physical_ar'][0]=PARK
        probe.expected_step(expected,CALL)
        equal(probe.capture('after-rejection'),expected,'bad-SP CALL0 rejection prefix differs')
        probe.result['rejection_timing']='after modeled CALL0 a0/dispatch/step trace, before call ledger or C admission'
        probe.result['modeled_prefix']=['a0=original call return PC','steps+1','visited/opcode recorded',
                                        'branch_taken=true','one step trace record']
    return 'pre-c',body


def unexpected_park(probe):
    machine=probe.machine;machine.pc=UNEXPECTED
    before=probe.capture('before')
    # This genuine self-J may run forever; bounded execution/closure, rather
    # than a fabricated immediate target fault, rejects it as success.
    probe.rejected(lambda:machine.run(budget=1),'instruction budget exhausted')
    expected=deepcopy(before);probe.expected_dispatch(expected,UNEXPECTED,'j')
    probe.expected_step(expected,UNEXPECTED)
    middle=probe.capture('after-one-unexpected-self-jump')
    equal(middle,expected,'unexpected park step must have no memory/access/call effect')
    probe.rejected(machine.evidence,'all checkpoints and two park iterations required')
    equal(probe.capture('after-closure-rejection'),middle,'wrong park closure changed state')
    probe.result['rejection_timing']='one real harmless self-J, then budget and success-evidence rejection'
    probe.result['limitation']='Unexpected park is not an immediate forbidden-instruction fault; it cannot produce success evidence.'


def wrong_park_next(probe):
    machine=probe.machine;before=probe.capture('before')
    # Inject only a wrong post-instruction successor into the guard method.
    # The original self-J bytes/instruction map remain unchanged and unexecuted.
    probe.rejected(lambda:machine.after_instruction(PARK,UNEXPECTED),
        'only terminal self-branch may execute after park')
    expected=deepcopy(before);probe.expected_step(expected,PARK)
    equal(probe.capture('after-rejection'),expected,'wrong terminal successor changed extra state')
    probe.result['rejection_timing']='post-instruction guard appends step trace before successor rejection'
    probe.result['injection']='Supplied wrong next_pc to guard only; no modified instruction or target execution.'


def park_write_detected_after_effect(probe):
    machine=probe.machine;before=probe.capture('before-effect')
    address=STATE[0];value=image_bytes(before['regions'],address,1)[0]^0xff
    machine.write(address,1,value)
    expected=deepcopy(before);change_byte(expected,address,value)
    probe.expected_access_record(expected,'write',PARK,address,1,value)
    middle=probe.capture('after-injected-effect')
    equal(middle,expected,'park effect fixture must be exactly one actual modeled byte write')
    probe.rejected(lambda:machine.after_instruction(PARK,PARK),
        'terminal park changed registers or performed an access/call')
    probe.expected_step(expected,PARK)
    equal(probe.capture('after-detection'),expected,'park detector changed or rolled back the injected effect')
    probe.result['rejection_timing']='detection after explicitly injected permitted-address write; no rollback/prevention claim'
    probe.result['injected_effect']=dict(address=address,bytes=1,before=value^0xff,after=value)
    probe.result['limitation']='Ordinary write() remains enabled for owned RAM at park. Actual audited self-J cannot write; after_instruction detects an injected prior access.'


def permitted_read(address,value):
    def body(probe):
        machine=probe.machine;before=probe.capture('before')
        result=machine.read(address,1)
        need(result==value,'read-only allocation literal byte differs')
        expected=deepcopy(before);probe.expected_access_record(expected,'read',machine.pc,address,1,value)
        equal(probe.capture('after-read'),expected,'permitted immutable read had extra effect')
        probe.result['scope']='permission control: immutable data/code bytes are readable, never writable'
        probe.result['read_value']=value
    return 'c',body


def run_guard_controls(program,audit,regions,capture_dir):
    """Run only on root's explicit invocation, after independent static review.

    capture_dir must be new. regions is a detached original initial full-image
    capture, not a successful final state. No program/region supplied object is
    modified. Returns a separate guard report, never a candidate pass report.
    """
    folder=Path(capture_dir);folder.mkdir(parents=True,exist_ok=False)
    results=[];report=dict(schema='hp1020-entry-interpreter-guards-v1',status='fail',
        scope='isolated negative interpreter guard probes plus two permitted reads; no lifecycle, QEMU or hardware proof',
        candidate_lifecycle_execution=False,isolated_original_instruction_probes=True,cases=results)
    try:
        target=Path(program.path).read_bytes()
        need(sha(target)==TARGET_SHA256==audit['target_sha256'],'exact reviewed target required')
        need(audit['audit_source_sha256']==AUDIT_SHA256,'exact strict audit revision required')
        machine_path=Path(sys.modules[EntryMachine.__module__].__file__)
        base_path=Path(sys.modules[EntryMachine.__bases__[0].__module__].__file__)
        need(sha(machine_path.read_bytes())==MACHINE_SHA256 and sha(base_path.read_bytes())==BASE_SHA256,
             'guard controls target exact frozen interpreter sources')
        need(program.entry==ENTRY and [list(x) for x in program.write_ranges]==audit['write_ranges'] and
             [list(x) for x in program.execute_ranges]==audit['execution_ranges'] and
             [list(x) for x in program.entry_read_spans]==audit['read_spans'],
             'unchanged audited program permissions')
        need(program.instructions[STORE]==('s32i.n',(4,2,0),bytes.fromhex('9420')) and
             program.instructions[CALL]==('call0',(C_ENTRY,),bytes.fromhex('5000d5')) and
             program.instructions[PARK]==('j',(PARK,),bytes.fromhex('63fffc')) and
             program.instructions[UNEXPECTED]==('j',(UNEXPECTED,),bytes.fromhex('63fffc')),
             'four exact original instruction anchors')
        need([(a,len(raw)) for a,raw in regions]==list(ENVELOPES),'exact seven initial backing images')
        origin=tuple((a,bytes(raw)) for a,raw in regions);fingerprint=program_fingerprint(program)
        report.update(target_sha256=sha(target),audit_source_sha256=AUDIT_SHA256,
            interpreter_sha256=MACHINE_SHA256,base_interpreter_sha256=BASE_SHA256,
            guard_source_sha256=sha(Path(__file__).read_bytes()),program_fingerprint=fingerprint,
            input_regions=[dict(start=a,bytes=len(raw),sha256=sha(raw)) for a,raw in origin])
        (folder/'target.elf').write_bytes(target);save_json(folder/'audit.json',audit)
        (folder/'guard-source.py').write_bytes(Path(__file__).read_bytes())
        (folder/'entry-machine-source.py').write_bytes(machine_path.read_bytes())
        (folder/'base-machine-source.py').write_bytes(base_path.read_bytes())
        cases=[]
        for label,address in (('named-guard',0x1000d000),('omitted-gap',0x10011500)):
            for kind in ('write','read'):cases.append((label+'-'+kind,*rejected_data(kind,address,1)))
        cases += [('initialized-data-write',*rejected_data('write',0x1000d020,1)),
                  ('entry-island-write',*rejected_data('write',ENTRY,1))]
        for label,(a,n) in (('state',STATE),('memory',MEMORY),('mailbox',MAILBOX),('stack',STACK)):
            for kind in ('write','read'):
                cases.append((label+'-one-beyond-'+kind,*rejected_data(kind,a+n,1)))
        for kind in ('write','read'):
            # Contains/full-width precedes alignment: the last two owned bytes
            # and first two guard bytes must be rejected without partial access.
            cases.append(('cross-owned-boundary-'+kind,*rejected_data(kind,STATE[0]+STATE[1]-2,4)))
            cases.append(('misaligned-in-owned-'+kind,*misaligned_data(kind)))
        cases += [('stack-read-before-c','clear',pre_c_stack_read),
                  ('stack-write-before-c',*rejected_data('write',STACK[0],4,'clear')),
                  ('store-before-normalization',*rejected_data('write',STATE[0],4,'initial')),
                  ('original-store-to-guard','clear',original_store_to_guard)]
        for label,sp in (('below',STACK[0]-16),('above',TOP+16),('misaligned',TOP-4)):
            cases.append(('original-call-sp-'+label,*bad_call_sp(sp)))
        cases += [('unexpected-park','after-c',unexpected_park),
                  ('wrong-terminal-successor','park',wrong_park_next),
                  ('terminal-write-detected-after-effect','park',park_write_detected_after_effect),
                  ('initialized-data-permitted-read',*permitted_read(0x1000d020,0x31)),
                  ('entry-island-permitted-read',*permitted_read(ENTRY,0x63))]
        need(len(cases)==30 and len({name for name,phase,body in cases})==30,'frozen thirty-control matrix')
        save_json(folder/'intended-cases.json',[dict(name=n,phase=p) for n,p,b in cases])
        for name,phase,body in cases:
            probe=None
            try:
                probe=Probe(program,origin,folder,name,phase)
                body(probe)
                need(program_fingerprint(program)==fingerprint,'probe changed immutable program authority')
                need(tuple((a,bytes(raw)) for a,raw in regions)==origin,'probe changed caller initial image')
                results.append(probe.finish())
                save_json(folder/'validation.partial.json',report)
            except BaseException as error:
                if probe is not None:
                    probe.result['status']='fail'
                    probe.result['error']=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
                    probe.capture('failure-state');probe.machine.close()
                    probe.result['snapshots']=probe.snapshots;probe.result['rejections']=probe.rejections
                    save_json(probe.folder/'result.json',probe.result)
                    results.append(probe.result)
                raise
        need(sum(bool(c['rejections']) for c in results)==28 and
             sum(not c['rejections'] for c in results)==2,'twenty-eight rejected controls and two permitted reads')
        report.update(status='pass',rejected_controls=28,permitted_read_controls=2,
            limits=['Phase contexts are supplied isolated fixtures; no startup/C lifecycle is executed.',
                    'Rejected direct data operations preserve complete RAM/CPU/access/call state.',
                    'Dispatch/CALL0 and post-instruction rejection prefixes are retained explicitly.',
                    'The park effect control detects an injected write after effect, without rollback.',
                    'No QEMU, MMIO, printer, hardware or physical-capacity claim.'])
        return report
    except BaseException as error:
        report['error']=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
        raise
    finally:
        save_json(folder/'validation.json',report)
