# Entry interpreter guard controls — unexecuted draft

This package is a narrow test of interpreter admission/detection predicates.
It does not add a startup/C lifecycle, does not change the production
interpreter, and has no QEMU, MMIO, printer or installed-printing operation.
The draft has not been imported, parsed, compiled or executed by its author.
Root owns independent review and any later sequential execution.

The frozen matrix has 28 rejected controls and two permitted-read controls.
Each creates a fresh `EntryMachine`, copies the validated initial seven backing
images, supplies a deliberately isolated phase context, and retains complete
before/after RAM and semantic state. Phase flags and call/park bookkeeping are
explicit test fixtures; they are not disguised as observed startup execution.
No instruction map or loaded target byte is edited. There are only five
one-instruction `Machine.run` probes, using the audited original bytes:

- One original S32I.N at 10007056, `9420`, with its address register redirected
  to a guard. This stops before the store/access hook.
- Three original CALL0s at 10007078, `5000d5`, with bad SP values. Each stops in
  the post-instruction call guard before C executes or a call ledger is added.
- One original unexpected self-J at 10007080, `63fffc`. One harmless step
  reaches its own PC again; the instruction budget and evidence closure reject
  that state as success.

The original terminal J at1000707b remains `63fffc`; two other probes exercise
its post-instruction guard directly without changing or executing its bytes.

## Integration

`hp1020_entry_guard_controls.py` exports:

```python
run_guard_controls(program, audit, regions, capture_dir) -> report
```

`program` and `audit` must be the actual result of the strict V3 entry audit;
`regions` is a detached initial full-image capture from the validated positive
case, in the original main-then-six-islands order. It must not be a final-state
image. `capture_dir` must be new. The module requires the exact previously
reviewed ELF, audit and interpreter hashes before constructing a machine:

- ELF: `7e0cc607f02f3b28a6b585c5e689cea6d880621b80f07a06bd1ceff5edbdb11b`
- Audit: `2f990f9f57731c49d8931138d32ce100fecd1d2fed722354f6c01117e52042eb`
- EntryMachine: `46cc66fc2ac1c22201ef6a33ee13eba4a54087bb416ccc1b8726aae2d2c98b07`
- Base Machine: `ed2924d8e46c0e553fe079a5ecdfff77dc40f1aa228588d9a86c39ce98769480`

The root's existing import environment must make the frozen interpreter modules
available. No runner/builder or independent checker is invoked by this module.
It writes only its own new capture directory, never a positive report or target.
The captured report explicitly says `candidate_lifecycle_execution=false`,
while acknowledging isolated original-instruction probes.

The module seals the full instruction/symbol/permission authority before each
case and confirms it afterward. It saves the exact target, audit, guard source,
EntryMachine and base Machine source into the new output before probing. Source
files and intended matrix must be archived before root invokes the draft.

## Exact matrix and reasons

| Controls | Count | Required result |
| --- | ---: | --- |
| Named guard read/write; omitted main gap read/write |4|forbidden data read / forbidden phase store|
| Initialized sentinel write; original entry-island write |2|forbidden phase store|
| One byte beyond each state, memory, mailbox and stack span, read/write |8|forbidden data read / forbidden phase store|
| Four-byte access straddling state end, read/write |2|full-width permission rejection before alignment or any partial effect|
| Misaligned four-byte access wholly inside state, read/write |2|unaligned load / unaligned store|
| Stack read before C; stack write during clear phase |2|stack read before C / forbidden phase store|
| State store before normalization |1|forbidden phase store|
| Original S32I.N redirected into guard |1|forbidden phase store, no RAM/access/call effect|
| Original CALL0 with SP below, above, or misaligned within stack |3|call SP outside owned aligned stack|
| Original unexpected self-park |1|one-step budget rejection followed by required-checkpoint/park evidence rejection|
| Wrong successor supplied to real park guard |1|only terminal self-branch may execute after park|
| Injected owned-RAM write during park, then guard |1|terminal park changed registers or performed an access/call|
| Permitted sentinel read and entry-byte read |2|literal31/63 plus exactly one read record, unchanged RAM/CPU/calls|

Every rejection compares its exact exception type and reason. Broad exception
catching is only for preserving unexpected failure captures; it is never a pass.
Immutable data/code allocations remain readable under the actual interpreter
contract. Rejecting their writes does not justify inventing a read prohibition.
Stack-before-C writes naturally fail the phase permission before the redundant
stack-store predicate; the draft states that exact ordering.

## Before-effect rejection versus after-effect detection

Direct rejected reads/writes require exact equality of full current and initial
region bytes, CPU/logical/physical state, active/pending window, phase/ranges,
checkpoint/call/return ledgers, stack minima, all access counters/digests, step
state and observation history. No forbidden write is inferred merely from an
exception. Raw trace files are decompressed only after close and checked
byte-for-byte against independently assembled expected records.

The original redirected S32I.N has already incremented dispatch bookkeeping
(steps/visited/opcode and branch_taken=false) before `write` rejects. The draft
permits exactly that prefix; no after-instruction trace, RAM, register, access
or call effect is permitted.

The bad-SP CALL0 controls are deliberately different: the base model writes
original return PC to a0 before `EntryMachine.after_instruction` checks SP.
The post-instruction hook also records its one step before rejection. The draft
requires those exact CPU/dispatch/step changes and requires every RAM byte,
access ledger, call stack and C-admission flag unchanged. It does not call this
an entirely effect-free rejection or silently reset the changed state.

The terminal wrong-successor predicate is checked after its step trace has been
recorded. It must reject without another effect. The injected park-write case
is explicitly **detection after effect**: `write()` permits one owned state byte
and appends its access record, then the park guard rejects the changed access
count. Three full snapshots retain before-write, after-write and after-detection
states; there is no rollback claim. Actual audited self-J has no write effect.
This control does not authorize replacing it with a store, much less an unsafe
hardware instruction. Ordinary `write()` being enabled at park is a documented
predicate boundary, not evidence of a native bad path.

The unexpected park is executable harmless code, not a forbidden opcode. It
cannot satisfy the designated checkpoint/two-terminal-step evidence condition.
Its one self-J and subsequent budget/closure rejections are retained separately.

## Scope and provenance

This implements the bounded guard portion of the independent frozen acceptance
plan, items9–10. Capture corruption/oracle controls and the six successful
continuous runs remain separate evidence. No whole-input, physical-address,
exception/IRQ or printer behavior is established by these isolated contexts.

`inputs/` retains the exact three implementation sources and original plan.
`INPUTS.sha256` binds them and the linked ELF/map/source evidence. The preserved
`hp1020_entry_guard_controls-v1-author-read.py` is the first unexecuted author
version; the current revision adds explicit initial-region/window snapshots and
uses an unambiguous lifecycle field. No result has been produced for either.
