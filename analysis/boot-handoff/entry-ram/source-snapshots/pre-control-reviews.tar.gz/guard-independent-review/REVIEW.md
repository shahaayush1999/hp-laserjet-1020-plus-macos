# Independent entry guard-control review

Static review only, 2026-10-03. No blocking semantic or fixture mismatch found
within the proposed30-control scope. No input candidate/result capture was
read, and no source was imported, parsed, built or executed. The guard module
and all repository sources remain unchanged. Root owns any subsequent run.

## Exact reviewed inputs

- Guard module: `7fe9bea14b742f7a6027178acc1116e7f3663c5a253452e324b38bdbe7f5f776`
- Guard README: `c59125a01cbabe125ee172d3f45d83cb517dd30e723de96cd12f0c068e8442f6`
- EntryMachine: `46cc66fc2ac1c22201ef6a33ee13eba4a54087bb416ccc1b8726aae2d2c98b07`
- Base Machine: `ed2924d8e46c0e553fe079a5ecdfff77dc40f1aa228588d9a86c39ce98769480`
- Current strict audit source: `2f990f9f57731c49d8931138d32ce100fecd1d2fed722354f6c01117e52042eb`
- Frozen independent acceptance plan: `45c4a5366baff6e6db7650a7114be8bf8639be6b05a7ad12138aa375ae4bb8c1`

Complete copies are in `inputs/`; `INPUTS.sha256` records every copied member.
The draft's declared target hash and instruction anchors were treated as its
explicit admission contract, not as new runtime evidence. No target ELF or
successful/failed execution report was opened for this review.

## Rejection timing checked against source

The direct data controls at guard lines206–237 compare all state before and
after the exact expected exception. EntryMachine read/write checks full-width
phase/range membership before calling the base memory operation. Thus a
four-byte access crossing the final two state bytes correctly fails the
permission check before alignment. An otherwise owned but misaligned access
reaches the base alignment guard and leaves memory and access traces unchanged.
The stack-before-C read reaches its explicit stack predicate; the corresponding
write is refused earlier by the clear-phase write span. The expected messages
match that order rather than conflating the predicates.

For the original S32I.N probe at lines240–249, base `Machine.run` increments
steps, visited/opcode and `branch_taken=false` before invoking `write`. The
redirected guard address is rejected before the store or access log. Since the
base method never reaches `after_instruction`, no step record is appended.
The expected state permits precisely the dispatch prefix, keeping PC and all
register/RAM/call state unchanged.

The three bad-SP CALL0 probes at252–266 correctly have a different prefix.
Base run writes a0 to CALL+3, then enters EntryMachine's post-instruction hook,
which appends the step record before validating the SP. With the declared
bytes5000d5, CALL0's literal target is
`(10007078 & ~3) +4 + (0xd5 *4) =100073d0`; return PC is1000707b.
The draft expects a0 in both logical and currently exposed physical AR state
to become that return PC. The inactive physical shadow stays unchanged. The
PC assignment enclosing `after_instruction` does not complete after an
exception, so PC stays at the call. No C-admission flag or call ledger is added.
These controls are not incorrectly described as entirely effect-free.

The genuine unexpected self-J probe at269–282 permits one real instruction and
one step record. The next loop checks its one-step budget before any second
fetch; its supplied after-C context cannot satisfy the required named park
and two-step evidence closure. This is a budget/closure rejection, not an
invented illegal-opcode or immediate branch guard.

The two terminal direct-hook controls at285–311 retain their explicitly
supplied phase contexts. A wrong successor is rejected after the hook appends
its step record. The owned-RAM write control performs and records one actual
modeled byte write before the park hook detects changed access accounting.
The expected post-detection state retains that write and both raw records;
no prevention or rollback claim is made. The unchanged audited self-J itself
has no store semantics. Minimum SP remains at the supplied owned top in these
contexts, so the hook's intermediate minimum update adds no unaccounted effect.

## Fixture and capture authority

Each probe creates a fresh EntryMachine and detached region copies. Supplied
normalization/C/park flags are clearly named fixtures, never represented as
executed startup observations. The runtime instruction/permission authority is
fingerprinted before the matrix and after every probe; each of the four used
instruction anchors is compared to exact original bytes/decoded operands.
The module also checks the exact target and interpreter hashes and compares
all read/write/execute ranges against the supplied audit.

The snapshot at65–91 makes independent copies of all seven current and initial
memory images, logical/physical ARs, inactive physical shadow, active/pending
window, phase and range state, calls, checkpoint history, stack minima, access
counters/digests, steps, opcodes and observation history. No mutable list/dict
alias was found that would let an unexpected effect rewrite the earlier
expected snapshot. The PC and the separate active window state are both kept.

`finish()` closes the trace writers, decompresses both raw traces and compares
their complete bytes to independently constructed expected records. It does
not accept hashes alone. Successful read controls permit exactly one byte
record with literal31/63 and no RAM/CPU/call effect. Failure capture retains
the available full state and closes the machine before propagation; unexpected
exception types/messages are not counted as successful rejection.

The matrix arithmetic is30 distinct probes:28 with at least one expected
rejection and two successful immutable reads. The unexpected-park probe has
two separate rejections; the report correctly counts rejected probe cases,
not total raised exceptions. Only five `Machine.run` calls have a budget of1;
the remaining controls invoke explicit guard/read/write APIs directly.

## Scope limits retained

The caller must supply the original validated initial images and actual strict
audit/program. This module checks their geometry, hashes them in its report,
and checks loaded instruction bytes when its five instruction probes run; it
does not independently reconstruct the complete initial paint/file overlay.
Root should keep the guard invocation's input-region hashes linked to that
already validated initial snapshot. This is the existing declared API
precondition, not a blocker requiring a duplicate loader model.

The supplied WB0 guard contexts do not execute dirty-window normalization;
the separate six-profile lifecycle covers that. The guard probes add no
continuous entry/document lifecycle, no QEMU evidence and no physical RAM,
cache, interrupt, USB, engine or printing claim. Their pre-/post-effect
distinctions should remain explicit when the results are integrated.
