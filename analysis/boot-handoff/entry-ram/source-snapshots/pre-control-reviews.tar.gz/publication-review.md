# Entry evidence publication and recovery — static review, 2026-10-03

Scope: only the new `publish_evidence`, its caller's failure handling,
`entry_capture_archive_gate`, and suite integration. No candidate results/raw
captures were opened, and no Python import, parsing, build, validator or other
execution was performed. No repository files were changed by this reviewer.

Reviewed source identities:

- Final `scripts/validate-hp1020-entry-ram.py`:
  `f61fe39ae28a48bd8712e62c2fa4afa7c6688cdfb8fcd66f80a618a6d5f7f216`.
- `scripts/check-hp1020-analysis-consistency.py`:
  `14ceb2e75b279257701eb07c8264301b44796e9a5640d2fde7816569196195c0`.
- `scripts/validate-hp1020-offline-analysis.sh`:
  `70e2443bd28269b4c238d916fa655d2b9bf927b9b40810d578790512b7e4e064`.
- Frozen raw checker `scripts/check-hp1020-entry-ram.py`:
  `a792e16d4040c75953c7fb43466adf6787bf91efd625f1d6683764ac7bcf5dfe`.
- Unchanged aggregate `scripts/validate.sh`:
  `5633b86fbde5d66dcdf3b5c3c71604c1743abd6ff18d91ebcabeb794e222d916`.

Exact copies are in `/tmp/hp1020-entry-publication-review-inputs-20261003/`;
its `SHA256SUMS` hash is
`908f47743a2f4e8be622f2965329ca708ef9bf4ab63cf633c6a326ae33062ca5`.

## Findings and correction

The initially inspected, unexecuted publisher
`dab07c9c6b7b9aaaedf2799b8b95f654c539bc84add6f63c862f5e8e3bf6a59b`
published a passing report before summary generation, Markdown write and
notification. A later exception could leave an archive/report pair still
passing recovery while the fresh run was marked publication-failed only in
`/tmp`. Root corrected this before executing the changed runner.

The reviewed final version performs the checker, member/archive limits,
compression, exact archive readback, summary construction, serialization and
all staged writes first. Lines 376–381 replace archive, manifest, Markdown and
finally the JSON success report, each from a staged sibling file. No fallible
notification or report computation follows that final report replacement.
The caller records and raises a precommit publication exception. This closes
the concrete ordering defect. A partial multi-file replacement is detected by
the recovery seals/report equality rather than accepted as a new checkpoint;
this is not a claim of a filesystem-wide atomic transaction or power-loss
durability beyond the written artifacts and subsequent verification.

Publication now enforces the same limits as recovery: 32 MiB per member,
128 MiB total member data, and 32 MiB compressed archive. It cannot knowingly
publish an archive that recovery rejects merely for these size limits.

## Bounded no-finding conclusions

- The independent raw checker runs against the complete temporary capture with
  `source_root=ROOT` before publication. Sources, linked bytes, semantic evidence
  and the current frozen checker must therefore agree. The new runner must be
  rerun; an older successful capture is not silently relabeled with its hash.
- The archive contains the capture's exact report, source closure, target files,
  headers, paired raw snapshots, traces, ledger and independent-check result.
  Only `target-before-build` history is excluded, matching its explicitly
  separate status. Each archived member and the complete compressed payload
  receive a SHA-256 seal, and in-memory archive readback checks every byte.
- Recovery creates a fresh private directory, accepts only regular relative
  members without `..`, rejects duplicate member names, verifies member/data
  sizes and hashes, and writes bytes explicitly rather than using tar extraction
  permissions, links or device objects. It executes the trusted current local
  checker, not Python code extracted from the archive.
- Recovery requires byte-for-byte equality between the archived and public
  report, then independently replays the recovered evidence with the frozen
  checker. Its `source_root` check ties current sources, including the checker,
  to the exact saved source closure. The newly obtained result must also equal
  the archived independent-check result.
- No recovery step dereferences the old report's temporary capture path or
  requires the former compiler/emulator installation. Original absolute paths
  and command arguments remain provenance data. The previously reviewed gate
  resolves compiler-header aliases lexically and uses saved bytes.
- The suite invokes the new experiment synchronously before the shared
  consistency check. `set -euo pipefail` and ordinary `run_step` propagation
  stop the suite on a failed run. Shared consistency records recovery failures
  as a failed check instead of substituting the stored success flag.

No additional blocking issue was found in this narrow final static review.
The archive is an internally generated, source-sealed evidence format, not a
general untrusted-tar extraction service. Actual archive limits, successful
publication/recovery and all source identities still require the root-owned
rerun/full validation. The earlier entry execution result does not validate
these newly added publication operations.
