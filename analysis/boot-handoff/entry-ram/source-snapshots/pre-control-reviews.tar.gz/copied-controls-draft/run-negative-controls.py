#!/usr/bin/env python3
"""Copied-evidence negative controls for the independent one-entry RAM gate.

This driver imports only a selected local capture checker when explicitly run.
It never executes target code or imports a producer, interpreter, QEMU adapter,
builder or audit. Each synthetic corruption is made in a separate new evidence
copy, with atomic replacement so hardlinks cannot modify the original capture.
See README.md for deliberately preserved semantic contradictions and limits.
"""
import argparse
import copy
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile


STATE = (0x1000e000, 13496)
MEMORY = (0x10016800, 114704)
MAILBOX = (0x10014040, 1024)
STACK = (0x10012000, 8192)
DATA = (0x1000d020, 256)
MODEL_PHASES = ('initial', 'after-normalization', 'pre-c', 'pre-finish', 'park')
QEMU_PHASES = MODEL_PHASES + ('park-step-1', 'park-step-2')
GDB = dict(pc=0, lbeg=33, lend=34, lcount=35, sar=36,
           windowbase=38, windowstart=39, ps=42, intenable=110)
SOURCE_MEMBER = 'open-firmware/entry-ram-test/hp1020_entry_workload.c'
FIRST_CASE = '00-ordinary-privilege-a5'


class ControlError(ValueError):
    pass


def require(ok, message):
    if not ok:
        raise ControlError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def fnv(raw):
    value = 0x811c9dc5
    for byte in raw:
        value = ((value ^ byte) * 0x01000193) & 0xffffffff
    return value


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def json_lines(rows):
    return b''.join((json.dumps(row, sort_keys=True, separators=(',', ':')) + '\n').encode()
                    for row in rows)


def atomic_write(path, raw):
    """Replace a new inode; never open a shared evidence inode for writing."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(raw)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def link_or_copy(source, destination):
    try:
        os.link(source, destination)
    except OSError as error:
        if error.errno != errno.EXDEV:
            raise
        shutil.copy2(source, destination)
    return destination


def tree_manifest(root):
    result = {}
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), 'capture copies do not admit symlinks: ' + str(path))
        if path.is_file():
            data = path.read_bytes()
            result[str(path.relative_to(root))] = dict(bytes=len(data), sha256=sha(data))
    require(result, 'nonempty evidence tree required')
    return result


def load_checker(path):
    spec = importlib.util.spec_from_file_location('independent_entry_capture_checker', path)
    require(spec is not None and spec.loader is not None, 'selected checker cannot be loaded')
    module = importlib.util.module_from_spec(spec)
    previous = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = previous
    require(callable(getattr(module, 'check_capture', None)), 'selected checker lacks check_capture')
    return module


def compact_delta(before, after):
    prefix = 0
    while prefix < min(len(before), len(after)) and before[prefix] == after[prefix]:
        prefix += 1
    suffix = 0
    while (suffix < min(len(before), len(after)) - prefix and
           before[len(before) - 1 - suffix] == after[len(after) - 1 - suffix]):
        suffix += 1
    end_before, end_after = len(before) - suffix, len(after) - suffix
    delta = dict(original_bytes=len(before), modified_bytes=len(after),
                 original_sha256=sha(before), modified_sha256=sha(after),
                 first_changed_byte=prefix, original_changed_end=end_before,
                 modified_changed_end=end_after)
    if end_before - prefix <= 64 and end_after - prefix <= 64:
        delta['original_changed_hex'] = before[prefix:end_before].hex()
        delta['modified_changed_hex'] = after[prefix:end_after].hex()
    return delta


def normalized_registers(registers, engine):
    result = copy.deepcopy(registers)
    if engine == 'qemu':
        result['logical_ar'] = result.pop('logical_a')
    return result


class EvidenceCopy:
    def __init__(self, original_root, root, label):
        require(not root.exists(), 'refuse to overwrite a control evidence tree')
        shutil.copytree(original_root, root, copy_function=link_or_copy)
        self.original_root = original_root
        self.root = root
        self.label = label
        self.report = self.read_json('validation.json')
        self.original_report = copy.deepcopy(self.report)
        matches = [case for case in self.report['cases'] if case['case'] == FIRST_CASE]
        require(len(matches) == 1, 'frozen ordinary/a5 case must occur exactly once')
        self.case = matches[0]
        self.case_prefix = 'cases/' + FIRST_CASE + '/'
        self.ledger = [json.loads(line) for line in self.read(
            self.case_prefix + 'qemu/host-interventions.jsonl').splitlines()]
        self.original_files = {}
        self.notes = []
        self.ledger_mutator = None
        self.intentional_unsealed = set()

    def path(self, relative):
        require(isinstance(relative, str) and relative and not Path(relative).is_absolute(),
                'relative copied evidence path')
        path = self.root / relative
        require(path.resolve().is_relative_to(self.root.resolve()), 'copy path escapes root')
        return path

    def read(self, relative):
        return self.path(relative).read_bytes()

    def read_json(self, relative):
        return json.loads(self.read(relative))

    def write(self, relative, raw):
        path = self.path(relative)
        require(path.is_file(), 'control may replace only an existing captured member: ' + relative)
        before = path.read_bytes()
        if before != raw:
            self.original_files.setdefault(relative, before)
            atomic_write(path, raw)

    def write_json(self, relative, value):
        self.write(relative, json_bytes(value))

    def note(self, field, change):
        self.notes.append(dict(field=field, change=change))

    def snapshot(self, engine, phase):
        matches = [item for item in self.case[engine]['snapshots'] if item['name'] == phase]
        require(len(matches) == 1, 'unique snapshot ' + engine + '/' + phase)
        return matches[0]

    def region(self, engine, phase, address, count):
        matches = [item for item in self.snapshot(engine, phase)['regions']
                   if item['start'] <= address and address + count <= item['start'] + item['bytes']]
        require(len(matches) == 1 and count > 0, 'one complete captured region for mutation')
        item = matches[0]
        relative = self.case_prefix + engine + '/' + item['path']
        return item, relative, address - item['start']

    def memory(self, engine, phase, address, count):
        _, relative, offset = self.region(engine, phase, address, count)
        return self.read(relative)[offset:offset + count]

    def replace_memory(self, engine, phase, address, new):
        item, relative, offset = self.region(engine, phase, address, len(new))
        data = bytearray(self.read(relative))
        require(len(data) == item['bytes'] == item['captured_bytes'], 'full raw region before mutation')
        data[offset:offset + len(new)] = new
        self.write(relative, bytes(data))
        item['sha256'] = sha(data)

    def mutate_pair_byte(self, phase, address, expected=None):
        before = self.memory('model', phase, address, 1)
        require(before == self.memory('qemu', phase, address, 1), 'original paired byte')
        if expected is not None:
            require(before == bytes([expected]), 'frozen original byte prerequisite')
        after = bytes([before[0] ^ 1])
        for engine in ('model', 'qemu'):
            self.replace_memory(engine, phase, address, after)
        self.note('paired ' + phase + ' byte',
                  dict(address=address, before=before.hex(), after=after.hex()))

    def replace_pair_word(self, phase, address, expected, value):
        for engine in ('model', 'qemu'):
            require(self.memory(engine, phase, address, 4) == expected.to_bytes(4, 'big'),
                    'frozen original paired word')
            self.replace_memory(engine, phase, address, value.to_bytes(4, 'big'))

    def registers(self, engine, phase):
        return self.snapshot(engine, phase)['registers']

    def recalculate_aliases(self, registers, engine):
        base = registers['windowbase'] * 4
        key = 'logical_a' if engine == 'qemu' else 'logical_ar'
        registers[key] = [registers['physical_ar'][(base + i) % 32] for i in range(16)]

    def register_value(self, phase, number):
        registers = self.registers('qemu', phase)
        named = [name for name, index in GDB.items() if number == index]
        if named:
            require(len(named) == 1, 'unique semantic debugger register')
            return registers[named[0]]
        if 1 <= number <= 32:
            return registers['physical_ar'][number - 1]
        if 124 <= number <= 139:
            return registers['logical_a'][number - 124]
        raise ControlError('unexpected snapshot register in frozen ABI')

    def refresh_snapshot_replies(self):
        """Propagate changed raw snapshots into p/m replies inside markers only."""
        phase = None
        for i, row in enumerate(self.ledger):
            if row['kind'] == 'snapshot-start':
                require(phase is None, 'non-nested snapshot markers')
                phase = row['name']
            elif row['kind'] == 'snapshot-end':
                require(row['name'] == phase, 'paired snapshot marker')
                phase = None
            elif row['kind'] == 'gdb-request' and phase is not None:
                require(i + 1 < len(self.ledger) and self.ledger[i + 1]['kind'] == 'gdb-reply',
                        'snapshot request/reply pair')
                reply = self.ledger[i + 1]
                command = row['command']
                if re.fullmatch(r'p[0-9a-f]+', command):
                    reply['reply'] = f'{self.register_value(phase, int(command[1:], 16)):08x}'
                else:
                    match = re.fullmatch(r'm([0-9a-f]+),([0-9a-f]+)', command)
                    require(match is not None, 'only snapshot p/m commands may be refreshed')
                    address, count = (int(v, 16) for v in match.groups())
                    reply['reply'] = self.memory('qemu', phase, address, count).hex()
        require(phase is None, 'all snapshot markers closed')

    def reseal_ledger(self):
        commands = 0
        for i, row in enumerate(self.ledger):
            row['ledger_index'] = i
            if row['kind'] == 'gdb-request':
                require(i + 1 < len(self.ledger) and self.ledger[i + 1]['kind'] == 'gdb-reply',
                        'every debugger request retains its reply')
                row['command_index'] = commands
                self.ledger[i + 1]['command_index'] = commands
                commands += 1
            elif row['kind'] == 'initial-state-locked':
                row['gdb_commands'] = commands
        data = json_lines(self.ledger)
        self.write(self.case_prefix + 'qemu/host-interventions.jsonl', data)
        self.case['qemu']['gdb_commands'] = commands
        self.case['qemu']['host_intervention_ledger'] = dict(
            path='host-interventions.jsonl', sha256=sha(data), lines=len(self.ledger), bytes=len(data))

    def sync(self):
        self.refresh_snapshot_replies()
        if self.ledger_mutator is not None:
            self.ledger_mutator(self)
        self.reseal_ledger()
        for engine in ('model', 'qemu'):
            for item in self.case[engine]['snapshots']:
                prefix = self.case_prefix + engine + '/' + item['name'] + '/'
                self.write_json(prefix + 'registers.json', item['registers'])
                self.write_json(prefix + 'snapshot.json', item)
            if engine == 'model':
                self.write_json(self.case_prefix + 'model/snapshots.json', self.case['model']['snapshots'])
            self.write_json(self.case_prefix + engine + '/result.json', self.case[engine])
        self.write_json(self.case_prefix + 'case.json', self.case)
        require(self.report['source_sha256'] == self.original_report['source_sha256'] and
                self.report['target_sha256'] == self.original_report['target_sha256'],
                'real source and target-build manifests must remain unchanged')
        self.write_json('validation.json', self.report)

    def paired_sealing(self):
        """Verify envelopes/hashes only; do not enforce the deliberately broken fact."""
        require(self.read_json('validation.json') == self.report and
                self.read_json(self.case_prefix + 'case.json') == self.case,
                'report/case metadata propagation')
        for engine, phases in (('model', MODEL_PHASES), ('qemu', QEMU_PHASES)):
            result = self.case[engine]
            require(result == self.read_json(self.case_prefix + engine + '/result.json'),
                    'result metadata propagation')
            require([s['name'] for s in result['snapshots']] == list(phases), 'exact unchanged snapshot matrix')
            if engine == 'model':
                require(result['snapshots'] == self.read_json(self.case_prefix + 'model/snapshots.json'),
                        'model snapshot-list metadata propagation')
            for item in result['snapshots']:
                prefix = self.case_prefix + engine + '/'
                require(item == self.read_json(prefix + item['name'] + '/snapshot.json') and
                        item['registers'] == self.read_json(prefix + item['name'] + '/registers.json'),
                        'individual snapshot metadata propagation')
                for region in item['regions']:
                    data = self.read(prefix + region['path'])
                    require(len(data) == region['bytes'] == region['captured_bytes'] and
                            sha(data) == region['sha256'], 'actual raw snapshot size/hash')
        for phase in MODEL_PHASES:
            model = self.snapshot('model', phase)
            native = self.snapshot('qemu', phase)
            require(normalized_registers(model['registers'], 'model') ==
                    normalized_registers(native['registers'], 'qemu'), 'paired full registers')
            require([(r['start'], r['bytes'], r['sha256']) for r in model['regions']] ==
                    [(r['start'], r['bytes'], r['sha256']) for r in native['regions']],
                    'paired full raw region records')
            for left, right in zip(model['regions'], native['regions']):
                require(self.read(self.case_prefix + 'model/' + left['path']) ==
                        self.read(self.case_prefix + 'qemu/' + right['path']), 'paired actual raw bytes')
        data = self.read(self.case_prefix + 'qemu/host-interventions.jsonl')
        seal = self.case['qemu']['host_intervention_ledger']
        require(len(data) == seal['bytes'] and sha(data) == seal['sha256'] and
                len(self.ledger) == seal['lines'], 'refreshed ledger raw seal')
        require(all(row['ledger_index'] == i for i, row in enumerate(self.ledger)), 'refreshed ledger indices')
        return dict(case=FIRST_CASE, full_paired_checkpoints=5, full_qemu_snapshots=7,
                    raw_hashes_and_report_copies_agree=True,
                    snapshot_p_m_replies_refreshed_before_deliberate_ledger_control=True,
                    intentional_unsealed_members=sorted(self.intentional_unsealed),
                    original_model_trace_preserved=True)

    def save_deltas(self, control_root):
        changed = {name: compact_delta(before, self.read(name))
                   for name, before in sorted(self.original_files.items())}
        require(changed, 'negative control must actually change copied evidence')
        actual = {name for name, value in tree_manifest(self.root).items()
                  if value != tree_manifest_member(self.original_root, name)}
        require(actual == set(changed), 'every changed copied member is tracked')
        atomic_write(control_root / 'deltas.json', json_bytes(changed))
        atomic_write(control_root / 'SYNTHETIC-CORRUPTION.json', json_bytes(dict(
            control=self.label, not_target_model_or_device_execution=True, mutations=self.notes,
            original_model_trace_preserved=True, intentional_unsealed_members=sorted(self.intentional_unsealed),
            changed_members=changed)))
        return changed


def tree_manifest_member(root, relative):
    path = root / relative
    if not path.is_file():
        return None
    data = path.read_bytes()
    return dict(bytes=len(data), sha256=sha(data))


def bss_byte(evidence, span, offset):
    evidence.mutate_pair_byte('pre-c', span[0] + offset, expected=0)


def protected_byte(evidence, address):
    evidence.mutate_pair_byte('pre-c', address)


def early_zero(evidence):
    for engine in ('model', 'qemu'):
        require(evidence.memory(engine, 'after-normalization', STATE[0], 1) == b'\xa5',
                'original first BSS byte still painted after normalization')
        evidence.replace_memory(engine, 'after-normalization', STATE[0], b'\0')
    evidence.note('BSS was zeroed before its first allowed store',
                  dict(address=STATE[0], before=0xa5, after=0))


def cpu_field(evidence, field, expected, value):
    for engine in ('model', 'qemu'):
        registers = evidence.registers(engine, 'after-normalization')
        require(registers[field] == expected, 'frozen normalized original ' + field)
        registers[field] = value
        if field == 'windowbase':
            evidence.recalculate_aliases(registers, engine)
    evidence.note('paired normalized CPU ' + field, dict(before=expected, after=value,
                  aliases_recalculated=field == 'windowbase'))


def cpu_sp(evidence, value):
    for engine in ('model', 'qemu'):
        registers = evidence.registers(engine, 'after-normalization')
        require(registers['physical_ar'][1] == STACK[0] + STACK[1], 'original owned SP top')
        registers['physical_ar'][1] = value
        evidence.recalculate_aliases(registers, engine)
    evidence.note('paired normalized physical AR1/SP and aliases',
                  dict(before=STACK[0] + STACK[1], after=value))


def wrong_alias(evidence):
    for engine in ('model', 'qemu'):
        registers = evidence.registers(engine, 'after-normalization')
        key = 'logical_a' if engine == 'qemu' else 'logical_ar'
        require(registers['windowbase'] == 0 and registers[key][7] == registers['physical_ar'][7],
                'original WB0 physical/logical alias')
        registers[key][7] ^= 1
    evidence.note('paired logical a7 only', 'Same wrong logical value in both engines; original physical AR7 retained.')


def wrong_event(evidence):
    evidence.replace_pair_word('pre-finish', MAILBOX[0] + 35 * 4, 1, 2)
    evidence.note('pre-finish END_DOC generation', 'Original generation1 becomes2 in both mailbox event observations.')


def wrong_pixel(evidence):
    phase = 'pre-finish'
    for engine in ('model', 'qemu'):
        pixels = evidence.memory(engine, phase, MAILBOX[0] + 256, 32)
        require(pixels == b'\xff' * 32 and evidence.memory(engine, phase, MEMORY[0] + 81936, 32) == pixels,
                'literal original completed black page')
        changed = pixels[:17] + b'\xfe' + pixels[18:]
        evidence.replace_memory(engine, phase, MAILBOX[0] + 256, changed)
        evidence.replace_memory(engine, phase, MEMORY[0] + 81936, changed)
        evidence.replace_memory(engine, phase, MAILBOX[0] + 33 * 4, fnv(changed).to_bytes(4, 'big'))
    evidence.note('pre-finish page, literal witness and FNV', 'Byte17 is FE in both actual output slots and mailbox; FNV updated.')


def premature_finish(evidence):
    address = STATE[0] + 13492
    for engine in ('model', 'qemu'):
        require(evidence.memory(engine, 'pre-finish', address, 1) == b'\0', 'original live document before finish')
        evidence.replace_memory(engine, 'pre-finish', address, b'\1')
    evidence.note('actual document.finished at first finish entry', 'Claims completion before that function executes; mailbox final fields are not used.')


def wrong_rx_suffix(evidence):
    byte_index = 1024 + 47
    phases = [('model', 'park')] + [('qemu', name) for name in ('park', 'park-step-1', 'park-step-2')]
    first = evidence.memory('model', 'park', MEMORY[0], 4096)
    changed = bytearray(first)
    changed[byte_index] ^= 1
    for engine, phase in phases:
        require(evidence.memory(engine, phase, MEMORY[0], 4096) == first, 'same final original receive storage')
        evidence.replace_memory(engine, phase, MEMORY[0], bytes(changed))
        evidence.replace_memory(engine, phase, MAILBOX[0] + 57 * 4, fnv(changed).to_bytes(4, 'big'))
    evidence.note('final receive slot1 retained suffix and full4096 FNV',
                  dict(offset=byte_index, previous_fragment_suffix_offset=47,
                       before=first[byte_index], after=changed[byte_index], all_final_park_observations_updated=True))


def post_lock_write(evidence):
    def mutate(ev):
        positions = [i for i, row in enumerate(ev.ledger)
                     if row['kind'] == 'snapshot-start' and row['name'] == 'initial']
        require(len(positions) == 1, 'one initial snapshot marker')
        index = positions[0] + 1
        require(ev.ledger[index]['kind'] == 'gdb-request' and ev.ledger[index]['command'] == 'p0',
                'initial readback starts with PC')
        value = ev.registers('qemu', 'initial')['physical_ar'][1]
        ev.ledger[index:index] = [
            dict(kind='gdb-request', command=f'P2={value:08x}', command_index=0,
                 phase='observe', action='post-lock-same-value-write'),
            dict(kind='gdb-reply', command_index=0, reply='OK')]
        ev.note('post-lock debugger command', 'Insert same-value physical AR1 write inside initial snapshot; reindex all commands, retain zero-mutation claim.')
    evidence.ledger_mutator = mutate


def wrong_ledger_reply(evidence):
    def mutate(ev):
        phase = None
        for i, row in enumerate(ev.ledger):
            if row['kind'] == 'snapshot-start':
                phase = row['name']
            elif row['kind'] == 'snapshot-end':
                phase = None
            elif (phase == 'after-normalization' and row['kind'] == 'gdb-request' and
                  row['command'] == 'm10003000,1000'):
                reply = ev.ledger[i + 1]
                raw = bytes.fromhex(reply['reply'])
                require(len(raw) == 4096 and reply['kind'] == 'gdb-reply', 'one full raw memory reply')
                reply['reply'] = (bytes([raw[0] ^ 1]) + raw[1:]).hex()
                ev.note('one resealed debugger reply', 'Memory reply byte0 differs from unchanged saved after-normalization raw bytes.')
                return
        raise ControlError('frozen after-normalization memory reply missing')
    evidence.ledger_mutator = mutate


def changed_park_step(evidence):
    registers = evidence.registers('qemu', 'park-step-2')
    previous = copy.deepcopy(registers)
    require(registers == evidence.registers('qemu', 'park'), 'original second park iteration unchanged')
    registers['physical_ar'][3] ^= 1
    evidence.recalculate_aliases(registers, 'qemu')
    evidence.note('second actual park step register', dict(physical_ar=3,
                  before=previous['physical_ar'][3], after=registers['physical_ar'][3],
                  aliases_and_debugger_replies_updated=True))


def saved_byte_seal(evidence, member):
    data = evidence.read(member)
    require(data, 'nonempty saved source/listing member')
    evidence.write(member, data + b'\n/* SYNTHETIC COPIED-EVIDENCE CORRUPTION */\n')
    evidence.intentional_unsealed.add(member)
    evidence.note('saved-byte authority', dict(member=member,
                  original_claimed_sha256_preserved=True, original_source_not_modified=True))


def controls():
    result = []
    for name, span in (('state', STATE), ('memory', MEMORY), ('mailbox', MAILBOX)):
        for position, offset in (('first', 0), ('middle', span[1] // 2), ('last', span[1] - 1)):
            result.append((f'pre-c-bss-{name}-{position}',
                lambda ev, s=span, o=offset: bss_byte(ev, s, o),
                'ValueError: all three BSS objects zero before C'))
    for name, address in (('sentinel', DATA[0]), ('stack', STACK[0] + 123),
                          ('gap', 0x10011500), ('island', 0x10000010)):
        result.append(('protected-' + name, lambda ev, a=address: protected_byte(ev, a),
                       f'ValueError: protected byte changed at{address:#x}'))
    for field, expected, value in (('ps', 15, 14), ('windowbase', 0, 1),
                                  ('intenable', 0, 1), ('windowstart', 1, 3),
                                  ('sar', 0, 1), ('lbeg', 0, 0x10003000),
                                  ('lend', 0, 0x10003020), ('lcount', 0, 1)):
        message = 'startup SAR' if field == 'sar' else 'normalized actual CPU ' + field
        result.append(('normalized-cpu-' + field,
            lambda ev, f=field, old=expected, new=value: cpu_field(ev, f, old, new),
            'ValueError: ' + message))
    result += [
        ('normalized-sp-top', lambda ev: cpu_sp(ev, STACK[0] + STACK[1] + 16),
         'ValueError: own stack top at checkpoint'),
        ('normalized-sp-alignment', lambda ev: cpu_sp(ev, STACK[0] + STACK[1] - 1),
         'ValueError: own stack top at checkpoint'),
        ('physical-logical-alias', wrong_alias, 'ValueError: physical/logical register aliases'),
        ('pre-finish-original-event', wrong_event,
         'ValueError: completed output and original event before finish'),
        ('pre-finish-literal-pixel', wrong_pixel, 'ValueError: literal pixels and untouched mailbox tail'),
        ('pre-finish-live-flags', premature_finish, 'ValueError: actual production boundary fields'),
        ('final-rx-retained-suffix', wrong_rx_suffix, 'ValueError: exact receive bytes/reused short suffix'),
        ('post-lock-host-write', post_lock_write, 'ValueError: exact permitted debugger command envelope'),
        ('ledger-reply-disagrees', wrong_ledger_reply, 'ValueError: debugger memory reply vs saved raw bytes'),
        ('second-park-step-changes-register', changed_park_step, 'ValueError: two unchanged actual park steps'),
        ('saved-source-bytes', lambda ev: saved_byte_seal(ev, 'source/' + SOURCE_MEMBER),
         'ValueError: source bytes differ: ' + SOURCE_MEMBER),
        ('early-bss-zeroing', early_zero,
         f'ValueError: protected byte changed at{STATE[0]:#x}'),
        ('saved-annotated-disassembly', lambda ev: saved_byte_seal(ev, 'annotated-disassembly.txt'),
         'ValueError: actual annotated disassembly byte seal')]
    require(len(result) == 34 and len({name for name, _, _ in result}) == 34, 'exact independent34-control scope')
    return result


def run(args):
    original = args.capture_root.resolve()
    checker_path = args.checker.resolve()
    output = args.output_root.resolve()
    require(original.is_dir() and checker_path.is_file(), 'existing capture and checker paths required')
    require(not output.exists() and original != output and original not in output.parents,
            'output must be new and outside original evidence')
    original_manifest = tree_manifest(original)
    checker_bytes = checker_path.read_bytes()
    checker_hash = sha(checker_bytes)
    if args.checker_sha256 is not None:
        require(checker_hash == args.checker_sha256, 'selected checker hash differs from explicit pin')
    output.mkdir(parents=True)
    atomic_write(output / 'checker.py', checker_bytes)
    atomic_write(output / 'driver.py', Path(__file__).read_bytes())
    atomic_write(output / 'original-members.json', json_bytes(original_manifest))
    checker = load_checker(checker_path)
    accepted, detail = checker.check_capture(original)
    baseline = dict(status='pass' if accepted else 'fail', accepted=accepted, detail=detail,
                    capture_root=str(original), checker=str(checker_path), checker_sha256=checker_hash,
                    driver_sha256=sha(Path(__file__).read_bytes()), no_new_target_execution=True)
    atomic_write(output / 'baseline.json', json_bytes(baseline))
    require(accepted, 'unchanged successful capture must pass selected checker before controls: ' + str(detail))
    baseline_root = output / 'baseline-capture'
    shutil.copytree(original, baseline_root, copy_function=link_or_copy)
    require(tree_manifest(baseline_root) == original_manifest, 'exact retained baseline byte copy')
    results = []
    for label, mutate, expected in controls():
        folder = output / label
        folder.mkdir()
        result = dict(control=label, status='error', expected_error=expected,
                      checker_sha256=checker_hash, synthetic_not_target_execution=True)
        evidence = None
        try:
            evidence = EvidenceCopy(baseline_root, folder / 'capture', label)
            mutate(evidence)
            evidence.sync()
            result['paired_sealing'] = evidence.paired_sealing()
            result['mutations'] = evidence.notes
            result['changed_members'] = evidence.save_deltas(folder)
            accepted_control, actual = checker.check_capture(evidence.root)
            result['checker'] = dict(accepted=accepted_control, detail=actual)
            precise = not accepted_control and isinstance(actual, dict) and actual.get('error') == expected
            result['status'] = 'rejected-as-intended' if precise else 'wrong-result-or-mechanism'
        except Exception as error:
            result['error'] = type(error).__name__ + ': ' + str(error)
            if evidence is not None:
                result['mutations'] = evidence.notes
                try:
                    result['changed_members'] = evidence.save_deltas(folder)
                except Exception as delta_error:
                    result['delta_error'] = type(delta_error).__name__ + ': ' + str(delta_error)
                    partial = {name: compact_delta(before, evidence.read(name))
                               for name, before in evidence.original_files.items()}
                    atomic_write(folder / 'partial-deltas.json', json_bytes(partial))
        atomic_write(folder / 'result.json', json_bytes(result))
        results.append(result)
        atomic_write(output / 'negative-controls-progress.json', json_bytes(results))
        print(label + ': ' + result['status'], flush=True)
    require(tree_manifest(original) == original_manifest, 'original capture was changed during controls')
    require(tree_manifest(baseline_root) == original_manifest, 'retained baseline was changed through a shared inode')
    require(checker_path.read_bytes() == checker_bytes, 'selected checker source changed during controls')
    final_accepted, final_detail = checker.check_capture(original)
    require(final_accepted, 'original raw baseline no longer passes after copied controls: ' + str(final_detail))
    summary = dict(status='pass' if all(row['status'] == 'rejected-as-intended' for row in results) else 'fail',
                   controls=results, count=len(results), baseline=baseline,
                   original_rechecked=dict(accepted=final_accepted, detail=final_detail),
                   original_and_retained_baseline_members_unchanged=True,
                   atomic_replacement_for_every_copy_mutation=True,
                   no_new_target_model_or_hardware_execution=True)
    atomic_write(output / 'negative-controls.json', json_bytes(summary))
    return summary['status'] == 'pass'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('capture_root', type=Path)
    parser.add_argument('--checker', type=Path, required=True)
    parser.add_argument('--checker-sha256')
    parser.add_argument('--output-root', type=Path, required=True)
    args = parser.parse_args()
    try:
        passed = run(args)
    except Exception as error:
        print('STOP: ' + type(error).__name__ + ': ' + str(error), flush=True)
        raise SystemExit(2)
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    main()
