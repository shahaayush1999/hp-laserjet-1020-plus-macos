# Entry copied-evidence controls — unexecuted draft

This package was drafted without reading any candidate execution results.
`run-negative-controls.py` has not been parsed, imported, executed or tested by
its author. Root owns static review and execution only after the exact positive
capture passes its independent checker. No repository or checker file is edited.

The runner accepts a successful capture directory, a checker path, an optional
exact checker SHA256 pin and a new output directory. It imports only that
selected checker and standard-library modules when explicitly executed. It
does not import a producer, target interpreter, QEMU adapter, audit or builder;
there are no firmware instructions or hardware operations in this driver.

```sh
python3 /tmp/hp1020-entry-controls-draft-20261003/run-negative-controls.py \
  /path/to/untouched-successful-capture \
  --checker /path/to/the/exact/check-hp1020-entry-ram.py \
  --checker-sha256 EXACT_TESTED_CHECKER_SHA256 \
  --output-root /tmp/NEW-entry-negative-controls
```

This is an unexecuted command template, not a claim that a successful baseline
already exists. The output directory must be new and outside the input capture.

## Copying, sealing and attribution

The complete existing publication control runner was read first; its exact
source is saved under `inputs/`. This draft reuses the same atomic replacement
and hardlink-copy technique, with entry-specific capture propagation. Every
changed file is written to a temporary new inode and replaced atomically. No
write can pass through an unchanged hardlink into the source capture.

Before controls, the unchanged capture must pass the selected checker. The
driver seals every original file, retains a complete baseline copy and saves
the checker/driver bytes. Each control then receives its own full evidence
copy. It changes only the first frozen ordinary/a5 case, except the two explicit
saved-byte seal controls. The other five CPU/paint cases remain untouched.

For paired snapshot controls, both actual raw images/register sets are changed
consistently. Each region hash, per-snapshot JSON, register JSON, model snapshot
list, model/QEMU result, case JSON and top-level validation JSON is refreshed.
Snapshot p/m replies inside the QEMU ledger are updated from those saved bytes,
and the complete ledger digest, byte/line counts and event indices are resealed.
The retained-RX control updates the receive FNV and both later QEMU park-step
observations. The changed second-park control intentionally affects only that
extra QEMU observation; the five paired observations remain equal.

The driver independently checks this mechanical pairing and propagation before
calling the checker. A control passes only when `detail.error` equals its exact
frozen expected rejection string. A missing file, unrelated hash failure,
metadata mismatch, incidental exception or unexpected acceptance is a failed
control. Every original and copied baseline byte is rehashed at the end, and
the original positive gate is run again. No original source/report hash is
replaced with a synthetic result.

Each control preserves its full altered capture, `deltas.json` with every changed
member's before/after hash and changed byte extent, a separate
`SYNTHETIC-CORRUPTION.json` and exact `result.json`. Small deltas include changed
byte literals. The retained baseline supplies all original member bytes; the
altered capture supplies all resulting bytes, including large JSON/ledger
changes. Partial driver failures keep available deltas and evidence too.

## Exact34-control scope

| Controls | Mutation | Intended first rejection |
|---|---|---|
|9 pre-C BSS controls|First, middle and last byte of each state, memory and mailbox span; zero becomes1 in both engines|All three BSS objects must be zero before C|
|4 protected controls|One sentinel, pre-C stack, main-envelope gap or immutable island byte changes|Exact protected address changed|
|PS|After normalization15 becomes14|Normalized actual PS|
|WINDOWBASE|After normalization0 becomes1; logical aliases are recomputed consistently|Normalized actual WINDOWBASE|
|INTENABLE|After normalization0 becomes1|Normalized actual INTENABLE|
|WINDOWSTART|After normalization1 becomes3|Normalized actual WINDOWSTART|
|SAR|After normalization0 becomes1|Startup SAR|
|LBEG, LEND, LCOUNT|Each zero changes independently to a nonzero value|Its named normalized loop register|
|SP top|Aligned physical AR1 becomes owned top+16; aliases updated|Own stack top at checkpoint|
|SP alignment|Physical AR1 becomes owned top−1; aliases updated|Own stack top at checkpoint|
|Alias|Logical a7 alone changes in both engines, physical AR7 stays original|Physical/logical aliases must agree|
|Pre-finish event|Original END_DOC generation1 becomes2|Original event before finish|
|Pre-finish pixel|One FF pixel becomesFE in actual output and mailbox witness, pixel FNV updated|Literal pixels|
|Pre-finish state|Actual production document.finished becomes1 before the first finish instruction|Actual production boundary fields|
|Final RX suffix|Slot1 byte47 changes after the final32-byte overwrite, complete receive FNV updated|Exact receive bytes and retained short suffix|
|Post-lock host write|One same-value P2 write is inserted inside initial read-back; command indices/counts updated and claimed zero runtime writes retained|Exact permitted debugger command envelope|
|Ledger reply|One after-normalization m reply differs from unchanged actual saved memory, while ledger seal is updated|Debugger memory reply versus saved bytes|
|Second park step|One physical AR changes with coherent logical alias and reply, after the five paired captures|Two actual park steps must leave all state unchanged|
|Saved source|Append bytes to the captured workload C; its original authority hash stays unchanged|Actual saved source bytes differ|
|Early zeroing|State's first byte changes fromA5 to0 already at after-normalization|BSS cannot change before the first allowed zero store|
|Saved listing|Append bytes to capture-root annotated-disassembly.txt, keeping linked-audit authority unchanged|Actual annotated disassembly byte seal|

The exact strings are embedded in `controls()`. They use checker V2's sole new
listing check, `actual annotated disassembly byte seal`, whose source SHA256 is
`a792e16d4040c75953c7fb43466adf6787bf91efd625f1d6683764ac7bcf5dfe`.
V1 and V2 are saved as separate inputs; neither is changed here.

## Deliberate limits

Checkpoint-semantic controls preserve the original model instruction/access
traces. They deliberately contradict a literal checkpoint assertion, and must
fail that assertion before a later trace-to-snapshot comparison. They do not
pretend to describe a possible newly executed target path. This keeps the
independent expected result separate from the observed producer trace.

The two byte-seal controls intentionally retain their original claimed hashes,
because the property under test is that actual saved bytes are read and hashed.
The ledger-reply control intentionally retains the real saved snapshot while
altering one reply. Those three named contradictions are not incidental seal
mistakes. All other raw hashes and copied metadata remain consistent.

The same-value post-lock write has no necessary effect on captured CPU state;
its rejection proves the actual ledger policy is checked even if a declared
zero-mutation counter and all final bytes look correct. The late park register
mutation is made after the five paired checkpoints, so pairing alone cannot
reject it. The alias control intentionally violates a public register alias,
while the WINDOWBASE and SP controls preserve aliases to reach their distinct
normalization checks.

Input literal/linked-layout corruption, interpreter forbidden-access probes,
trace corruption and hardware fault injection are outside this34-control
driver. Root owns separate interpreter guard probes. No coverage of an omitted
control is claimed, and no passing control adds a firmware or device lifecycle.
If the first run finds a driver or oracle mistake, preserve its exact source,
copies and result before a separately explained correction.

`INPUTS.sha256` and `DRAFT.sha256` seal the static inputs and this draft. The
captured schema comes from the reviewed runner V2 and QEMU adapter V2; no
candidate report or raw execution capture was inspected to choose mutations.
