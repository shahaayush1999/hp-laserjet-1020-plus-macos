# Root static review of the copied-entry evidence controls

Reviewed the complete frozen runner and README before execution. Runner SHA256
`cc8fa2729fab0e19041aef810946de41c1917fb08593a3a93d01d02645a8edfc`;
checker V2 remains `a792e16d4040c75953c7fb43466adf6787bf91efd625f1d6683764ac7bcf5dfe`.

All writes to hardlinked copies replace a new inode atomically. Snapshot bytes,
hashes, register aliases where appropriate, snapshot lists, nested reports and
actual debugger replies are consistently propagated. Exact first rejection
strings agree with the frozen gate's check order. The alias control deliberately
keeps aliases inconsistent; WINDOWBASE/SP controls repair them to reach their
separate assertions. The second park mutation occurs beyond paired checkpoints.

The post-lock write changes no necessary CPU value, so the command envelope,
not an incidental state mismatch, must reject it. Source/listing corruption
intentionally contradicts original authority seals. Checkpoint mutations retain
original traces and must fail literal assertions before replay; they are not
invented target executions. Full before/after member checks protect the original
and retained baseline, and unexpected errors cannot count as successful controls.

No blocking implementation mismatch found. Full altered trees/deltas/results
must be retained. Root will execute sequentially after the running full suite;
this static review is not validation. The three separate input/linked-input/
layout controls have already passed and do not expand this runner's34-case scope.
