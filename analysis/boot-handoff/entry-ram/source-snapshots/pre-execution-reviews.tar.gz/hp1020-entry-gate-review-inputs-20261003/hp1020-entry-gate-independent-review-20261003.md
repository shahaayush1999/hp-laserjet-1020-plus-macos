# Independent entry capture gate: static review — 2026-10-03

Reviewer: `/root/usb_reference_contract`; gate author:
`/root/printer_class_reuse`; integration/execution owner: `/root`.

No result capture was opened. No candidate or checker was imported, parsed,
built, executed or validated; no repository file was edited. This review uses
the frozen literal acceptance plan/oracle, the gate's sealed source inputs and
current producer source text only.

## Reviewed identities

| File | SHA-256 |
| --- | --- |
| `/tmp/hp1020-entry-gate-draft-20261003/check-hp1020-entry-ram.py` | `b2189d70d8062a1a1788a86d05384d2e93ab5fecc71490c982b97a02a12aec09` |
| Gate `README.md` | `10a211b782b5addf96bb3f07a224baab698b55e8f75d676cf43661bfca837200` |
| Gate `INPUTS.sha256` | `dd2d0e72f5c631c4a605f709baa9acbaafbe471119939dc4152c6d6c81c155cb` |
| Repo `scripts/validate-hp1020-entry-ram.py` | `92117ccaee75de71768ad68417b7e693d8bc81437669d71061b7383d64ba2020` |
| Repo `scripts/hp1020_entry_machine.py` | `46cc66fc2ac1c22201ef6a33ee13eba4a54087bb416ccc1b8726aae2d2c98b07` |
| Repo `scripts/hp1020_entry_qemu.py` | `4ef9ffcfac58a326b68df526c8ddec93868cf18cf85eae76682a30ab9cf9d080` |
| Repo `scripts/hp1020_entry_audit.py` | `2f990f9f57731c49d8931138d32ce100fecd1d2fed722354f6c01117e52042eb` |
| Repo `scripts/hp1020_xtensa_call0.py` | `ed2924d8e46c0e553fe079a5ecdfff77dc40f1aa228588d9a86c39ce98769480` |
| Repo `scripts/hp1020_xtensa_properties.py` | `8a98e5ba3ead469cd431a06260e78c836993348d878ae96595d0b622538d0280` |
| Frozen literal oracle | `a5046eb1a84b67ef7f4461e9169cbd14c88024161d786fd1b7438677233718ee` |
| Frozen manual target32 layout | `c37ba6986d6ed7cb2dceb647902873e04302e7eb55256eb73ebdf26ea1df6f35` |

The repository path is
`/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos`.
Exact review copies and their manifest are preserved under
`/tmp/hp1020-entry-gate-review-inputs-20261003/`. The gate's original package
and bytes remain untouched.

## One concrete finding

**The exact audited disassembly file is outside the gate's checked seals.**
Gate lines 682–684 compare audit JSON, ELF identity and audit-source hash, but
never read `annotated-disassembly.txt` or check it against
`audit['disassembly_sha256']`. The target tree seal does not cover this file:
the runner writes it at capture root after copying target artifacts. Changing
or removing this file alone would therefore leave this gate's checks unaffected.

Add the narrow raw-byte SHA-256 comparison after checking audit identity. A
useful negative control changes only that file while leaving the audit digest
and all other evidence intact; it should fail specifically at this seal. This
is a preservation/identity omission, not evidence of an incorrect execution.
Root agreed to preserve V1 and apply a separate pre-execution correction.

## Bounded no-finding conclusions

- The source, target, input, snapshot and dependency schemas agree with current
  producer text. The gate independently reconstructs all seven initial regions
  from ELF file bytes and paints; it does not credit implicit BSS zeroing.
  Linked input and layout symbols have exact independently expected extents.
- The literal six-case CPU/paint matrix, all 32 initial physical registers,
  alias relation, normalized CPU values, initialized sentinel and zero spans
  match the frozen plan. Pre-finish reads actual production fields through
  independent hand offsets and distinguishes already-delivered END_DOC/pixels
  from the explicit finish invocation. Final mailbox, receive reuse suffix,
  output slots and untouched tails have independent byte expectations.
- Model instruction records are BE u32 PCs. Access records are exactly
  `>B3xIIII`, including zero padding; values and store-width masking match the
  producer's recording semantics. Signed L16SI loads record the unsigned raw
  read before register sign extension, so comparing the recorded load against
  unsigned RAM is correct. Every recognized load/store requires one matching
  access and no leftover access is accepted.
- Load/store width decoding agrees with the pinned BE opcode encoders. L32R
  independently uses the negative 16-bit word displacement and aligned PC.
  Direct J/CALL0 targets, CALLX0 identity and RET/RET.N pairing agree with the
  existing producer encodings; checkpoint replay occurs before the instruction
  at that PC, matching the producer's observation timing.
- Every replayed access stays within actual allocated objects, with narrower
  phase-specific stores and no inherited stack access. Read values use RAM as
  modified by preceding writes; reconstructed checkpoint/final RAM is compared
  byte-for-byte, including all otherwise private decoder storage. The final
  two PC records must be the independently decoded self-J and cannot hide an
  unmatched memory access or call.
- The native ledger is reconstructed as exact requests and replies, not
  accepted from a claimed zero-mutation counter. Constructor traffic removes
  the historical breakpoint before the only seed. WB precedes all physical AR
  seeds. Each snapshot's register and memory replies match saved raw evidence.
  Four ordered Z/c/PC/snapshot/z cycles and two s/snapshot cycles are required.
  A post-lock M/P, addressed continue, extra step, omitted reply or unexplained
  event fails the next exact ledger envelope. Cleanup is also tied to the
  reported reaped child and the ledger must be exhausted.
- QEMU V2 does not change successful ledger flow, so its approved failure-path
  changes do not require a successful-capture ABI exception here.

## Explicit limits of this review and gate

No other blocking raw-format or semantic mismatch was found statically. This
does not predict the first run will pass. The capture-only gate is deliberately
not a second arithmetic CPU interpreter: ordinary branch decisions, every
intermediate register value and computed base-register addresses are not
independently re-executed. In particular, non-control arithmetic fallthrough is
not fully reconstructed by its PC trace loop. Those limits are already stated
in the gate README; do not describe its trace checks as complete independent
CPU execution. Exact source-bound concrete execution plus the independent
native observations remain separate required evidence.

Likewise, the minimum-SP witness is bounded against the owned stack and actual
lowest access, but the gate does not reconstruct every SP update. Static linked
frame/callback analysis and changed-paint measurements remain distinct evidence.
Executable hashes without saved tool binaries are recorded provenance, not
independent proof of compiler or emulator identity. None of these artifacts
establishes physical CPU, loader, cache, controller, USB or printing behavior.
