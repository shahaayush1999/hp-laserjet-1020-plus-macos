# Independent one-entry capture checker draft

Prepared 2026-10-03 before the first candidate instruction execution. This
package has only been read as text. The checker has not been parsed, imported,
executed or validated. Root owns integration, all execution and any correction;
preserve this version before changing it.

`check-hp1020-entry-ram.py` exports
`check_capture(capture_root, source_root=None) -> (bool, detail)` and a CLI with
positional capture root and optional `--source-root`. It reads evidence only,
uses Python's standard library and imports no producer, interpreter, emulator
adapter, audit or independent-oracle module. The optional source root checks
current files against the saved source closure; omit it when validating a
historical archive after deliberate later source changes.

## Frozen expectations and saved inputs

The three CPU profiles, two nonzero paint pairs, all32 initial physical ARs,
352-byte input framing, six fragment lengths, one32-byte all-black page,
original document event and final64-word mailbox come from the independently
written literal oracle. Its unchanged SHA256 is
`a5046eb1a84b67ef7f4461e9169cbd14c88024161d786fd1b7438677233718ee`.
The target32 field layout is independently hand-derived from production
headers, with frozen table SHA256
`c37ba6986d6ed7cb2dceb647902873e04302e7eb55256eb73ebdf26ea1df6f35`.
Both files are copied under `inputs/` as provenance, never imported. The
actual linked input symbol and const layout table must match those literals.

`inputs/validate-hp1020-entry-ram.py` is the reviewed schema V2
`d2cf439c0adcaf661a0154bae735ee2d5adcfb37240dbb9d9bec972adb1c0025`.
Later audit-only build handling does not change the successful capture schema.
The saved QEMU adapter V1 and V2 have the same successful command envelope;
V2 fixes only failure cleanup/identity/rejected-command preservation. Their
source copies are API/schema evidence, not independent semantic authorities.
`INPUTS.sha256` seals all input copies and `DRAFT.sha256` seals this package's
three top-level artifacts. No prior draft is represented as executed.

## Checks performed by the proposed gate

- Exactly six paired cases, with initial plus four ordered model observations
  and those same five QEMU observations plus two real park steps. Every
  register and byte of all seven supplied regions is paired, including the
  entire owned stack, decoder storage, gaps and inert vector islands.
- Independent ELF32BE parsing requires the fixed allocated objects and13
  nonoverlapping load segments. Initial RAM is reconstructed from the literal
  poison pattern plus file-backed ELF bytes, then the independent BSS/stack
  paints. No loader zeroing of NOBITS is used or credited.
- Before C, all129224 BSS bytes must be zero and data, stack, gaps and islands
  must be unchanged. At the first actual finish entry, the literal page and
  original document event already exist, all six packets have been consumed,
  the live generation is1, and the document/output remain unfinished. The
  later park must show the separate explicit finish, complete mailbox,
  exact4096-byte receive storage, exact32768-byte output storage and all tails.
- Actual compiler-layout offsets are checked against the independent table
  before reading production flags. Final stack paint is recomputed from bytes;
  it does not replace the separate minimum-SP/access witnesses.
- Model step and access trace digests/counts are checked, then every recorded
  load/store is replayed in order from the independently reconstructed initial
  bytes. Each actual encoded memory instruction consumes one matching record;
  reads must equal current RAM, source store values are masked by width, and
  permitted ranges/phases are checked before writes. Checkpoint and final RAM
  must match the replay. Literal loads, direct jumps/calls, own call/return
  nesting, seven normalization writes and two terminal self-J instructions
  receive additional encoding/identity checks.
- The QEMU host ledger is consumed as one exact command sequence, including
  constructor traffic. It must contain exactly one complete seed before lock,
  WINDOWBASE before the physical AR seeds, initial read-back, four ordered
  breakpoint/continue/remove cycles, and two park single steps. Every p/m reply
  inside a snapshot marker is compared to actual saved registers/memory. No
  later M/P/G/X, addressed resume, helper reset, hidden command or unexplained
  event can be accepted by a claimed zero-intervention counter.
- Source and target member sets/hashes, all actual compiler dependencies,
  copied target headers, input bytes, exact-version QEMU source closure,
  linked-audit identity and complete raw region/ledger seals are checked.

## Independent bounded instruction decoding

The checker is deliberately not another CPU emulator. It independently decodes
instruction widths, the admitted ordinary load/store classes, L32R, CALL0,
CALLX0, RET/RET.N, J and the seven exact WSR encodings. These rules come from the
existing pinned big-endian binutils overlay, complete copy
`inputs/pinned-xtensa-modules.c`, SHA256
`c9899233c5d134ad55329b57e05809b328c4a86b7455b5cbe5a56dd7ac07d29c`.
Its upstream revision is `1e225492405c82b0b7b9973d8f549e1411168e3d`:
https://github.com/espressif/binutils-gdb/blob/1e225492405c82b0b7b9973d8f549e1411168e3d/bfd/xtensa-modules.c
Relevant declarations are operand decoding near1419/2095, opcode encoders
near6171–6593 and instruction lengths near12265–12300. No objdump or producer
decoder is invoked by this checker.

Modern `.xt.prop` records establish actual encoded instruction boundaries;
nonexecuted data, literal and unreachable padding never become instruction
boundaries. The sole mixed INSN|DATA exception is the exact six-byte linked
before-C CALL0 and adjacent park span with flags0x2906. Both target encodings
are independently checked. This exception follows the pinned GAS producer:
`gas/config/tc-xtensa.c:12157–12212` first sets DATA for an empty no-transform
fragment, then INSN, and serializes both bits. Complete source copy SHA256
`adc8a0e97548e11fae18a7859418b063dd12fa31d64abea89f4899e951dc184d`:
https://github.com/espressif/binutils-gdb/blob/0104f7d3c1a3e55954bf7b09fc70dd542b910714/gas/config/tc-xtensa.c
The matching property-bit header copy has SHA256
`aecfb03e0d322454de00416db604e3fbcf461389a613856323edf0c8d6f0f58e`:
https://github.com/espressif/binutils-gdb/blob/0104f7d3c1a3e55954bf7b09fc70dd542b910714/include/elf/xtensa.h

The QEMU register numbers and alias interpretation are pinned to official
v11.1.1 source, not the different binutils debugger overlay. Their exact URLs
and hashes are in `inputs/qemu-provenance.json`; the checker requires those
full original source bytes in each captured QEMU closure.

## Limits and first-run integration

The gate does not independently recompute every arithmetic register or branch
condition, prove compiler correctness, or replace the complete linked opcode
audit. Ordinary computed addresses, minimum SP and indirect-call targets are
cross-checked through the actual access/call records and full paired captures;
only the listed encodings have additional direct decode. Private decoder bytes
are fully paired/replayed, not assigned an invented independent final layout.

Tool executable/libgcc hashes are recorded producer metadata because those
executables are not all copied into this capture. Their configuration/header
bytes and actual linked target bytes are independently sealed. Trace seals are
over decompressed semantic records; gzip containers are covered by the outer
archive, not a distinct producer digest. This verifies evidence consistency,
not cryptographic attestation that a trusted capture process actually ran.

Root must first statically review and integrate this draft, then run it on the
first successful frozen capture. Any ABI/oracle mistake must preserve this
version and the first failure before a narrowly explained correction. Copied-
evidence controls should separately mutate initial paints/physical ARs,
pre-C zeroing, pre-finish flags/pixels/event, exact layout, access values/ranges,
post-lock host writes, ledger replies, terminal bytes/steps and saved source
bytes, while maintaining unrelated seals so the intended independent check is
exercised. No such controls have been run by this agent.

No physical CPU, loader, RAM mapping, interrupt delivery, DMA/cache, USB,
controller, engine, printer or power-cycle behavior is proved. Inert software
park and a correct RAM page are only this bounded offline experiment.
