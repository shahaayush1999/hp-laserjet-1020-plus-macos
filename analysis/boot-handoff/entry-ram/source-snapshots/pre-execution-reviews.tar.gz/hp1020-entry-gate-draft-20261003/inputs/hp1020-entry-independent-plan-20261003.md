# Independent acceptance plan: one entry to completed RAM document

2026-10-03. Author: `/root/usb_reference_contract`. This plan is written before
reading the candidate assembly, linker script, workload C or runner. It uses
the frozen CPU/layout reviews, the lead's decision note, existing production
receive/document/image contracts and the new public mailbox header only. No
candidate, generator, validator, compiler, import or emulator was executed.
The companion Python file is an unexecuted literal oracle, not a runner.

## What this experiment should establish

Start exactly once at `0x100167a8`, with deliberately nonzero writable RAM and
distinct incoming physical registers. The new entry must itself establish the
admitted CPU state, its own stack and exactly three zeroed objects, then call
the unchanged full receive/document/image composition. Feed the fixed small
black ZjStream through supplied successful RAM transport completion. Observe
32 literal `ff` bytes and original event `(1,1,0,1)` before explicit end-of-input.
The C call then finishes once, returns to the entry's own park and stays there.

This removes per-function supplied stack/CPU/BSS resets from this bounded
software path. It does not prove a ROM handoff, cold boot, loader packaging,
physical RAM ownership, cache or TLB state, controller activity, USB events,
DMA settlement, video representation, engine operation or printing. The new
layout intentionally reuses old HP private data/ACL addresses. Those old
addresses are not retained as a compatible private ABI.

## Frozen independent inputs and admission

- CPU review: `/tmp/hp1020-entry-cpu-contract-review-20261003.md`, SHA256
  `52da0feb834455c18c5581c1058a4107b4619f24328ec78297b14a011c9c5054`.
  Its byte evidence independently identifies the original entry, ordinary
  special registers and the excluded TLB boundary. Do not execute the original
  ENTRY or initializer. The stock ELF is
  `2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`.
- Layout review: `/tmp/hp1020-entry-layout-review-20261003.md`; source snapshot
  manifest `75c24748a97f07562372a96baa53ef8c5f4482f76be981a69ab888ff6841c380`.
  The relevant stock-declared main span is `[10003000,100351e0)`, not a probe
  of total physical RAM. Component state and contiguous memory remain13496
  and114704 bytes. Neither is reduced for this small page.
- Lead decision: `/tmp/hp1020-entry-root-decisions-20261003.md`.
- Public workload header:
  `/tmp/hp1020-entry-workload-draft-20261003/hp1020_entry_workload.h`, SHA256
  `8602f2588f768c694fdbace5923ab785149eba4f25bb2c8f9414ed47b6773287`.
  This is schema and scheduling input, not evidence that its implementation
  satisfies the schema.
- Existing fixture `analysis/open-firmware-model/image-core/fixtures/32x8-stripe4-black.jbg`,
  SHA256 `78744d4c1f1f3ac06000192663330834b02b277df26f790aaa340ac322e9cf99`.
  Literal bytes:
  `000001000000002000000008000000041000035cfd98ff02ff02`.
  Its independent decoded result is32 bytes of `ff`.

Supply privilege, usable exclusive loaded RAM, PC-relative L32R mode and no
asynchronous IRQ/NMI/debug event. Do not initialize or discover those physical
conditions in this experiment. Incoming LEND must not intersect execution
before the entry has disabled loops. No privilege recovery or arbitrary active
loop recovery is claimed. All initial PS values below have UM/RING clear.

Verify the installed QEMU core's debugger register mapping before first launch.
Root retrieved exact-version official QEMU11.1.1 source after the stopped
debugger did not advertise target XML. I independently read and hash-matched
the four files in `/tmp/hp1020-entry-qemu-primary-20261003/provenance.json`
(manifest SHA256 `a207e83239270e8cd09763a9b96e80e733745e2e74d70cd44337ee27dc88f100`).
`target/xtensa/core-test_kc705_be/gdb-config.c.inc:24–65,118,145,159`
identifies PC0, physical AR0..31 at1..32, loops33..35, SAR36, WB38, WS39,
PS42, INTENABLE110 and logical a0..a15 at124..139. Register37 is PREFCTL and
83 is DBREAKC0: neither is the optional literal-mode/INTENABLE register guessed
from another GDB configuration. `gdbstub.c:122–152` writes SR state directly,
whereas each physical-AR write synchronizes the logical window. Set WB before
seeding all32 physical ARs, and read back physical/current-window aliases.
`core-isa.h:49–67` has32 ARs, loops/windows and
`XCHAL_HAVE_ABSOLUTE_LITERALS=0`, so PC-relative literals are configured for
this emulator; no LITBASE write is needed or admitted. Preserve the exact
installed version/core identity as well as source hashes. This is not a probe
of HP's optional CPU configuration. The pure oracle uses semantic names,
deliberately no debugger register numbers.

## Fixed memory contract

| Object | Half-open target interval | Rule |
|---|---|---|
| Main observed envelope |10003000..100351e0|Paint gaps, overlay file bytes, retain full captures|
| Code/literals/rodata/input budget |10007000..1000d000|Only audited actual executable ranges may be fetched|
| Initialized sentinel |1000d020..1000d120|256 exact file bytes, never zeroed or written|
| Document state |1000e000..100114b8|13496 bytes, zero at pre-C|
| Owned stack |10012000..10014000|8192 bytes, SP starts at10014000; pre-C paint untouched|
| Mailbox |10014040..10014440|1024 bytes, zero at pre-C|
| Entry island |10016780..100167e0|Immutable candidate bytes; entry at100167a8|
| Document memory |10016800..10032810|114704 bytes, zero at pre-C|

Explicit unchanged guards are `1000d000..1000d020`, `1000d120..1000d140`,
`1000dfe0..1000e000`, `100114b8..100114e0` (40 bytes),
`10011fe0..10012000`, `10014000..10014020`, `10014020..10014040`,
`10014440..10014460`, `100167e0..10016800`, `10032810..10032830`.
All omitted main-envelope gaps and the tail to100351e0 are equally protected;
checking only named guards is insufficient.

Selected immutable external islands are `[10000000,10000184)`,
`[10000200,1000023c)`, `[10000270,10000350)`, `[10000370,1000049c)`,
`[10100020,10100304)`, `[10100320,1010032c)`. Do not admit their gaps as RAM.
New vector self-parks/interface pointers are inert candidate contents, not
exception support or retained stock services. An unexpected park is failure,
not successful completion. No vector path is deliberately invoked here.

The initialized sentinel is the16-byte pattern
`31 52 73 94 b5 d6 f7 18 39 5a 7b 9c bd de ff 20`, repeated16 times.
Require the ELF's actual file-backed bytes to contain it. No runner write may
repair a missing sentinel after loading.

Load only actual file-backed bytes. Then poison the three entire zero ranges
and independently paint the stack. ELF NOBITS handling must not zero them.
Record initial complete RAM/islands and registers before the one entry.

## Positive matrix: six continuous executions per engine

Cross each of the following three CPU profiles with two paints: BSS `a5`, stack
`5a`; and BSS `cc`, stack `96`. Every one of the129224 owned BSS bytes is nonzero
before execution. The input, initialized data, guards and islands remain their
recorded loaded bytes. Give each profile all32 distinct physical AR values
`0x8a000001 + profile_index*0x00100000 + i*0x00010101`, with `i=0..31`.
None supplies the eventual valid stack. Set physical ARs, not sixteen aliases
followed by a hidden window change. Assert their read-back image is exact.

| Profile | PS | INTENABLE | WB | WS | SAR | LBEG/LEND/LCOUNT |
|---|---:|---:|---:|---:|---:|---|
|ordinary privilege|00000000|0|0|01|0|0/0/0|
|dirty window3|00070302|1|3|89|37|10003000/10003020/17|
|dirty window7, EXCM|00050711|2|7|c1|63|10003040/10003060/65535|

The dirty profiles have WOE and nonzero CALLINC/OWB, valid selected current
window bits, nontrivial loop/SAR state and supplied absent asynchronous events.
These are bounded admissible alternatives, not every possible boot state.
Keep optional literal mode explicitly PC-relative in all six. The associated
hardware register, if exposed by the selected emulator, is supplied once;
startup is not licensed to write it by this plan.

Each interpreter/QEMU pair starts from identical bytes and semantic physical
register values. Cross-profile final arbitrary registers/stack bytes need not
match: a harmless retained register value may be spilled. All required outputs
and protected bytes must match the independent oracle for every profile.

## Execution and observations without repair

There is one initial CPU setup, one entry, one C call and one terminal return.
No `QemuRAM.call0`, `reset_cpu`, per-C-call return sentinel, forced PC advance,
stack reseed, BSS rewrite or hidden helper call is allowed between observations.
Debugger stop/resume may observe, not repair. A stopped PC is resumed at that
same instruction. Do not use software breakpoint patching of immutable code
without preserving and accounting for it; prefer the existing nonmutating
debugger stop mechanism and compare actual loaded bytes.

At the pre-C checkpoint, before CALL0 or a C prologue/initializer can mask a
bad entry:

1. Check every byte of state13496, memory114704 and mailbox1024 is zero.
2. Compare every other main/island byte with the initial image. In particular
   the stack is still painted and the data sentinel is intact. An overly broad
   zero sweep crossing the stack/entry island fails even if C later works.
3. Require PS=`0x0000000f`, INTENABLE0, WINDOWBASE0, WINDOWSTART1,
   LBEG/LEND/LCOUNT0, SAR0 and physical/logical a1=`0x10014000`, aligned16.
   Capture all32 ARs. Do not invent an all-GPR-zero requirement for call0.
4. Confirm the next intended CALL0 enters the linked workload exactly once;
   no earlier C initializer or helper ran. Check actual stack establishment
   precedes every stack access, CALL0 and C operation.

Use a read-only observation at the **first actual
`hp1020_usb_document_finish` entry** to distinguish an END_DOC notification
from an EOF-created result. Before its first instruction, pixels are32 `ff`,
the callback already copied `(1,1,0,1)`, all six receive reservations are
consumed, generation is1, count0, stopped0, finished0 and quiescent0. The final
mailbox snapshot fields may not yet be filled; read the production fields
using measured target member offsets, independently checked against headers,
or preserve an equivalent ordered read-only execution witness. The callback
itself must reject execution during/after finish. A read-only extra checkpoint
does not split the continuous run into fresh CPU calls.

At the terminal success park:

- Require the designated success PC, not the unexpected-vector/failure park.
  Observe at least two further executions of its local self-branch without any
  new write/call, or a bounded equivalent instruction witness. There is no
  return through an incoming a0 and no controller polling.
- Require SP10014000, PS0xf, INTENABLE0, WB0, WS1 and loops0. Compiled C may
  legitimately change SAR; do not require final SAR0. Capture all32 ARs and
  compare the two engines for the same initial profile.
- Require the exact mailbox contract below, unchanged sentinel/guards/islands/
  code/input and protected gaps, and independent receive/output storage bytes.
- Compare full state, document memory, mailbox and stack between engines for
  the same case, after independent semantic checks. Pair equality is additional
  evidence, not the oracle for output or initialization.

## Literal input, ownership and final mailbox oracle

The companion source reconstructs the352-byte input from the literal BIH/BIE
and fixed ZjStream chunk/item numbers, without importing a producer. It uses
the established small profile: width32, height8, stripe4, standard600dpi/BPP2
page metadata. The first32 decoded bytes are the independent literal `ff`
result; no pixel expectation is decoded by the candidate under test.

Public workload scheduling is six reserve/copy/complete_data/pump steps with
lengths64,64,64,64,64,32. Each must retain its original ticket `(1,1)` through
`(1,6)`, use that ticket for supplied completion and consume before reuse.
This is supplied settled RAM transport, not the descriptor/physical controller
path. Only after pumping all input and observing the page/document does the
caller close local admission and call finish once. No receive_stop precedes
finish, no restart or generation change, and no external quiescence is supplied.

One final eight-row view at stride4/final1 is accepted and completed in software
exactly once. The callback only uses ring peek/accept/complete, never reenters
document feeding. One document callback retains original event fields by value.

At park the64 BE words and actual32 mailbox pixel bytes must agree with the
literal helper. Principal exact facts are: PASS2/error0/DONE5; zero scan129224;
data scan256; input/fed352; copy/reserve/complete/pump6; finish1; receive
generation1/issued6/consumed6/count0/stopped1/quiescent0/finished1; one output
call/accept/complete;32 pixel bytes; one event `(1,1,0,1)`; parser documents,
stream pages, drained pages and completed documents all1; copied/accepted/
completed rows all8; nonfree output slots0; last original ticket `(1,6)`;
last fragment32; final1/rows8/stride4; all recorded errors0; exact state/memory
sizes13496/114704. Mailbox bytes288..1023 remain zero.

The literal helper independently simulates receive storage writes, not parser
or queue internals. Receive slots0/1 are reused: slot0 holds input256..319;
slot1 holds input320..351 then retains its earlier bytes96..127 in its32-byte
suffix. Slots2/3 retain input128..191 and192..255; all other receive bytes are
zero. Do not zero a released slot or forget the retained suffix in the oracle.
The4096-byte receive FNV is checked against these actual bytes.

Output storage at1002a810 has32 bytes of `ff` followed by32736 zero bytes.
Its entire32768-byte FNV is computed independently. The semantic compression,
history, decoder-band and internal state regions need not be independently
reimplemented in this small oracle: check their bounds, production witnesses
and paired complete captures. Claiming an independent byte oracle for those
private internals would overstate this experiment.

## Closure, accesses and stack evidence

Audit the entire actual linked closure, not only new assembly: all executable
sections, resolved calls/jumps, compiler/libgcc helpers, memory functions and
callback targets. Preserve source/fixture/compiler/profile/ELF/map/symbol/
disassembly/stack-use hashes. Check exact target object sizes and no unexpected
writable global, unresolved symbol, host pointer, stock callback, heap or host
runtime. The24KiB text budget is an assertion to measure, not an assumed fit.

Admit the narrowly reviewed standard special-register prefix only. No ENTRY,
windowed call/return, LOOP, exception return, cache/TLB/debug/timer operation,
custom instruction, MMIO or controller/engine register address becomes allowed.
Normal compiler SAR operations remain ordinary admitted instructions. A
special-register operation outside its approved role fails the closure audit.

Instruction fetches stay in resolved executable code. Ordinary data reads stay
in the actual admitted read-only objects or owned mutable spans; guards and
unused holes are not scratch objects. Startup writes only its three zero spans;
post-C writes only state, memory, mailbox and owned stack. Validate each complete
access width, alignment and overflow. Record forbidden access rejection before
any external/emulated side effect, rather than rely on QEMU's address space.

Track actual a1 after it is established, call-boundary16-byte alignment, the
lowest stack read/write address and the lowest changed painted byte. Preserve
both8KiB stack captures and guards. Paint scanning can undercount a store whose
value equals paint; concrete minimum SP/accesses are complementary. Neither a
single page's measured high-water nor the preliminary608-byte call-chain sum
proves a maximum for all valid inputs. Review the linked call graph, tail calls,
inlining, both callbacks, memory routines and libgcc frames; unresolved indirect
calls, recursion or dynamic stack growth must remain an explicit limit or fail
admission. The stack budget does not become a physical RAM-size claim.

## Required meaningful controls, separate from positive cases

Freeze these before results. Negative controls modify isolated copies of paired
evidence and update ordinary hashes/paired values where feasible, so rejection
cannot be explained only by pair mismatch. Do not execute modified hardware or
custom paths. A separate source/hash control can test seals by name.

1. Leave one nonzero byte at each of the first/middle/last positions of each
   zero range in the pre-C capture. Every position must fail the full-range
   oracle even if final pixels/counters are correct. C scan-failure controls,
   if added later, must preserve their own bounded execution status separately.
2. Change one initialized-sentinel byte, one stack byte before C, one guard,
   one omitted gap and one entry/island byte in both paired captures. Each
   immutable-range check must fail with the exact address.
3. Change PS, INTENABLE, WB, WS, a1 alignment/top, each loop register or pre-C
   SAR in both witnesses. Each field must be rejected independently. Include
   correct logical a1 but wrong physical register/window mapping as a harness
   admission control, not an accepted dirty state.
4. Replace one actual output byte, rehash pixels and full output storage, and
   make both engines agree. The32-`ff` oracle must reject it.
5. Change original document generation or identity in both evidence sets.
   Separately move first successful event after finish. Original tuple and
   pre-finish/order checks must reject these despite final PASS.
6. Clear the retained32-byte receive-slot1 suffix and update its FNV in both
   captures. The independent six-write storage oracle must reject the change.
7. Change full input bytes and all redundant input hashes while leaving the
   known32-pixel result. The literal352-byte input oracle must reject it.
8. Add a hidden host reset/re-zero between pre-C and park while preserving
   final snapshots. The event/runner audit must reject intervention; final
   data alone cannot detect or prove its absence.
9. Redirect a permitted store past any owned interval or into a guard/entry
   byte in a bounded interpreter-only guard test. Reject before performing it;
   do not broaden QEMU/hardware allowances to run that control.
10. Claim success at a failure/unexpected park, with a write on the second park
    iteration, or with SP outside the owned stack at a call. Control-flow and
    concrete-access checks must reject each, not accept only a PASS mailbox.

These are a test plan, not completed control executions. Later runner/gate
implementation and any discrepancy must be preserved separately from this
initial oracle. Do not revise an expected literal merely because the first
implementation produces something else.

## Evidence deliverables for integration

For each of six profiles in each engine save initial registers/full RAM,
pre-C registers/full RAM, first-finish event/state witness, terminal registers/
full RAM, immutable-island captures, exact input, full mailbox and bounded
execution/access/call/host-intervention logs. Save measured stack witnesses and
the full linked-source/tool provenance. Report observed completion separately
from rejected controls and excluded hardware assumptions. A successful result
is one continuous software-entry experiment per supplied state, not a native
HP lifecycle or a working firmware replacement.
