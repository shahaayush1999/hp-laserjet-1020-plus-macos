# Entry runner V1 independent static review — 2026-10-03

Status: static review only. No candidate import, syntax parse, build, interpreter
execution, QEMU execution, validator, or device access was performed by this
reviewer. The independent literal oracle and acceptance plan were frozen before
the candidate sources were read. This note reviews the unchanged runner V1;
proposed corrections are not validated by this review.

## Exact reviewed inputs

| Input | SHA-256 |
| --- | --- |
| `entry-integration-20261003/validate-hp1020-entry-ram.py` | `0cc34a851c9758aa7ebd4577226a6b90b5dab777a80ce65728dcba272484d403` |
| `entry-integration-20261003/build-hp1020-entry-ram-target.sh` | `891d55135f70e7a8df21cb7af4b69e4c27efbc2e31e6c75a06e8ce5c84045ffe` |
| `entry-integration-20261003/hp1020_entry_machine.py` | `46cc66fc2ac1c22201ef6a33ee13eba4a54087bb416ccc1b8726aae2d2c98b07` |
| `entry-audit-draft-20261003/hp1020_entry_audit.py` | `5ca4f1672967f0606fdcbab2cfe94571076beab69cf0171ae52675afbfaf2297` |
| `entry-startup-draft-20261003/startup.S` | `c1184dd473f513189cfbbdee6e059a1ac429bbec962ada1c048dd0a433e4433f` |
| `entry-startup-draft-20261003/entry.ld` | `de92c21e52ec9c250d5ced551f31d4ead06b40fedd354d560d1b95377fb46bf0` |
| `entry-workload-draft-20261003/hp1020_entry_workload.c` | `6b84d6a1168630402483d0c5dd397a0d2b8335fa502d2e01ef7049f66dd62090` |
| `entry-workload-draft-20261003/hp1020_entry_workload.h` | `8602f2588f768c694fdbace5923ab785149eba4f25bb2c8f9414ed47b6773287` |
| `entry-layout-witness-draft-20261003/hp1020_entry_layout.c` | `7e28ba53b54c168b3ed4b1d217922666eee895aca980f7a77d57721247983e05` |
| `entry-layout-witness-draft-20261003/expected-target32.json` | `c37ba6986d6ed7cb2dceb647902873e04302e7eb55256eb73ebdf26ea1df6f35` |
| `hp1020-entry-literal-oracle-20261003.py` | `a5046eb1a84b67ef7f4461e9169cbd14c88024161d786fd1b7438677233718ee` |
| `hp1020-entry-independent-plan-20261003.md` | `45c4a5366baff6e6db7650a7114be8bf8639be6b05a7ad12138aa375ae4bb8c1` |
| `entry-qemu-adapter-draft-20261003/hp1020_entry_qemu.py` | `2e6ef12dcee6c163298e9a4a76e05c98ede6ba6adf111a7d7614f73964166711` |

All abbreviated paths above start with `/tmp/hp1020-`, except the two already
fully named `hp1020-entry-*` paths, which start with `/tmp/`. Exact review-input
copies and a manifest accompany this note in
`/tmp/hp1020-entry-runner-review-inputs-20261003/`.

## Corrections needed before the first execution

1. **A source-seal failure in `finally` is reported as failure but exits zero.**
   Runner lines 338–344 catch the final source verification exception, change
   report status, and save the report without raising. If all cases passed, the
   previously printed pass message and successful exit remain. Audit-only return
   has the same finally behavior. Preserve the failure report first, then fail
   the process; do not obscure an already active exception. Root independently
   identified the same issue before this note.

2. **The V1 audit's `.su` closure omits the new const-only layout translation
   unit.** Builder lines 29–40 compile `hp1020_entry_layout.c` with
   `-fstack-usage`, while audit lines 25–30 and 498–500 require an exact name set
   without it. Pinned GCC 14.3.0 `gcc/toplev.cc:1845–1853` opens the `.su` file
   during initialization whenever this flag is enabled outside LTO/debug-compare,
   before any requirement for a function body. Its SHA-256 is
   `b4fc386d6dadc5181b5c5029e39ad0055ac02a2cba5d3e69cfad53b9b7ab2471`.
   The audit author has separately frozen the narrow V2 name-set correction
   (`f8a06e54e000f0dba9a120ff9dcbf99f0b8ca75146f2fd0be778e2d6eda705fd`).
   Keep the exact closure rather than allowing arbitrary `.su` files.

3. **Preserve the exact property-aware audit disassembly.** The audit API asks
   its caller to preserve `program.entry_audit_disassembly`; runner lines
   315–316 save only the returned JSON. Builder `objdump -d` is a separate
   listing, not this exact audited text. Save/hash the returned listing before
   either execution engine. Root independently identified the same omission.

4. **Partial target output currently escapes the fresh failure capture.**
   `command(build)` raises before runner line 312 copies the target directory.
   A failed build can leave mixed older/new target files in the shared output
   directory, without the partial files in the failure capture. Save the prior
   output separately, build in a fresh target directory, and snapshot partial
   output in a failure-safe path. This is a preservation issue, not permission
   to treat incomplete artifacts as audited. Root already planned this fix.

5. **Seal the actual compiler and QEMU primary input closure.** Builder invokes
   the GCC driver for C and linking; runner lines 230–245 hash explicit
   `PREFIX-as/ld` and libgcc, but that does not identify the driver's actual
   cc1/as/ld/collect2 paths. Also `source_files()` excludes `.inc` primary-map
   inputs, and the runner does not explicitly select the primary-source path
   consumed by the QEMU adapter. Record the actual driver-resolved tools and
   standard headers; retain all four exact primary source files and provenance,
   and explicitly pass their sealed path. Root independently planned this
   source-closure correction. No external hardware fact follows from it.

6. **Add an exact linked-input check.** `make_input()` independently compares the
   saved 352-byte stream with the frozen literal stream, but after linking only
   `hp1020_entry_layout` is compared byte-for-byte with its independent table.
   Read the linked `hp1020_entry_input` symbol's exact file-backed span, check
   its extent and compare every byte with the frozen literal input before
   execution. Runtime FNV, page output and final receive-slot contents provide
   useful checks but do not replace this straightforward linked-input claim.

## Bounded no-finding conclusions

- The linked audit runs before either candidate execution engine. The input is
  independently constructed and checked before the build. Target bytes loaded
  by `initial_regions()` are only PT_LOAD file bytes; there is no implicit
  `memsz-filesz` zero fill. All three BSS ranges and the owned stack are painted
  nonzero after file overlays, so startup must perform the observed zeroing.
- The after-normalization and pre-C markers align with the new assembly. The
  former preserves all supplied RAM; the latter requires all 129,224 BSS bytes
  to be zero while initialized data, guards, stack and immutable islands remain
  untouched. The independent CPU normalization checks are applied at both.
- The pre-finish breakpoint is the actual production finish entry. Its
  production fields are read using the frozen manual offsets after checking
  the complete 65-word compiler `offsetof`/`sizeof` witness. This establishes
  the intended distinction between an END_DOC event already delivered and a
  later explicit finish call.
- The concrete machine limits every memory access and records instruction and
  access streams. It does not restart CPU/BSS between phases. The native adapter
  seeds once and captures actual registers, physical/logical aliases and all
  seven complete RAM envelopes. The five paired observations compare every
  captured byte and all registers, including the owned stack.
- The native path requires two actual steps of the park self-jump and unchanged
  full state. The concrete path independently requires two park steps without
  new accesses/calls. No forced PC assignment or hidden call helper joins phases.
- The workload checks zeroed storage before production initialization, preserves
  the initialized sentinel, uses six original-generation reservations, copies
  the actual accepted pixel view, and verifies the page/document event before
  the sole explicit finish call. No quiescence promise is fabricated.

## Limits and follow-up checking

The `.su` files bound individual static frames, not every possible callback or
linked call path. This experiment additionally bounds the actual six-fragment
workload's stack accesses and minimum SP; it cannot claim an all-input stack
bound. All painted stack bytes are captured, so the later independent checker
can calculate changed-paint high-water as a separate witness. The runner does
not yet emit that derived witness directly.

No candidate has executed as part of this review. Actual assembler emission,
strict section/property admission, direct QEMU register mapping and complete
model/native equality remain first-run checks. Reusing numeric HP addresses in
a new offline layout is not loader compatibility, cold boot, cache/TLB setup,
USB operation or physical printing evidence. The separate QEMU failure-path
review remains applicable; its V1 fixes must be preserved as a separate V2.
