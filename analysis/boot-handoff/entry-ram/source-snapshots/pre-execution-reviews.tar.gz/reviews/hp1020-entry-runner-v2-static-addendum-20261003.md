# Entry runner V2 static delta confirmation — 2026-10-03

Reviewed without importing, parsing, building or executing candidate code.
V1 review remains unchanged at
`/tmp/hp1020-entry-runner-independent-review-20261003.md`, SHA-256
`7b8d1ce83e7610457054cefb9379854f472ea6f553a54024f48b1b501e87c55e`.
Its restored exact V1 input copies have manifest SHA-256
`f05a7b29d3f299391593623d753fe2d742b90cff938e38879a0b3af60ff8d1ad`.

Reviewed runner V2:
`/tmp/hp1020-entry-integration-20261003/validate-hp1020-entry-ram.py`, SHA-256
`d2cf439c0adcaf661a0154bae735ee2d5adcfb37240dbb9d9bec972adb1c0025`.
Builder remains V1 SHA-256
`891d55135f70e7a8df21cb7af4b69e4c27efbc2e31e6c75a06e8ce5c84045ffe`.
Expected audit V2 separately adds the const-only layout `.su` member, SHA-256
`f8a06e54e000f0dba9a120ff9dcbf99f0b8ca75146f2fd0be778e2d6eda705fd`.

No new blocking issue found in this bounded V1-to-V2 delta:

- Existing target output is copied to the new capture before removal. The new
  build's partial or complete target directory is copied from a finally block,
  so a build failure preserves both the prior artifacts and the new attempt.
- A final source-seal failure now persists `status=fail` and the seal error,
  then raises. This also overrides an audit-only return and makes that outcome
  nonzero. Any earlier exception and traceback remain in the report.
- Every primary QEMU input file, including `.inc` and provenance, enters the
  source closure. The sealed primary-source path is explicitly selected before
  execution; the adapter independently checks the fixed hashes at use time.
- The exact property-aware disassembly returned by the audit is saved before
  execution, alongside its already-reported SHA-256.
- The compiler closure now records GCC-selected cc1/as/ld/collect2 and libgcc,
  plus selected external binutils and target header copies. Configuration,
  specs and search-directory output are retained and hashed.
- The linked constant input's 352 file-backed bytes are compared with the
  independent literal stream before any execution. This closes the concrete
  linked-byte gap identified in the V1 review.
- Stack paint diagnostics derive from the complete final paired RAM capture.
  They explicitly acknowledge that stores equal to the paint are invisible;
  minimum SP and concrete access addresses remain separate witnesses.

These changes do not alter candidate instructions, declared memory envelopes,
CPU profiles, workload semantics, checkpoint sequence, native continuation
rules or the independent expected page/document result. The first build may
still expose genuine section/ISA/tool-layout incompatibilities; they are not
implicitly waived. The QEMU adapter's separate frozen V2 failure-path fixes
and an independent capture gate remain separate inputs to root's integration.
