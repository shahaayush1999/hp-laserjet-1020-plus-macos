# QEMU adapter V2: static delta confirmation

2026-10-03. Read only the preserved V1-to-V2 patch and corresponding reviewed
flow. V2 source is `/tmp/hp1020-entry-qemu-adapter-v2-20261003/hp1020_entry_qemu.py`,
SHA256 `4ef9ffcfac58a326b68df526c8ddec93868cf18cf85eae76682a30ab9cf9d080`.
No import, parsing, build or execution. The original review and V1 are unchanged.

The three reported issues are addressed in source: command-count failure now
enters the existing rejected-command logger; a child still alive after interrupted
communicate receives a bounded kill/reap attempt and remains retryable if still
alive; finally preserves available partial constructor identity without another
process launch or debugger query. Requested machine/core are labeled as requested
in partial metadata rather than substituted for an observed launch.

Earlier cleanup attempts remain distinct ledger events; the final cleanup result
can legitimately replace the current in-memory result while the original main
failure stays recorded. No successful seeding, checkpoint, readback or park command
sequence changed. The independent capture gate therefore uses the same positive
ledger envelope and requires one successful final cleanup. Runtime cleanup and
failure-control behavior remain unexecuted here.
