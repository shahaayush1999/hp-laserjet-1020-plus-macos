# Direct QEMU single-entry observer draft

Author `/root/usb_reference_contract`,2026-10-03. **Unexecuted and unparsed.**
No Python module was imported, no compiler/build/validator/QEMU was run, and no
repository file was changed. V1 followed the separately frozen independent
plan/oracle before candidate sources were read. This V2 preserves that contract
and changes only the three approved failure-evidence issues in `V2_DELTA.md`.
It does not replace the lead's concrete interpreter, linked audit or checker.

## API and load contract

`execute(initial_regions, initial_registers, checkpoints, output_dir) -> dict`

The lead puts the sealed repository `scripts/` directory on its ordinary import
path, then loads this separate adapter. The adapter imports the existing
`hp1020_qemu_ram.QemuRAM`; it checks that module's exact source SHA256 before
launch. The reference copy here is provenance, not another edited implementation.
The primary-source default is `references/qemu-primary/` beside this module.
An explicit `HP1020_ENTRY_QEMU_PRIMARY` path can select a preserved copy, but
every required byte hash is fixed and verified. No download, fallback version
or inferred debugger-register number exists.

Inputs:

- `initial_regions` is seven `(start, bytes)` pairs: the exact entire main
  envelope plus the six selected islands. All bytes are already painted and
  overlaid with file-backed candidate bytes by the caller. This adapter never
  reads/loads an ELF or zeroes a NOBITS region. It rejects missing, extra,
  duplicate or wrongly sized regions; internal ordering is main, then islands.
- `initial_registers` has exactly `pc,ps,intenable,windowbase,windowstart,lbeg,
  lend,lcount,sar,physical_ar`. The last is32 u32 values. The admitted entry is
 100167a8. Input shape, selected emulator register widths, privileged PS fields
  and nonintersecting active-loop endpoint are checked. The lead still owns
  the six-case matrix and exclusive-memory/no-asynchronous-event preconditions.
- `checkpoints` is the ordered list `[("after-normalization",address),
  ("pre-c",address),("pre-finish",address),("park",address)]`. All four are
  distinct and inside the new text/entry budgets. The lead separately seals
  their linked symbols and instruction identities. This adapter cannot derive
  a C function's semantic role merely from an address.
- `output_dir` must be absent or empty. Refusing a nonempty destination does
  not overwrite old evidence. Once an empty destination is accepted, ordinary
  failures return `status=fail` with partial evidence/result.json. Interrupts
  and SystemExit are recorded, cleaned up and re-raised.

The caller must run on a POSIX main thread without an active ITIMER_REAL.
The adapter refuses to steal a caller's alarm. Total child/observation time is
bounded at120 seconds and each debugger socket transaction at10 seconds.
Cleanup uses terminate/communicate5 seconds, then kill/communicate2 seconds.
Cleanup failures are recorded and force failure; a surviving PID is reported.
If an exception interrupts the first wait before its timeout handler, cleanup
still attempts that bounded kill. A live process is never marked closed and its
private directory remains available, so the outer finally can retry after the
constructor's alarm is restored. An already attempted kill is not looped.

## One seed, then observation only

The private subclass retains the unchanged RAM sim transport and launch flags:
`sim`, `test_kc705_be`,1GiB synthetic RAM, no default devices/display/serial/
monitor/network and initially stopped. Exact reported version11.1.1 is required.
The constructor's historical RETURN breakpoint is inserted by existing code
and explicitly removed before seed, with both commands recorded. This is the
only bootstrap breakpoint outside the seven regions, and no execution occurs
while it exists. No `reset_cpu`, `call0`, `call8`, `load` or address-bearing
continue is called.

Every initial memory-write packet is precomputed from the supplied exact bytes,
including chunk boundaries. Initial register-write packets have one exact
sequence: WB first; remaining supplied SRs; all32 physical ARs; PC last.
The physical writes resynchronize QEMU's logical window per its exact-version
GDB stub. The adapter reads every supplied register and logical alias back
after locking, and compares every initial region byte. It cannot repair a
bad read-back, since later writes are already forbidden.

All GDB commands pass through the subclass boundary, including the constructor.
After lock, only admitted register reads, bounded in-region memory reads,
four named read-only query forms, ordered Z0/z0 checkpoint controls, four bare
continues and exactly two park single-steps can pass. Register sets/whole-file
writes, M/X/G/P packets, addressed c/s and arbitrary packets are rejected before
the shared transport sends them. The code neither hands the QEMU object to the
caller nor returns it. That boundary is an execution harness constraint, not
a security sandbox against hostile monkeypatching in the same Python process.

For each checkpoint: insert one nonmutating QEMU breakpoint, read its actual
three code bytes, bare-continue at the existing PC, require T05 at the exact
address, capture, remove the consumed breakpoint, and re-read those bytes.
No host PC advance occurs. Full immutable main/island bytes are compared with
the initial image after every capture; only the documented state, memory,
mailbox and stack spans may change. The independent oracle makes the stricter
pre-C zero/stack/CPU checks and later semantic checks.

At park the breakpoint is removed. Two genuine `s` operations must each stop
at the same PC with all observed CPU registers and every supplied memory byte
unchanged. The lead must separately audit the actual three-byte instruction as
a plain self-J: snapshot equality alone cannot prove absence of an invisible
read or a transient store restored before the snapshot. All observed registers
means the supplied SRs/PC, all32 physical ARs and16 logical aliases, not unrelated
optional/time-advancing special registers such as CCOUNT. Final SAR is observed
and compared across the two park steps, not forced back to zero.

## Evidence and failure preservation

Each run preserves:

- Exact initial region binaries, initial register/checkpoint JSON and source
  copies/hashes for this adapter, the unchanged backend and five primary files.
- Full initial, four checkpoint and two park-step register/region captures.
  Regions are written/flushed chunk by chunk; a failed read retains its prefix.
  Snapshot JSON records partial status and captured lengths. Incomplete register
  observations also remain in snapshot JSON and the command/reply ledger.
- `host-interventions.jsonl`, with every exact allowed command, complete reply,
  any rejected attempt/error, seed lock, snapshot boundaries and final cleanup.
  Full initial M packets are retained, allowing independent comparison against
  input bytes. Full read replies are retained, allowing reconstruction of even
  a partially captured region. Limits are4096 commands and16MiB of ledger.
- Actual executable identity/hash, reported version, private launch argv,
  stderr, cleanup result and final `result.json`. A resume attempt is distinct
  from an observed checkpoint stop; failure after sending c does not assert a
  successfully completed checkpoint.

When construction fails, any available executable path/hash, version and actual
launch argv are still saved under `qemu` with `partial=true`. Missing fields
remain null; requested core/machine are labeled as requested, not observed.
This fallback reads existing host-side values and binary bytes only: it neither
queries target state nor launches another version probe. The successful report
identity format and successful debugger command sequence remain unchanged.
The command-count limit is inside the existing rejection-ledger boundary, so
the over-limit attempted command is recorded without being sent.

The immutable loader/image/root-audit seals are supplied by the lead; this
module's result cannot establish them by itself. QEMU does not provide a
per-instruction memory-access log here. The separate concrete interpreter
must bound every actual instruction/access and establish stack witnesses; the
same sealed binary is then cross-checked by this direct path. A1/SAR/register
captures, park stability and main-region equality do not prove real loader,
cache, TLB, DMA, controller, engine, USB or printing behavior.

## Static review targets before first use

Check exact-version map/source hashes, bootstrap removal, WB-before-AR seeding,
fail-closed command dispatch, alias mapping, breakpoint sequencing, cleanup
under constructor timeout and complete evidence finalization after failure.
Verify root uses the fresh output directory and rejects any non-pass result.
Review malformed/wrong-register/addressed-continue/extra-write command controls
without weakening this draft's command boundary. Root owns all execution and
may archive the unchanged draft before any correction.
