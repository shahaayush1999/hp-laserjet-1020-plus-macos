# Direct entry QEMU adapter: independent static review

2026-10-03. Reviewed the frozen adapter SHA256
`2e6ef12dcee6c163298e9a4a76e05c98ede6ba6adf111a7d7614f73964166711`, its README,
the complete unchanged `QemuRAM`, the independent entry plan and all four pinned
QEMU11.1.1 source files. No import, parsing, build, validator, QEMU/candidate
execution or repository edit was performed. The reviewed V1 remains untouched.

No normal-path CPU seeding, breakpoint continuation, capture or park mismatch
was found. Two failure-path corrections are recommended before use; one smaller
recording correction is also identified. Findings were sent to root and author.

## Findings

1. **Cleanup can become permanently closed while its child is still alive.**
   In `close()` lines326–349, a total-deadline signal raised inside
   `process.communicate()` is an `EntryQemuError`, hence an `Exception` caught
   by line338. If the child remains alive, lines340–342 record this correctly,
   but line349 still sets `closed=True`. The caller's finally block then cannot
   retry cleanup, contrary to the comment at313–315. This is reachable when
   constructor cleanup starts near the overall deadline and the child has not
   exited after terminate. It is not a false-success bug—the result is failed—
   but can leave a live research process behind. Attempt bounded kill/reap when
   still alive or leave cleanup retryable for execute's finally after the timer
   is restored. Preserve prior cleanup attempts/errors instead of replacing the
   original interrupted attempt's evidence.
2. **Constructor failure loses available executable/launch identity.**
   `report['qemu']` is assigned only after `q.__init__` returns at492–495.
   Failed exact-version validation, bootstrap traffic or connection can leave
   binary, reported version, process argv and PID available on the allocated
   object, while the final report retains only command/cleanup information.
   Record available identity as partial metadata in finally as well; unavailable
   fields should stay explicitly unavailable. Collecting metadata must not
   prevent cleanup or overwrite the original failure. This matters for the
   promised complete constructor evidence, not the successful execution path.
3. **The command-count-limit rejection is not recorded as an attempted command.**
   The limit check at273 precedes the guarded rejection logger at274–279.
   Attempt4097 therefore fails before transport, correctly, but its exact command
   is absent from the ledger. Put the limit check inside the existing logged
   rejection path. The ledger has its own bounded size and need not accept
   further traffic; this asks only to preserve the first rejected attempt when
   capacity remains. Lower priority than the two failure-preservation issues.

## Confirmed source-level contracts

- Every command sent by the unchanged constructor dynamically dispatches through
  the subclass guard/logger. The exact bootstrap is qSupported, Hg0, historical
  RETURN breakpoint insertion and its explicit removal. No execution occurs
  while that breakpoint exists. The known backend launch remains private sim,
  test_kc705_be, initially stopped, without the printer/USB/network paths.
- Initial M and P packets are precomputed and admitted only in their exact
  sequence. WB precedes other SRs, all32 physical AR writes and the final PC.
  The QEMU primary GDB stub writes SRs directly, but every physical-AR write
  synchronizes the logical window; this order supplies the intended dirty
  window correctly. All supplied fields, all32 ARs and all16 aliases are read
  back after locking, alongside every initial memory byte. No failed readback
  can be repaired through the command allowlist.
- The register map matches the exact-version source: PC0, physical AR1..32,
  loop33..35, SAR36, WB38, WS39, PS42, INTENABLE110, logical aliases124..139.
  PREFCTL37/DBREAKC0=83 are absent from the admitted writes. The core source
  independently configures32 physical ARs, big-endian byte order, windows/loops
  and no absolute-literal mode. This is emulator configuration, not HP hardware.
- Post-lock mutation packets and addressed continue/step forms fail before
  transport. Admitted reads are bounded to the exact seven supplied regions
  and named registers. Each checkpoint gets one ordered breakpoint, one bare
  continue, a T05/exact-PC check and complete capture before breakpoint removal.
  No host PC advance, reset_cpu, per-call trampoline, ELF NOBITS zeroing, hidden
  stack seed or later memory/register write appears in this execution path.
- The exact code bytes are checked after breakpoint insertion and removal.
  Entire main/island captures preserve every immutable byte, including unnamed
  gaps. Root separately checks the stricter pre-C zero/stack/CPU state and seals
  each checkpoint to the correct audited symbol/instruction; the adapter does
  not infer semantics from an address in the text budget.
- Park removal is followed by two genuine bare single-step commands, each with
  the same PC, every observed register and every supplied memory byte unchanged.
  The independent linked self-J audit remains necessary: snapshot equality is
  not by itself an instruction/access trace. The adapter does not claim one.
- Snapshot failures retain completed region chunks, partial register reads,
  per-region captured lengths and JSON, while completed command replies remain
  in the ledger. A resume attempt and an observed stop are distinct. The actual
  QEMU object is allocated before initialization, making partially constructed
  resources reachable for cleanup; the findings above concern how that retained
  object is subsequently handled.
- A POSIX main-thread timer bounds construction, version query and observation;
  an existing caller timer is refused. Each debugger transaction is separately
  bounded. Cleanup has terminate/communicate5 then kill/communicate2 paths, with
  errors forcing failure. Ordinary failures produce result.json; main-path
  KeyboardInterrupt/SystemExit are preserved and re-raised after finalization.

## Explicit review limits

The exact six admissible CPU profiles, distinct AR values/current WS bit,
source/ELF seals, opcode closure, first-finish object offsets, literal pixels,
original document event, stack/access bounds and interpreter/QEMU comparisons
are owned by the separate root runner/oracle. This adapter provides observations
and cannot alone prove those conditions. After-lock architectural changes are
limited by actual command flow; the reported zero intervention/helper counts
still depend on auditing that flow, not an isolated final mailbox.

Physical-register debugger reads call QEMU's internal window-to-physical sync.
That synchronizes representations of the same architectural window; it is not
an extra supplied register seed. Raw debugger traffic remains preserved for
independent checking. Full malformed transport packets interrupted mid-reply
are not promised as completed reply records; successfully returned replies and
completed region prefixes are preserved.

No physical processor, ROM loader, memory attribute, cache/TLB, controller,
settlement, USB or printing claim is added by this review.

## Exact inputs

The adjacent `hp1020-entry-qemu-independent-review-inputs-20261003.sha256` names
all nine exact reviewed files, including the official primary-source provenance.
Each pinned primary-file hash in the adapter was independently matched to the
local file using SHA256; the URLs in provenance pin QEMU v11.1.1. The source
review used no live QEMU observations or candidate results.
