# Entry RAM experiment: root decisions before any candidate build/execution

2026-10-03. Root read both independent CPU and layout reviews completely, then
independently matched all five raw byte blocks, 28 exact instruction/literal
anchors, the ELF entry and all 11 PT_LOAD records against analysis/sihp1020.elf
with a standalone stdlib reader. The original ELF SHA256 was checked before
using the extracted records. No stock instruction or new candidate was executed.

Select the proposed NEW layout inside [10003000,100351e0). Keep the full current
production document state and contiguous memory, not reduced capacities or the
large existing multi-case fixture. Reuse later HP private runtime/ACL locations
explicitly. Preserve selected address islands using new inert contents, not HP
code that could escape into hardware. Loader expectations remain unresolved.

The RAM-only test supplies loaded accessible exclusively owned memory,
privilege, PC-relative L32R mode, and no asynchronous IRQ/NMI/debug exceptions.
Incoming active loops must not redirect the initial prefix before LCOUNT is
cleared. Do not use original ENTRY or original full CPU/TLB/cache initializer.
The selected stock writes are CPU-operation/ABI evidence, not an instruction
sequence that has to be reproduced. No custom instruction or new MMIO exists.

Use an initial host setup ONCE, never the shared call0/reset_cpu convenience
functions. Paint the full main envelope and selected islands; overlay only
file-backed PT_LOAD bytes without implicit NOBITS zeroing. Candidate startup
must establish allowed special-register state, own stack and three exact zero
ranges. Read-only checkpoints may observe after normalization, before CALL0,
and terminal park. They may not rewrite CPU, SP or memory to repair execution.
The C workload independently scans all zero ranges before its initializers.

Use a bounded concrete interpreter with strictly admitted standard startup
operations and explicit physical/logical window mapping, then independent QEMU
execution from the identical initial image/registers. The interpreter must
reject any runtime access outside admitted code/RAM/mutable spans, including
all guards, entry/vector islands and protected gaps. QEMU's CPU is a standard
ISA cross-check, not the printer's exact processor or physical memory map.
Keep supplied mappings/cache state visible and unchanged.

The workload uses unchanged production receive/document/image APIs, a const
existing small-black host-generated ZjStream, supplied successful RAM transport
completion and immediate software output accept/complete. Its intended result
is32 literal ff pixels and one original event(generation1,document1,firstpage0,
pages1). It returns only to own park. This is a continuous software run, not a
native HP page lifecycle, actual USB/controller completion or printing.

Expected BSS sizes: state13496, memory114704, mailbox1024. Initialized256-byte
sentinel is file-backed and preserved. Owned downward stack is [10012000,
10014000),16-aligned. Stack paint and concrete minimum a1/accesses are measured;
8KiB is a budget until linked closure/callback/frame review, never an inferred
hardware maximum. Record actual footprint, all linked instruction properties,
helpers, allocatable sections and exact source/fixture/artifact hashes.

Draft task split: adapter_review owns only assembly/linker; printer_class_reuse
owns only minimal C/mailbox contract; usb_reference_contract freezes independent
acceptance plan before reading candidate implementation. Root integrates,
audits, owns all execution and compares evidence. Current acquisition full suite
continues sequentially; no new candidate build/run begins until it finishes.
