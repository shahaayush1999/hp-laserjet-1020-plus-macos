# QEMU adapter V2 — static corrections, 2026-10-03

This is a separate unexecuted, unparsed proposal. V1 at
`/tmp/hp1020-entry-qemu-adapter-draft-20261003/` remains untouched; its code,
README and manifest are additionally copied under `original/` here. No candidate
import, parsing, build, validator, QEMU execution or repository edit occurred.

The independent review is copied in
`references/hp1020-entry-qemu-independent-review-20261003.md`, SHA-256
`ad7348f9a224477fb094418ae948ae29f48dc69923f73d91b22cd908429121a2`.
Root approved these three bounded corrections:

1. Preserve available QEMU identity when constructor/version/bootstrap fails.
   The success format remains unchanged. Only a missing `report['qemu']` invokes
   the new host-only fallback in finally. It records constructor completion,
   requested binary/core/machine, available executable path/hash, available
   version and actual Popen args. Missing values remain null. Binary metadata
   read failures are recorded separately without replacing the original error.
   No target command, process launch or version retry is added.
2. Keep process cleanup bounded and retryable while the child remains alive.
   If an exception interrupts communicate before the existing timeout handler,
   one kill plus at most a two-second communicate is still attempted. An already
   attempted kill is not repeated in the same close call. A surviving child
   keeps `closed=False` and retains the private directory. The outer finally can
   therefore retry after the constructor deadline handler has been restored.
   All encountered failures remain in the cleanup result/ledger; failure is
   never converted into a successful candidate observation.
3. Move the existing command-count rejection into its existing logged guard
   try. The over-limit attempt produces `gdb-rejected`; it produces no request
   or transport call. The byte-budget limit and admitted commands are unchanged.

No new ledger kinds or successful-run GDB operations are added. A constructor
failure may produce a failed `process-cleanup` attempt and a later retry of the
same ledger kind. Successful construction, seed, snapshots, breakpoint order,
four continuations and two park steps retain their exact V1 envelopes.

The static failure schedules to check in root-owned tests are: missing binary,
version failure before process creation, bootstrap failure after Popen, alarm
while waiting for termination, persistent child after the bounded kill, and
MAX_COMMANDS+1 rejection. Neither this note nor a static read proves those
failure schedules have executed. Parent owns integration and all execution.
