"""Preserve frozen entry reviews/drafts before the first target execution."""
from pathlib import Path
import gzip, hashlib, io, json, tarfile

root=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
folders=(
 '/tmp/hp1020-entry-qemu-adapter-v2-20261003',
 '/tmp/hp1020-entry-audit-emitted-v3-20261003',
 '/tmp/hp1020-entry-call0-review-20261003',
 '/tmp/hp1020-entry-linked-review-20261003',
 '/tmp/hp1020-entry-gate-draft-20261003',
 '/tmp/hp1020-entry-gate-review-inputs-20261003',
)
notes=(
 '/tmp/hp1020-entry-qemu-independent-review-v2-addendum-20261003.md',
 '/tmp/hp1020-entry-runner-independent-review-20261003.md',
 '/tmp/hp1020-entry-runner-v2-static-addendum-20261003.md',
 '/tmp/hp1020-entry-gate-independent-review-20261003.md',
)
files={}
for folder in folders:
 p=Path(folder);assert p.is_dir(),p
 for f in p.rglob('*'):
  if f.is_file():files[p.name+'/'+str(f.relative_to(p))]=f
for name in notes:
 p=Path(name);assert p.is_file(),p
 files['reviews/'+p.name]=p
for name in ('scripts/check-hp1020-entry-ram.py','scripts/validate-hp1020-entry-ram.py',
 'scripts/hp1020_entry_audit.py','scripts/hp1020_entry_machine.py','scripts/hp1020_entry_qemu.py',
 'scripts/build-hp1020-entry-ram-target.sh','open-firmware/entry-ram-test/startup.S',
 'open-firmware/entry-ram-test/entry.ld'):
 files['integrated/'+name]=root/name
files['archive.py']=Path(__file__)
payloads={n:p.read_bytes() for n,p in files.items()}
sha=lambda raw:hashlib.sha256(raw).hexdigest()
buf=io.BytesIO()
with gzip.GzipFile(fileobj=buf,mode='wb',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w') as tf:
  for n,data in sorted(payloads.items()):
   assert not Path(n).is_absolute() and '..' not in Path(n).parts
   info=tarfile.TarInfo(n);info.size=len(data);info.mode=0o644;info.mtime=0
   tf.addfile(info,io.BytesIO(data))
archive=buf.getvalue()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tf:
 assert set(tf.getnames())==set(payloads)
 for n,data in payloads.items():assert tf.extractfile(n).read()==data
meta=dict(status='pre-execution-review-and-source-freeze',
 scope='Reviews and drafts only; no target instruction execution in this archive.',
 members=len(payloads),archive_bytes=len(archive),archive_sha256=sha(archive),
 member_sha256={n:sha(v) for n,v in sorted(payloads.items())})
out=root/'analysis/boot-handoff/entry-ram/source-snapshots'
for suffix,data in (('.tar.gz',archive),('.json',(json.dumps(meta,indent=2)+'\n').encode())):
 p=out/('pre-execution-reviews'+suffix);assert not p.exists();p.write_bytes(data)
print(json.dumps({k:v for k,v in meta.items() if k!='member_sha256'},indent=2))
