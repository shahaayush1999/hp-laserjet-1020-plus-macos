"""Read-only saved ELF/map extraction; not the target audit or runner."""
from pathlib import Path
import struct,json,collections,hashlib
cap=Path('/tmp/hp1020-entry-ram-26izpj9h/target');out=Path('/tmp/hp1020-entry-linked-review-20261003')
b=(cap/'entry-ram.elf').read_bytes();so=struct.unpack_from('>I',b,32)[0];ss,sn,st=struct.unpack_from('>HHH',b,46)
h=[struct.unpack_from('>10I',b,so+i*ss)for i in range(sn)];names=b[h[st][4]:h[st][4]+h[st][5]]
s={names[x[0]:].split(b'\0')[0].decode():x for x in h}
def get(a,n):
 for x in h:
  if x[2]&2 and x[1]!=8 and x[3]<=a and a+n<=x[3]+x[5]:return b[x[4]+a-x[3]:x[4]+a-x[3]+n]
 raise ValueError(('unbacked span',a,n))
x=s['.xt.prop'];rows=list(struct.iter_unpack('>III',b[x[4]:x[4]+x[5]]))
unreachable=[dict(address=a,bytes=n,flags=f,hex=get(a,n).hex())for a,n,f in rows if n and f&7==0]
mixed=[dict(address=a,bytes=n,flags=f,hex=get(a,n).hex())for a,n,f in rows if n and f&7==6]
fills=[];t=s['.text'];mapraw=(cap/'entry-ram.map').read_bytes()
for line in mapraw.decode().splitlines():
 c=line.split()
 if c and c[0]=='*fill*':
  a,n=int(c[1],16),int(c[2],16)
  if n and t[3]<=a and a+n<=t[3]+t[5]:
   fills.append(dict(address=a,bytes=n,hex=get(a,n).hex(),preceding_insn=any(nn and ff&2 and aa+nn==a for aa,nn,ff in rows),unreachable_marker=(a,0,8) in rows,next_alignment_marker=(a+n,0,0x2804) in rows,next4=a+n==((a+3)&~3),map_line=line))
summary=dict(elf_sha256=hashlib.sha256(b).hexdigest(),map_sha256=hashlib.sha256(mapraw).hexdigest(),properties=len(rows),kinds=dict(collections.Counter(f&7 for a,n,f in rows)),unreachable=unreachable,mixed=mixed,linker_fills=fills,diagnostic_marker=dict(address=0x1000ab7c,hex=get(0x1000ab7c,4).hex()),scope='Observed file bytes and metadata only; no candidate execution.')
(out/'emitted-properties-evidence.json').write_text(json.dumps(summary,indent=2)+'\n')
print('unreachable',len(unreachable),sum(x['bytes']for x in unreachable),'all_zero_1_3_flags8',all(x['flags']==8 and 1<=x['bytes']<=3 and x['hex']=='00'*x['bytes']for x in unreachable))
print('mixed',mixed)
print('fills',len(fills),sum(x['bytes']for x in fills),'all_proven',all(x['preceding_insn']and x['unreachable_marker']and x['next_alignment_marker']and x['next4']and 1<=x['bytes']<=3 and x['hex']=='00'*x['bytes']for x in fills))
