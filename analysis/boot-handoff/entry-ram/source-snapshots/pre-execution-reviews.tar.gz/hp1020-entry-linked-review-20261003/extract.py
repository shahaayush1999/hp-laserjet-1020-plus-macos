"""Read-only ELF/property/disassembly extraction, not the candidate audit/runner."""
from pathlib import Path
import struct,json,re,subprocess,collections
root=Path('/tmp/hp1020-entry-ram-26izpj9h/target')
out=Path('/tmp/hp1020-entry-linked-review-20261003')
raw=(root/'entry-ram.elf').read_bytes()
shoff=struct.unpack_from('>I',raw,32)[0];shsz,shnum,shstr=struct.unpack_from('>HHH',raw,46)
h=[struct.unpack_from('>10I',raw,shoff+i*shsz) for i in range(shnum)]
strings=raw[h[shstr][4]:h[shstr][4]+h[shstr][5]]
secs={strings[x[0]:].split(b'\0')[0].decode():x for x in h}
def at(a,n):
 for x in h:
  if x[2]&2 and x[1]!=8 and x[3]<=a and a+n<=x[3]+x[5]:return raw[x[4]+a-x[3]:x[4]+a-x[3]+n]
 return b''
p=secs['.xt.prop'];rows=sorted(struct.iter_unpack('>III',raw[p[4]:p[4]+p[5]]))
def merged(rr):
 result=[]
 for a,n in sorted(rr):
  if not n:continue
  if result and result[-1][0]+result[-1][1]==a:result[-1]=(result[-1][0],result[-1][1]+n)
  else:result.append((a,n))
 return result
ranges=merged((a,n) for a,n,f in rows if f&2)
listings=[]; decoded=[]
for a,n in ranges:
 text=subprocess.check_output(['/tmp/hp1020-xtensa-manual-systemz/bin/xtensa-fsf-elf-objdump','-d',f'--start-address={a}',f'--stop-address={a+n}',str(root/'entry-ram.elf')],text=True)
 listings.append(text)
 for line in text.splitlines():
  m=re.match(r'\s*([0-9a-f]{8}):\s+([0-9a-f]{4,6})\s+(\S+)\s*(.*)',line)
  if m:decoded.append({'pc':int(m[1],16),'hex':m[2],'op':m[3],'args':m[4].split('<')[0].strip(),'display':line})
out.joinpath('annotated-review-disassembly.txt').write_text(''.join(listings))
out.joinpath('annotated-review-instructions.json').write_text(json.dumps(decoded,indent=2)+'\n')
known=[(0x10007000,28),(0x10016780,0x28),(0x100167ab,0x35)]
known += [(a+3,0x3d) for a in range(0x10000000,0x10000180,0x40)]
known += [(a+3,n-3) for a,n in ((0x10000200,0x1c),(0x10000220,0x1c),(0x10000270,0xe0),(0x10100020,0x2e0),(0x10100320,0xc))]
align=[]
for a,n,f in rows:
 if f&0x800:
  p=(f>>12)&31;b=(a+n+(1<<p)-1)&-(1<<p)
  if b>a+n:align.append((a+n,b-a-n))
gaps=[]
for name,s in secs.items():
 if not(s[2]&4 and s[5]):continue
 covered=bytearray(s[5])
 for a,n in [(a,n) for a,n,f in rows]+known+align:
  for x in range(max(s[3],a),min(s[3]+s[5],a+n)):covered[x-s[3]]=1
 pos=0
 while pos<len(covered):
  if covered[pos]:pos+=1;continue
  end=pos+1
  while end<len(covered) and not covered[end]:end+=1
  gaps.append(dict(section=name,address=hex(s[3]+pos),bytes=end-pos,hex=at(s[3]+pos,end-pos).hex()));pos=end
legacy=secs['.xt.lit'];old=list(struct.iter_unpack('>II',raw[legacy[4]:legacy[4]+legacy[5]]))
modern=[(a,n) for a,n,f in rows if f&1]
summary=dict(code_ranges=len(ranges),instructions=len(decoded),opcodes=dict(collections.Counter(d['op'] for d in decoded)),gaps=gaps,literal_legacy=old,literal_modern=modern,literal_merged_equal=merged(old)==merged(modern),stack_changes=[d for d in decoded if ('a1' in d['args'].split(',')[0] and d['op'] in ('addi','addi.n','addmi','mov.n','movi','movi.n','mov','sub','add','l32r'))],dynamic=[d for d in decoded if d['op'] in ('callx0','jx')],direct_calls=[d for d in decoded if d['op']=='call0'])
out.joinpath('classification-call-extract.json').write_text(json.dumps(summary,indent=2)+'\n')
print('ranges',len(ranges),'instructions',len(decoded),'ops',summary['opcodes'])
print('gaps',gaps)
print('literal_old/new',len(old),len(modern),'merged_equal',summary['literal_merged_equal'])
print('dynamic calls',len(summary['dynamic']))
for d in summary['dynamic']:print(d['display'])
print('direct calls',len(summary['direct_calls']))
