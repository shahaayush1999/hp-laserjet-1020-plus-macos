"""Read-only metadata/call-graph extraction; never import audit or run target."""
from pathlib import Path
import json,struct,collections
cap=Path('/tmp/hp1020-entry-ram-26izpj9h/target')
out=Path('/tmp/hp1020-entry-linked-review-20261003')
raw=(cap/'entry-ram.elf').read_bytes()
so=struct.unpack_from('>I',raw,32)[0];ss,sn,st=struct.unpack_from('>HHH',raw,46)
h=[struct.unpack_from('>10I',raw,so+i*ss) for i in range(sn)]
names=raw[h[st][4]:h[st][4]+h[st][5]]
secs={names[z[0]:].split(b'\0')[0].decode():z for z in h}
def read(a,n):
 for z in h:
  if z[2]&2 and z[1]!=8 and z[3]<=a and a+n<=z[3]+z[5]:return raw[z[4]+a-z[3]:z[4]+a-z[3]+n]
 raise ValueError(('missing file span',hex(a),n))
s=secs['.symtab']; names=raw[h[s[6]][4]:h[s[6]][4]+h[s[6]][5]]
functions={}
for z in struct.iter_unpack('>IIIBBH',raw[s[4]:s[4]+s[5]]):
 if z[3]&15==2 and z[2]:functions[z[1]]=dict(name=names[z[0]:].split(b'\0')[0].decode(),start=z[1],end=z[1]+z[2])
def owner(pc):
 found=[a for a,f in functions.items() if a<=pc<f['end']]
 if not found:raise ValueError(('function owner',hex(pc),found))
 # The named park is intentionally nested inside the startup function.
 return min(found,key=lambda a:functions[a]['end']-a)
frames=collections.defaultdict(set)
for p in sorted(cap.glob('*.su')):
 for line in p.read_text().splitlines():
  where,size,kind=line.rsplit('\t',2)
  assert kind=='static'; frames[where.rsplit(':',1)[-1]].add(int(size))
for f in functions.values():
 name=f['name']; choices=frames.get(name,set())
 if name=='__udivsi3' or name.startswith('hp1020_entry_') and name in ('hp1020_entry_normalize','hp1020_entry_start','hp1020_entry_park','hp1020_entry_unexpected_park'):choices={0}
 assert len(choices)==1,(name,choices)
 f['frame']=next(iter(choices))
rows=json.loads((out/'annotated-review-instructions.json').read_text()); bypc={r['pc']:r for r in rows}
callbacks={0x10007cd5:'consume',0x100084bf:'chunk_in',0x100093d3:'entry_document',0x10009996:'boundary',0x10009bed:'entry_output',0x10009d15:'document_out',0x10009fcf:'row_out',0x1000a009:'row_out',0x1000a233:'row_out'}
def named(name):
 a=[a for a,f in functions.items() if f['name']==name]; assert len(a)==1,(name,a);return a[0]
tables={0x10007d5e:(0x10007d20,6),0x1000821f:(0x10008178,15),0x100082c8:(0x10008284,7),0x10008b91:(0x100089e4,8)}
edges=[]; dynamic=[]; direct_bad=[]; literals=[]; bad_bytes=[]
branches=set('bbci bbsi beq beqi beqz beqz.n bge bgei bgeu bgeui bgez blt blti bltu bltui bltz bne bnei bnez bnez.n bnone bany ball bnall j call0'.split())
for i,r in enumerate(rows):
 pc=r['pc'];op=r['op'];args=[x.strip() for x in r['args'].split(',')]
 if bytes.fromhex(r['hex'])!=read(pc,len(r['hex'])//2):bad_bytes.append(pc)
 if op in branches:
  target=int(args[-1],16)
  if target not in bypc:direct_bad.append((pc,target))
  if op=='call0':edges.append(dict(source=owner(pc),target=owner(target),pc=pc,kind='direct-call0'))
  elif pc>=0x1000701c and pc<0x1000ab84 and owner(pc)!=owner(target):edges.append(dict(source=owner(pc),target=owner(target),pc=pc,kind='cross-function-direct-branch'))
 if op=='l32r':
  target=int(args[1],16); b=bytes.fromhex(r['hex']);decoded=(((pc+3)&~3)+(int.from_bytes(b[1:],'big')-65536)*4)&0xffffffff
  assert target==decoded and b[0]>>4==1 and b[0]&15==int(args[0][1:])
  literals.append(dict(pc=pc,target=target,word=int.from_bytes(read(target,4),'big')))
 if op not in ('jx','callx0'):continue
 f=owner(pc);record=dict(pc=pc,source=f,name=functions[f]['name'],kind=None)
 if pc in callbacks:
  target=named(callbacks[pc]);record.update(kind='source-bound-callback',target=target);edges.append(dict(source=f,target=target,pc=pc,kind=record['kind']))
 elif pc in tables:
  ptr,count=tables[pc];base=int.from_bytes(read(ptr,4),'big');targets=[x[0]for x in struct.iter_unpack('>I',read(base,count*4))]
  assert all(t in bypc and owner(t)==f for t in targets)
  record.update(kind='bounded-intra-function-table',pointer_literal=ptr,base=base,count=count,targets=targets)
 elif op=='jx' and i and rows[i-1]['op']=='l32r' and rows[i-1]['args'].split(',')[0]==args[0]:
  previous=rows[i-1];ptr=int(previous['args'].split(',')[1],16);target=int.from_bytes(read(ptr,4),'big');assert target in functions
  record.update(kind='literal-tail-call',target=target);edges.append(dict(source=f,target=target,pc=pc,kind=record['kind']))
 else:record['kind']='unbound-unused-encoder-callback'
 dynamic.append(record)
adj=collections.defaultdict(list)
for e in edges:adj[e['source']].append(e)
root=named('hp1020_entry_c');reachable=set()
def visit(a):
 if a in reachable:return
 reachable.add(a)
 for e in adj[a]:visit(e['target'])
visit(root)
unknown=[r for r in dynamic if r['source'] in reachable and r['kind']=='unbound-unused-encoder-callback'];assert not unknown,unknown
memo={}
def bound(a,chain=()):
 assert a not in chain,('recursive graph',chain,a)
 if a in memo:return memo[a]
 paths=[(0,[])]
 for e in adj[a]:paths.append(bound(e['target'],chain+(a,)))
 weight,tail=max(paths,key=lambda x:x[0]);answer=(functions[a]['frame']+weight,[a]+tail);memo[a]=answer;return answer
peak,path=bound(root)
frame_instructions=[]
for a in sorted(reachable):
 changes=[]
 for r in rows:
  if a<=r['pc']<functions[a]['end'] and r['args'].split(',')[0]=='a1':
   assert r['op'] in ('addi','addmi') and r['args'].split(',')[1].strip()=='a1',r
   delta=int(r['args'].split(',')[2],0)
   if delta>=0x80000000:delta-=0x100000000
   changes.append(dict(pc=r['pc'],delta=delta,hex=r['hex']))
 frame=functions[a]['frame'];negative=[x['delta']for x in changes if x['delta']<0];positive=[x['delta']for x in changes if x['delta']>0]
 assert negative==([-frame] if frame else []),(functions[a],changes)
 assert all(x==frame for x in positive) and (not frame or positive),(functions[a],changes)
 frame_instructions.append(dict(function=functions[a],changes=changes))
summary=dict(functions=list(functions.values()),edges=edges,dynamic=dynamic,reachable=sorted(reachable),conservative_bound_bytes=peak,bound_chain=[functions[a] for a in path],remaining_stack_bytes=8192-peak,frame_instruction_matches=frame_instructions,unknown_reachable_dynamic=unknown,direct_target_errors=direct_bad,byte_errors=bad_bytes,literal_uses=literals,tail_frames='Conservatively added even when restored before JX; source callbacks fixed by this workload only.',scope='Static metadata and source-bound graph, not target execution or runtime maximum.')
(out/'call-frame-evidence.json').write_text(json.dumps(summary,indent=2)+'\n')
print('functions',len(functions),'reachable',len(reachable),'callbacks',collections.Counter(r['kind']for r in dynamic))
print('bound',peak,'spare',8192-peak)
for a in path:print(hex(a),functions[a]['name'],functions[a]['frame'])
print('direct errors',direct_bad,'bytes',bad_bytes,'literals',len(literals),'edges',len(edges))
print('reachable stack changes:')
for r in rows:
 if 0x1000708c<=r['pc']<0x1000ab84 and owner(r['pc']) in reachable and r['args'].split(',')[0]=='a1' and r['op'] in ('addi','addi.n','addmi','mov.n','movi','movi.n','mov','sub','add','l32r'):print(r['display'])
