# Emitted-property audit correction — unexecuted V3

This is a `/tmp`-only proposal against captured audit SHA256
`67b6bbbbe3ed5f40d2c581d3bd315fa686847d36c6559aba9c244e9ef7c32875`.
The original is retained under `baseline/`; `changes.patch` is the complete
delta. Neither this module nor the candidate ELF has been imported or executed
by this review. Root owns audit execution and any later target execution.

The first successful link is captured at
`/tmp/hp1020-entry-ram-26izpj9h`. Its ELF SHA256 is
`7e0cc607f02f3b28a6b585c5e689cea6d880621b80f07a06bd1ceff5edbdb11b`.
Its map SHA256 is
`ed29b365997fe9d44191126fcf6cb4c721e3cfddfd6caa2ac78c6aaaf7a5d2f8`.
The review reads ELF metadata and uses the pinned corrected objdump only over
INSN-flagged spans; it does not execute the audit or candidate.

## Four narrow changes

1. Pinned GAS's RELAX_UNREACHABLE records use kind zero with flag 8. The 84
   nonempty records in this ELF comprise 116 zero bytes, each extent 1–3 bytes.
   V3 accepts only this exact flag/size/content form in `.text`, and labels it
   non-executable padding. Other nonempty kind-zero records still fail.
2. The local no-transform region is emitted as kind 6, DATA|INSN, because GAS
   sets DATA before subsequently adding INSN. V3 admits exactly one six-byte
   record at `hp1020_entry_before_c`, flags `0x2906`, raw bytes
   `5000d563fffc`, with the existing park symbol at +3. Existing decoded
   CALL0-to-own-C and self-park checks remain authoritative. Original kind and
   flags are retained in the report; DATA elsewhere is never decoded.
3. Sixty-seven 1–3-byte zero linker gaps are outside nonempty properties. Each
   is an exact map `*fill*`, starts at a zero-size UNREACHABLE marker and the
   end of an INSN record, and ends at the next 4-byte boundary with a zero-size
   `0x2804` alignment marker. All these predicates and exact zero bytes are
   required before labeling a gap non-executable. The saved sibling `.map`
   becomes a required audit input, recorded with byte count and SHA256. A map
   label alone cannot authorize code or padding; missing fill proof fails the
   existing exhaustive executable-section classification.
4. Pinned libgcc emits literal ASCII `DIV0` immediately after its excluded
   unsigned-division ILL. V3 recognizes only the four bytes at
   `__udivsi3+0x44`, preceded by the existing exact ILL at +0x41. The marker
   remains outside instruction annotations and executable permissions. The
   trap remains excluded; no exception handling is supplied.

All existing ELF layout, input/source, byte decoder, startup, opcode, direct
control, L32R, runtime range and individual-frame gates remain. The report adds
link-map provenance, linker padding and the excluded diagnostic marker. Labels
7/8/9 distinguish unreachable padding, linker padding and DIV0. Schema remains
v1 with additive evidence fields.

## Primary provenance

Pinned binutils commit `0104f7d3c1a3e55954bf7b09fc70dd542b910714`:
`gas/config/tc-xtensa.c:7930–7961` marks unreachable fragments;
`12157–12176` explains DATA|INSN under no-transform and unreachable without
INSN; `12190–12212` serializes flags; `12261–12326` describes alignment and
zero-size end-marker handling. `include/elf/xtensa.h` defines the low flag bits
and alignment metadata, whose padding is not included in block size.
Pinned GCC 14.3.0 `libgcc/config/xtensa/lib1funcs.S:588–593` emits ILL and DIV0.
The complete input hashes are recorded separately. The initial linked audit
has not yet reached these new checks, so no success is claimed.
