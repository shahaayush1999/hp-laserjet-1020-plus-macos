# Pre-execution review binding

V2 runner remains unchanged in its frozen tooling package. V3 adds only the
actual reviewed ELF SHA256 and a check after audit-only returns, before either
execution engine imports. The reviewed static7904-byte stack/callback bound
applies to exactly that linked image. No target has executed. A future changed
image may use audit-only, but needs a fresh source/byte review and an explicit
new admission pin before execution. This is not a literal semantic expectation
derived from runtime results. No caps, snapshots, calls or gate were changed.
