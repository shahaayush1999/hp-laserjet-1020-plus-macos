# Reset tooling V2: independent static delta review

Reviewed 2026-10-03, without imports, parsing, compilation, audit execution,
candidate execution, hardware access or repository edits. This is a source
review of the frozen V2 delta, not an emitted-link or runtime acceptance result.
The earlier full V1 plumbing review remains separately preserved.

No actionable blocker found in this delta.

The library selection is a new, explicit sibling-profile admission contract.
It requires exactly `_udivsi3.o` in the actual map and exactly the original
76-byte `__udivsi3` function in the linked ELF. The new audit rejects any
`__umodsi3` symbol; it does not accept an arbitrary subset of known helpers.
Its sole ILL location must still match the whole helper hash and original
ILL/DIV0 bytes, and is removed from admitted instructions. The unchanged
neutral classifier receives the one proved helper explicitly and therefore
does not inherit the healthy profile's two-helper count implicitly.

The full pinned original archive and both extracted member copies remain
required and byte-bound to the archive. Both original members still pass the
unchanged complete raw section classifier, including nonallocated/discarded
sections. The map must name only the original archive path and the exact
28 LOAD inputs. The change distinguishes capture inventory from actual link
selection; it neither drops raw modulo provenance nor loosens input closure.
The builder's actual extraction/link commands are unchanged.

The local helpers are copies with narrow selection changes. No imported module
global is changed, and the healthy audit, helper expectations and runner retain
their original source hashes. Instruction/property/layout/NOLOAD/global/source
gates, memory/stack budgets and direct/dynamic target restrictions are untouched.
The new library contract is both an exact audit pin and a runner source member.

Failure preservation now additionally copies all three actual reset ledgers:
`reset_seen`, `reset_observations` and `reset_api_events`. It does not replace
the inherited core ledgers or turn partial observations into accepted results.
This is compatible with the observer's constructor/field lifetime; V2 observer
separately closes inherited streams if post-parent symbol binding fails before
the runner receives a constructed machine.

The source-derived udiv-only expectation must still agree with the first actual
reset link. An unexpected helper remains an admission stop requiring evidence,
not permission to change an expected result after execution. A fresh actual
linked callback/frame review is still required; no healthy stack bound transfers.
The JX callback observation/schema issue discussed separately with the gate
author is outside this tooling delta and remains a pre-execution integration
requirement.

Exact reviewed seals:

- V2 DRAFT.sha256: `4eb7646aeb7a7cc1093154e90e058ae15379a84d818ff4ccf447e55d06ca6ef8`
- audit: `422d43890e93b657fc26056cd872a5ecfca379a4b0b72a8ef31cba5fc48c613c`
- runner: `81cde1ff5891a0a72609a6f218a369764055d9430ef0ecc6408578e94368c9cb`
- builder: `44e9801116b1e0a05d52e5e832b66bc790c01cce46d4158497f2df53e70279b2`
- library contract: `e5d344e4afe2817186960ef3108a7f82baf0089f2e333e012f950994b7be7fdd`
- unchanged healthy audit: `a1544c2e1b155dcb70b1b12b1d0be99f1558799a2e56b697a4477c9a7e259f22`
- unchanged healthy runner: `ef7cd2ef5c0ee6618002d600efea1a6844ea627a288c3022e766297cda694e1d`

`inputs/` preserves the complete reviewed V2 package, neutral source copies,
prior review and original healthy map selection excerpt. `INPUTS.sha256` seals
those files; the report is not a claim that any candidate ran here.
