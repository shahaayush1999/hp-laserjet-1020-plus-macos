# Reset tooling V2 — pre-build source correction

V1 is unchanged at `/tmp/hp1020-entry-usb-reset-tooling-draft-20261003`.
No reset build, linked audit or target execution has happened.

V2 separates the precise selected-library rule from the unchanged full archive
and both extracted original-member inventory. See the independently reviewable
LIBRARY_SELECTION.md contract. Local audit helpers require exactly udiv; old
healthy helpers/modules are unchanged. Builder comments explain extraction
versus map selection; extraction itself remains byte-identical.

The runner additionally preserves actual partial reset checkpoint, observation
and API-event ledgers on failure and seals the new library contract as source.
Limits, expected semantic behavior and publication policy are unchanged.

The lead AST-parsed these Python drafts only; no module imports or compiler/
audit/validator/target operations were performed. The first emitted source and
callback stack still require their own audit/review before execution.
