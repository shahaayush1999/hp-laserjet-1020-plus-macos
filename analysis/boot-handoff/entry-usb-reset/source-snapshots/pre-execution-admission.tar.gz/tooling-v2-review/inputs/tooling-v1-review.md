# Independent static review of reset tooling V1

2026-10-03. Read-only source and contract review. No imports, syntax parsing,
builds, audits, validators, target execution, hardware operations or repository
edits were performed by this reviewer. Exact inspected inputs are copied under
`inputs/`; the supplied package remains unchanged.

No admission, source-binding or success-publication blocker was found.

The inspected V1 identities are:

- manifest `19c4c503c27ffa5f8b5143770a026ff0ec452b8fd186eeddab16a9a273dc6c75`;
- builder `5a6349c3391179f2152f83ca8cf708c6ffcdfa0299033c906f677395c6d1975a`;
- audit `03d2d599e5604808b37ab093e270eee1217e2f5451ade13946327df088dff61d`;
- runner `cc8fe3f47266c43119221539c6374c40c1508158807ca7dfdaf7d8ef9812e347`.

## Concrete observations

The builder differs from the accepted builder only in sibling source/output and
effective-source temporary names and descriptions. The compiler-profile check,
all 26 C inputs plus startup, flags/includes, exact352-byte input, actual GCC
runtime archive capture, selected-member identity and link/undefined checks stay
intact. New target output cannot overwrite the healthy target. A direct repeat
build still requires a clean libgcc destination; the new runner preserves and
removes the sibling prior target before invoking it.

The new audit copies `SCRIPT_PINS` rather than mutating the imported dictionary.
It pins the reused complete USB audit, unchanged neutral audit/call0/property
helpers, production/protocol anchors and new header/manual tables. Its local
dependency checks accept only the retained object path or the sibling reset
target path, bind all three runtime units to the sibling sources, retain actual
repeated GCC dependency occurrences, and require the one pinned effective
TinyUSB tree/configuration. The unchanged raw-input gate still checks all27
objects and every input section, including GC-discarded allocations and NOLOAD
initializers; the full archive and selected two helper inputs remain checked.

The original layout/stack/code caps, exact20 allocated sections and15 load
segments remain enforced by unchanged helpers taking the new manual object
table. The local public-layout check requires all525 literal words/2100 bytes,
16 actual object extents,118 fields, the unchanged stream/configuration record
and exact immutable16-byte SOFT_RESET record. No private runtime/CPU/property
check was relaxed. `entry_symbol_records` correctly copies actual ELF rows,
preserving duplicate local callback names instead of deriving them from the
collapsing symbol dictionary. The new actual linked call/frame bound still
requires fresh review; the old bound is not an admission result for this draft.

The runner pins and reuses only the accepted runner's byte/image/snapshot
helpers. Their retained ROOT, stack and seven envelopes are appropriate for the
same repository/layout; no old SOURCE/OUT global is changed or used for new
publication. Input intentionally remains the already-sealed entry-RAM fixture.
Local source/tool/dependency snapshots include new and reused modules, separate
contracts/oracles, actual compiler/system/effective headers, selected libgcc and
original runtime source/notices. The runtime path refuses a missing independent
checker before building or executing; audit-only may omit it and cannot publish
a successful lifecycle report.

The exact20 labels resolve to actual linked functions/assembly symbols. The
new model API and QEMU API agree with the frozen observer draft. Two paint cases
produce21 paired snapshots each and23 QEMU snapshots including two park steps,
giving42 paired observations and four park instructions in total. Comparison
uses complete RAM/stack/islands and normalized physical/logical registers; the
neutral snapshot check adds no healthy-document schedule assumption. Execution
retains10M instructions and the observer's unchanged120s/4096/16MiB limits.

Source seals are rechecked before execution and in the finalizer. Public raw
archive, manifest and success report are emitted only after the separate raw
checker succeeds, with staged writes and exact member readback. A failed gate
changes the disposable result to failure and records the publication error;
it cannot publish a new success report. Build-stop artifacts, logs, available
tool closure, partial cases, trace files and failure-state RAM are retained.

## Small preservation corrections agreed with the lead

V1 `execute_case` saves only inherited ledgers in `model_partial`. Add the actual
`reset_checkpoints`/`reset_observations`/`reset_api_events` available at the failure
point in a separately preserved V2. This is a diagnostic-preservation gap, not a
false-pass path: raw PC/access traces and failure-state RAM already survive.
The lead has accepted this change and owns V2; this review does not claim it has
been applied or checked.

The lead also identified a cleanup improvement in the separately frozen observer
V1: its post-parent-constructor watched-symbol validation occurs after inherited
gzip trace streams open. If that validation raises, explicitly close the
inherited streams before re-raising the original error. This prevents partial
constructor resource leakage and retains valid empty/partial traces; it does
not execute a target or change any execution permission. Preserve observer V1
and make this a narrow V2 delta. It is independent of the three tooling files
reviewed here.

Actual emitted ELF/input/dependency/property behavior, new callback/frame depth,
paired execution and raw semantic acceptance remain pending. This static review
establishes no hardware reset, DMA/cache settlement, USB or printing behavior.
