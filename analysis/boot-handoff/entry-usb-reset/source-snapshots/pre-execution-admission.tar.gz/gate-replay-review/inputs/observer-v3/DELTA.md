# V3 observer delta: original indirect operand evidence

V1 and V2 are unchanged in their original `/tmp` packages. V3 retains V2's
post-constructor cleanup and changes only observational operand evidence.
QEMU source is byte-identical to both previous versions.

The actual accepted healthy target already contains dynamic tail entry into
the selected provider `request_cancel`: JX a8 at 0x1000b556 has bytes 0a8000,
after loading adapter.ops.request_cancel. Another tail uses JX a9 at
0x10006b73, bytes 0a9000. CALLX0 a0 at 0x10006a05, bytes 030000, is a concrete
reason to capture before the core writes the return address to a0. These are
existing emitted-byte examples, not assertions about the new reset addresses.
The accepted disassembly is preserved under inputs with its exact hash.

The new `span` override delegates every permission/backing check first. Only an
actual execute=True instruction fetch records an audited JX/CALLX0 register
and value, together with original PC and pre-effect step count. No target
register, memory, callback, PC, access/step trace or permission is changed.
The unchanged base loop still verifies exact instruction bytes after the
override returns. Rejected byte comparison cannot produce a successful entry.

The after-instruction observer verifies the captured PC, step, register and
target, clears the temporary tuple, then delegates the same parent instruction
guards and records the same physical call/tail frame as before. Entry rows gain
`transfer_register` and `transfer_value`; both are null for direct transfers.
The independent raw checker decodes the actual transfer bytes. RET-to-function
entry is not newly admitted by this proposal. The observer still grants no
execution permission, and the parent/core sources remain unchanged.

The tuple is diagnostic observation only. It is not a parallel call stack,
operand wrapper, new execution backend or a way to perform arbitrary target
reads. Model calls, returns, twenty natural stops, six inherited guards, QEMU
snapshots/commands and all limits remain unchanged. Final evidence additionally
requires that no tuple remains pending.

Static source writing/read-through only: no imports, syntax parsing, builds,
audits, tests, validators, target execution or repository edits occurred here.
The lead owns independent review, integration and any later execution.
