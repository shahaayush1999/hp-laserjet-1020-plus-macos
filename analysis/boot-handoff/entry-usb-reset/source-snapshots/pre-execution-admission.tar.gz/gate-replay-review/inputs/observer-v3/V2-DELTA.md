# V2 observer delta: post-constructor failure cleanup

V1 remains unchanged at
`/tmp/hp1020-entry-usb-reset-observers-draft-20261003/`.
This separate V2 changes only the reset model's post-parent-constructor
validation lifetime. QEMU source is byte-identical to V1.

After the accepted parent constructor succeeds, its trace streams are open.
The inherited core-order and new watched-symbol checks now run inside a guarded
block. On any `BaseException`, the inherited `close()` finalizes those streams
before re-raising the original error. If cleanup also raises, the original
validation error remains the raised error with the cleanup failure as its cause.
No returned incomplete instance is required for cleanup.

The actual symbol-binding body is moved unchanged to `_bind_reset_entries`.
CPU/memory/call/return permissions, evidence schema, natural-stop ordering,
runtime limits and success behavior are unchanged. This covers failures after a
successful parent construction; it does not alter the accepted parent's own
partial-constructor implementation. No target instruction runs during binding.

Static source read-through only. No imports, syntax parsing, builds, audits,
tests, validation, target execution or repository edits were performed. The lead
owns independent review and any later execution. `v1-to-v2.diff` and exact source
manifests identify the narrow change.
