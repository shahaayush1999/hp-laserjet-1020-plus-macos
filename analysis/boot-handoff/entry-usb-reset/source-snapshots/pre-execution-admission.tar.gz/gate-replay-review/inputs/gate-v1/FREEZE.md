# Gate V1 freeze

2026-10-03. Independently drafted before the first reset-profile target instruction.
Root performed only audit/admission work while this gate was drafted. The author
read no new reset runtime/provider implementation or CPU/RAM result captures.
Exact new observer sources were read only to bind the public capture schema;
unchanged production APIs/headers supplied argument and state semantics.

Original frozen semanticV2, public amendment and additive literal bytes are not
changed. Pre-freeze local checker read-through corrected implementation-only
mistakes (EP0 staging offset, SAR startup-only condition, meaningful aggregate
padding, helper call argument order and existing field-offset aliases); none was
a target observation or an adjustment to the acceptance literals.

The parent-approved observer V3 addition records pre-effect JX/CALLX0 operands.
This closes a raw evidence gap found from already accepted old instruction bytes,
including CALLX0 a0, and changes no target instruction or stop. Both new observer
sources are pinned byte-exact. Their V1 schema name is retained with the approved
two fields on entry records; return rows are unchanged. No RET-entry allowance.

The parent-approved pre-build library selection note is pinned separately:
original archive and two raw inventory members retained, actual map selects only
udiv. This is a reset-profile source dependency change, not a widened runtime or
arbitrary subset rule. Unchanged neutral helper remains exactly pinned.

DRAFT.sha256 covers draft checker/helper, all read-time input copies and these
notes. V1 is now immutable. Any later review/execution correction must be copied
into a separate version with its original stop/review/provenance preserved.
No parse, import, build, audit, test, validator or target execution is claimed.
