# Independent continuous reset evidence gate — unexecuted draft

Author: `/root/usb_reference_contract`, 2026-10-03. This is a separately authored,
stdlib-only saved-capture checker. No checker/producer/observer source was parsed,
imported or executed while drafting. No build, target instruction, validator,
printer operation or repository edit was performed. New runtime/provider C and
new candidate result captures were not read. Parent owns review and execution.

Run after integration with the exact pinned neutral reader beside the new file:

```
python3 scripts/check-hp1020-entry-usb-reset.py CAPTURE --source-root REPOSITORY
```

The public function is `check_capture(capture_root, source_root=None)`, returning
`(ok, detail)`. It reads saved bytes only. CLI failure is nonzero. It neither
repairs evidence nor invokes tools/targets; there is no host-only success mode.

## Independent authorities

The embedded semantic V2 and additive literal blocks are exact text copies of
the independently frozen contracts. Original V1/V2/addendum remain untouched.
The public header and manual 525-word/118-field layout table are source-pinned.
The new runtime source is not an oracle. Fixed pixels, generation/tickets/cookies,
240 ordered logical hook records, 65 actual-span rows, 15 binds, all descriptor
and receive-prefix effects, four WAITs/two STALEs and the healthy final ZLP drain
come from those frozen contracts and unchanged production APIs.

The library selection is a separate source-reviewed contract frozen before the
first reset build: only the original udiv member is linked, both known original
members plus the complete archive remain captured as provenance inventory. No
healthy exact-two linked-helper assumption is reused. The original archive,
member payloads, sole76-byte helper/trap, map references and28 LOAD inputs are
checked independently. The five forbidden shortcut functions still require
original ET_REL definition/section plus exact discarded-map proof when absent;
retained entries remain forbidden. Actual out_request_cancel is now purposeful.

## Reuse map

The sole import is the preceding independent checker with exact SHA256
`38f520c5d23834532806821d14ce9e5a8c3703d57935bcc923e453b43dece277`.
It is admitted before loading and is never modified. Reused functions are neutral
bounded file/hash/JSON helpers, ELF reader, memory slice/put/width/encoding helpers,
register/snapshot readers, immutable-region comparison, fixed initial paint,
private-core getter byte proof, gzip reader, GNU ar decoder, discarded-function
proof and the exact-command Ledger reader. Its constants retain the unchanged
RAM spans, CPU map, source/map format and baseline production field offsets.

The new gate has its own source/target/library checks, semantic snapshots,
original-argument/return contract, raw instruction/access/call replay, twenty-stop
GDB ledger and top-level acceptance. It does **not** call the old healthy
model_trace, check_entry, semantic_snapshots, qemu_ledger or check_capture, and
never monkeypatches imported globals. Tools/QEMU plumbing was copied textually
and scoped to new source paths, 21/23 snapshots and reset-specific library choice.

## Raw evidence checks

Every full snapshot includes all seven regions, 32 physical ARs, 16 logical aliases
and admitted special registers. The gate reconstructs file overlays/nonzero paint,
startup-only zeroing, all525 compiled constants, private68-byte TinyUSB state and
actual CPU arguments at the natural stop. `pre-c` explicitly means the original
assembly `hp1020_entry_before_c` CALL0 boundary, not the function body. SAR must be
zero after normalization/pre-C; ordinary C may use it afterward. Own SP is restored
on the real return to park. Two actual park steps must preserve all CPU and RAM.

The local model replay consumes every raw PC and access row, checks actual opcode
memory width/literal address, preceding read bytes, phase-specific write spans,
full initial scan, all original physical calls/returns, and all twenty first hits
of the next armed natural role. No occurrence counter skips an armed breakpoint.
It reconstructs complete RAM at each stop and ties mixed API entry/return rows to
the actual physical frame, raw cursor and unchanged return PC/SP. Tail-entered
functions share their genuine frame and return in innermost order.

JX and CALLX0 are necessary original compiled transfers, not new permissive paths.
Accepted byte examples are JX a8 `0a8000`, JX a9 `0a9000`, CALLX0 a10 `03a000`,
a11 `03b000` and importantly a0 `030000`. Mask `0xff0fff` distinguishes JX
`0x0a0000` / CALLX0 `0x030000`; operand register is byte1>>4. Observer V3 must
save that operand **before** the instruction (CALLX0 a0 overwrites it). Entry rows
carry transfer_register/value, null for direct transfers; the checker decodes and
binds both to actual next PC and retained frame. It additionally cross-checks
unchanged a2..a7/SP operands when exposed by the original entry observation.
RET-to-function-entry is not an added allowance.

Four actual WAIT returns protect production BSS, private core, initialized data
and all document memory, apart from the documented last_class_result. Their raw
writes are limited to stack and actual busy/class-result fields. Both stale calls
permit only stack and transient OUT busy; they cannot read the reused descriptor,
payload, source image or setup storage, write hooks/evidence, alter acquisition
diagnostics or grant recovery. The old SUCCESS32 driver callback is tied to its
original delivering cookie and performs no receive completion, feed or document
mutation before truthful promises. Generation restart preserves all114704 bytes.
Actual fresh feed/release, output/END_DOC and final healthy ZLP calls are counted
and checked independently of the mailbox.

The local QEMU transcript checker reconstructs one98-command initial seed after
four constructor commands, the lock, all57-register/57-memory-chunk snapshots,
twenty exact Z/c/observe/z cycles and two actual park steps. No hidden function
call, extra mutation, addressed resume, skipped stop or unpaired reply is admitted.
The original120-second helper,4096-command/16MiB ledger and10M model caps remain.

This is not a third instruction-level arithmetic engine. Selected-register and
return values remain source-bound model observations, strengthened by actual
frame/access replay and full independent QEMU snapshots; it does not invent a
physical CPU/USB/controller/cache/settlement/output guarantee from RAM records.
