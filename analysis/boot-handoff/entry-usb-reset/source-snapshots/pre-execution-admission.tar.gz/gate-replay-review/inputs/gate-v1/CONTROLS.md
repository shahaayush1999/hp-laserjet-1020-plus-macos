# Proposed copied-evidence controls — not executed

Run baseline first on a complete paired report. Preserve original captures and
change fresh copies. Recompute relevant region/report seals, and make paired
copies agree where applicable so rejection reaches the intended independent
contract rather than only a byte-seal mismatch. Keep exact changed bytes/reason.

1. At the paired late-PENDING stop, change the original cookie to the new transport
   epoch or set expected_cancel. Reject original identity/fake-cancellation state.
2. Insert a claimed old (2,6) receive completion or old tail feed in selected
   events/calls. Reject actual code/frame/cursor closure and forbidden old feed;
   do not count this as actual execution of that path.
3. Change one WAIT result/check row and recovery part consistently across metadata
   and paired snapshots. Reject original API return/permission and preservation.
4. Change the saved stale replay to the current reused cookie while preserving
   slot/address. Reject original call0 cookie rather than accepting address reuse.
5. Alter acquisition last diagnostic or an otherwise untouched receive tail in
   both stale-pair snapshots. Reject full-production/stale or receive byte oracle.
6. Replace the final healthy zero completion with cancellation metadata, clear
   core BUSY before service, or consume the reservation at acquisition. Reject
   original PENDING/count/core and genuine service/release ordering.
7. Change the fresh event to old generation2 or first_page1; change one FF pixel
   in both engines/witness/output and update hashes. Reject literal fresh output.
8. Omit/reorder one natural repeated-PC stop or inject a post-lock debugger write
   with otherwise complete pairing. Reject exact20 ordered no-repair transcript.
9. Change a JX transfer operand/physical frame while keeping entry name and target
   address. Reject original opcode/register/value/frame closure. A fabricated
   return to a function start remains inadmissible.
10. Select an extra archive/member or insert a false LOAD, and separately change
    an extracted original member byte. Reject exact udiv-only selection or archive
    payload provenance; these are admission controls, not target lifecycles.

The raw PC/access replay is not a complete arithmetic emulator. A copied control
must be named according to the actual failed predicate; do not describe a metadata
rejection as observing the proposed malicious target behavior.
