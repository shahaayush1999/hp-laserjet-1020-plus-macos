# Reset observer modules — unexecuted draft

This package adds only `hp1020_entry_usb_reset_machine.py` and
`hp1020_entry_usb_reset_qemu.py`. No repository source was changed. No Python
source was imported or parsed, and no build, audit, validation, target or hardware
execution occurred. The lead owns integration, source closure, linked admission,
the independent semantic gate, execution and durable capture publication.

## Exact interfaces and prerequisite

The requested interfaces are:

```
EntryUSBResetMachine(program, regions, initial, checkpoints, trace_dir, observe)
execute(initial_regions, initial_registers, checkpoints, layout, output_dir)
```

The separate reset audit must additionally expose
`program.entry_symbol_records = [dict(r) for r in elf['symbol_records']]`.
These are the same raw symbol records already present in the audit report, not
a new inferred callback map. Existing `entry_function_starts`, symbols, admitted
instructions, read/write ranges, four actual zero spans, data and stack fields
remain required. The healthy audit and its accepted evidence stay unchanged.

The ordinary name→address map loses one of the two local `request_cancel`
definitions in the current linked closure. The new ledger keeps both actual
nonempty function records. The independent gate binds the provider callback from
the actual adapter callback pointer and audited bytes, not its textual name.

The twenty labels/roles come exactly from the frozen independent addendum
SHA256 `4b9df5dc50186b05879ae7fc71f9922302679d6ffeda2402a218c8686bb5cea0`.
Only `after-normalization`, `pre-c` and `park` map to existing assembly symbols;
all other roles map to the named actual functions. The pre-C cut is immediately
before the initial CALL0, not at the first instruction of the C function.

## Guard delegation

The model subclasses the unchanged `EntryUSBMachine`. It passes only the six
accepted core checkpoints into that constructor and does not replace its
`checkpoints`, `seen`, `calls`, `call_stack`, `entry_names`, access traces or
instruction traces. The parent alone implements instruction/CPU normalization,
all data/fetch/write permissions, own-stack/call/return checks, phase-dependent
writes, one close/finish and two inert park iterations. Its six-core evidence
retains the same names and meaning.

A separate ordered ledger captures the next expected natural role. Every first
hit of that currently selected address is observed; there is no ordinal skip,
injected call, PC repair, target-memory read operation or instruction omitted.
Earlier legitimate calls to addresses not currently selected remain ordinary
execution and are still present in raw PC/access/entry evidence. Core callback
file observation is delayed only to the end of the same already-guarded
instruction transition so that call metadata is recorded first; no instruction
executes or memory changes in between. Adjacent selected addresses must differ.

The subclass also follows the existing real physical CALL0/CALLX0 frames in a
private observational stack. It never grants permission. Returns are emitted
only after the parent's exact original return-PC/SP guard passes. Tail-entered
selected functions can share a physical frame and point to the same actual
RET. The independent gate must verify those relationships from raw trace bytes.
One `run(args=(), budget<=10000000)` is admitted; repeated invocation, arguments
or a larger budget are rejected.

QEMU subclasses the unchanged `ObservedUSBQemu`; it changes only the closed
breakpoint/continue/park admission from six to twenty roles. Constructor, exact
seed, post-seed lock, command handling, input/read policy, full snapshots, cleanup
and partial-failure capture use unchanged helpers. New local orchestration owns
the fixed twenty-role loop. Repeated roles use exactly the same original PC;
distinct roles cannot alias. The old memory policy validates four actual BSS
spans, the same 8 KiB stack and actual initialized data. No permission, command,
reply, byte or timeout cap is widened: 4096 commands, 16 MiB ledger, 120 seconds,
57 register reads and 57 memory chunks per snapshot.

## Evidence schema

Root records the initial model snapshot separately. The observer invokes its
callback twenty times, yielding 21 paired snapshots including initial. QEMU's
existing `snapshots` format contains initial + twenty roles + two full park
snapshots = 23. Every stop reads complete supplied RAM and all actual registers;
no new per-call QEMU stop or hidden single-step is introduced.

The inherited model evidence keeps `checkpoints` as the original six names and
`actual_entry_events` as the original selected-name ledger. Additions are:

- `reset_checkpoints`: the twenty observed labels in exact order.
- `reset_observations`: twenty records with `label`, `address`, `instruction`,
  `access_index`.
- `reset_api_events`: selected actual entry/return records described below.
- `reset_observation_schema`: `hp1020-entry-usb-reset-observation-v1`.
- `reset_cursor_convention`, `reset_host_target_calls=0` and
  `reset_host_target_mutations=0`.

`instruction` is the count of completed instructions and therefore the
zero-based raw-PC index of the next instruction at `target`. The causing CALL/J
or completed RET is index `instruction-1`, stored as `pc`. `access_index` is the
number of completed raw access rows at that same boundary, before effects of
`target`. This convention is identical for entries, returns and observations.

Entry records have `kind='entry'`, `name`, `pc`, `target`, `instruction`,
`access_index`, `arguments` (logical a2..a7), `sp`, `return_pc`, `call_pc`,
`call_ledger_index`, `depth`, and actual `transfer` opcode. `call_ledger_index`
selects the originating physical call record in inherited `calls`.

Return records have `kind='return'`, `entry_event_index`, `name`, `pc`, `target`,
`instruction`, `access_index`, actual logical a2 as `result`, `sp`,
`call_ledger_index`, and `depth`. `entry_event_index` indexes that same mixed
`reset_api_events` array. Void-return a2 is recorded without assigning a success
meaning. Multiple tail entries sharing a real return are emitted innermost first.

The selected names are the inherited twenty APIs plus the fifteen additional
names in `ADDITIONAL_ENTRIES`, including OUT cancellation, checked-return/source
helpers, real receive completion/release, feed/ring callbacks, status completion,
driver delivery, document output and provider cancellation/output/event callbacks.
All matching actual function addresses are retained. This provides direct
boundaries for the four actual WAIT returns, two actual STALE returns, ordinary
cancellation success, late original driver delivery and absence of old tail feed.

These records are observations, not acceptance predicates. The separate raw gate
must reconstruct instruction transitions, physical frames, stack/pointer
arguments and original identities from actual code/accesses/RAM; it must compare
the selected calls' before/after production bytes and exclude any invented
completion, feed, settlement or callback. Mailbox check rows alone prove none of
those claims. The observer does not manufacture or suppress them.

## Freeze and integration

`inputs/` and `INPUTS.sha256` retain all read-time neutral sources and the public
contract/addendum/design. `DRAFT.sha256` seals these two new scripts and this
note. The QEMU source-copy path also saves itself and the unchanged old USB/entry
observer/back-end/primary closure before later execution. Root's source capture
must include the new model, both reused model modules, unchanged call0 engine,
new QEMU module and existing source-copy dependencies.

No syntax success, target compatibility or reset lifecycle pass is claimed.
Fresh emitted input/ELF/function/stack closure, paired execution and the frozen
independent raw gate remain prerequisites. Physical settlement, cache/mapping,
controller reset and printer behavior remain supplied or unproved as specified
by the public reset contract.
