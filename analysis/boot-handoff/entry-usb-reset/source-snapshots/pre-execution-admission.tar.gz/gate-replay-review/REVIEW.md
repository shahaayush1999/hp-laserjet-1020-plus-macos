# Reset gate V1: independent observer/replay/transcript review

Reviewed 2026-10-03 by `/root/adapter_review`, statically only. No producer,
checker, parser or Python module was imported or executed; no build, audit,
validator, candidate instruction, device operation or repository edit occurred.

No actionable blocker found within the assigned scope: actual transfer and
call/return/access replay, observer V3 compatibility, twenty-stop QEMU transcript,
raw bounds and source binding. The lead separately reviews semantic state/manual
layout/entry acceptance. This review does not substitute for that review or an
execution result.

## Actual entries and returns

The local replay consumes original PC rows and decoded bytes, reconstructs the
physical CALL0/CALLX0 stack, and binds each selected event to its original
`call_ledger_index`, call PC, return PC, stack and depth. It retains duplicate
local function names by actual symbol/address, matching observer V3. Direct
CALL0/J targets are decoded from bytes; a selected entry cannot be fabricated by
merely inserting a label in the event list.

The exact JX/CALLX0 masks and register extraction agree with accepted emitted
examples and observer V3. Indirect entry rows require the recorded original
register number and value to equal the actual next PC. The source-pinned V3
observer obtains that value during the genuine guarded fetch, before CALLX0 can
overwrite a0. The gate correctly avoids sampling post-call a0 and cross-checks
unchanged argument/SP operands where they are present. It grants no additional
RET-to-function-entry allowance.

JX does not allocate a new physical frame. Selected tail entries share the
current frame; original returns are processed in the same innermost-first order
as the observer. Completed-instruction/access cursors agree: a target entry or
post-RET row is at index i, the causing instruction is i-1, and access_index is
the complete preceding access prefix. The gate consumes all selected rows and
all physical call records and requires no outstanding frames/returns at end.
Void a2 values are observations unless a separate API contract expects a result.

## Raw access and checkpoint replay

Every admitted raw PC is an independently width-decoded annotated instruction
boundary. The replay consumes one exact-width/aligned access record for each
recognized memory instruction, verifies read values against preceding bytes,
checks L32R addressing independently and applies only permitted phase writes.
Full RAM is compared at every first hit of the next armed natural checkpoint.
The before-C boundary is the actual startup CALL0, not an invented API call.
Earlier ordinary calls to a later checkpoint's function remain in the trace;
there is no skip counter once that role is armed.

All twenty added observations, the six inherited guard observations, original
selected-entry subset, final RAM, access counts and complete call/return rows
must agree. Trace decompression remains bounded at40M PC bytes and200M access
bytes, with the unchanged10M instruction cap. Two terminal self-jumps remain
actual instructions; excluded trap/ENTRY encodings are rejected. The selected
API semantic checks use the same replayed RAM at entry/return, rather than an
unrelated saved mailbox result.

This is deliberately not a new full arithmetic/register CPU emulator. Selected
argument/return values remain source-bound model observations, checked against
actual frame/access effects and paired QEMU registers at natural checkpoints.
The gate's README states this limit honestly.

## QEMU transcript and source closure

The new local transcript checker uses only the unchanged bounded neutral Ledger
reader. It consumes the exact constructor traffic, the sole initial seed/lock,
all20 Z/read/continue/PC/snapshot/remove/read cycles, final self-J byte read,
two actual park steps and cleanup. All23 snapshots include the complete57
registers and57 memory chunks over the original seven envelopes. Command/reply
pairing, phases, actions, complete raw reply values, saved snapshot seals and
end-of-ledger consumption prohibit an unrecorded extra resume or mutation.
The4096-command and16MiB raw-ledger bounds remain unchanged; the observer's
source-pinned120-second execution scope remains unchanged.

The exact V3 model/QEMU and all neutral helper/backend/primary source seals are
bound to saved files. The QEMU source inventory must equal the required closure,
not merely contain it. The inherited healthy semantic/schedule routines are
not called or monkeypatched. Source/target trees are sealed before observation
acceptance, and the reset runner's V2 failure additions preserve partial reset
ledgers without creating success evidence.

## Resolved review question

An early review message questioned the EP0 take busy/stack_active zero check by
recalling a superseded inside-DCD proposal. Re-reading the final frozen
ADDENDUM.md110–114 and observation-design-V2.md34–39 resolves it: the DCD only
prepares/binds, and both actual takes are outer orchestration after unwind.
The zero checks are correct. That suspicion was withdrawn to the lead and gate
author; no gate change is requested for it.

## Exact preserved basis

- gate V1: `1dbcdb801178d4d62f03324c237041ec39c29f36d2e7e5b78ea416ac143ba989`
- gate DRAFT.sha256: `ec733df525e62a1de1c38ce92f399ee87611b0660b9a1cdfaf07abce0a2efa78`
- neutral independent gate: `38f520c5d23834532806821d14ce9e5a8c3703d57935bcc923e453b43dece277`
- observer V3 model: `416da967974ac555b6365f3ba52e46bdac32650426fb06856ba8ff0f9a20c083`
- unchanged reset QEMU observer: `10784d56e54277919b788f83ef6195628b77667e804b869ac9bf69d99ec7a862`
- runner V2: `81cde1ff5891a0a72609a6f218a369764055d9430ef0ecc6408578e94368c9cb`

`inputs/` contains the complete frozen gate and observer packages, their neutral
source and contract copies, and the reviewed runner. `INPUTS.sha256` seals every
member. No claim is made that the new reset candidate or gate has passed.
