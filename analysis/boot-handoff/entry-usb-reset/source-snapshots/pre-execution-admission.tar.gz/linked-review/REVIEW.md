# Independent linked reset-runtime frame and callback review

2026-10-03. **No blocker found for the fixed serialized RAM-only schedule.**
The fresh conservative static ceiling is **7,904 bytes**, below the unchanged
8,192-byte owned stack by288 bytes. This sums every retained C function once,
using a deliberately conservative frame for colliding local names. It is not
an observed peak, a general USB-input bound or a hardware/exception-stack claim.
The earlier7,472-byte ceiling was not transferred.

This review read saved sources, ELF bytes, compiler reports, disassembly and
JSON. Its small local extraction programs perform only byte comparison,
metadata arithmetic and graph traversal. No candidate/audit module was imported;
no compiler, linker, audit, validator, interpreter, QEMU or target instruction
was run. Repository files were not edited.

## Exact reviewed image

Capture: `/tmp/hp1020-entry-usb-reset-jemqpib2`.

| Input | SHA256 |
|---|---|
| target/entry-usb.elf | d2daf38cbff95b0a2b990c7fc99b0b5655ebfb1c8e12bc9f108c65bf5ed2fa8f |
| linked-audit.json | bb1a59b59c62b4c807dcf48c1b1e73b3c79c3bba3e7f0414374a88b6fa1946f1 |
| annotated-disassembly.txt | d8176a45bfcce300d47bb9e634d06e98254ff3dd88ffd4eeb94851314d24c7d4 |
| fresh frame catalogue | 76ede9fef5d79e0ebe3b21e38bd1c4e3e9259d7e1fdbd63c1d53105d9a5386e0 |
| explicit callback graph | 7d6c0ea99442fb1ff147519d96c8d2be1a978ecea52c1edbf6299071cdadcf0b |

The saved26 `.su` reports are all `static`. The exact sized-symbol list has
276 functions:271 C functions plus the stack-free normalizer, entry jump,
two parks and76-byte `__udivsi3`. There is no modulo helper. All17,005 annotated
instruction byte strings (including the separately excluded division trap)
compare directly with ELF file-backed bytes. The276 sized nm entries agree
exactly with the audit's function records, including both local
`request_cancel` functions; they were never collapsed by name.

## Fresh stack accounting

The prior arithmetic methodology is applicable because this program still uses
fixed call0 frames, one owned stack and explicitly installed synchronous
callbacks. `frame-catalogue.awk` was read and reused solely for metadata
arithmetic. Optimization-number/name spelling is normalized; every retained
function gets the maximum frame reported under that normalized name among all
26 inputs, even if that larger same-named function was discarded. This assigns
48 bytes to both distinct `request_cancel` symbols although the adapter's
actual tail wrapper uses no stack. Such collisions overestimate, not undercount.

All355 explicit SP destinations were inspected:one startup L32R,336 fixed ADDI,
four ADDMI,12 ADD.N and two ADD. Ordinary ADDI changes are aligned fixed
±16/32/48/64/80/96/112. The larger changes are:

| Function | Frame | Allocation instruction | Restoration instruction(s) |
|---|---:|---|---|
| settle_status |144|10003453 ADD a1,a1,a9 after MOVI -144|1000355e|
| runtime entry C |144|10003605 ADD.N after MOVI -144|1000384b,10003d37|
| provider initialization |240|10005033 ADD.N after MOVI -240|10005252|
| publish prepare |176|10006393 ADD after MOVI -176|10006880|
| EP0 init |144|10006ae9 ADD.N after MOVI -144|10006cbe|
| acquire packet |160|1000712f ADD.N after MOVI -160|10007418,100074a3|
| image chunk_in |256|10008834 ADDMI -256|100089e2,10008a69,10008a85|

The large restorations load the corresponding positive literal amount, with
saved registers restored before the final ADD. Every ordinary SP change is a
fixed16-aligned step at or below its fresh compiler-catalogue ceiling. No
dynamic allocation, variable SP assignment, windowed ENTRY/call or assembly
spill frame appeared. The lone startup L32R at10003053 establishes the owned
top10016020; stack extent is10014020..10016020. Call0 stores its return link in
a register, not an implicit hardware stack frame. Outgoing argument storage is
already part of each compiler report. The unsigned division helper has no
calls/SP writes; its ILL/DIV0 path remains excluded.

## Actual indirect transfers and original callback bindings

All93 indirect sites are classified:45 exact literal function tails,37 fixed
callback sites, eight bounded within-function switch tables, and three
unavailable callback branches. Literal target words and all eight switch tables
were read from the ELF itself. Every switch target remains inside its original
function after its prologue; none starts another frame or re-enters allocation.
The static graph contains direct calls/cross-function jumps, literal tails and
all37 source-bound callback edges, including conditional errors. It has no
cycle, including self-calls. Source contracts, not an observed run, supply the
callback bindings:

- Actual linked36-byte `class_driver` has exact init/deinit/reset/open/control/
  transfer function pointers; `sof` and `xfer_isr` are literal NULL. The linked
  `_usbd_qdef` starts with the actual `usbd_int_set` pointer. These immutable
  words were independently compared with the linked function entries.
- Publisher/acquirer callbacks bind the fixed provider RX/descriptor/order
  hooks. Program and publisher logical read/write/order callbacks bind the
  fixed provider. Hooks only check, copy, record and return; none calls service,
  arm, acquire, pump or a completion recursively.
- TinyUSB's initialization/reset/open/control/transfer dispatch targets the
  actual custom driver table. EP0 ACK invokes the provider status hook, then
  the real class control callback. The provider status hook records only;
  release_response returns through the core rather than reentering service.
- Document/image bindings are chunk_in, consume, boundary, document_out,
  provider document_event/output, and row_out. Output callbacks only operate
  the retained ring and witness. row_out only copies/counters. None feeds or
  decodes recursively. Document restart rebuilds these bindings without
  invoking them or feeding abandoned bytes.
- The two literal-NULL core callbacks cannot be called. The remaining generic
  deferred-function site1000a681 is not produced:usbd_defer_func is GC-discarded
  and this provider/adapter only queues the explicit reset, SETUP and packet
  events. Arbitrary deferred events would invalidate this workload bound.

The fixed graph's longest weighted walk is1,280 bytes when tails are still
added as nested frames. It combines mutually exclusive/error branches and is
only a secondary overestimate; the reported admission ceiling deliberately
uses the simpler all-retained-function7,904 sum. Neither number is a measurement.

## Reset-specific nesting and tail evidence

The adapter `request_cancel` at1000bf08 is a real zero-frame tail wrapper:
1000bf18 loads ops.request_cancel from adapter+12 intoa8;1000bf1a..1000bf22 copy
the original owner's five ABI words intoa3..a7;1000bf24 loads context at+16;
1000bf26 executes bytes0a8000, JX a8. The actual installed pointer is the
provider callback at10003d7c. No synthetic CALL, new link or new generation is
created. The provider has a48-byte frame, validates all five original fields,
records the one request and returns. It does not call cancellation settlement,
service, acknowledgment or restart. Its error-only JX a9 at10003f1a restores
48 bytes at10003f0e and uses a linked literal for runtime_fail. Other adapter
cancellation tails100074f7/1000754c likewise target their genuine helper entries.

The reset schedule adds no concurrent activation:admit/fence/cancellation
callback returns before the explicit OUT mark and service; class dispatch
begins deferred recovery and returns; late old acquisition queues completion
and returns; service drains that original callback while fenced and discards
its bytes; only after service returns can receive/output/transport promises
and finish-reset run. Finish-reset invokes document_restart synchronously,
then submits deferred EP0 status through the core/DCD. Both operations unwind
before the outer explicit EP0 observation/service. The second status callback
does not restart or pump. Stale-cookie probes refuse before hooks and do not
reenter the retained/current callback. The fresh document loop and final
close/ZLP/service/finish remain sequential.

The existing machine's CALL0/CALLX0 guards require an actual audited function
entry, own aligned SP and return to the original call's SP/link. JX tails
share that original call frame; the reset observer records both local callback
entries and their one real RET without fabricating a new call. This review
confirms these concrete tail targets; it does not authorize arbitrary computed
branches, runtime repair or debugger function calls.

## Limits and preserved evidence

No asynchronous IRQ/debug/exception producer, arbitrary callback replacement,
corrupted object graph or physical stack ownership is covered. The root-owned
first execution must still check actual SP/access minima, function transitions,
returns and all20 checkpoints without intervention. Source/compiler/callback
changes require fresh review. Tests passing later will not prove hardware,
cache, controller settlement or printing.

This package preserves exact ELF/map/symbols/all27 objects/all26 `.su` reports,
audit/annotated bytes and source/tool identities, relevant original captured
sources/headers, actual effective TinyUSB C, and the prior methodology note.
`static-extraction.json`, `literal-tail-targets.json`, `callback-graph.json`,
`frame-steps.json`, complete text extracts and arithmetic scripts retain the
review basis. All package members are sealed by `DRAFT.sha256`.
