# Read-only arithmetic over retained compiler reports and saved nm symbols.
# It does not decode/execute instructions, import a candidate, or admit an ELF.
# Local-name collisions deliberately take the largest frame from every input
# .su, including discarded functions. This is an upper bound, not exact size.
FILENAME ~ /\.su$/ {
    n=$1
    sub(/^.*:[0-9]+:[0-9]+:/,"",n)
    gsub(/\$/, ".", n)
    gsub(/\.[0-9]+/,"",n)
    if ($3 != "static") {
        print "NONSTATIC",FILENAME,$0 > "/dev/stderr"
        bad=1
    }
    if (!(n in frame) || $2>frame[n]) frame[n]=$2
    next
}
NF==4 && $3 ~ /^[TtWw]$/ {
    n=$4
    gsub(/\$/, ".", n)
    gsub(/\.[0-9]+/,"",n)
    if (n in frame) {
        printf "%s %s %s %u\n",$1,$2,$4,frame[n]
        total+=frame[n]
        count++
    } else {
        printf "UNMAPPED %s\n",$0 > "/dev/stderr"
    }
}
END {
    printf "CONSERVATIVE_NAME_MAX_SUM %u FUNCTIONS %u BAD %u\n",total,count,bad
}
