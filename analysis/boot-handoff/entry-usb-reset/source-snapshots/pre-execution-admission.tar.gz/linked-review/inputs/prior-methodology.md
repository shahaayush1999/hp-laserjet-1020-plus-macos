# Independent linked USB-runtime frame and callback review

Frozen 2026-10-03. Read-only review of the newly linked program and the narrow
two-helper audit correction. No target, interpreter, QEMU, build, candidate
module import or validator was executed by this reviewer. Read-only arithmetic
over saved compiler metadata and textual extraction of saved disassembly are
identified below; they do not admit or execute a target.

## Result and exact boundary

No remaining blocker was found in the reviewed frame, callback and libgcc
classifier subset for the fixed, serialized RAM-provider workload. The fresh
conservative static ceiling is **7,472 bytes**, below the separately owned
8,192-byte stack. This is deliberately much larger than a feasible simultaneous
call chain. It is **not an observed stack peak, an all-input TinyUSB bound, an
exception/reentry bound, or a physical boot/RAM claim**. The old document-only
784-byte bound was not reused.

The first successful link-only image was initially unadmitted. Root subsequently
completed the new whole-linked audit before this review froze. Its saved ELF is
byte-identical to that original link-only image. At that audit checkpoint no
target instruction had executed. This review does not replace the independent
raw gate, the root's raw-input/removed-section gate, or subsequent actual
interpreter/QEMU stack and boundary observations.

| Exact input | SHA-256 |
| --- | --- |
| `target/entry-usb.elf`, both captures | `5d20ef15633de527aaa2d92001c6e910006e3a26eefadd0512a1594884eddf3b` |
| passed `linked-audit.json` | `681b7a740917afae5aa90a4b26fdb52a00a35303a187bcc086ade239479d4e92` |
| passed `annotated-disassembly.txt` | `dcd259978ae498cf5ee85d6c0775d206c5cbdbcd3fa2c0a7fc3a5ff43723705d` |
| reviewed classifier before | `e69e50abe58720660ef4972a4b9e839b240b878b89144d9fcb3ede40d95466f3` |
| reviewed classifier after | `491227dc04f840d8b100b4c04b628a5d9da62978c023d850d3a40b93f41d6116` |
| pinned GCC14.3.0 `lib1funcs.S` | `797133627a7b62390ff2cf3c6dd2b5d2e723c552793f88c84b73450f4127c908` |
| this package's full input manifest | `96daf10ad5571804de6e893a483f86f4253ab5262a0e52495db876282d9e9903` |

Original captures are `/tmp/hp1020-entry-usb-link-only-6by_g5e1` and
`/tmp/hp1020-entry-usb-oiav3mu0`. `inputs/target` preserves the former; the latter's
audit, annotated bytes, source manifest and all26 `.su` reports are preserved in
`inputs/audit-pass`. The final integrated audit source hash reported by the latter
is `a1544c2e1b155dcb70b1b12b1d0be99f1558799a2e56b697a4477c9a7e259f22`;
that includes root's separately reviewed raw-input/dependency changes, not just
the narrow classifier delta reviewed here.

## Fresh frame accounting

`frame-catalogue.awk` performs only arithmetic over the saved `.su` and sized
function-symbol records. Every compiler report must say `static`. GCC's `$`/`.`
optimization-name presentation is normalized. Where multiple input functions
share a normalized name, the largest same-named frame in **all**26 input reports
is assigned to every retained symbol with that name, including when the larger
input function was discarded. This intentionally overcounts local-name
collisions. The retained-symbol catalogue includes all linked C functions, not
only the expected positive path.

Both captures independently produce the exact same catalogue:264 retained C
function symbols, all static, summed once each to7,472 bytes. The later TinyUSB
`.su` reports have a different temporary source-directory prefix; their frame
catalogue and six unmapped entries compare exactly. Both original report sets
remain preserved. `conservative-frames-audit-pass.txt` has SHA-256
`8e4bd327f231f2ba379b7d19a39209677c99d07118732289bd2a6c71899f17c3`.

The six remaining nonempty functions are the normalizer, normal park, unexpected
park, entry jump, `__udivsi3` and `__umodsi3`. Their exact instructions are
stack-free. The C count plus these six agrees with the audit's270 function
records. Call0 puts its link in a register; it adds no implicit window/stack
frame. Caller argument storage is already included in the compiler's frame.

The annotated instruction stream, not broad linear objdump, was used to inspect
every explicit SP destination. There are340:one startup `L32R`,323 `ADDI`,four
`ADDMI`,eleven `ADD.N` and one `ADD`. All ordinary `ADDI a1,a1` values are fixed
aligned amounts ±16/32/48/64/80/96/112. The larger register-add cases use the
following constant prologue/epilogue sizes; they do not use input-dependent
allocation. The four ADDMI instructions are the256-byte allocation and its
three alternative restorations. There are no other decoded instructions that
assign SP, no ENTRY/windowed call, dynamic alloca or hidden assembly spills.

| Function | Frame | Exact allocation anchor |
| --- | ---: | --- |
| `hp1020_usb_runtime_c` |208| `100033ba: MOVI a9,-208`; `100033bd: ADD.N a1,a1,a9` |
| `hp1020_usb_runtime_ram_init` |240| `100049bc: MOVI a9,-240`; `100049bf: ADD.N` |
| `hp1020_udc_publish_prepare_and_publish` |176| `10005a0c: MOVI a9,-176`; `10005a0f: ADD` |
| `hp1020_udc_ep0_init` |144| `10006160: MOVI a9,-144`; `10006165: ADD.N` |
| `hp1020_udc_acquire_packet` |160| `100067a8: MOVI a9,-160`; `100067ab: ADD.N` |
| `chunk_in` |256| `10007eb0: ADDMI a1,a1,-256` |

Restorations occur at100036e8/100038c3,10004bde,10005efc,1000633a,
10006a94/10006b1f, and1000805e/100080e5/10008101 respectively. The single startup
SP load at10003053 uses the owned-stack-top literal. The normalizer/entry does
not allocate a hidden frame before the C call. `annotated-sp-destinations.txt`
preserves the full extraction, SHA-256
`40b1f8993dd9907c68b1b5ba6a6e185ece57ea6b4479f74198d76b528256194f`.

## Why summing functions once is conservative for this workload

This argument depends on the fixed callback bindings and serialized event
producer, not on a general promise that callbacks are harmless. The preserved
source set includes the root/provider, actual patched TinyUSB device core,
adapter, descriptor/publication/acquisition components and full document/image
path. The relevant boundaries are:

* The root invokes initialization, reset/configuration service, recovery,
  arm/acquire/service/pump, close and finish sequentially. It does not call its
  own entry recursively. All13 arm/acquire iterations unwind before the next.
* The three logical I/O hooks, publication range hooks and acquisition hooks
  validate/copy/log and return. They do not call service, arm, pump, complete or
  acquire recursively. The genuine DCD bulk callback calls publication prepare
  and adapter binding inside the one synchronous arm window; binding is a
  distinct function and cannot call arm again. The provider's cancellation
  callback records/fails; it does not settle, service or resubmit.
* Adapter service calls `drain_stack`; the core dispatches the fixed class table.
  The actual open/control/transfer callbacks call the appropriate ordinary core,
  printer and DCD APIs, then return. The DCD does not synchronously report a
  completion. `deliver` may call a later `drain_stack`, after the first drain has
  returned; no second activation of service/task/drain is introduced. Provider
  guards also reject misplaced stack-active/output callback combinations.
* `_usbd_qdef` uses `usbd_int_set`; the supplied interrupt enable/disable functions
  return without generating an interrupt or event. Only actual adapter reset,
  SETUP and transfer-complete event constructors feed this profile. The generic
  `USBD_EVENT_FUNC_CALL` callback branch remains linked in `tud_task_ext`, but
  `usbd_defer_func` is not linked and the provider creates no such event. A new
  producer of arbitrary deferred callbacks would invalidate this argument.
* Document pump feeds semantic parsing, whose bound `chunk_in` invokes the image
  decoder. `jbg85_dec_in` may call `finish_sde` and `decode_pscd`; `finish_sde`
  calls `decode_pscd`. None calls back into the parser or decoder entry. The bound
  `row_out` only copies into the current band and updates counters. Decoder
  calls return before `chunk_in` invokes `band_out`/the output bridge.
* Output consume/drain invokes the provider output callback. It operates only
  the already-owned ring view, copies pixels and completes that view; it cannot
  feed, pump or decode. Document boundary forwarding similarly ends at a
  recording-only document callback. The explicit output callback-depth checks
  are additional guards, not a substitute for this source call inspection.
* Error/cancellation functions may be linked even though unused by the fixed
  successful inputs. They fence/record and return through the same leaf provider
  callbacks; they do not start a new document/task lifetime. Tail calls restore
  the outgoing frame before jumping and only lower this sum.

Thus the reviewed fixed schedule has no simultaneously recursive activation of
a retained function. A sum of every retained function's conservatively selected
static frame bounds any of its call chains without relying on a tight longest
path estimate. This assumes no asynchronous/debug/exception entry, arbitrary
callback injection or memory corruption. The initialized INTENABLE/PS/window
policy, function-target guards and subsequent measured SP high-water remain
separate runtime obligations. The experiment's own stack is
`[10014020,10016020)`; no old external model stack is counted.

## Newly linked modulo helper and classifier correction

The first linked closure contains both unsigned division and modulo helpers.
The old neutral classifier only knew the first helper's diagnostic. That was a
real new-closure mismatch, not evidence that DIV0 bytes are executable code.
The narrow new USB classifier correctly keeps the old neutral module unchanged.

| Helper | Exact bytes | ILL | Noncode marker | Whole-helper SHA-256 |
| --- | ---: | --- | --- | --- |
| `__udivsi3` |76 at1000d700|1000d741|1000d744..1000d748| `97c0f245a842a23b8ca0ad47d15b781a0dc0537c7aa2dc7251efa494e734e3f9` |
| `__umodsi3` |57 at1000d74c|1000d77a|1000d77d..1000d781| `14ae148884c6f9f3658da10de58e1d0a6ba01a70a145260bc8899a98c586ca21` |

Pinned GCC14.3.0 `libgcc/config/xtensa/lib1funcs.S` lines74–92 make the call0
leaf-entry macro stack-free and its return an ordinary RET. Lines535–599 give
unsigned division, with exact ILL plus ASCII `DIV0` at588–593. Lines679–732 give
unsigned modulo, with the zero-divisor branch and ILL plus ASCII `DIV0` at719–726.
Both actual helpers have no calls, SP adjustments or spills. The new local
classifier checks each unique function symbol, exact size, `.text` membership,
whole raw byte hash and exact trap/marker offset. It requires exactly the two
recognized ILLs and removes them from admitted instructions/execution ranges.
The four-byte markers receive a noncode label; overlapping instruction/data
annotations still fail. No opcode or ordinary target permission is widened.

`udivsi3.bin`, `umodsi3.bin` and `helper-annotated-disassembly.txt` preserve these
bytes and the correctly bounded decode. `helper-linear-disassembly.txt` is
retained only as an earlier read artifact: broad linear objdump can become
misaligned on literals/padding and is **not** the authoritative helper decode.
The normal zero/one-divisor branches were checked against the source; invoking
the excluded divide-by-zero path remains a rejection, not a supported exception.

## Remaining acceptance work

Root owns the first interpreter/QEMU run and independent gate. They must measure
the new stack high-water, retain actual call/return and original-owner boundary
evidence, and compare all protected storage without importing the old entry
experiment's results. Changes to linked code, compiler options, provider callback
bindings or event producers need a fresh frame/callback review. This static
result grants no USB contact, hardware writes, upload or printing claim.
