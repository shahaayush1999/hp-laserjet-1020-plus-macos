"""Static graph arithmetic with explicit source-reviewed callback bindings only."""
import json,struct
from pathlib import Path
P=Path(__file__).resolve().parent
j=json.loads((P/'static-extraction.json').read_text())
funcs=j['functions']; labels={r['address']:f"{r['address']:08x}:{r['name']}" for r in funcs}
def dest(name):
 f=[f for f in funcs if f['name']==name];assert len(f)==1,name;return f[0]['address']
# Deliberately source-derived fixed binding map, never from execution/capture results.
bind={
 0x1000652b:dest('rx_before'),0x100065ba:dest('descriptor_before'),0x10006773:0x10004064,
 0x10007389:dest('descriptor_after'),0x100073ca:dest('payload_after'),0x100073fb:dest('acquire_order'),
 0x100087d9:dest('consume'),0x10008fa3:dest('chunk_in'),
 0x100099c2:dest('driver_reset'),0x10009a39:dest('driver_control'),0x10009af6:dest('driver_init'),
 0x10009c42:dest('usbd_int_set'),0x10009c5b:dest('usbd_int_set'),
 0x10009c9e:dest('usbd_int_set'),0x10009cb6:dest('usbd_int_set'),
 0x10009d59:dest('usbd_int_set'),0x10009d71:dest('usbd_int_set'),
 0x1000a076:dest('usbd_int_set'),0x1000a08d:dest('usbd_int_set'),
 0x1000a2d2:dest('driver_open'),0x1000a59d:dest('driver_control'),
 0x1000a606:dest('driver_control'),0x1000a645:dest('driver_xfer'),
 0x1000a74f:0x10003fd8,0x1000a7e7:0x10004064,0x1000a843:0x1000401c,
 0x1000aaf6:0x10004064,0x1000abb2:0x1000401c,0x1000ac13:0x10003fd8,
 0x1000bf26:0x10003d7c,
 0x1000d14f:dest('document_event'),0x1000d40e:dest('boundary'),
 0x1000d665:dest('output'),0x1000d78d:dest('document_out'),
 0x1000da27:dest('row_out'),0x1000da61:dest('row_out'),0x1000dc8b:dest('row_out'),
}
# Indirect switches stay inside their containing function after range checks.
switches={0x10008862:(0x10008824,6),0x10008d03:(0x10008c5c,15),
 0x10008dac:(0x10008d68,7),0x10009555:(0x100093a8,8),0x10009b91:(0x10009b60,6),
 0x1000a0a9:(0x1000a038,8),0x1000a1ca:(0x1000a040,10),0x1000a360:(0x1000a044,15)}
excluded={0x10009bf3:'class_driver.sof is a linked literal NULL; no SOF producer',
 0x10009d32:'class_driver.xfer_isr is a linked literal NULL',
 0x1000a681:'USBD_EVENT_FUNC_CALL never produced; usbd_defer_func is discarded; no arbitrary producer'}
elf=(P/'inputs/target/entry-usb.elf').read_bytes(); h=struct.unpack_from('>16sHHIIIIIHHHHHH',elf)
secs=[struct.unpack_from('>IIIIIIIIII',elf,h[6]+i*h[11]) for i in range(h[12])]
def raw(a,n):
 ss=[s for s in secs if s[1]!=8 and s[2]&2 and s[3]<=a and a+n<=s[3]+s[5]];assert len(ss)==1
 s=ss[0];return elf[s[4]+a-s[3]:s[4]+a-s[3]+n]
def words(a,n):return struct.unpack('>'+'I'*n,raw(a,4*n))
# Actual linked fixed class table is decisive for pointers/nulls, not its name alone.
class_words=words(0x1000ec90,9)
assert class_words[1:]==tuple(dest(n) for n in ('driver_init','driver_deinit','driver_reset','driver_open','driver_control','driver_xfer'))+(0,0)
assert words(0x100164a0,1)==(dest('usbd_int_set'),)
byaddr={r['address']:r for r in j['dynamic']}
tails=json.loads((P/'literal-tail-targets.json').read_text())
assert set(byaddr)==set(bind)|set(switches)|set(excluded)|{r['address'] for r in tails}
assert not(set(bind)&set(switches) or set(bind)&set(excluded))
switch_evidence=[]
for pc,(literal,n) in switches.items():
 r=byaddr[pc];f=next(f for f in funcs if labels[f['address']]==r['function'])
 table=words(literal,1)[0];targets=words(table,n)
 assert all(f['address']<=t<f['address']+f['size'] for t in targets),(hex(pc),targets)
 # Targets cannot re-enter the prologue/reallocate the frame.
 assert all(t>f['address']+12 for t in targets),(hex(pc),targets)
 switch_evidence.append(dict(pc=pc,literal=literal,table=table,targets=list(targets),function=r['function']))
g={v:set() for v in labels.values()};edges=[]
for r in j['direct']:
 if r['target_function']==r['function'] and r['op']!='call0':continue
 assert r['target_function']!='?'
 g[r['function']].add(r['target_function']);edges.append((r['function'],r['target_function'],'direct'))
for r in tails:
 g[r['function']].add(r['target_function']);edges.append((r['function'],r['target_function'],'literal tail'))
for pc,t in bind.items():
 assert t in labels
 r=byaddr[pc];g[r['function']].add(labels[t]);edges.append((r['function'],labels[t],'fixed callback'))
# Detect any simultaneous recursion conservatively, including conditional error paths.
seen=set();active=[];cycles=[]
def visit(n):
 if n in active:cycles.append(active[active.index(n):]+[n]);return
 if n in seen:return
 active.append(n)
 for m in sorted(g[n]):visit(m)
 active.pop();seen.add(n)
for n in sorted(g):visit(n)
report=dict(fixed_callback_sites=[dict(pc=p,function=byaddr[p]['function'],target=t,target_function=labels[t]) for p,t in sorted(bind.items())],
 literal_tail_count=len(tails),switches=switch_evidence,excluded_sites=[dict(pc=p,reason=r) for p,r in excluded.items()],
 class_driver_words=list(class_words),queue_interrupt_pointer=dest('usbd_int_set'),cycles=cycles,edges=edges)
(P/'callback-graph.json').write_text(json.dumps(report,indent=2)+'\n')
print('fixed callback sites',len(bind),'literal tails',len(tails),'internal switches',len(switches),'excluded sites',len(excluded),'cycles',cycles)
