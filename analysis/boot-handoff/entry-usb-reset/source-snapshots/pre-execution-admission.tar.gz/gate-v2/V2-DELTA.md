# V2: preserve the original successful endpoint selection

2026-10-03. Author `/root/usb_reference_contract`. One checker-only source
correction before any reset-profile target instruction; no producer/runtime C
or new candidate result was read. No source was imported, parsed, built or run.

Preserved V1 checker SHA256:
`1dbcdb801178d4d62f03324c237041ec39c29f36d2e7e5b78ea416ac143ba989`.
The original full V1 package stays unchanged at
`/tmp/hp1020-entry-usb-reset-gate-draft-20261003/`; its saved checker is copied into
this package's inputs. V1 manifest is
`ec733df525e62a1de1c38ce92f399ee87611b0660b9a1cdfaf07abce0a2efa78`.

The sole code delta changes check_live's field73 (selection_mask) expected value
from0 to3. Field72 (completed_mask) remains3 and field74 (binding_ready) remains1.
This applies only to post-initialization live semantic snapshots; startup and
pre-C still have their original paint/whole-zero checks.

Independent static basis, unchanged hp1020_udc_program.c SHA256
`a0dbe512b4b4f7d045960800637f858165a3757f1e5c17096532616133f33cce`:

- selection(), lines137–143, clears the selection mask only when a programming
  ticket is actively selected. program_endpoint(), lines145–175, ORs the OUT1
  bit1 and IN1 bit2 into both completed_mask and selection_mask, then sets binding
  ready when selection_mask is3. Both endpoint opens precede the first ordinary
  configuration status proposal in this approved profile.
- open(), lines272–295, selects the actual configuration ticket before programming
  each endpoint. disable_endpoints(), lines186–199, clears both masks only on its
  explicit close path; cleanup has its separate clear at450. Neither operation
  belongs to the raw class SOFT_RESET schedule or its recovery promises.
- service(), lines248–267, does not select another ticket or clear either mask.
  Its two binding-only invalidations are an actual bus-reset control epoch and a
  pending typed SET_INTERFACE. The class request is neither. The initial actual
  reset epoch is1; configuration advances to2 and class SOFT_RESET to3, so the
  reset_control_epoch predicate does not fire for this class request.
- hp1020_udc_setup.c:100–127 updates the admitted raw SETUP/control identity without
  rewriting reset_control_epoch. Its progress():252–266 reserves SERVICE-only
  reset drain for the original actual-reset epoch, not this later class request.

Frozen semantic ACCEPTANCE.md:132–138 already requires the original successful
program binding/masks to remain intact and excludes new controller-close or
endpoint-programming work. Public AMENDMENT.md:206–207 likewise says recovery adds
no programming operation or read/write/order. The previously accepted healthy
independent checker's COMMON_LIVE also explicitly requires both masks3. Thus the
V1 zero was an implementation mistake in the new checker, not an ambiguity or
newly observed behavior. No literal semantic block or public contract changes.

Root's independent semantic/source review and the other reviewer's raw-frame,
access and transcript review found no further actionable blocker before this
freeze. An early suspicion that EP0 takes run inside callbacks was withdrawn:
final ADDENDUM110–114 correctly puts both takes after prepare/bind callback unwind.
Those busy0/stack_active0 expectations remain untouched.

No success of the target or gate is claimed. Root alone owns integration and the
first execution. Any later correction must preserve this V2 and the exact stop.
