# Reset raw gate V2 — frozen, unexecuted

Use `draft/check-hp1020-entry-usb-reset.py` with the exact sibling neutral helper
`draft/check-hp1020-entry-usb.py`. Public interface and invocation are unchanged:
`check_capture(capture_root, source_root=None)` or the CLI capture directory with
optional `--source-root`.

Only selection_mask0→3 differs from frozen V1. V2-DELTA.md gives original-source
and frozen-contract evidence. Original V1 semantics, embedded literals,20/21/23
observation schedule, raw replay, byte/source seals, JX original-operand proof,
QEMU transcript and copied-evidence control plan remain unchanged. No candidate
runtime/provider C or result capture was consulted, and no source was parsed,
imported, built or executed. Parent reviewed the proposed narrow correction.
