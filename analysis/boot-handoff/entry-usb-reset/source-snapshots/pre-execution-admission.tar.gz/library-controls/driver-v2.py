"""Copied raw library admission controls; zero target instructions."""
from pathlib import Path
import hashlib, importlib.util, json, re, shutil, sys

ROOT = Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
CAPTURE = Path('/tmp/hp1020-entry-usb-reset-jemqpib2')
HEALTHY = Path('/tmp/hp1020-entry-usb-hjxqsyjw')
OUT = Path('/tmp/hp1020-entry-usb-reset-library-controls-v2-run-20261003')
assert not OUT.exists()
OUT.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
save = lambda path, value: path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')
audit_path = ROOT / 'scripts/hp1020_entry_usb_reset_audit.py'
assert sha(audit_path.read_bytes()) == '422d43890e93b657fc26056cd872a5ecfca379a4b0b72a8ef31cba5fc48c613c'
assert sha((ROOT / 'scripts/hp1020_entry_usb_audit.py').read_bytes()) == 'a1544c2e1b155dcb70b1b12b1d0be99f1558799a2e56b697a4477c9a7e259f22'
sys.path.insert(0, str(ROOT / 'scripts'))
spec = importlib.util.spec_from_file_location('reset_library_audit', audit_path)
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
target = CAPTURE / 'target'
baseline_files = sorted(p for p in target.rglob('*') if p.is_file())
before = {str(p.relative_to(target)): sha(p.read_bytes()) for p in baseline_files}

def positive():
    selected = audit.check_selected_libgcc(target / 'libgcc', target / 'entry-usb.map')
    assert selected['selected_members'] == ['_udivsi3.o']
    assert selected['captured_members'] == ['_udivsi3.o', '_umodsi3.o']
    raw = (target / 'entry-usb.elf').read_bytes()
    helpers = audit.check_libgcc_helpers(audit.neutral.read_elf(raw), raw)
    assert [row['name'] for row in helpers] == ['__udivsi3']
    return {'selected': selected['selected_members'], 'captured': selected['captured_members'],
            'target_sha256': sha(raw), 'helpers': helpers}

report = {'status': 'fail', 'scope': 'Copied raw admission evidence, not firmware lifecycles',
          'target_instructions': 0, 'cases': [], 'positive_before': positive()}
save(OUT / 'result.json', report)
original_map = (target / 'entry-usb.map').read_bytes()
archive_path = json.loads((target / 'libgcc/manifest.json').read_text())['archive']['original_path']
try:
    for name in ('extra-selected-modulo', 'missing-selected-division', 'changed-unselected-member'):
        folder = OUT / name
        folder.mkdir()
        shutil.copytree(target / 'libgcc', folder / 'libgcc')
        map_path = folder / 'entry-usb.map'
        map_path.write_bytes(original_map)
        if name == 'extra-selected-modulo':
            old_lines = (HEALTHY / 'target/entry-usb.map').read_bytes().splitlines(keepends=True)
            selected_line = next(line for line in old_lines if b'(_umodsi3.o)' in line)
            encoded_archive = selected_line.decode().split('(_umodsi3.o)', 1)[0].strip()
            assert str(Path(encoded_archive).resolve()) == archive_path
            map_path.write_bytes(original_map + selected_line)
            expected = 'exact link-map selected archive members'
        elif name == 'missing-selected-division':
            lines = original_map.splitlines(keepends=True)
            removed = [line for line in lines if b'.a(_udivsi3.o)' in line]
            assert removed
            map_path.write_bytes(b''.join(line for line in lines if line not in removed))
            expected = 'exact link-map selected archive members'
        else:
            path = folder / 'libgcc/_umodsi3.o'
            raw = bytearray(path.read_bytes())
            sections, _, _ = audit.read_relocatable(raw)
            text = next(s for s in sections if s['type'] == 1 and s['size'] and s['flags'] & 4)
            raw[text['offset']] ^= 1
            path.write_bytes(raw)
            expected = 'captured original libgcc member bytes'
        try:
            audit.check_selected_libgcc(folder / 'libgcc', map_path)
        except ValueError as error:
            assert expected in str(error), (name, str(error))
            row = dict(name=name, status='expected refusal', expected=expected,
                       error=str(error), files={str(p.relative_to(folder)): sha(p.read_bytes())
                           for p in sorted(folder.rglob('*')) if p.is_file()})
        else:
            raise AssertionError('incorrectly accepted ' + name)
        report['cases'].append(row)
        save(OUT / 'result.json', report)

    # Feed actual healthy bytes, not an invented symbol table, to the new
    # linked-helper rule. This is a helper-rule control, not a full ELF audit.
    old_raw = (HEALTHY / 'target/entry-usb.elf').read_bytes()
    (OUT / 'healthy-two-helper.elf').write_bytes(old_raw)
    try:
        audit.check_libgcc_helpers(audit.neutral.read_elf(old_raw), old_raw)
    except ValueError as error:
        assert 'must not retain the unused modulo helper' in str(error), str(error)
        report['cases'].append(dict(name='actual-healthy-two-helper-ELF',
            status='expected helper-rule refusal', error=str(error), sha256=sha(old_raw)))
    else:
        raise AssertionError('incorrectly admitted healthy two-helper ELF')
    report['positive_after'] = positive()
    after = {str(p.relative_to(target)): sha(p.read_bytes()) for p in baseline_files}
    assert before == after and report['positive_before'] == report['positive_after']
    report.update(status='pass', unchanged_baseline=before,
                  limitations='Three changed copies and one actual prior ELF test admission rules only; no target, emulator or device execution.')
finally:
    save(OUT / 'result.json', report)
print(json.dumps({'status': report['status'], 'refusals': len(report['cases']),
                  'target_instructions': 0, 'output': str(OUT)}, indent=2))
