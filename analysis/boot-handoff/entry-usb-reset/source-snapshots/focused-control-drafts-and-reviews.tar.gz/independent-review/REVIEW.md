# Six copied reset controls: static review

2026-10-03. No actionable blocker found in driver SHA256
`be8175beaf77afebd1b3faf62021acc8226fba55e0ffb413951dc17e89c5870b`
and its frozen README.

Output paths must be new and disjoint in both ancestry directions from the
original capture and repository before creation. The accepted checker and
neutral reader are byte-bound to the original captured source. A failed capture
cannot become the baseline. Only the saved independent checker is invoked;
there is no compiler, model, QEMU, producer or hardware operation.

Hardlinked copies are safe for these mutations: every changed file is written
to a new temporary inode and atomically replaced, never opened in place. The
mutation interface is limited to the first case and private report, rejects
source/input/trace paths, and checks complete membership and tracked before/after
bytes. Source/target/tool/expectation metadata and the second paint are required
unchanged. Original and retained baseline manifests plus the unchanged positive
are checked again after all six controls.

The six intended refusal strings match the frozen V3 checker locations. Field
controls keep paired RAM and complete region/report/snapshot copies coherent;
cookie relabeling updates both selected-entry subsets and physical/logical
aliases; JX changes only the claimed original operand. Debugger p/m replies at
their original positions and ledger seals are updated consistently. The stale
diagnostic mutation targets last.reason at offset56 and is compared against the
untouched pre-stale reference. Raw PC/access traces remain original.

Construction errors, ordinary seal failures, wrong refusal strings and accepted
corruptions all fail a control. The result cannot count them as intended
rejections. The README accurately labels these as deliberately false copied
evidence, not executions of target faults or added lifecycle/hardware coverage.

`inputs/` preserves the reviewed driver/README/manifest, exact two checker
sources and inspected acquisition layout contract. `INPUTS.sha256` seals them.
No import, parsing, build, audit, test, validator, candidate execution, hardware
contact or repository edit occurred during this review. Root owns sequential
execution and final checkpoint; no new controls or research scope were added.
