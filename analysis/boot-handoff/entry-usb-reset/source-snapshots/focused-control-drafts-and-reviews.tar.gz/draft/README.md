# Six reset evidence controls — frozen draft, not executed by author

2026-10-03, author `/root/usb_reference_contract`. This is a bounded selection
from the independently frozen reset gate's CONTROLS.md. It adds no target
lifecycle, interpreter/QEMU execution, hardware operation, or production change.
No candidate result was inspected to choose these mutations or their expected
values. The draft was statically read, not parsed, imported, or executed.

Root alone runs it after the sequential validation slot is free. It accepts only
a complete successful V3 capture that passes the unchanged exact checker first.
The earlier failed capture is refused as a baseline. Repository/source/target/
tool/expectation pins remain untouched; `validation.json` changes occur only in
explicitly private copied evidence trees, never in the supplied capture or public
reports. The unchanged positive is checked again after all controls.

## Exact bounded scope

|Control|One deliberately false claim|Evidence copies kept coherent|Required refusal|
|---|---|---|---|
|late-success-fake-cancellation|At pre-late-service, adapter bulk expected_cancel changes0→1; original SUCCESS32, cookie and PENDING ownership stay intact.|Both full RAM snapshots, region hashes, report/case/result/snapshot metadata, matching original-position debugger memory replies.|`pre-late-service: original field owner_expected_cancel`|
|receive-promise-before-dcd-settlement|At pre-receive-owned, printer reset_parts changes0→1 while original DCD owner and WAIT evidence remain held.|Both snapshot/reply envelopes as above.|`pre-receive-owned: original field reset_parts`|
|stale-cookie-relabelled-current|The actual stale acquisition entry claims current cookie(10,4,3,2,1) in place of original(7,3,2,6,1), retaining the same reused storage.|New and inherited selected-entry records, paired logical a3..a6 and their physical aliases, and matching debugger register replies. Memory owners/slots, instruction/access traces, frame and return result stay original.|`exact original acquisition cookie, including old replay without relabeling`|
|stale-pair-changes-diagnostic|After stale acquisition, acquirer.last.reason changes0→1 and remains changed through post-stale-pair.|Both engines at pre-stale-cancel and post-stale-pair, including full region hashes and debugger replies. The pre-stale-acquire reference, ownership and failure flag remain untouched.|`stale pair preserves all production/private RAM`|
|tail-original-operand-disagrees|The provider request_cancel JX entry claims original transfer_value XOR4 while its actual target, opcode/register, caller frame, cursor and original cookie stay unchanged.|All redundant model/case/report copies of the changed metadata. No snapshot or command is fabricated.|`entry record tied to actual code/caller/stack/cursor`|
|status-take-false-callback-context|At pre-reset-status, adapter.busy changes0→1 despite the required outer status take after callback/API unwind.|Both complete RAM snapshots and matching debugger replies, with original status owner/packet intact.|`pre-reset-status: context adapter_busy`|

The errors above include the gate's `ValueError: ` prefix in the driver. An
unexpected rejection, a plain seal mismatch, an accepted corruption, or mutation
construction failure is a failed control, never silently counted as success.

The late-success and premature-promise rows challenge snapshot claims, not a
fabricated execution of a forbidden callback. The stale-cookie and JX rows
challenge original-call metadata. All raw PC/access streams remain exact. Paired
snapshots and debugger replies are deliberately made to agree on false facts;
that demonstrates independent semantic/context checking rather than only a
report-to-byte comparison. It does not make the copied evidence a possible CPU
execution, and it does not execute an actual buggy target or hardware race.

No old CPU/stack/library controls are repeated. Reordering complete instruction
traces or inserting a real old-tail parser feed is outside these six controls.

## Invocation and preservation

From a host with Python3, after root's normal review:

```sh
python3 /tmp/hp1020-entry-usb-reset-controls-draft-20261003/copied-reset-controls.py \
  /path/to/accepted-capture \
  --repo-root /Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos \
  --output-root /tmp/hp1020-entry-usb-reset-controls-run-20261003
```

The output directory must be new and disjoint from the repository and original
capture. Original capture members, source manifests, V3 checker and its neutral
reader are SHA-bound before import. Only that independent checker/reader is
imported; no producer, observer, audit, compiler or target code is invoked.

Copies initially use hardlinks when available. Every mutation uses atomic inode
replacement, so shared original bytes are never opened for writing. A retained
`baseline-capture/`, `original-members.json`, copied exact checker sources and
driver, before/after positive results and final integrity comparison are saved.
Each control preserves its private capture plus exact changed members under
`before/` and `after/`, with byte lengths/hashes and reconstruction instructions
in `OVERLAY.json`. Copy baseline-capture, replace only those after/ members, and
the synthetic tree is reproduced exactly. Source/target/tool/input files and
the second paint case cannot be mutated by this driver.

Final `negative-controls.json` can pass only if all six reject for their exact
intended reason, the original and retained baseline manifests remain equal, and
the final unchanged positive passes. `paired_envelope` separately records full
21 paired snapshots,23 QEMU snapshots, exact region/report copies, physical/
logical aliases, and matching p/m snapshot replies; it is not semantic approval.

Static provenance: `inputs/original-CONTROLS.md` is the unchanged ten-family plan;
the selected six obligations correspond to its1,3,4,5,9 plus the approved outer
context invariant. `inputs/old-usb-controls.py` supplied neutral atomic-copy,
metadata propagation and debugger-reply plumbing, adapted locally without
importing it. The exact gate/reader, public schema and relevant production types
are preserved under inputs and sealed in DRAFT.sha256.
