#!/usr/bin/env python3
"""Draft six copied-evidence controls for the exact frozen reset gate V3.

Execution imports only the sealed independent capture checker and its neutral
reader. No target, interpreter, QEMU, producer, audit, or builder is run/imported.
Each control changes private copies after an unchanged complete positive check.
These are deliberately false evidence records, not executions of target bugs.
"""
import argparse
import copy
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile


GATE = 'check-hp1020-entry-usb-reset.py'
NEUTRAL = 'check-hp1020-entry-usb.py'
PINS = {
    GATE: 'eacaf2792eec5916e87e25afa247031c70c86f723171da0c2a6e31a7a4e7ecef',
    NEUTRAL: '38f520c5d23834532806821d14ce9e5a8c3703d57935bcc923e453b43dece277',
}
FIRST_CASE = '00-ordinary-privilege-a5'
PHASES = ('initial', 'after-normalization', 'pre-c', 'pre-initial-status',
          'pre-reset-offer', 'pre-cancel-mark', 'pre-receive-owned',
          'pre-late-service', 'pre-receive-drained', 'pre-restart',
          'pre-reset-status', 'pre-fresh-arm', 'pre-fresh-service',
          'pre-reuse-arm', 'pre-stale-acquire', 'pre-stale-cancel',
          'post-stale-pair', 'pre-close', 'pre-final-service', 'pre-finish', 'park')
QEMU_PHASES = PHASES + ('park-step-1', 'park-step-2')
GDB = dict(pc=0, lbeg=33, lend=34, lcount=35, sar=36,
           windowbase=38, windowstart=39, ps=42, intenable=110)
OLD = (7, 3, 2, 6, 1)
CURRENT = (10, 4, 3, 2, 1)
OBJECTS = {
    'adapter': ('hp1020_usb_runtime_adapter', 332),
    'printer': ('hp1020_usb_runtime_printer', 56),
    'acquirer': ('hp1020_usb_runtime_acquirer', 152),
    'provider': ('hp1020_usb_runtime_provider', 224),
}


class ControlError(ValueError):
    pass


def require(ok, message):
    if not ok:
        raise ControlError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def atomic_write(path, data):
    """Replace the inode; a copied hardlink is never opened for mutation."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(data)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def link_or_copy(source, destination):
    try:
        os.link(source, destination)
    except OSError as error:
        if error.errno != errno.EXDEV:
            raise
        shutil.copy2(source, destination)
    return destination


def tree_manifest(root):
    result = {}
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), 'no symlink in saved evidence: ' + str(path))
        if path.is_file():
            data = path.read_bytes()
            result[str(path.relative_to(root))] = dict(bytes=len(data), sha256=sha(data))
    require(result, 'nonempty original evidence tree')
    return result


def load_gate(path):
    spec = importlib.util.spec_from_file_location('sealed_reset_capture_checker', path)
    require(spec is not None and spec.loader is not None, 'independent gate load specification')
    module = importlib.util.module_from_spec(spec)
    old = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = old
    require(callable(getattr(module, 'check_capture', None)), 'independent check_capture API')
    return module


def registers(value, engine):
    result = copy.deepcopy(value)
    if engine == 'qemu':
        result['logical_ar'] = result.pop('logical_a')
    return result


class Evidence:
    def __init__(self, baseline, root, name, addresses):
        require(not root.exists(), 'new control capture directory required')
        shutil.copytree(baseline, root, copy_function=link_or_copy)
        self.root, self.name, self.addresses = root, name, addresses
        self.report = self.read_json('validation.json')
        self.original_report = copy.deepcopy(self.report)
        matches = [x for x in self.report['cases'] if x['case'] == FIRST_CASE]
        require(len(matches) == 1, 'one frozen first-case identity')
        self.case = matches[0]
        self.prefix = 'cases/' + FIRST_CASE + '/'
        self.ledger = [json.loads(line) for line in self.read(
            self.prefix + 'qemu/host-interventions.jsonl').splitlines()]
        self.before = {}
        self.notes = []

    def path(self, relative):
        require(isinstance(relative, str) and relative and not Path(relative).is_absolute(),
                'relative private capture member')
        path = self.root / relative
        require(path.resolve().is_relative_to(self.root.resolve()), 'capture path cannot escape copy')
        return path

    def read(self, relative):
        return self.path(relative).read_bytes()

    def read_json(self, relative):
        return json.loads(self.read(relative))

    def write(self, relative, data):
        require(relative == 'validation.json' or relative.startswith(self.prefix),
                'only first-case evidence/private report may change')
        require('/source/' not in relative and '/input/' not in relative and '/traces/' not in relative,
                'original sources, supplied inputs, and PC/access traces stay sealed')
        path = self.path(relative)
        require(path.is_file(), 'replace only an existing evidence member')
        before = path.read_bytes()
        if before != data:
            self.before.setdefault(relative, before)
            atomic_write(path, data)

    def write_json(self, relative, value):
        if self.read_json(relative) != value:
            self.write(relative, json_bytes(value))

    def snapshot(self, engine, phase):
        rows = [x for x in self.case[engine]['snapshots'] if x['name'] == phase]
        require(len(rows) == 1, 'unique original snapshot: ' + phase)
        return rows[0]

    def region(self, engine, phase, address, count):
        rows = [x for x in self.snapshot(engine, phase)['regions']
                if x['start'] <= address and address + count <= x['start'] + x['bytes']]
        require(count > 0 and len(rows) == 1, 'mutation lies in one full original region')
        row = rows[0]
        return row, self.prefix + engine + '/' + row['path'], address - row['start']

    def memory(self, engine, phase, address, count):
        _, path, offset = self.region(engine, phase, address, count)
        return self.read(path)[offset:offset + count]

    def paired(self, phase, address, old, new):
        require(len(old) == len(new) and old != new, 'one nonempty exact-width field change')
        for engine in ('model', 'qemu'):
            require(self.memory(engine, phase, address, len(old)) == old, 'literal original paired field')
            row, path, offset = self.region(engine, phase, address, len(new))
            data = bytearray(self.read(path))
            require(len(data) == row['bytes'] == row['captured_bytes'], 'complete original raw region')
            data[offset:offset + len(new)] = new
            self.write(path, bytes(data))
            row['sha256'] = sha(data)
        self.notes.append(dict(kind='paired-field', phase=phase, address=address,
                               original_hex=old.hex(), changed_hex=new.hex()))

    def scalar(self, phase, address, width=4):
        left = self.memory('model', phase, address, width)
        require(left == self.memory('qemu', phase, address, width), 'original paired locator bytes')
        return int.from_bytes(left, 'big')

    def set_logical_pair(self, phase, logical, old, new):
        for engine in ('model', 'qemu'):
            r = self.snapshot(engine, phase)['registers']
            key = 'logical_a' if engine == 'qemu' else 'logical_ar'
            physical = (r['windowbase'] * 4 + logical) % 32
            require(r[key][logical] == r['physical_ar'][physical] == old,
                    'original by-value argument agrees across physical/logical aliases')
            r[key][logical] = r['physical_ar'][physical] = new

    def reg_value(self, phase, number):
        r = self.snapshot('qemu', phase)['registers']
        for name, index in GDB.items():
            if index == number:
                return r[name]
        if 1 <= number <= 32:
            return r['physical_ar'][number - 1]
        if 124 <= number <= 139:
            return r['logical_a'][number - 124]
        raise ControlError('unknown captured debugger register')

    def snapshot_replies(self, change):
        phase = None
        for index, row in enumerate(self.ledger):
            if row['kind'] == 'snapshot-start':
                require(phase is None, 'non-nested original snapshot markers')
                phase = row['name']
            elif row['kind'] == 'snapshot-end':
                require(phase == row['name'], 'original paired snapshot-end marker')
                phase = None
            elif row['kind'] == 'gdb-request' and phase is not None:
                require(index + 1 < len(self.ledger) and self.ledger[index + 1]['kind'] == 'gdb-reply',
                        'original contiguous request/reply')
                reply = self.ledger[index + 1]
                command = row['command']
                if re.fullmatch(r'p[0-9a-f]+', command):
                    expected = f'{self.reg_value(phase, int(command[1:], 16)):08x}'
                else:
                    match = re.fullmatch(r'm([0-9a-f]+),([0-9a-f]+)', command)
                    require(match is not None, 'snapshot accepts only original p/m envelope')
                    address, count = (int(x, 16) for x in match.groups())
                    expected = self.memory('qemu', phase, address, count).hex()
                if change:
                    reply['reply'] = expected
                else:
                    require(reply['reply'] == expected, 'changed raw snapshot and original-position reply agree')
        require(phase is None, 'closed original snapshot sequence')

    def sync(self):
        old_ledger = copy.deepcopy(self.ledger)
        self.snapshot_replies(True)
        if self.ledger != old_ledger:
            data = b''.join((json.dumps(x, sort_keys=True, separators=(',', ':')) + '\n').encode()
                            for x in self.ledger)
            self.write(self.prefix + 'qemu/host-interventions.jsonl', data)
            self.case['qemu']['host_intervention_ledger'] = dict(
                path='host-interventions.jsonl', sha256=sha(data), lines=len(self.ledger), bytes=len(data))
        for engine in ('model', 'qemu'):
            for item in self.case[engine]['snapshots']:
                path = self.prefix + engine + '/' + item['name'] + '/'
                self.write_json(path + 'registers.json', item['registers'])
                self.write_json(path + 'snapshot.json', item)
            if engine == 'model':
                self.write_json(self.prefix + 'model/snapshots.json', self.case[engine]['snapshots'])
            self.write_json(self.prefix + engine + '/result.json', self.case[engine])
        self.write_json(self.prefix + 'case.json', self.case)
        require({k: v for k, v in self.report.items() if k != 'cases'} ==
                {k: v for k, v in self.original_report.items() if k != 'cases'} and
                self.report['cases'][1:] == self.original_report['cases'][1:],
                'source/target/tool/expectation pins and second case remain exact')
        self.write_json('validation.json', self.report)

    def envelope_check(self):
        require(self.read_json('validation.json') == self.report and
                self.read_json(self.prefix + 'case.json') == self.case, 'private report/case propagation')
        for engine, phases in (('model', PHASES), ('qemu', QEMU_PHASES)):
            result = self.case[engine]
            require(result == self.read_json(self.prefix + engine + '/result.json') and
                    tuple(x['name'] for x in result['snapshots']) == phases, 'complete original result/schedule')
            if engine == 'model':
                require(result['snapshots'] == self.read_json(self.prefix + engine + '/snapshots.json'),
                        'complete model snapshot metadata propagation')
            for item in result['snapshots']:
                base = self.prefix + engine + '/'
                require(item == self.read_json(base + item['name'] + '/snapshot.json') and
                        item['registers'] == self.read_json(base + item['name'] + '/registers.json'),
                        'individual original snapshot/register envelopes')
                r = registers(item['registers'], engine)
                require(r['logical_ar'] == [r['physical_ar'][(4*r['windowbase']+i)%32] for i in range(16)],
                        'coherent physical/logical aliases')
                for region in item['regions']:
                    data = self.read(base + region['path'])
                    require(len(data) == region['bytes'] == region['captured_bytes'] and
                            sha(data) == region['sha256'], 'coherent raw region seal')
        for phase in PHASES:
            left, right = (self.snapshot(engine, phase) for engine in ('model', 'qemu'))
            require(registers(left['registers'], 'model') == registers(right['registers'], 'qemu'),
                    'coherent full paired register set')
            require([(x['start'], x['bytes'], x['sha256']) for x in left['regions']] ==
                    [(x['start'], x['bytes'], x['sha256']) for x in right['regions']],
                    'coherent full paired region set')
            for lrow, rrow in zip(left['regions'], right['regions']):
                require(self.read(self.prefix + 'model/' + lrow['path']) ==
                        self.read(self.prefix + 'qemu/' + rrow['path']), 'paired actual full bytes')
        data = self.read(self.prefix + 'qemu/host-interventions.jsonl')
        seal = self.case['qemu']['host_intervention_ledger']
        require(sha(data) == seal['sha256'] and len(data) == seal['bytes'] and
                len(self.ledger) == seal['lines'], 'coherent full ledger seal')
        self.snapshot_replies(False)
        return dict(paired_snapshots=21, qemu_snapshots=23, raw_seals=True,
                    full_paired_state=True, snapshot_replies=True,
                    pc_access_traces_untouched=True, not_a_semantic_acceptance=True)

    def preserve(self, control_root, baseline_manifest):
        current = tree_manifest(self.root)
        changed = {name for name in current if current[name] != baseline_manifest.get(name)}
        require(set(current) == set(baseline_manifest) and changed == set(self.before) and changed,
                'every changed member is tracked; no addition/deletion')
        delta = {}
        for name in sorted(changed):
            old, new = self.before[name], self.read(name)
            require(dict(bytes=len(old), sha256=sha(old)) == baseline_manifest[name],
                    'overlay before bytes match immutable baseline')
            atomic_write(control_root / 'before' / name, old)
            atomic_write(control_root / 'after' / name, new)
            delta[name] = dict(before=baseline_manifest[name], after=current[name])
        atomic_write(control_root / 'OVERLAY.json', json_bytes(dict(
            schema='hp1020-reset-copied-overlay-v1', control=self.name,
            reconstruction='Copy retained baseline-capture, then replace listed members with after/ bytes.',
            changed_members=delta, original_trace_kept=True, synthetic_not_execution=True,
            mutation_records=self.notes)))
        return delta


def late_success_is_not_cancelled(ev):
    address = ev.addresses['adapter'] + 133
    ev.paired('pre-late-service', address, b'\0', b'\1')
    ev.notes.append(dict(claim='False expected_cancel for genuine late SUCCESS32; original owner/result/actual stay exact.'))


def premature_receive_promise(ev):
    ev.paired('pre-receive-owned', ev.addresses['printer'] + 51, b'\0', b'\1')
    ev.notes.append(dict(claim='False RECEIVE promise bit while original DCD owner remains held; WAIT row stays original.'))


def stale_cookie_retagged(ev):
    phase = 'pre-stale-acquire'
    cursor = [x['instruction'] for x in ev.case['model']['reset_observations'] if x['label'] == phase]
    require(len(cursor) == 1, 'original stale acquisition natural cursor')
    rows = [x for x in ev.case['model']['reset_api_events'] if x['kind'] == 'entry' and
            x['name'] == 'hp1020_udc_acquire_packet' and x['instruction'] == cursor[0]]
    require(len(rows) == 1, 'one selected original stale acquisition event')
    row = rows[0]
    require(row['arguments'][1:5] == list(OLD[:4]) and row['arguments'][5] >> 24 == 1,
            'literal original stale metadata cookie')
    before = copy.deepcopy(row)
    row['arguments'][1:5] = CURRENT[:4]
    # Keep both recorded subsets and the paired captured call0 registers honest
    # to the same synthetic argument claim. The independently expected OLD cookie
    # must reject it; addresses, memory owners, code and raw steps are unchanged.
    matches = [x for x in ev.case['model']['actual_entry_events'] if
               x['name'] == row['name'] and x['instruction'] == row['instruction']]
    require(len(matches) == 1 and matches[0]['arguments'] == before['arguments'],
            'exact inherited selected-entry subset before retagging')
    matches[0]['arguments'] = list(row['arguments'])
    for logical, old, new in zip(range(3, 7), OLD[:4], CURRENT[:4]):
        ev.set_logical_pair(phase, logical, old, new)
    ev.notes.append(dict(kind='by-value-cookie-retag', instruction=cursor[0],
        original=list(OLD), changed=list(CURRENT), target=row['target'],
        unchanged_current_owner_and_slot=True, event_before=before, event_after=copy.deepcopy(row)))


def stale_diagnostic_mutation(ev):
    # Public target32 layout: acquire.out4 + hooks16; last.cookie20 then
    # prefix/dma/bytes/io four words, so last.reason lies at context+56.
    for phase in ('pre-stale-cancel', 'post-stale-pair'):
        ev.paired(phase, ev.addresses['acquirer'] + 56, bytes(4), (1).to_bytes(4, 'big'))
    ev.notes.append(dict(claim='False last.reason mutation survives both inert stale boundaries; first-failure flag stays0.'))


def indirect_original_operand(ev):
    callback = ev.scalar('pre-cancel-mark', ev.addresses['adapter'] + 12)
    rows = [x for x in ev.case['model']['reset_api_events'] if x['kind'] == 'entry' and
            x['name'] == 'request_cancel' and x['transfer'] == 'jx' and x['target'] == callback]
    require(len(rows) == 1, 'one actual indirect provider cancellation tail entry')
    row = rows[0]
    require(row['transfer_value'] == callback and row['arguments'][0] == ev.addresses['provider'] and
            row['arguments'][1:5] == list(OLD[:4]), 'original provider tail target and cookie')
    before = row['transfer_value']
    row['transfer_value'] ^= 4
    ev.notes.append(dict(kind='original-indirect-operand', instruction=row['instruction'],
        original=before, changed=row['transfer_value'], target=callback,
        transfer_register=row['transfer_register'], original_frame_and_target_unchanged=True))


def outer_status_not_reentrant(ev):
    ev.paired('pre-reset-status', ev.addresses['adapter'] + 314, b'\0', b'\1')
    ev.notes.append(dict(claim='False busy context at genuine outer status take after finish_reset/callback unwind.'))


CONTROLS = (
    ('late-success-fake-cancellation', late_success_is_not_cancelled,
     'ValueError: pre-late-service: original field owner_expected_cancel'),
    ('receive-promise-before-dcd-settlement', premature_receive_promise,
     'ValueError: pre-receive-owned: original field reset_parts'),
    ('stale-cookie-relabelled-current', stale_cookie_retagged,
     'ValueError: exact original acquisition cookie, including old replay without relabeling'),
    ('stale-pair-changes-diagnostic', stale_diagnostic_mutation,
     'ValueError: stale pair preserves all production/private RAM'),
    ('tail-original-operand-disagrees', indirect_original_operand,
     'ValueError: entry record tied to actual code/caller/stack/cursor'),
    ('status-take-false-callback-context', outer_status_not_reentrant,
     'ValueError: pre-reset-status: context adapter_busy'),
)


def run(args):
    original, repo, output = args.capture_root.resolve(), args.repo_root.resolve(), args.output_root.resolve()
    require(original.is_dir() and repo.is_dir(), 'existing complete accepted capture and repository')
    require(not output.exists() and output != original and original not in output.parents and
            output != repo and repo not in output.parents and output not in original.parents and
            output not in repo.parents, 'new output directory disjoint from capture and repository')
    originals = tree_manifest(original)
    report = json.loads((original / 'validation.json').read_bytes())
    require(report.get('status') == 'pass' and not any(k in report for k in
            ('error', 'source_seal_error', 'publication_error')), 'failed captures are never a control baseline')
    frozen = {}
    for name, expected in PINS.items():
        member = 'scripts/' + name
        data = (repo / member).read_bytes()
        require(sha(data) == expected == report['source_sha256'][member] and
                (original / 'source' / member).read_bytes() == data, 'exact original frozen checker dependency')
        frozen[name] = data
    output.mkdir()
    atomic_write(output / 'driver.py', Path(__file__).read_bytes())
    for name, data in frozen.items():
        atomic_write(output / 'checker' / name, data)
    atomic_write(output / 'original-members.json', json_bytes(originals))
    gate = load_gate(output / 'checker' / GATE)
    accepted, detail = gate.check_capture(original, source_root=repo)
    baseline_result = dict(accepted=accepted, detail=detail, capture=str(original), repo=str(repo),
                           gate_sha256=PINS[GATE], driver_sha256=sha(Path(__file__).read_bytes()))
    atomic_write(output / 'baseline-before.json', json_bytes(baseline_result))
    require(accepted, 'unchanged positive must pass before any evidence mutation: ' + str(detail))
    baseline = output / 'baseline-capture'
    shutil.copytree(original, baseline, copy_function=link_or_copy)
    require(tree_manifest(baseline) == originals, 'byte-exact retained immutable baseline')
    # Only neutral ELF symbol lookup after whole-baseline acceptance; these are
    # locations, not expectations read from runtime diagnostic fields.
    elf = gate.B.Elf((baseline / 'target/entry-usb.elf').read_bytes())
    addresses = {key: elf.symbol(name, size) for key, (name, size) in OBJECTS.items()}
    atomic_write(output / 'locations.json', json_bytes(addresses))
    results = []
    for name, mutate, expected in CONTROLS:
        folder = output / name
        folder.mkdir()
        result = dict(control=name, status='error', expected_error=expected,
                      synthetic_evidence_not_target_execution=True)
        evidence = None
        try:
            evidence = Evidence(baseline, folder / 'capture', name, addresses)
            mutate(evidence)
            evidence.sync()
            result['paired_envelope'] = evidence.envelope_check()
            result['changed_members'] = evidence.preserve(folder, originals)
            accepted_control, actual = gate.check_capture(evidence.root, source_root=repo)
            result['checker'] = dict(accepted=accepted_control, detail=actual)
            result['status'] = ('rejected-as-intended' if not accepted_control and
                                isinstance(actual, dict) and actual.get('error') == expected
                                else 'wrong-result-or-mechanism')
        except Exception as error:
            result['error'] = type(error).__name__ + ': ' + str(error)
            if evidence is not None:
                result['mutation_records'] = evidence.notes
                try:
                    result['changed_members'] = evidence.preserve(folder, originals)
                except Exception as partial:
                    result['preservation_error'] = type(partial).__name__ + ': ' + str(partial)
        atomic_write(folder / 'result.json', json_bytes(result))
        results.append(result)
        atomic_write(output / 'progress.json', json_bytes(results))
        print(name + ': ' + result['status'], flush=True)
    # A passing control count cannot hide source or baseline mutations.
    intact = tree_manifest(original) == originals and tree_manifest(baseline) == originals
    intact = intact and all((repo / 'scripts' / name).read_bytes() == data and
                            (output / 'checker' / name).read_bytes() == data for name, data in frozen.items())
    final_accepted, final_detail = gate.check_capture(original, source_root=repo)
    summary = dict(status='pass' if intact and final_accepted and
                   all(x['status'] == 'rejected-as-intended' for x in results) else 'fail',
                   count=len(results), controls=results, baseline_before=baseline_result,
                   baseline_after=dict(accepted=final_accepted, detail=final_detail),
                   original_and_retained_baseline_unchanged=intact, pins=PINS,
                   no_target_interpreter_qemu_build_or_hardware_execution=True,
                   original_pc_access_traces_and_source_target_tool_pins_unchanged=True)
    atomic_write(output / 'negative-controls.json', json_bytes(summary))
    return summary['status'] == 'pass'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('capture_root', type=Path)
    parser.add_argument('--repo-root', type=Path, required=True)
    parser.add_argument('--output-root', type=Path, required=True)
    args = parser.parse_args()
    try:
        passed = run(args)
    except Exception as error:
        print('STOP: ' + type(error).__name__ + ': ' + str(error), flush=True)
        raise SystemExit(2)
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    main()
