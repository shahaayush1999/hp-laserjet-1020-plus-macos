#!/usr/bin/env python3
"""UNEXECUTED draft: copied-evidence controls for the independent USB-entry gate.

This driver imports only a selected local capture checker when explicitly run.
It never executes target code or imports a producer, interpreter, QEMU adapter,
builder or audit. Each synthetic corruption is made in a separate new evidence
copy, with atomic replacement so hardlinks cannot modify the original capture.
This is the practical eleven-of-twelve family subset approved before the first
candidate execution. Plan9's stronger trace-order construction remains pending.
See README.md for deliberately preserved semantic contradictions and limits.
"""
import argparse
import copy
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile


DOCUMENT = (0x10010000, 13496)
MEMORY = (0x10016800, 114704)
MAILBOX = (0x10016060, 1024)
STACK = (0x10014020, 8192)
DATA = (0x100164a0, 29)
WITNESS = (0x10032830, 9216)
MODEL_PHASES = ('initial', 'after-normalization', 'pre-c', 'pre-close',
                'pre-final-service', 'pre-finish', 'park')
QEMU_PHASES = MODEL_PHASES + ('park-step-1', 'park-step-2')
GDB = dict(pc=0, lbeg=33, lend=34, lcount=35, sar=36,
           windowbase=38, windowstart=39, ps=42, intenable=110)
FIRST_CASE = '00-ordinary-privilege-a5'
PLAN_SHA256 = 'b2bb807cd73712f1aec1f74c162eaa1fc84f62a02f8f0f1c049676a19d0687bb'
CHECKER_SOURCE_MEMBER = 'scripts/check-hp1020-entry-usb.py'


class ControlError(ValueError):
    pass


def require(ok, message):
    if not ok:
        raise ControlError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def fnv(raw):
    value = 0x811c9dc5
    for byte in raw:
        value = ((value ^ byte) * 0x01000193) & 0xffffffff
    return value


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def json_lines(rows):
    return b''.join((json.dumps(row, sort_keys=True, separators=(',', ':')) + '\n').encode()
                    for row in rows)


def atomic_write(path, raw):
    """Replace a new inode; never open a shared evidence inode for writing."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(raw)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def link_or_copy(source, destination):
    try:
        os.link(source, destination)
    except OSError as error:
        if error.errno != errno.EXDEV:
            raise
        shutil.copy2(source, destination)
    return destination


def tree_manifest(root):
    result = {}
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), 'capture copies do not admit symlinks: ' + str(path))
        if path.is_file():
            data = path.read_bytes()
            result[str(path.relative_to(root))] = dict(bytes=len(data), sha256=sha(data))
    require(result, 'nonempty evidence tree required')
    return result


def load_checker(path):
    spec = importlib.util.spec_from_file_location('independent_usb_entry_capture_checker', path)
    require(spec is not None and spec.loader is not None, 'selected checker cannot be loaded')
    module = importlib.util.module_from_spec(spec)
    previous = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = previous
    require(callable(getattr(module, 'check_capture', None)), 'selected checker lacks check_capture')
    return module


def compact_delta(before, after):
    prefix = 0
    while prefix < min(len(before), len(after)) and before[prefix] == after[prefix]:
        prefix += 1
    suffix = 0
    while (suffix < min(len(before), len(after)) - prefix and
           before[len(before) - 1 - suffix] == after[len(after) - 1 - suffix]):
        suffix += 1
    end_before, end_after = len(before) - suffix, len(after) - suffix
    delta = dict(original_bytes=len(before), modified_bytes=len(after),
                 original_sha256=sha(before), modified_sha256=sha(after),
                 first_changed_byte=prefix, original_changed_end=end_before,
                 modified_changed_end=end_after)
    if end_before - prefix <= 64 and end_after - prefix <= 64:
        delta['original_changed_hex'] = before[prefix:end_before].hex()
        delta['modified_changed_hex'] = after[prefix:end_after].hex()
    return delta


def normalized_registers(registers, engine):
    result = copy.deepcopy(registers)
    if engine == 'qemu':
        result['logical_ar'] = result.pop('logical_a')
    return result


class EvidenceCopy:
    def __init__(self, original_root, root, label):
        require(not root.exists(), 'refuse to overwrite a control evidence tree')
        shutil.copytree(original_root, root, copy_function=link_or_copy)
        self.original_root = original_root
        self.root = root
        self.label = label
        self.report = self.read_json('validation.json')
        self.original_report = copy.deepcopy(self.report)
        matches = [case for case in self.report['cases'] if case['case'] == FIRST_CASE]
        require(len(matches) == 1, 'frozen ordinary/a5 case must occur exactly once')
        self.case = matches[0]
        self.case_prefix = 'cases/' + FIRST_CASE + '/'
        self.ledger = [json.loads(line) for line in self.read(
            self.case_prefix + 'qemu/host-interventions.jsonl').splitlines()]
        self.original_files = {}
        self.notes = []
        self.ledger_mutator = None
        self.intentional_unsealed = set()
        # Location aid only: the selected unchanged checker must first accept
        # this whole baseline, binding these symbols to actual ELF bytes. The
        # mutation's expected values/offsets remain independent fixed inputs.
        self.addresses = self.read_json('linked-audit.json')['symbols']
        for name in ('hp1020_usb_runtime_document', 'hp1020_usb_runtime_memory',
                     'hp1020_usb_runtime_adapter', 'hp1020_usb_runtime_provider',
                     'hp1020_usb_runtime_out_memory', 'hp1020_usb_runtime_acquirer',
                     'hp1020_usb_runtime_mailbox', 'hp1020_usb_runtime_witness', '_usbd_dev'):
            require(type(self.addresses.get(name)) is int, 'original linked symbol: ' + name)
        require(self.addresses['hp1020_usb_runtime_document'] == DOCUMENT[0] and
                self.addresses['hp1020_usb_runtime_memory'] == MEMORY[0] and
                self.addresses['hp1020_usb_runtime_mailbox'] == MAILBOX[0] and
                self.addresses['hp1020_usb_runtime_witness'] == WITNESS[0],
                'frozen fixed object locations')

    def path(self, relative):
        require(isinstance(relative, str) and relative and not Path(relative).is_absolute(),
                'relative copied evidence path')
        path = self.root / relative
        require(path.resolve().is_relative_to(self.root.resolve()), 'copy path escapes root')
        return path

    def read(self, relative):
        return self.path(relative).read_bytes()

    def read_json(self, relative):
        return json.loads(self.read(relative))

    def write(self, relative, raw):
        path = self.path(relative)
        require(path.is_file(), 'control may replace only an existing captured member: ' + relative)
        before = path.read_bytes()
        if before != raw:
            self.original_files.setdefault(relative, before)
            atomic_write(path, raw)

    def write_json(self, relative, value):
        self.write(relative, json_bytes(value))

    def note(self, field, change):
        self.notes.append(dict(field=field, change=change))

    def snapshot(self, engine, phase):
        matches = [item for item in self.case[engine]['snapshots'] if item['name'] == phase]
        require(len(matches) == 1, 'unique snapshot ' + engine + '/' + phase)
        return matches[0]

    def region(self, engine, phase, address, count):
        matches = [item for item in self.snapshot(engine, phase)['regions']
                   if item['start'] <= address and address + count <= item['start'] + item['bytes']]
        require(len(matches) == 1 and count > 0, 'one complete captured region for mutation')
        item = matches[0]
        relative = self.case_prefix + engine + '/' + item['path']
        return item, relative, address - item['start']

    def memory(self, engine, phase, address, count):
        _, relative, offset = self.region(engine, phase, address, count)
        return self.read(relative)[offset:offset + count]

    def replace_memory(self, engine, phase, address, new):
        item, relative, offset = self.region(engine, phase, address, len(new))
        data = bytearray(self.read(relative))
        require(len(data) == item['bytes'] == item['captured_bytes'], 'full raw region before mutation')
        data[offset:offset + len(new)] = new
        self.write(relative, bytes(data))
        item['sha256'] = sha(data)

    def mutate_pair_byte(self, phase, address, expected=None):
        before = self.memory('model', phase, address, 1)
        require(before == self.memory('qemu', phase, address, 1), 'original paired byte')
        if expected is not None:
            require(before == bytes([expected]), 'frozen original byte prerequisite')
        after = bytes([before[0] ^ 1])
        for engine in ('model', 'qemu'):
            self.replace_memory(engine, phase, address, after)
        self.note('paired ' + phase + ' byte',
                  dict(address=address, before=before.hex(), after=after.hex()))

    def replace_pair_word(self, phase, address, expected, value):
        for engine in ('model', 'qemu'):
            require(self.memory(engine, phase, address, 4) == expected.to_bytes(4, 'big'),
                    'frozen original paired word')
            self.replace_memory(engine, phase, address, value.to_bytes(4, 'big'))

    def registers(self, engine, phase):
        return self.snapshot(engine, phase)['registers']

    def recalculate_aliases(self, registers, engine):
        base = registers['windowbase'] * 4
        key = 'logical_a' if engine == 'qemu' else 'logical_ar'
        registers[key] = [registers['physical_ar'][(base + i) % 32] for i in range(16)]

    def register_value(self, phase, number):
        registers = self.registers('qemu', phase)
        named = [name for name, index in GDB.items() if number == index]
        if named:
            require(len(named) == 1, 'unique semantic debugger register')
            return registers[named[0]]
        if 1 <= number <= 32:
            return registers['physical_ar'][number - 1]
        if 124 <= number <= 139:
            return registers['logical_a'][number - 124]
        raise ControlError('unexpected snapshot register in frozen ABI')

    def refresh_snapshot_replies(self):
        """Propagate changed raw snapshots into p/m replies inside markers only."""
        phase = None
        for i, row in enumerate(self.ledger):
            if row['kind'] == 'snapshot-start':
                require(phase is None, 'non-nested snapshot markers')
                phase = row['name']
            elif row['kind'] == 'snapshot-end':
                require(row['name'] == phase, 'paired snapshot marker')
                phase = None
            elif row['kind'] == 'gdb-request' and phase is not None:
                require(i + 1 < len(self.ledger) and self.ledger[i + 1]['kind'] == 'gdb-reply',
                        'snapshot request/reply pair')
                reply = self.ledger[i + 1]
                command = row['command']
                if re.fullmatch(r'p[0-9a-f]+', command):
                    reply['reply'] = f'{self.register_value(phase, int(command[1:], 16)):08x}'
                else:
                    match = re.fullmatch(r'm([0-9a-f]+),([0-9a-f]+)', command)
                    require(match is not None, 'only snapshot p/m commands may be refreshed')
                    address, count = (int(v, 16) for v in match.groups())
                    reply['reply'] = self.memory('qemu', phase, address, count).hex()
        require(phase is None, 'all snapshot markers closed')

    def reseal_ledger(self):
        commands = 0
        for i, row in enumerate(self.ledger):
            row['ledger_index'] = i
            if row['kind'] == 'gdb-request':
                require(i + 1 < len(self.ledger) and self.ledger[i + 1]['kind'] == 'gdb-reply',
                        'every debugger request retains its reply')
                row['command_index'] = commands
                self.ledger[i + 1]['command_index'] = commands
                commands += 1
            elif row['kind'] == 'initial-state-locked':
                row['gdb_commands'] = commands
        data = json_lines(self.ledger)
        self.write(self.case_prefix + 'qemu/host-interventions.jsonl', data)
        self.case['qemu']['gdb_commands'] = commands
        self.case['qemu']['host_intervention_ledger'] = dict(
            path='host-interventions.jsonl', sha256=sha(data), lines=len(self.ledger), bytes=len(data))

    def sync(self):
        self.refresh_snapshot_replies()
        if self.ledger_mutator is not None:
            self.ledger_mutator(self)
        self.reseal_ledger()
        for engine in ('model', 'qemu'):
            for item in self.case[engine]['snapshots']:
                prefix = self.case_prefix + engine + '/' + item['name'] + '/'
                self.write_json(prefix + 'registers.json', item['registers'])
                self.write_json(prefix + 'snapshot.json', item)
            if engine == 'model':
                self.write_json(self.case_prefix + 'model/snapshots.json', self.case['model']['snapshots'])
            self.write_json(self.case_prefix + engine + '/result.json', self.case[engine])
        self.write_json(self.case_prefix + 'case.json', self.case)
        require(self.report['source_sha256'] == self.original_report['source_sha256'] and
                self.report['target_sha256'] == self.original_report['target_sha256'],
                'real source and target-build manifests must remain unchanged')
        self.write_json('validation.json', self.report)

    def paired_sealing(self):
        """Verify envelopes/hashes only; do not enforce the deliberately broken fact."""
        require(self.read_json('validation.json') == self.report and
                self.read_json(self.case_prefix + 'case.json') == self.case,
                'report/case metadata propagation')
        for engine, phases in (('model', MODEL_PHASES), ('qemu', QEMU_PHASES)):
            result = self.case[engine]
            require(result == self.read_json(self.case_prefix + engine + '/result.json'),
                    'result metadata propagation')
            require([s['name'] for s in result['snapshots']] == list(phases), 'exact unchanged snapshot matrix')
            if engine == 'model':
                require(result['snapshots'] == self.read_json(self.case_prefix + 'model/snapshots.json'),
                        'model snapshot-list metadata propagation')
            for item in result['snapshots']:
                prefix = self.case_prefix + engine + '/'
                require(item == self.read_json(prefix + item['name'] + '/snapshot.json') and
                        item['registers'] == self.read_json(prefix + item['name'] + '/registers.json'),
                        'individual snapshot metadata propagation')
                for region in item['regions']:
                    data = self.read(prefix + region['path'])
                    require(len(data) == region['bytes'] == region['captured_bytes'] and
                            sha(data) == region['sha256'], 'actual raw snapshot size/hash')
        for phase in MODEL_PHASES:
            model = self.snapshot('model', phase)
            native = self.snapshot('qemu', phase)
            require(normalized_registers(model['registers'], 'model') ==
                    normalized_registers(native['registers'], 'qemu'), 'paired full registers')
            require([(r['start'], r['bytes'], r['sha256']) for r in model['regions']] ==
                    [(r['start'], r['bytes'], r['sha256']) for r in native['regions']],
                    'paired full raw region records')
            for left, right in zip(model['regions'], native['regions']):
                require(self.read(self.case_prefix + 'model/' + left['path']) ==
                        self.read(self.case_prefix + 'qemu/' + right['path']), 'paired actual raw bytes')
        park = self.snapshot('qemu', 'park')
        for phase in ('park-step-1', 'park-step-2'):
            item = self.snapshot('qemu', phase)
            require(item['registers'] == park['registers'], 'unchanged final park-step register copies')
            for left, right in zip(park['regions'], item['regions']):
                require((left['start'], left['bytes']) == (right['start'], right['bytes']) and
                        self.read(self.case_prefix + 'qemu/' + left['path']) ==
                        self.read(self.case_prefix + 'qemu/' + right['path']),
                        'same mutation propagated to both final park-step byte copies')
        data = self.read(self.case_prefix + 'qemu/host-interventions.jsonl')
        seal = self.case['qemu']['host_intervention_ledger']
        require(len(data) == seal['bytes'] and sha(data) == seal['sha256'] and
                len(self.ledger) == seal['lines'], 'refreshed ledger raw seal')
        require(all(row['ledger_index'] == i for i, row in enumerate(self.ledger)), 'refreshed ledger indices')
        return dict(case=FIRST_CASE, full_paired_checkpoints=7, full_qemu_snapshots=9,
                    raw_hashes_and_report_copies_agree=True,
                    snapshot_p_m_replies_refreshed_before_deliberate_ledger_control=True,
                    intentional_unsealed_members=sorted(self.intentional_unsealed),
                    original_model_trace_preserved=True)

    def save_deltas(self, control_root):
        changed = {name: compact_delta(before, self.read(name))
                   for name, before in sorted(self.original_files.items())}
        require(changed, 'negative control must actually change copied evidence')
        actual = {name for name, value in tree_manifest(self.root).items()
                  if value != tree_manifest_member(self.original_root, name)}
        require(actual == set(changed), 'every changed copied member is tracked')
        require(not any(name.startswith(('source/', 'target/', 'input/')) or '/traces/' in name
                        for name in changed), 'semantic subset never changes real inputs or model traces')
        atomic_write(control_root / 'deltas.json', json_bytes(changed))
        atomic_write(control_root / 'SYNTHETIC-CORRUPTION.json', json_bytes(dict(
            control=self.label, not_target_model_or_device_execution=True, mutations=self.notes,
            original_model_trace_preserved=True, intentional_unsealed_members=sorted(self.intentional_unsealed),
            changed_members=changed)))
        return changed


def tree_manifest_member(root, relative):
    path = root / relative
    if not path.is_file():
        return None
    data = path.read_bytes()
    return dict(bytes=len(data), sha256=sha(data))


def be_words(words):
    return b''.join(value.to_bytes(4, 'big') for value in words)


def cookie(sequence):
    require(1 <= sequence <= 13, 'bounded original cookie sequence')
    return (sequence + 1, 3, 2, sequence, 1)


def cookie_bytes(sequence):
    original = cookie(sequence)
    return be_words(original[:4]) + bytes([original[4]]) + bytes(3)


def later(first):
    require(first in MODEL_PHASES, 'known first mutated checkpoint')
    for engine, phases in (('model', MODEL_PHASES), ('qemu', QEMU_PHASES)):
        for phase in phases[phases.index(first):]:
            yield engine, phase


def replace_exact(ev, engine, phase, address, before, after):
    require(len(before) == len(after) and before != after, 'nonempty same-width semantic change')
    require(ev.memory(engine, phase, address, len(before)) == before,
            'original literal before mutation: ' + engine + '/' + phase + '/' + hex(address))
    ev.replace_memory(engine, phase, address, after)


def word_exact(ev, engine, phase, address, before, after):
    replace_exact(ev, engine, phase, address, be_words((before,)), be_words((after,)))


def final_digest(ev, engine, phase, index, address, count):
    if phase in ('park', 'park-step-1', 'park-step-2'):
        ev.replace_memory(engine, phase, MAILBOX[0] + 4 * index,
                          be_words((fnv(ev.memory(engine, phase, address, count)),)))


def wrong_pixels(ev):
    # The same per-page byte is altered in both historical output witnesses;
    # the current production slot contains the second page. Full allocations
    # and final digest copies remain mutually coherent but violate literal FF.
    for engine, phase in later('pre-close'):
        for offset in (17, 49):
            replace_exact(ev, engine, phase, WITNESS[0] + 8832 + offset, b'\xff', b'\xfe')
        replace_exact(ev, engine, phase, MEMORY[0] + 81936 + 17, b'\xff', b'\xfe')
        final_digest(ev, engine, phase, 76, MEMORY[0] + 81936, 32768)
        final_digest(ev, engine, phase, 77, WITNESS[0] + 8832, 64)
    ev.note('plan1: full production pixels and both page witnesses',
            dict(page_byte=17, before=255, after=254, final_output_and_pixel_digests_updated=True))


def retag_old_image(ev):
    provider = ev.addresses['hp1020_usb_runtime_provider']
    adapter = ev.addresses['hp1020_usb_runtime_adapter']
    for engine in ('model', 'qemu'):
        require(ev.memory(engine, 'pre-close', adapter + 100, 20) == cookie_bytes(13),
                'current original DCD owner13 stays healthy')
        replace_exact(ev, engine, 'pre-close', provider + 180, cookie_bytes(12), cookie_bytes(13))
        word_exact(ev, engine, 'pre-close', provider + 200, 3, 0)
    ev.note('plan2: old retained device image identity',
            dict(original_image_cookie=list(cookie(12)), false_cookie=list(cookie(13)),
                 image_slot_before=3, image_slot_after=0, current_actual_owner_unchanged=True,
                 source_image_bytes_and_bind_table_unchanged=True))


def clear_pending_core_busy(ev):
    core = ev.addresses['_usbd_dev']
    adapter = ev.addresses['hp1020_usb_runtime_adapter']
    for engine in ('model', 'qemu'):
        require(ev.memory(engine, 'pre-final-service', adapter + 130, 1) == b'\2',
                'original owner is PENDING, not already delivered')
        replace_exact(ev, engine, 'pre-final-service', core + 54, b'\5', b'\4')
    for engine, phase in later('pre-final-service'):
        word_exact(ev, engine, phase, MAILBOX[0] + 127 * 4, 1, 0)
    ev.note('plan3: actual private OUT1 status before delivery',
            dict(before=5, after=4, claimed_bit_preserved=True,
                 secondary_before_service_getter_changed_to_zero=True, owner_pending_retained=True))


def early_release_after_acquire(ev):
    adapter = ev.addresses['hp1020_usb_runtime_adapter']
    core = ev.addresses['_usbd_dev']
    for engine in ('model', 'qemu'):
        phase = 'pre-final-service'
        require(ev.memory(engine, phase, adapter + 100, 20) == cookie_bytes(13) and
                ev.memory(engine, phase, adapter + 130, 1) == b'\2', 'original final pending owner')
        word_exact(ev, engine, phase, DOCUMENT[0] + 76, 12, 13)
        word_exact(ev, engine, phase, DOCUMENT[0] + 80, 1, 0)
        replace_exact(ev, engine, phase, DOCUMENT[0] + 4,
                      be_words((13, 64, 0, 0)), bytes(16))
        ev.replace_memory(engine, phase, adapter + 100, bytes(40))
        replace_exact(ev, engine, phase, core + 54, b'\5', b'\0')
    # Keep the copied historical after-acquisition counters coherent with the
    # false immediate-release account, including the final mailbox copies.
    for engine, phase in later('pre-final-service'):
        for index, before, after in ((71, 2, 0), (72, 1, 0), (73, 12, 13), (127, 1, 0)):
            word_exact(ev, engine, phase, MAILBOX[0] + index * 4, before, after)
    ev.note('plan4: release claimed before the actual next service entry',
            dict(original_cookie=list(cookie(13)), consumed_before=12, consumed_after=13,
                 pending_owner_and_slot_cleared=True, core_cleared=True,
                 secondary_after_acquire_fields_updated=True,
                 actual_trace_and_checkpoint_PC_unchanged=True))


def wrong_receive_tail(ev):
    offset = 2 * 1024 + 64 + 17
    for engine, phase in later('pre-final-service'):
        replace_exact(ev, engine, phase, MEMORY[0] + offset, b'\0', b'\1')
        final_digest(ev, engine, phase, 75, MEMORY[0], 4096)
    ev.note('plan5: unused receive capacity after ZLP acquisition',
            dict(slot=2, allocation_offset=offset, before=0, after=1,
                 all_later_snapshots_updated=True, full_receive_digest_updated=True,
                 actual_zero_length_and_cookie_unchanged=True))


def wrong_descriptor_dma(ev):
    desc = ev.addresses['hp1020_usb_runtime_out_memory']
    acq = ev.addresses['hp1020_usb_runtime_acquirer']
    for engine, phase in later('pre-final-service'):
        for address in (desc + 8, acq + 66 + 8, WITNESS[0] + 8688 + 16 + 8):
            word_exact(ev, engine, phase, address, 0x24681340, 0x24682340)
    ev.note('plan6: descriptor body, acquisition snapshot and separate source image',
            dict(original_dma=0x24681340, false_dma=0x24682340,
                 count_zero_and_original_cookie_unchanged=True,
                 descriptor_and_diagnostic_and_device_copy_coherent=True))


def wrong_rde_command(ev):
    # Nineteen initial rows plus twelve complete17-row packets. RDE is offset12
    # in the thirteenth publication block, giving zero-based row235/ordinal236.
    row = 19 + 12 * 17 + 12
    require(row == 235, 'independent final RDE row arithmetic')
    row_address = WITNESS[0] + 16 + row * 24
    for engine, phase in later('pre-close'):
        require(ev.memory(engine, phase, row_address, 24) ==
                be_words((13, 236, 2, 0x404, 0x34120324, 0)), 'original final RDE command literal')
        word_exact(ev, engine, phase, row_address + 16, 0x34120324, 0x34120320)
        final_digest(ev, engine, phase, 78, WITNESS[0] + 16, 5760)
    ev.note('plan7: recorded final RDE write',
            dict(ordinal=236, offset=0x404, before=0x34120324, after=0x34120320,
                 counts_outcomes_and_other_rows_retained=True, final_trace_digest_updated=True))


def wrong_range_cpu(ev):
    # Last packet's payload acquisition is row63 of65. The three trailing
    # fields independently record CPU span, actual packet allocation and64.
    row_address = WITNESS[0] + 5792 + 63 * 36
    original = be_words((239, *cookie(13), MEMORY[0], MEMORY[0], 64))
    for engine, phase in later('pre-final-service'):
        require(ev.memory(engine, phase, row_address, 36) == original,
                'original final payload acquisition span and cookie')
        word_exact(ev, engine, phase, row_address + 24, MEMORY[0], MEMORY[0] + 1024)
        word_exact(ev, engine, phase, row_address + 28, MEMORY[0], MEMORY[0] + 1024)
        final_digest(ev, engine, phase, 79, WITNESS[0] + 5792, 2340)
    ev.note('plan8: range pointer and allocation witness',
            dict(range_row=63, command_ordinal=239, original_cookie=list(cookie(13)),
                 before_cpu=MEMORY[0], after_cpu=MEMORY[0]+1024,
                 original_actual_owner_and_bind_table_unchanged=True,
                 final_ranges_digest_updated=True))


def wrong_document_event(ev):
    second_event = WITNESS[0] + 8896 + 20
    for engine, phase in later('pre-close'):
        require(ev.memory(engine, phase, second_event, 20) == be_words((2, 2, 1, 1, 0)),
                'original generation/document/page event2')
        word_exact(ev, engine, phase, second_event + 8, 1, 0)
    ev.note('plan10: copied second original END_DOC event',
            dict(before=[2, 2, 1, 1, 0], after=[2, 2, 0, 1, 0],
                 generation_document_id_page_count_result_retained=True,
                 aggregate_document_and_page_counts_remain_two=True))


def post_lock_write(ev):
    def mutate(evidence):
        positions = [i for i, row in enumerate(evidence.ledger)
                     if row['kind'] == 'snapshot-start' and row['name'] == 'initial']
        require(len(positions) == 1, 'one initial snapshot marker')
        index = positions[0] + 1
        require(evidence.ledger[index]['kind'] == 'gdb-request' and
                evidence.ledger[index]['command'] == 'p0', 'initial readback starts with PC')
        value = evidence.registers('qemu', 'initial')['physical_ar'][1]
        evidence.ledger[index:index] = [
            dict(kind='gdb-request', command=f'P2={value:08x}', command_index=0,
                 phase='observe', action='post-lock-same-value-write'),
            dict(kind='gdb-reply', command_index=0, reply='OK')]
        evidence.note('plan11: post-lock debugger write allegation',
                      dict(register='physical AR1', same_value=True,
                           command_and_reply_inserted=True, indices_and_ledger_seal_updated=True,
                           no_actual_debugger_or_target_execution=True))
    ev.ledger_mutator = mutate


def corrupt_initialized_data(ev):
    for engine in ('model', 'qemu'):
        before = ev.memory(engine, 'pre-c', DATA[0], 1)
        require(before == ev.memory(engine, 'initial', DATA[0], 1),
                'original file-backed initialized byte survived startup')
        ev.replace_memory(engine, 'pre-c', DATA[0], bytes([before[0] ^ 1]))
    ev.note('plan12: initialized generic data is not a zeroable BSS span',
            dict(address=DATA[0], xor=1, both_engines=True,
                 initial_file_backed_image_unchanged=True, later_state_unchanged=True))


def controls():
    witness_error = 'ValueError: full9216 independent trace/range/bind/device/pixels/events/guards'
    rows = [
        (1, 'literal-pixels', wrong_pixels, 'ValueError: full32768 actual production output allocation'),
        (2, 'old-device-image-retag', retag_old_image,
         'ValueError: old source image identity is distinct from newly armed owner'),
        (3, 'pending-private-busy-clear', clear_pending_core_busy,
         'ValueError: actual private BUSY/CLAIMED endpoint array'),
        (4, 'acquisition-releases-before-service', early_release_after_acquire,
         'ValueError: pre-final-service: actual consumed'),
        (5, 'unused-receive-tail', wrong_receive_tail,
         'ValueError: full4096 actual receive allocation/padding/tails'),
        (6, 'asymmetric-descriptor-dma', wrong_descriptor_dma,
         'ValueError: actual final descriptor body/status/count'),
        (7, 'final-rde-command', wrong_rde_command, witness_error),
        (8, 'final-acquire-cpu-range', wrong_range_cpu, witness_error),
        (10, 'second-document-first-page', wrong_document_event, witness_error),
        (11, 'post-lock-register-write', post_lock_write,
         'ValueError: exact permitted debugger command envelope'),
        (12, 'pre-c-initialized-data', corrupt_initialized_data,
         f'ValueError: protected byte changed at{DATA[0]:#x}')]
    require([row[0] for row in rows] == [1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 12] and
            len({row[1] for row in rows}) == 11, 'approved eleven-family subset; plan9 stays pending')
    return rows


def run(args):
    original = args.capture_root.resolve()
    checker_path = args.checker.resolve()
    output = args.output_root.resolve()
    require(original.is_dir() and checker_path.is_file(), 'existing capture and checker paths required')
    require(not output.exists() and original != output and original not in output.parents,
            'output must be new and outside original evidence')
    original_manifest = tree_manifest(original)
    checker_bytes = checker_path.read_bytes()
    checker_hash = sha(checker_bytes)
    require(checker_hash == args.checker_sha256, 'selected checker differs from explicit pin')
    report = json.loads((original / 'validation.json').read_bytes())
    require(report['source_sha256'].get(CHECKER_SOURCE_MEMBER) == checker_hash and
            sha((original / 'source' / CHECKER_SOURCE_MEMBER).read_bytes()) == checker_hash,
            'selected frozen checker is the original captured checker')
    output.mkdir(parents=True)
    atomic_write(output / 'checker.py', checker_bytes)
    atomic_write(output / 'driver.py', Path(__file__).read_bytes())
    atomic_write(output / 'original-members.json', json_bytes(original_manifest))
    checker = load_checker(output / 'checker.py')
    accepted, detail = checker.check_capture(original)
    baseline = dict(status='pass' if accepted else 'fail', accepted=accepted, detail=detail,
                    capture_root=str(original), checker=str(checker_path), checker_sha256=checker_hash,
                    driver_sha256=sha(Path(__file__).read_bytes()), no_new_target_execution=True)
    atomic_write(output / 'baseline.json', json_bytes(baseline))
    require(accepted, 'unchanged complete capture must pass before controls: ' + str(detail))
    baseline_root = output / 'baseline-capture'
    shutil.copytree(original, baseline_root, copy_function=link_or_copy)
    require(tree_manifest(baseline_root) == original_manifest, 'exact retained baseline byte copy')
    results = []
    for plan_item, label, mutate, expected in controls():
        folder = output / label
        folder.mkdir()
        result = dict(plan_item=plan_item, control=label, status='error', expected_error=expected,
                      checker_sha256=checker_hash, synthetic_not_target_execution=True)
        evidence = None
        try:
            evidence = EvidenceCopy(baseline_root, folder / 'capture', label)
            mutate(evidence)
            evidence.sync()
            result['paired_sealing'] = evidence.paired_sealing()
            result['mutations'] = evidence.notes
            result['changed_members'] = evidence.save_deltas(folder)
            accepted_control, actual = checker.check_capture(evidence.root)
            result['checker'] = dict(accepted=accepted_control, detail=actual)
            precise = not accepted_control and isinstance(actual, dict) and actual.get('error') == expected
            result['status'] = 'rejected-as-intended' if precise else 'wrong-result-or-mechanism'
        except Exception as error:
            result['error'] = type(error).__name__ + ': ' + str(error)
            if evidence is not None:
                result['mutations'] = evidence.notes
                try:
                    result['changed_members'] = evidence.save_deltas(folder)
                except Exception as delta_error:
                    result['delta_error'] = type(delta_error).__name__ + ': ' + str(delta_error)
                    partial = {name: compact_delta(before, evidence.read(name))
                               for name, before in evidence.original_files.items()}
                    atomic_write(folder / 'partial-deltas.json', json_bytes(partial))
        atomic_write(folder / 'result.json', json_bytes(result))
        results.append(result)
        atomic_write(output / 'negative-controls-progress.json', json_bytes(results))
        print(label + ': ' + result['status'], flush=True)
    require(tree_manifest(original) == original_manifest, 'original capture changed during controls')
    require(tree_manifest(baseline_root) == original_manifest, 'retained baseline changed through a shared inode')
    require(checker_path.read_bytes() == checker_bytes, 'selected checker changed during controls')
    final_accepted, final_detail = checker.check_capture(original)
    require(final_accepted, 'original baseline no longer passes: ' + str(final_detail))
    summary = dict(status='pass' if all(row['status'] == 'rejected-as-intended' for row in results) else 'fail',
                   controls=results, count=len(results), baseline=baseline,
                   original_rechecked=dict(accepted=final_accepted, detail=final_detail),
                   plan_sha256=PLAN_SHA256, plan_families_implemented=[row[0] for row in controls()],
                   pending_plan_items=[dict(number=9, reason='Strong raw-trace natural-order construction not implemented.')],
                   original_and_retained_baseline_members_unchanged=True,
                   atomic_replacement_for_every_copy_mutation=True,
                   no_new_target_model_or_hardware_execution=True)
    atomic_write(output / 'negative-controls.json', json_bytes(summary))
    return summary['status'] == 'pass'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('capture_root', type=Path)
    parser.add_argument('--checker', type=Path, required=True)
    parser.add_argument('--checker-sha256', required=True)
    parser.add_argument('--output-root', type=Path, required=True)
    args = parser.parse_args()
    try:
        passed = run(args)
    except Exception as error:
        print('STOP: ' + type(error).__name__ + ': ' + str(error), flush=True)
        raise SystemExit(2)
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    main()
