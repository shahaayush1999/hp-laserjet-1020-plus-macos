# Reset-profile compiler-helper selection: static review

2026-10-03. Source reads, byte comparisons and evidence copies only. No compiler,
linker, audit, Python import, model/QEMU, target or validator was executed. No
repository file was edited.

## Conclusion

The reset profile can reasonably freeze **exactly `_udivsi3.o` selected and
`__udivsi3` linked, with no `_umodsi3.o` selection or `__umodsi3` symbol**, as a
pre-build admission expectation. It is not yet a claim about an emitted reset
ELF. Keep an unexpected selection as an admission failure for investigation;
do not accept an arbitrary observed subset or revise a report hash.

The separate `LIBRARY_SELECTION.md` accurately distinguishes both captured
original archive members from the one expected linked member. Retaining both
copies for source/section provenance does not link both. The accepted healthy
profile's exact-two rule must remain unchanged.

## Exact source and object evidence

The saved V2 builder has exactly26 C translation units: the three sibling
runtime/provider/constant-layout sources, the20 paths in
`production-c-paths.txt`, then materialized TinyUSB `src/tusb.c`,
`src/device/usbd.c`, and `src/common/tusb_fifo.c`. Startup is the separate27th
object; `-lgcc` is the28th LOAD input. The V1 and V2 source loop and compiler
flags are identical to the healthy builder. V2 changes the profile directories,
temporary source prefix, descriptions and selection-comment wording only.
There is no LTO or new translation unit.

All20 ordinary production/JBIG C bytes compare equal to the accepted healthy
capture and current repository. The three upstream TinyUSB C inputs, patch,
patch manifest, materializer, TinyUSB configuration and compiler-profile checker
also compare equal. The three actual compiled TinyUSB sources are copied from
the accepted capture's compiler-source closure, independently bound there to
the effective-source manifest:

- tusb.c: b5f0e8ca00ba6e63914583f7b4711c540a125c261b261216f89e5136fda2ac6f
- usbd.c: 8bf699c1522d65301a4c63e2bfa529d302d3955b8cd18dd1602d7ace441a62dc
- tusb_fifo.c: d87e25d3329244226f3b794882e89898ac5fe20e04568a7750f4aff154f871ac

Accepted healthy capture: `/tmp/hp1020-entry-usb-hjxqsyjw`. Its map begins with
`_udivsi3.o` selected to satisfy provider.o's `__udivsi3`, then `_umodsi3.o` for
runtime.o's `__umodsi3`. A map records the selecting reference, not all users.
The independently saved raw ET_REL inventory identifies undefined
`__umodsi3` only in runtime.o. It also identifies undefined `__udivsi3` in
image.o, image_ring.o, page_plan.o, provider.o and jbig85.o. Thus division is
not exclusive to the provider. The known two library objects define their
respective helpers. All27 inventoried ordinary/startup object bytes compare
exactly with the accepted capture; equality hashes and full inventory are saved.

## Arithmetic delta

Healthy runtime.c line205 contains `fragment=packet%6u`. Its reset replacement
has separate bounded old/fresh loops at lines333 and339, with `packet*64u`,
small additions and a last-fragment comparison. Static reading and the full
source diff find no division/remainder expression or explicit compiler-helper
reference in the new runtime. New failure/check/reset helpers copy/compare
fields and invoke production APIs; they add no variable division or remainder.

The reset provider still contains the unchanged output capacity check
`view.rows>(64-MW(PIXEL_BYTES))/ring->stride` at line337. Its new cancellation,
reset-observation, checked-result and second-status handling adds no division
or remainder. The layout source is a const initializer of `sizeof`, `_Alignof`
and `offsetof` expressions, with no runtime functions. Its17 added fields do
not introduce arithmetic instructions or helper calls. The healthy linker
script has no `__udivsi3`/`__umodsi3` EXTERN or explicit helper KEEP root.
The reset contract pins that identical linker script.

The changed runtime/provider/header must still be compiled and the actual
map/object/ELF closure checked by the root-owned next stage. Source-level
reasoning alone cannot certify backend lowering, linked reachability, helper
bytes, frame size, RAM behavior or reset recovery.

## Preserved inputs

`inputs/healthy/` comes from the accepted capture. `inputs/reset/` comes from:

- `/tmp/hp1020-entry-usb-reset-runtime-draft-20261003/hp1020_usb_runtime.c`
  SHA93d4ad702137156288ecac13fabea58d8ae9269ba309b14a43ea972cf2daf9d2;
- `/tmp/hp1020-entry-usb-reset-provider-draft-20261003/draft/open-firmware/entry-usb-reset-test/`
  provider10895c86ff673dfbeeb48eee2eed0bc0d6327546026ebfa54768c0f47c5bc9d4,
  layout63485583d31f26b50e07c7c1ea20b5f10a9cbed7a9b3b05a0ff7a3157732c7a7;
- `/tmp/hp1020-entry-usb-reset-tooling-v2-draft-20261003/draft/` for the builder
  and separate library contract.

`inputs/unchanged/` records exactly the compared repository input bytes.
`inputs/effective/` preserves the actual previously compiled TinyUSB C bytes.
`inputs/evidence/` contains healthy map/tool/patch/library provenance and the
full preexisting raw inventory from
`/tmp/hp1020-entry-usb-raw-input-inventory-20261003/inventory.json`.
`DRAFT.sha256` seals this review's copies and textual evidence. It is an evidence
package for a static review, not a fresh build or validation report.
