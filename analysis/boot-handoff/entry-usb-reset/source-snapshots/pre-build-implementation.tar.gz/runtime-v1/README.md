# Unexecuted reset orchestration draft

Root authored this after the preserved pre-C contracts. No compiler/target execution.
Factored the unchanged EP0 take/observe/retire/service sequence for its two real
statuses. Five64-byte old packets reach the320-byte cut; reset and queued cancel
mark are explicit existing API calls. Four actual WAIT returns are recorded; the
old late SUCCESS32 and real service precede the three independent promises.
Successful reset runs the production document restart. Newq1 is consumed before
exactq2 slot reuse; saved-cookie acquire/cancel actual STALE results are recorded
before any new image writes. The new document then completes and final ownedq7
settles by separately supplied ZLP352/0 before actual service/pump/finish/park.

Counter ownership: provider callback counts CANCEL_REQUESTS; runtime counts both
returned CANCEL_API_CALLS. ACQUIRE_CALLS includes stale; accepted does not. Refusal
record helpers pass the actual return and semantic ticket/cookie to ram_check.
No handwritten expected return is used as the actual value. No production object
or runtime output storage is cleared by this file during recovery.
