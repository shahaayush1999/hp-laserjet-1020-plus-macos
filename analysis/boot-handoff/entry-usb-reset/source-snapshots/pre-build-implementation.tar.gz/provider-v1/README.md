# Reset RAM provider and compiler witness draft

Authored2026-10-03, **unexecuted**. Only the two proposed sibling C files were
edited, under `draft/open-firmware/entry-usb-reset-test/`. The adjacent public
header is the byte-identical approved copy, SHA256
`a73a3904b094126e811f6d26249ab93d3d71cae7f5e0c00cedd10e77addc4679`.
No repository file, production component, accepted healthy profile, compiler,
candidate import/parser, build, audit, validator, Machine/QEMU or device was
changed/run. Root owns integration and all execution. This is not a test result.

## Changes

- Add the exact immutable SOFT_RESET record and bounded observation helper.
  It copies the source record only; root still calls actual offer/dispatch.
- The genuine cancellation callback validates all five cookie fields against
  actual adapter/OUT/retained ownership, saves the fields once (without C padding),
  marks the existing provider request and increments CANCEL_REQUESTS. No API is
  called, no buffer modified, no ownership/promise settled. It permits the real
  admission callback's busy adapter and old retained transport epoch.
- The status hook admits the two actual request types in order and checks the
  delivering original EP0 cookie, SUCCESS0, original NULL/0, component FREE and
  provider nonlive state. It does not clear class response ownership: TinyUSB
  invokes the real class ACK callback afterward.
- `ram_check` validates/appends the six returned WAIT/STALE rows from caller-
  supplied actual values/original identities. It performs no production action
  or counter repair. The added note tags reuse existing live-field snapshots.
- The const compiler witness adds the approved fields102..118. Existing member
  macros calculate changed array widths/offsets through actual declarations;
  no manually expected offsets or addresses were copied into the C table.

The only C deltas beyond comments are these bounded seams. Original descriptors,
immutable facts, initialized sentinel, all16 objects, initialization order,
full memory/stack caps, output consumer, trace/range hooks, poison/padding and
owned-device-image effects remain as before. Scope remains a log label: DMA/slot
selection still comes from the actual owned CPU pointer. Both genuine old/new
late completions retain their real cookie without consulting bind diagnostics.

## Root integration obligations

Root supplies `hp1020_usb_runtime.c`, the unchanged single external352-byte input
definition through `hp1020_usb_runtime_input.h`, build/admission and the separate
reset harness/checker. Do not overwrite the old entry-usb-test files.

Counter ownership is explicit: provider owns CANCEL_REQUESTS, CHECK_ROWS,
bind/cache/copy/image/poison/output callbacks and the old provider counters.
Root owns each returned CANCEL_API_CALLS attempt (final2), acquire attempts and
acceptance, successful recovery promises/finishes, service/pump/input-consumed,
close/finish and existing step/fail. A WAIT does not increment a successful
promise/finish count. `ram_check` updates CHECK_ROWS only; it does not replace
root's last API result or its API-attempt counters.

The original saved cookie stays untouched through late SUCCESS, callback drain,
restart, new binds and both inert stale calls. Root must use that saved value
for cancellation marks/stale ingress, never derive it from current state. The
old request is queued only; root marks OUT after callback return and must use
the actual late SUCCESS path with zero cancellation-settlement API calls.

Both EP0 takes/observations remain outer orchestration, after DCD callbacks
unwind. The status-complete hook observes `A.delivering_live` during TinyUSB
service, before class ACK releases response_owned; do not demand that response
flag was already zero there. No new status is fabricated by the provider.

The four refusal calls precede corresponding `ram_check` invocations. Root forms
each row using the actual return and original pending reset ticket or saved
cookie. Stale replay installs no new image. Only after both stale calls and rows
does normal `ram_install_bulk(new_cookie,64,64)` run, permitting an independent
entry snapshot before any source/poison write. Final ZLP uses offset352/count0.

## Remaining admission, not implied results

Independent C read-through remains pending. Root must freshly compile/link and
admit the exact input closure, custom NOLOAD inputs, all16 actual object extents,
525-word const layout, new linked call/stack/callback graph and code cap. No old
7472-byte static ceiling or runtime result transfers to the new code. The20
natural stops, two ordinary paint cases, actual returns, full raw storage and
no-host-repair ledger must satisfy the frozen independent acceptance. No
physical reset, DMA/cache, wire ACK or printing claim follows from this draft.

`provider.diff`/`layout.diff` expose every edit. `inputs/` preserves exact read-
time bytes; manifests within it are provenance references, not a claim their
entire external closures were copied. This package is a design/source subset,
not the future executable source closure. `DRAFT.sha256` seals every member
except itself; readback verifies storage only and is not candidate validation.
