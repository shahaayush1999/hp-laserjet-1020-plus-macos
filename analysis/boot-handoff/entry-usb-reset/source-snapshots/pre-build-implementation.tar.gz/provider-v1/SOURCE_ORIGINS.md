# Exact input origins

The root-approved public contract package is
`/tmp/hp1020-entry-usb-reset-contract-draft-20261003/`, manifest
`ac39294692cfdadbc35151facc3911d1fb42521b278e5a9d26f727cb3012f991`.
Its baseline healthy provider/layout C were copied unchanged to `inputs/baseline/`.
The original repository paths were under
`/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos/open-firmware/entry-usb-test/`.

`inputs/public/` contains its approved AMENDMENT, header, manual object/field
tables and original manifest. The proposed header is copied byte-for-byte next
to the C sources solely to make the selected public ABI explicit, not edited.

Independent acceptance is
`/tmp/hp1020-entry-usb-reset-independent-addendum-20261003/`, manifest
`a1ffbfa0ddf7dcc89544881f41da4883ec900789ae156cf4542239b3cf3eed98`.
Its ADDENDUM, literal-addendum, manifest and unchanged semanticV2 ACCEPTANCE/
literals were copied to `inputs/independent/`. SemanticV2 literal SHA is
`aab93eba1de9c9123e9344d8bb5fc642b690e7ac4b02c2fc3fd5efa4d501b333`.
They were read only. No oracle function was imported/evaluated or included in C.

`inputs/production/` preserves the public package's exact read-time copies of
adapter.{h,c}, printer.{h,c}, OUT.{h,c}, acquisition.h, document.{h,c} and
receive.{h,c}. The independent addendum additionally supplies its sealed
effective patched TinyUSB usbd.c and EP0/program/publish C. These clarify actual
callback/retirement order and remain unchanged source inputs. The future builder
must independently preserve its complete effective/vendor/tool closure.

This package's own `DRAFT.sha256` gives exact content identities for every copied
input and new C/note/diff member. No earlier report or source hash was altered.
