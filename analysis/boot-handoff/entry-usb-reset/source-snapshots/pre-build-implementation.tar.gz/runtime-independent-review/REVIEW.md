# Independent static review: reset orchestration

2026-10-03. **No material source-level blocker found.** This is a static review
of the root-authored top-level runtime against the frozen public header,
independent semanticV2/addendum and the separately frozen provider seam. No code
was changed, imported, parsed, compiled, instantiated or executed; no repository,
validator, emulator, hardware or installed-printing operation was performed.

Reviewed runtime:
`/tmp/hp1020-entry-usb-reset-runtime-draft-20261003/hp1020_usb_runtime.c`, SHA256
`93d4ad702137156288ecac13fabea58d8ae9269ba309b14a43ea972cf2daf9d2`.
Its original manifest is
`cfdc5aa0fde7573219b1ba4cb845b690ffdcf4e8582c82b1c5498697e6aaf615`.
The exact read-time inputs are preserved in `inputs/`; its copied foreign
manifest is provenance, not a claim that its entire larger package is present.

## Reviewed behavior

- The complete four-span zero/sentinel/data scan remains before every mailbox
  write and initializer. There is exactly one `ram_init`, configuration helper
  and initial recovery invocation. Reset never calls them again, changes stack,
  rewrites component memory, directly calls receive/document restart or sets a
  production generation field. The later generation advance comes from the real
  class finish-reset path with the original pending ticket.
- Lines330..340 consume five original64-byte fragments, eagerly retain arm6,
  perform the reset race, then admit a complete fresh document and eagerly arm
  its seventh transfer. The new log scopes7..13 are passed only to `arm`; no
  scope value becomes a production ticket/cookie or DMA/slot identity. Actual
  normal completion cookies come from the retained DCD record.
- Lines260..278 copy/offer/dispatch the immutable original sequence3 before
  reading the cookie saved by the genuine callback. Only after dispatch returns
  is `out_request_cancel` called. Its return increments CANCEL_API_CALLS once;
  no cancelled-completion or reset promise follows from marking cancellation.
- Lines279..293 service the real class request while bulk is retained, obtain
  the original pending reset ticket through the production API and record the
  first two WAITs. The late old32 bytes are installed/acquired with their actual
  retained cookie, then RECEIVE is retried while PENDING, producing the third
  WAIT. Actual service drains that callback. **There is no pump or input-consumed
  increment for the old32 bytes**, and no manual release of its reservation.
- Lines296..311 check the three distinct supplied facts, acknowledge RECEIVE
  only after actual drain, then OUTPUT, then the missing-TRANSPORT WAIT, then
  TRANSPORT. Each API receives the same ticket copied before recovery. Only
  actual successful acknowledgements/finish increment their success counters.
  The fourth WAIT does not count as a promise or finished recovery. The second
  actual document_restart remains inside successful adapter finish_reset.
- `settle_status` is called once after initial raw configuration and once after
  successful reset. It obtains the live original EP0 cookie, takes its genuine
  proposal, verifies original NULL/0 and separate staging/descriptor addresses,
  supplies the explicit observation, retires only provider ownership and services
  the actual callback. No provider hook or result code fabricates a status ACK.
  The provider hook legitimately sees delivering_live before TinyUSB's following
  class ACK callback releases response_owned; the orchestration does not demand
  premature release or clear historical request IDs.
- Lines314..327 replay only the callback-saved cookie after freshq1 was consumed
  and q2/slot1 was genuinely armed. Neither stale attempt installs an image or
  reads a historical pointer from a diagnostic row. The acquisition increments
  attempt count only, and the second direct cancellation increments its API
  attempt count only. No acceptance, successful promise, normal service or pump
  occurs between the two stale calls and their six completed check rows.
- Lines342..360 close exactly once with eager q7 still owned, install the
  explicit successful ZLP at offset352/count0, and perform **no intervening
  service** before acquisition. Then actual service and an empty pump precede
  the only finish. The ZLP is not a parsed EOF. Closing/finished are experiment
  flags used by real output callbacks, not direct writes to production state.

## Counters and checked-row seam

`checked_reset`/`checked_cookie` use the actual returned enum and original typed
arguments. Reset identities occupy two words with three explicit zeros; cookies
occupy all five semantic words. Their result domain is independent of identity
kind. The root records its last API result; provider `ram_check` validates/appends
and alone increments CHECK_ROWS. It does not overwrite the actual return or make
an extra production call. The six rows appear in the frozen order1..6.

Source-level successful-path totals agree with the public schedule:

| Counter | Count |
|---|---:|
|service calls|18|
|pumps, including final empty reservation|12|
|arms|13|
|acquisition attempts / accepted|14 /13|
|parser-fed bytes|672|
|queued cancellation callback / direct mark attempts / settlements|1 /2 /0|
|successful promises, each part / recovery finishes|2 /2|
|EP0 observations / settlements / actual status hooks|2 /2 /2|
|checked refusal rows|6|
|close / finish|1 /1|

These are a static consistency check, not observed counters. Raw call-entry,
return, input and full-memory evidence must still prove the actual run. In
particular exactly12 production receive completions/releases and11 nonempty
feeds must exclude old `(G2,sequence6)` even though its acquisition succeeded.

## Natural stop ordering

The code supports the independent20-stop order without hidden hit skipping:

1. Initial EP0 take follows initial setup offer/dispatch, so the next armed
   setup-offer breakpoint is the reset sequence3.
2. The first OUT cancellation-mark entry follows the actual callback. The next
   adapter RECEIVE acknowledgment is the owned WAIT after row1.
3. The next publisher service follows late SUCCESS and row3. The next RECEIVE
   acknowledgement follows its actual callback drain. The next document_restart
   is the second actual restart, after parts7; its busy adapter is legitimate.
4. The next EP0 take is outer reset-status publication, followed by fresh arm,
   fresh pending service, reuse arm, stale acquisition, stale cancellation and
   the next normal image-install entry before its first write.
5. Close, next post-close service, finish and park retain their required order.

The notes between these operations write secondary mailbox snapshots only.
Their tags do not select a production state or replace the independent actual
entry/return predicates. No source change was requested by this review.

## Remaining limits

The target compiler/ABI, actual linked observation symbols, unknown-section
admission, code budget, callback graph and stack ceiling need a fresh root audit.
In particular aggregate cookie arguments include target ABI padding; the future
observer must decode semantic fields rather than assume a whole endpoint
register is meaningful. This source review does not validate the future runner,
native command ledger, copied-evidence controls or physical platform promises.
Both supplied paint cases remain unexecuted for this new reset profile.

Other exact reviewed identities:

- Public header `a73a3904b094126e811f6d26249ab93d3d71cae7f5e0c00cedd10e77addc4679`.
- Provider `10895c86ff673dfbeeb48eee2eed0bc0d6327546026ebfa54768c0f47c5bc9d4`.
- SemanticV2 acceptance `26c0fc71d2bfbf027f2298288970a86fb77676c925bc1e51ea76f9a0d2dd96e2`.
- SemanticV2 literals `aab93eba1de9c9123e9344d8bb5fc642b690e7ac4b02c2fc3fd5efa4d501b333`.
- Public addendum `7f317b61e98080b4a42a3f2295367b7d1262d90a39412d2f9ca935a7f5a8439`.
- Literal addendum `4b9df5dc50186b05879ae7fc71f9922302679d6ffeda2402a218c8686bb5cea0`.
