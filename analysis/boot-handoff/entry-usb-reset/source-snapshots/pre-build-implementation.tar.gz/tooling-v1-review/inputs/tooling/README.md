# Unexecuted reset build, audit and runner coordination

The three local drafts reuse unchanged accepted USB/entry low-level helpers.
No imports, builds, linked audits, candidate execution or validators have run.
Python source was parsed syntactically only. Old source copies identify origins.

Build changes only sibling source/output/effective-temp names and description;
actual27 input units, profile gates, libgcc recovery and preserved objects stay.
Audit owns new pinned header/manual tables, new525word compiler witness and exact
new dependency targets, plus copies of the coordinating function. Raw allocation,
input sections/relocations/dependencies semantics, libgcc, ISA/startup/private-
core/stack helpers remain unchanged and pinned. New Program.entry_symbol_records
retains raw symbol rows so same-name local callbacks are not collapsed.
Runner owns source/tool closure,20symbol roles,2paint loop,21paired/23QEMU capture
comparison and separate raw publication. It reuses only pure byte/ELF/image/
snapshot helpers from the pinned old runner; no SOURCE/OUT globals are changed.
New execution is refused if the independent checker is absent; --audit-only may
seal a draft before the checker exists. Every first failure is retained; no new
report is published until its independently frozen raw gate succeeds.

Private7-region geometry, full buffers, original code/stack caps,10M/120s/4096/
16MiB limits are unchanged. Old reports and old aggregate validation remain intact.
Remaining: independent source review, actual input/link/layout/stack admission,
then focused sequential execution and negative controls before shared integration.
