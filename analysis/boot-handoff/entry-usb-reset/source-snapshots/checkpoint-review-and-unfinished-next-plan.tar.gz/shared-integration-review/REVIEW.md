# Reset checkpoint shared integration: static review

2026-10-03. No actionable blocker found in the three requested files.

- `check-hp1020-analysis-consistency.py` adds exactly one closed profile mapping
  and one named consistency row. The existing entry-ram default and healthy USB
  profile are unchanged. Archive/member/path/size/hash limits, exact report and
  saved-gate equality, source-root checking and failure handling remain intact.
  The new schema matches the reviewed reset runner's archive publisher.
- `validate-hp1020-offline-analysis.sh` adds five Python files to syntax checks
  and one ordinary synchronous `run_step` invocation after the healthy USB run.
  `run_step` still executes its command directly under `set -euo pipefail`.
  No background/parallel call or device-contact command is added.
- `.gitattributes` adds only the new reset target's raw `*.map -whitespace`
  exemption. It changes no evidence bytes or acceptance predicate and does not
  expand to ordinary source files.

The reviewed diff is against HEAD (both staged and unstaged changes), avoiding
the earlier empty-unstaged-diff race. `inputs/` preserves both exact versions of
all three files, that diff, the baseline commit and the runner schema excerpt.
No other working-tree changes were reviewed or modified by this task.

Current source SHA256 values:

- consistency checker: `a4de2b14aee7e54eb7cde2df7f775f47f3f19ab8c05ce8e49c0769049d6b54e7`
- offline runner: `f8b34467c8af8d74566cbc1dc02e27151e6eee3c65e21406bd9a72981afc1501`
- attributes: `82510e669235662d22948fc32c66fb4b6be2525808e67535e0eb4a65ef4100b0`

Static file/diff inspection and `/tmp` preservation only. No imports, source
parsing, builds, audits, tests, validators, target/hardware execution or repository
edits occurred here. The lead owns final validation, commit, push and stopping at
the owner's requested checkpoint; this review adds no execution success claim.
