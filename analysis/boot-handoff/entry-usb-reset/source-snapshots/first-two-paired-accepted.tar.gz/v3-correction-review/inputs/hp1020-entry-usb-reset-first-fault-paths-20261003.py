"""Read original first-run bytes/traces; no target or acceptance repair."""
from pathlib import Path
import gzip, hashlib, json, struct

C = Path('/tmp/hp1020-entry-usb-reset-2i2sfkkw')
sha = lambda b: hashlib.sha256(b).hexdigest()
audit = json.loads((C / 'linked-audit.json').read_text())
elf = (C / 'target/entry-usb.elf').read_bytes()
assert sha(elf) == 'd2daf38cbff95b0a2b990c7fc99b0b5655ebfb1c8e12bc9f108c65bf5ed2fa8f'
start, end = 0x1000cfcc, 0x1000cff8
text = next(s for s in audit['allocated_sections'] if s['name'] == '.text')
def code(at, n):
    off = text['offset'] + at - text['address']
    return elf[off:off+n]
anchors = {0x1000cfd8: '2a9058', 0x1000cfdd: 'cda5',
           0x1000cfdf: '229215', 0x1000cfe4: 'c0a7',
           0x1000cfe6: '2a9615', 0x1000cfee: '2a9458', 0x1000cff6: 'd00f'}
for at, value in anchors.items(): assert code(at, len(value)//2).hex() == value
memory_pcs = {0x1000cfce, 0x1000cfd8, 0x1000cfdf, 0x1000cfe6, 0x1000cfee}
rows = []
for folder in sorted((C / 'cases').iterdir()):
    model = json.loads((folder / 'model/result.json').read_text())
    steps = gzip.decompress((folder / 'model/traces/steps.bin.gz').read_bytes())
    accesses = gzip.decompress((folder / 'model/traces/accesses.bin.gz').read_bytes())
    assert len(steps) == model['instructions']*4 <= 40_000_000
    assert len(accesses) == sum(model['access_count'].values())*20 <= 200_000_000
    assert sha(steps) == model['step_sha256'] and sha(accesses) == model['access_sha256']
    pcs = [p[0] for p in struct.iter_unpack('>I', steps)]
    observed = [(k,pc,address,n,value) for k,pc,address,n,value in struct.iter_unpack('>B3xIIII', accesses)
                if start <= pc < end]
    cursor = 0
    first_status = next(r['instruction'] for r in model['reset_observations'] if r['label'] == 'pre-initial-status')
    paths = []
    for i, pc in enumerate(pcs):
        if pc != start: continue
        j = i
        while j < len(pcs) and start <= pcs[j] < end:
            j += 1
            assert j-i < 64
        sequence = pcs[i:j]
        wanted = [at for at in sequence if at in memory_pcs]
        actual = observed[cursor:cursor+len(wanted)];cursor += len(wanted)
        assert [r[1] for r in actual] == wanted
        stopped = next(r[4] for r in actual if r[1] == 0x1000cfd8)
        writes = [r for r in actual if r[0] == 2]
        if i < first_status:
            assert stopped == 1 and writes == [] and 0x1000cfdf not in sequence
        else:
            assert stopped == 0 and writes == [(2,0x1000cfe6,0x10010054,4,7),(2,0x1000cfee,0x10010058,1,1)]
        paths.append(dict(instruction_index=i, before_initial_status=i<first_status,
                          original_pcs=sequence, accesses=actual, stopped_before=stopped))
    assert cursor == len(observed) and paths
    rows.append(dict(case=folder.name, calls=paths, step_sha256=sha(steps), access_sha256=sha(accesses)))
out = Path('/tmp/hp1020-entry-usb-reset-first-fault-paths-20261003.json')
assert not out.exists()
out.write_text(json.dumps(dict(status='source/byte/trace diagnosis only; overall first-run gate failure unchanged',
    target_sha256=sha(elf), byte_anchors={hex(k):v for k,v in anchors.items()}, cases=rows),sort_keys=True,indent=2)+'\n')
print(json.dumps({'case_calls':{r['case']:len(r['calls']) for r in rows},
                  'pre_initial_status':'already-stopped branch reads1, performs no error write',
                  'later_reset':'active branch reads0, writes error7 and stopped1',
                  'target_instructions_executed_by_diagnostic':0},indent=2))
