# V3: initially stopped receive state preserves its zero error

2026-10-03. Author: `/root/usb_reference_contract`. Static source diagnosis and
narrow oracle correction, after root reported the first overall failed reset
experiment. This author did not inspect the new runtime/provider implementation,
candidate state captures, root's diagnostic JSON, or target PC/access traces.
No Python source was parsed/imported, built, or executed here. Root alone owns
validation and preservation of the failed run.

## Finding

The exact initial-status expectation is `receive_error=0`, with `stopped=1`.
The old additive literal's value7 was an oracle mistake: it conflated an
already-stopped initial binding with a fault admitted during active reception.
The source supports the reported zero; it does not require a target correction.
This finding alone does not accept the rest of the run or publish success.

The original frozen V2 checker remains unchanged (SHA256
`713c52a9d8b90f50c628d36cf55c18b71437953b68b6cad767af6a639ddbcbff`).
The original additive literal remains unchanged (SHA256
`4b9df5dc50186b05879ae7fc71f9922302679d6ffeda2402a218c8686bb5cea0`).
Both exact originals are copied under `inputs/original/`. The first candidate
run `/tmp/hp1020-entry-usb-reset-2i2sfkkw` remains an overall failure; root is
preserving it separately. No report/source hash is being repaired in place.

## Independent unchanged-source trace

The following line references are to the exact source copies in this package.

1. `hp1020_usb_document.c:18–28` zeroes the document and initializes its receive
   core. `hp1020_usb_receive.c:16–19` zeroes the receive state, establishes
   generation1, and returns OK with valid memory. At this point error0/stopped0
   follow directly from the successful initializer, not from incoming BSS paint.
2. The accepted prior healthy provider's `hp1020_usb_runtime_ram.c:350–355`
   calls document, printer, and adapter initialization in that order.
   `hp1020_usb_printer.c:88–107` does not modify receive error on its valid path.
   `hp1020_tusb_adapter.c:393–404` initializes transport epochs1, sets fenced and
   input_closed, and calls `hp1020_usb_receive_stop()`. That function is exactly
   `s->stopped=1` (`hp1020_usb_receive.c:77`); it never sets error.
3. The actual initial bus reset calls `fence()` after advancing control epoch
   (`hp1020_tusb_adapter.c:503–516`). `fence():96–109` calls printer_fault with
   the current receive generation and a nonzero reason. The printer wrapper
   (`hp1020_usb_printer.c:307–318`) calls receive_fault, then stop, then invalidates
   recovery metadata. In `hp1020_usb_receive.c:52–57`, after matching generation
   and nonzero fault, **stopped1 returns STOPPED before fail()**. It does not
   read or write the stored error. The wrapper's later stop also preserves it.
   Thus this genuine reset admission keeps error0/stopped1.
4. Servicing the actual reset calls the class driver reset. Its already-fenced,
   ownerless path (`hp1020_tusb_adapter.c:161–175`) does not add a fault. Nothing
   in this step restarts the receive generation.
5. Raw configuration1 is destructive by `changes_endpoints():426–441` and
   `admit_control():444–465`, so it invokes the same fence chain. Reception is
   still stopped from initialization; receive_fault again returns at its
   stopped guard and preserves error0. Successful driver_open sets binding
   metadata (`183–213`), and service creates binding recovery (`216–250`,
   `892–898`). `begin_recovery()` (`hp1020_usb_printer.c:42–64`) calls stop and
   records recovery identity1/generation1; it does not set receive error.
6. The accepted prior healthy orchestration `hp1020_usb_runtime.c:128–166`
   performs reset, service, raw configuration admission, service, then the first
   EP0 status take. It settles that status before `recover_initial_binding()`
   (`169–198`, call order at201–204). The frozen reset addendum preserves this
   prefix and observes the status take before those recovery promises. Therefore
   the initial-status snapshot must still have generation1/error0/stopped1.

This is distinct from the later mid-document reset. Successful receive restart
(`hp1020_usb_receive.c:83–88`, called through document restart) clears error and
stopped while advancing generation. After the old320-byte prefix, reception is
active. Its SOFT_RESET admission uses the same nonzero fence chain, but now
`receive_fault()` reaches `fail(HP1020_RX_ENDPOINT)`; `fail():5–8` records7 and
stops. The enum is independently fixed by `hp1020_usb_receive.h:8–11`.
All mid-document error7 predicates remain exact and unchanged.

## Exact correction and limits

- `draft/literal-addendum.py`: only INITIAL_STATUS.receive_error changes7→0.
- `draft/check-hp1020-entry-usb-reset.py`: the same embedded literal changes7→0,
  and its exact additive-source SHA pin changes to the revised literal's hash.
- `draft/ADDENDUM.md`: byte-identical original. Its initial-status prose contains
  no erroneous initial error7 claim; its error7 reference is the correct later
  drained G2 state. No prose amendment is needed.
- No other expectation, CPU rule, event/owner identity, WAIT/STALE predicate,
  trace, counter, fixture, runtime, production source, or memory allowance changes.
  In particular this is not an allowed set `{0,7}`: the initial snapshot requires0
  and the active-generation reset snapshots continue to require7.

Root separately reported an original ELF/trace confirmation in
`/tmp/hp1020-entry-usb-reset-first-fault-paths-20261003.{py,json}`. That independent
execution-derived proof was not used to select the value in this static trace.
Fresh full execution and the corrected exact gate are still required for a
successful checkpoint. Descriptor/controller/output facts remain supplied RAM
inputs; this correction establishes no hardware behavior.
