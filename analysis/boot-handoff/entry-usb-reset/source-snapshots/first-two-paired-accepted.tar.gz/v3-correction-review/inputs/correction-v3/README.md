# Reset raw gate V3 — frozen correction, unexecuted by author

Use `draft/check-hp1020-entry-usb-reset.py` with the exact sibling neutral helper
`draft/check-hp1020-entry-usb.py`. The public API and CLI are unchanged:
`check_capture(capture_root, source_root=None)` or capture-directory positional
argument with optional `--source-root`.

Integration additionally replaces only the sibling experiment's
`literal-addendum.py` with `draft/literal-addendum.py`. `draft/ADDENDUM.md` is an
unchanged convenience copy, not a requested prose change. `changes.patch` shows
all three changed lines: the single initial error expectation in the literal,
its embedded copy in the gate, and the exact literal-source seal.

V3-DELTA.md gives the unchanged production-source trace and distinguishes the
initial stopped/error0 state from active reception's later stopped/error7 state.
The V1/V2 gates and prior independent literals remain preserved. Root's original
first-run failure is not reclassified. This package changes no candidate code
and claims no passing execution; root owns the fresh sequential validation.
