# Reset gate V3 correction: independent static review

2026-10-03. No actionable blocker found.

The actual V2→V3 checker and additive-literal diffs are exactly the requested
three changed lines: initial `receive_error`7→0 in the original literal and its
embedded copy, plus the exact literal-source pin. The prose addendum is byte
identical. All mid-document7 expectations, identities, permissions, trace and
return predicates remain unchanged. The value is exact0, not a permissive set.

The unchanged source supports the correction independently: successful receive
initialization zeroes error; adapter initialization invokes stop, which writes
only stopped1. Initial reset/configuration fencing calls receive_fault with the
matching generation and a nonzero reason, but its stopped guard returns before
reading or writing error. Binding recovery also stops without setting error.
No restart precedes the first status-take observation. Initial error0/stopped1
therefore follows from the initialized state and control flow. Conversely,
restart clears stopped/error; the later active G2 SOFT_RESET reaches fail and
records the independently enumerated endpoint error7. That distinction is
preserved in V3.

The lead's separate diagnostic source matches the captured linked helper:
0x1000cfd8 reads stopped, 0x1000cfdd branches directly to RET when nonzero,
0x1000cfdf reads error only on the active path, and 0x1000cfe6/ee write error7
and stopped1. Its memory-PC set covers all accesses in this call-free helper.
The saved output describes two early stopped1/no-error-read-or-write calls and
one later stopped0/error0→7 call per paint, consistent with these bytes and the
unchanged source. I read that diagnostic and its saved result; I did not rerun
it or independently execute/decompress the full candidate trace.

The first overall report still explicitly records the initial receive_error
oracle failure and status fail. It is not relabeled by this correction. No
candidate code, target ELF, report hash or earlier source snapshot is changed;
fresh execution/acceptance remains the lead's responsibility.

Reviewed exact sources:

- old gate V2: `713c52a9d8b90f50c628d36cf55c18b71437953b68b6cad767af6a639ddbcbff`
- corrected gate V3: `eacaf2792eec5916e87e25afa247031c70c86f723171da0c2a6e31a7a4e7ecef`
- original literal: `4b9df5dc50186b05879ae7fc71f9922302679d6ffeda2402a218c8686bb5cea0`
- corrected literal: `dd5846e3acf9dd755ceb798629d42efe3c1031f3a40cfcd332942bf98e17a0c3`
- unchanged addendum: `7f317b61e98080b4a42a3f2295367b7d1262d90a39412d2f9fca935a7f5a8439`
- original target: `d2daf38cbff95b0a2b990c7fc99b0b5655ebfb1c8e12bc9f108c65bf5ed2fa8f`
- lead diagnostic source: `840b016e330cdbfd95618ea7d19c4b0b6dcacb53a3ee5a3578a24082ce6b2f6c`
- lead diagnostic result: `f3cda9698f0f3b0f6116155a00a5eff2cf7ffe51c33b47ccb57dec475c407d59`

`inputs/` preserves the complete correction package/original copies, diagnostic
source/result and actual first-run ELF/disassembly. The failed report is retained
at its original path; this review saves its exact hash and two-line failure
excerpt. Production hash readback agrees with the unchanged reviewed copies.
`INPUTS.sha256` seals every preserved member.

This was static reading, comparison, hashing and `/tmp` preservation only. No
imports, source parsing, builds, audits, validators, QEMU, candidate execution,
hardware contact or repository edits were performed.
