"""Compare unchanged execution evidence; never relabel the original failed run."""
from pathlib import Path
import copy,gzip,hashlib,json,re
A=Path('/tmp/hp1020-entry-usb-reset-2i2sfkkw')
B=Path('/tmp/hp1020-entry-usb-reset-_ld_tz8b')
OUT=Path('/tmp/hp1020-compare-entry-usb-reset-first-second-20261003.json')
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda p:json.loads(p.read_text())
assert not OUT.exists()
original_reports={p:(p/'validation.json').read_bytes() for p in (A,B)}
a,b=(load(p/'validation.json') for p in (A,B))
assert a['status']=='fail' and b['status']=='pass'
assert not load(A/'independent-gate.json')['ok'] and load(B/'independent-gate.json')['ok']
assert 'pre-initial-status: original field receive_error' in a['publication_error']
changed=[n for n in sorted(set(a['source_sha256'])|set(b['source_sha256']))
         if a['source_sha256'].get(n)!=b['source_sha256'].get(n)]
assert changed==['open-firmware/entry-usb-reset-test/literal-addendum.py',
                 'scripts/check-hp1020-entry-usb-reset.py']
assert a['target_sha256'].keys()==b['target_sha256'].keys()
metadata=[]
for n in a['target_sha256']:
    x=(A/'target'/n).read_bytes();y=(B/'target'/n).read_bytes()
    assert sha(x)==a['target_sha256'][n] and sha(y)==b['target_sha256'][n]
    if x==y:continue
    assert n.endswith(('.d','.su')),n
    pattern=rb'hp1020-entry-usb-reset-source\.[A-Za-z0-9]{6}'
    xs=set(re.findall(pattern,x));ys=set(re.findall(pattern,y))
    assert len(xs)==len(ys)==1,n
    left=next(iter(xs));right=next(iter(ys));assert x.replace(left,right)==y,n
    metadata.append(dict(file=n,before_prefix=left.decode(),after_prefix=right.decode()))
rows=[]
for old,new in zip(a['cases'],b['cases']):
    assert old['case']==new['case'];case=old['case']
    x,y=copy.deepcopy(old),copy.deepcopy(new)
    for row in (x,y):
        q=row['qemu'];assert q['cleanup']['returncode']==0 and not q['cleanup']['still_running']
        q['cleanup'].pop('pid');q.pop('elapsed_seconds')
        q['host_intervention_ledger'].pop('sha256');q['host_intervention_ledger'].pop('bytes')
        sock=q['qemu']['args'][18]
        assert re.fullmatch(r'unix:/tmp/hp1020-qemu-[^/]+/gdb\.sock,server=on,wait=off',sock)
        q['qemu']['args'][18]='same private socket shape'
    assert x==y,case
    raw_ledgers=[];pids=[]
    for root,row in ((A,old),(B,new)):
        raw=(root/'cases'/case/'qemu/host-interventions.jsonl').read_bytes()
        seal=row['qemu']['host_intervention_ledger']
        assert len(raw)==seal['bytes'] and sha(raw)==seal['sha256']
        ledger=[json.loads(line) for line in raw.splitlines()]
        assert len(ledger)==seal['lines']
        clean=[z for z in ledger if z.get('kind')=='process-cleanup'];assert len(clean)==1
        raw_ledgers.append(raw);pids.append(clean[0]['pid'])
    left,right=(('"pid":'+str(pid)+',').encode() for pid in pids)
    assert raw_ledgers[0].count(left)==raw_ledgers[1].count(right)==1
    assert raw_ledgers[0].replace(left,right)==raw_ledgers[1]
    assert len(raw_ledgers[1])-len(raw_ledgers[0])==len(right)-len(left)
    trace_seals={}
    for name,seal in (('accesses.bin.gz','access_sha256'),('steps.bin.gz','step_sha256')):
        raw_old=gzip.decompress((A/'cases'/case/'model/traces'/name).read_bytes())
        raw_new=gzip.decompress((B/'cases'/case/'model/traces'/name).read_bytes())
        assert raw_old==raw_new and sha(raw_old)==old['model'][seal]==new['model'][seal]
        trace_seals[name]=sha(raw_old)
    count=0
    for engine in ('model','qemu'):
        for old_snap,new_snap in zip(old[engine]['snapshots'],new[engine]['snapshots']):
            assert old_snap==new_snap
            for region in old_snap['regions']:
                x=(A/'cases'/case/engine/region['path']).read_bytes()
                y=(B/'cases'/case/engine/region['path']).read_bytes()
                assert x==y and len(x)==region['bytes']==region['captured_bytes']
                assert sha(x)==region['sha256'];count+=1
    rows.append(dict(case=case,all_actual_snapshots_equal=True,raw_snapshot_members=count,
                     raw_trace_sha256=trace_seals,debugger_bytes_equal_except_sole_cleanup_pid=True))
assert len(rows)==len(a['cases'])==len(b['cases'])==2
for p,raw in original_reports.items():assert (p/'validation.json').read_bytes()==raw
result=dict(status='comparison pass; first overall run remains failed',old_capture=str(A),
            accepted_capture=str(B),changed_source_seals=changed,target_code_objects_unchanged=True,
            temporary_metadata_differences=metadata,cases=rows,
            scope='Exact same target execution after source-derived oracle correction; acceptance belongs only to the fresh V3 run.')
OUT.write_text(json.dumps(result,indent=2)+'\n')
print('Both original execution traces and all raw snapshots match; first report remains failed. Only oracle sources and verified temporary metadata differ.')
