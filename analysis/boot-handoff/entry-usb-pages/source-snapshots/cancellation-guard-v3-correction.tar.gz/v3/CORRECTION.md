# V3 cancellation guard correction

First full execution remains an overall V2 gate failure and is archived separately.
The adapter and RAM provider each have a local request_cancel function. V2 banned
both entries by name. Unchanged adapter C lines61..65 return immediately unless
an owner belongs to the DCD. Initial bus reset and SET_CONFIGURATION each call
fence then cancel_ep0: bulk, EP0 OUT, EP0 IN are all empty. The exact ELF helper
reads owner.state then takes its immediate return; no callback or store executes.
V3 identifies the provider through the actual adapter ops pointer, refuses every
instruction of provider/controller cancellation, and additionally requires the
six exact four-instruction empty-owner helper paths before bulk publication,
with the original ordered one-byte zero reads. Both original function bodies
remain unchanged. No target, literal, observer, report or hash has been edited.

The diagnostic below replays the raw first capture with V3's trace semantics only.
It cannot accept the old capture under V3 (its sealed checker is V2); a fresh run
is required. No existing capture/report is written by the diagnostic.
