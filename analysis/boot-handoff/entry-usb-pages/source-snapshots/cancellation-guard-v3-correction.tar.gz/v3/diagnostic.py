from pathlib import Path
import importlib.util,json,hashlib,difflib,shutil,ast
root=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
capture=Path('/tmp/hp1020-entry-usb-pages-1i84bayj')
out=Path('/tmp/hp1020-pages-independent-gate-v3-20261005');out.mkdir()
gate=root/'scripts/check-hp1020-entry-usb-pages.py'
for p in (gate,root/'open-firmware/entry-usb-pages-test/independent-literals.py',root/'open-firmware/entry-usb-pages-test/literal-addendum.py'):
 ast.parse(p.read_text());shutil.copyfile(p,out/p.name)
old=(capture/'source/scripts/check-hp1020-entry-usb-pages.py').read_text()
(out/'gate-v2-v3.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),gate.read_text().splitlines(True),fromfile='frozen-v2',tofile='v3')))
(out/'CORRECTION.md').write_text('''# V3 cancellation guard correction

First full execution remains an overall V2 gate failure and is archived separately.
The adapter and RAM provider each have a local request_cancel function. V2 banned
both entries by name. Unchanged adapter C lines61..65 return immediately unless
an owner belongs to the DCD. Initial bus reset and SET_CONFIGURATION each call
fence then cancel_ep0: bulk, EP0 OUT, EP0 IN are all empty. The exact ELF helper
reads owner.state then takes its immediate return; no callback or store executes.
V3 identifies the provider through the actual adapter ops pointer, refuses every
instruction of provider/controller cancellation, and additionally requires the
six exact four-instruction empty-owner helper paths before bulk publication,
with the original ordered one-byte zero reads. Both original function bodies
remain unchanged. No target, literal, observer, report or hash has been edited.

The diagnostic below replays the raw first capture with V3's trace semantics only.
It cannot accept the old capture under V3 (its sealed checker is V2); a fresh run
is required. No existing capture/report is written by the diagnostic.
''')
spec=importlib.util.spec_from_file_location('pages_v3',gate);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
report=m.js(capture,'validation.json')
assert m.js(capture,'independent-gate.json')['ok'] is False
changed=[]
for name,h in m.js(capture,'source-sha256.json').items():
 if m.sha((root/name).read_bytes())!=h:changed.append(name)
assert changed==['scripts/check-hp1020-entry-usb-pages.py'],changed
elf=m.B.Elf(m.raw(capture,'target/entry-usb.elf'));assert m.sha(elf.data)==m.REVIEWED_TARGET_SHA256
a=m.object_addresses(elf);cps=m.checkpoint_addresses(elf);forbidden=m.B.forbidden_shortcut_policy(capture,elf)
results=[]
try:
 for c in report['cases']:
  p=capture/'cases'/c['case'];model=c['model']
  images=m.B.snapshots(p/'model',model['snapshots'],m.MODEL_PHASES)
  results.append({'case':c['case'],'trace':m.model_trace(p/'model',model,images,elf,cps,a,forbidden)})
  print(c['case']+': diagnostic trace passed',flush=True)
except Exception as exc:
 results.append({'error':type(exc).__name__+': '+str(exc)});raise
finally:
 (out/'diagnostic.json').write_text(json.dumps({'scope':'partial trace diagnostic, not capture acceptance','results':results},indent=2)+'\n')
 shutil.copyfile(__file__,out/'diagnostic.py')
 (out/'MANIFEST.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir()) if p.is_file()},indent=2)+'\n')
