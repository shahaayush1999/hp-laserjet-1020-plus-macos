from pathlib import Path
import hashlib,ast
old=Path('/tmp/hp1020-entry-usb-reset-controls-draft-20261003/copied-reset-controls.py').read_text()
s=old.replace('Draft six copied-evidence controls for the exact frozen reset gate V3.','Five copied-evidence controls for the exact frozen pages gate V3.')
s=s.replace('check-hp1020-entry-usb-reset.py','check-hp1020-entry-usb-pages.py')
s=s.replace('eacaf2792eec5916e87e25afa247031c70c86f723171da0c2a6e31a7a4e7ecef',hashlib.sha256(Path('scripts/check-hp1020-entry-usb-pages.py').read_bytes()).hexdigest())
start=s.index("PHASES = (");end=s.index('\nQEMU_PHASES',start)
s=s[:start]+"PHASES = ('initial', 'after-normalization', 'pre-c', 'pre-first-output',\n          'pre-first-complete', 'pre-second-output', 'pre-document-event',\n          'pre-close', 'pre-final-service', 'pre-finish', 'park')"+s[end:]
start=s.index('OLD = (');end=s.index('\n\n\nclass ControlError',start)
s=s[:start]+"OBJECTS = {\n    'document': ('hp1020_usb_runtime_document', 13496),\n    'memory': ('hp1020_usb_runtime_memory', 114704),\n    'witness': ('hp1020_usb_runtime_witness', 9216),\n}"+s[end:]
s=s.replace('sealed_reset_capture_checker','sealed_pages_capture_checker').replace('paired_snapshots=21, qemu_snapshots=23','paired_snapshots=11, qemu_snapshots=13').replace('hp1020-reset-copied-overlay-v1','hp1020-pages-copied-overlay-v1')
start=s.index('def late_success_is_not_cancelled');end=s.index('\ndef run(args):',start)
s=s[:start]+'''def wrong_first_page_witness(ev):
    ev.paired('pre-first-complete', ev.addresses['witness'] + 8864, b'\\x80', b'\\x00')
    ev.notes.append(dict(claim='First retained pixel differs from independent source at its actual completion boundary.'))


def wrong_second_page_output(ev):
    ev.paired('pre-second-output', ev.addresses['memory'] + 81936, b'\\xa5', b'\\xa4')
    ev.notes.append(dict(claim='Second original output allocation differs from independent page2 pixels.'))


def premature_first_page_completion(ev):
    ev.paired('pre-first-complete', ev.addresses['document'] + 13324, bytes(4), (4).to_bytes(4, 'big'))
    ev.notes.append(dict(claim='Rows declared completed before the actual first completion function executes.'))


def wrong_compact_io_address(ev):
    ev.paired('pre-first-output', ev.addresses['witness'] + 20, (0x220).to_bytes(4, 'big'), (0x22c).to_bytes(4, 'big'))
    ev.notes.append(dict(claim='Compact initial read row falsely names the packet-size word instead of endpoint control.'))


def omit_original_pjl_byte(ev):
    rows = [x for x in ev.case['model']['pages_api_events'] if x['kind'] == 'entry' and x['name'] == 'hp1020_image_output_feed']
    require(len(rows) == 16 and rows[0]['arguments'][2] == 64, 'exact original first64 PJL feed')
    before = copy.deepcopy(rows[0]);rows[0]['arguments'][2] = 63
    ev.notes.append(dict(kind='false-first-feed-length', original=before, changed=copy.deepcopy(rows[0]),
        claim='False by-value length skips an original PJL byte without altering sealed source or actual trace.'))


CONTROLS = (
    ('wrong-first-page-witness', wrong_first_page_witness,
     'ValueError: pre-first-complete: complete independent witness bytes'),
    ('wrong-second-page-output', wrong_second_page_output,
     'ValueError: pre-second-output: entire original output allocation, exact independently specified page'),
    ('premature-first-page-completion', premature_first_page_completion,
     'ValueError: pre-first-complete: original field ring_completed'),
    ('wrong-compact-io-address', wrong_compact_io_address,
     'ValueError: pre-first-output: complete independent witness bytes'),
    ('omitted-original-pjl-byte', omit_original_pjl_byte,
     'ValueError: actual unmodified original-generation input including all PJL/partial chunks'),
)

''' +s[end:]
p=Path('/tmp/hp1020-pages-controls-draft-20261005');p.mkdir();(p/'copied-pages-controls.py').write_text(s);ast.parse(s)
print(p/'copied-pages-controls.py')
