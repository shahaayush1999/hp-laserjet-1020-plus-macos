#!/usr/bin/env python3
"""Five copied-evidence controls for the exact frozen pages gate V3.

Execution imports only the sealed independent capture checker and its neutral
reader. No target, interpreter, QEMU, producer, audit, or builder is run/imported.
Each control changes private copies after an unchanged complete positive check.
These are deliberately false evidence records, not executions of target bugs.
"""
import argparse
import copy
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile


GATE = 'check-hp1020-entry-usb-pages.py'
NEUTRAL = 'check-hp1020-entry-usb.py'
PINS = {
    GATE: '00a3b35164d116779273b33be60bfefafb490a72758449b7628d79ce3087edf1',
    NEUTRAL: '38f520c5d23834532806821d14ce9e5a8c3703d57935bcc923e453b43dece277',
}
FIRST_CASE = '00-ordinary-privilege-a5'
PHASES = ('initial', 'after-normalization', 'pre-c', 'pre-first-output',
          'pre-first-complete', 'pre-second-output', 'pre-document-event',
          'pre-close', 'pre-final-service', 'pre-finish', 'park')
QEMU_PHASES = PHASES + ('park-step-1', 'park-step-2')
GDB = dict(pc=0, lbeg=33, lend=34, lcount=35, sar=36,
           windowbase=38, windowstart=39, ps=42, intenable=110)
OBJECTS = {
    'document': ('hp1020_usb_runtime_document', 13496),
    'memory': ('hp1020_usb_runtime_memory', 114704),
    'witness': ('hp1020_usb_runtime_witness', 9216),
}


class ControlError(ValueError):
    pass


def require(ok, message):
    if not ok:
        raise ControlError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def atomic_write(path, data):
    """Replace the inode; a copied hardlink is never opened for mutation."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name + '-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(data)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def link_or_copy(source, destination):
    try:
        os.link(source, destination)
    except OSError as error:
        if error.errno != errno.EXDEV:
            raise
        shutil.copy2(source, destination)
    return destination


def tree_manifest(root):
    result = {}
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), 'no symlink in saved evidence: ' + str(path))
        if path.is_file():
            data = path.read_bytes()
            result[str(path.relative_to(root))] = dict(bytes=len(data), sha256=sha(data))
    require(result, 'nonempty original evidence tree')
    return result


def load_gate(path):
    spec = importlib.util.spec_from_file_location('sealed_pages_capture_checker', path)
    require(spec is not None and spec.loader is not None, 'independent gate load specification')
    module = importlib.util.module_from_spec(spec)
    old = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    finally:
        sys.dont_write_bytecode = old
    require(callable(getattr(module, 'check_capture', None)), 'independent check_capture API')
    return module


def registers(value, engine):
    result = copy.deepcopy(value)
    if engine == 'qemu':
        result['logical_ar'] = result.pop('logical_a')
    return result


class Evidence:
    def __init__(self, baseline, root, name, addresses):
        require(not root.exists(), 'new control capture directory required')
        shutil.copytree(baseline, root, copy_function=link_or_copy)
        self.root, self.name, self.addresses = root, name, addresses
        self.report = self.read_json('validation.json')
        self.original_report = copy.deepcopy(self.report)
        matches = [x for x in self.report['cases'] if x['case'] == FIRST_CASE]
        require(len(matches) == 1, 'one frozen first-case identity')
        self.case = matches[0]
        self.prefix = 'cases/' + FIRST_CASE + '/'
        self.ledger = [json.loads(line) for line in self.read(
            self.prefix + 'qemu/host-interventions.jsonl').splitlines()]
        self.before = {}
        self.notes = []

    def path(self, relative):
        require(isinstance(relative, str) and relative and not Path(relative).is_absolute(),
                'relative private capture member')
        path = self.root / relative
        require(path.resolve().is_relative_to(self.root.resolve()), 'capture path cannot escape copy')
        return path

    def read(self, relative):
        return self.path(relative).read_bytes()

    def read_json(self, relative):
        return json.loads(self.read(relative))

    def write(self, relative, data):
        require(relative == 'validation.json' or relative.startswith(self.prefix),
                'only first-case evidence/private report may change')
        require('/source/' not in relative and '/input/' not in relative and '/traces/' not in relative,
                'original sources, supplied inputs, and PC/access traces stay sealed')
        path = self.path(relative)
        require(path.is_file(), 'replace only an existing evidence member')
        before = path.read_bytes()
        if before != data:
            self.before.setdefault(relative, before)
            atomic_write(path, data)

    def write_json(self, relative, value):
        if self.read_json(relative) != value:
            self.write(relative, json_bytes(value))

    def snapshot(self, engine, phase):
        rows = [x for x in self.case[engine]['snapshots'] if x['name'] == phase]
        require(len(rows) == 1, 'unique original snapshot: ' + phase)
        return rows[0]

    def region(self, engine, phase, address, count):
        rows = [x for x in self.snapshot(engine, phase)['regions']
                if x['start'] <= address and address + count <= x['start'] + x['bytes']]
        require(count > 0 and len(rows) == 1, 'mutation lies in one full original region')
        row = rows[0]
        return row, self.prefix + engine + '/' + row['path'], address - row['start']

    def memory(self, engine, phase, address, count):
        _, path, offset = self.region(engine, phase, address, count)
        return self.read(path)[offset:offset + count]

    def paired(self, phase, address, old, new):
        require(len(old) == len(new) and old != new, 'one nonempty exact-width field change')
        for engine in ('model', 'qemu'):
            require(self.memory(engine, phase, address, len(old)) == old, 'literal original paired field')
            row, path, offset = self.region(engine, phase, address, len(new))
            data = bytearray(self.read(path))
            require(len(data) == row['bytes'] == row['captured_bytes'], 'complete original raw region')
            data[offset:offset + len(new)] = new
            self.write(path, bytes(data))
            row['sha256'] = sha(data)
        self.notes.append(dict(kind='paired-field', phase=phase, address=address,
                               original_hex=old.hex(), changed_hex=new.hex()))

    def scalar(self, phase, address, width=4):
        left = self.memory('model', phase, address, width)
        require(left == self.memory('qemu', phase, address, width), 'original paired locator bytes')
        return int.from_bytes(left, 'big')

    def set_logical_pair(self, phase, logical, old, new):
        for engine in ('model', 'qemu'):
            r = self.snapshot(engine, phase)['registers']
            key = 'logical_a' if engine == 'qemu' else 'logical_ar'
            physical = (r['windowbase'] * 4 + logical) % 32
            require(r[key][logical] == r['physical_ar'][physical] == old,
                    'original by-value argument agrees across physical/logical aliases')
            r[key][logical] = r['physical_ar'][physical] = new

    def reg_value(self, phase, number):
        r = self.snapshot('qemu', phase)['registers']
        for name, index in GDB.items():
            if index == number:
                return r[name]
        if 1 <= number <= 32:
            return r['physical_ar'][number - 1]
        if 124 <= number <= 139:
            return r['logical_a'][number - 124]
        raise ControlError('unknown captured debugger register')

    def snapshot_replies(self, change):
        phase = None
        for index, row in enumerate(self.ledger):
            if row['kind'] == 'snapshot-start':
                require(phase is None, 'non-nested original snapshot markers')
                phase = row['name']
            elif row['kind'] == 'snapshot-end':
                require(phase == row['name'], 'original paired snapshot-end marker')
                phase = None
            elif row['kind'] == 'gdb-request' and phase is not None:
                require(index + 1 < len(self.ledger) and self.ledger[index + 1]['kind'] == 'gdb-reply',
                        'original contiguous request/reply')
                reply = self.ledger[index + 1]
                command = row['command']
                if re.fullmatch(r'p[0-9a-f]+', command):
                    expected = f'{self.reg_value(phase, int(command[1:], 16)):08x}'
                else:
                    match = re.fullmatch(r'm([0-9a-f]+),([0-9a-f]+)', command)
                    require(match is not None, 'snapshot accepts only original p/m envelope')
                    address, count = (int(x, 16) for x in match.groups())
                    expected = self.memory('qemu', phase, address, count).hex()
                if change:
                    reply['reply'] = expected
                else:
                    require(reply['reply'] == expected, 'changed raw snapshot and original-position reply agree')
        require(phase is None, 'closed original snapshot sequence')

    def sync(self):
        old_ledger = copy.deepcopy(self.ledger)
        self.snapshot_replies(True)
        if self.ledger != old_ledger:
            data = b''.join((json.dumps(x, sort_keys=True, separators=(',', ':')) + '\n').encode()
                            for x in self.ledger)
            self.write(self.prefix + 'qemu/host-interventions.jsonl', data)
            self.case['qemu']['host_intervention_ledger'] = dict(
                path='host-interventions.jsonl', sha256=sha(data), lines=len(self.ledger), bytes=len(data))
        for engine in ('model', 'qemu'):
            for item in self.case[engine]['snapshots']:
                path = self.prefix + engine + '/' + item['name'] + '/'
                self.write_json(path + 'registers.json', item['registers'])
                self.write_json(path + 'snapshot.json', item)
            if engine == 'model':
                self.write_json(self.prefix + 'model/snapshots.json', self.case[engine]['snapshots'])
            self.write_json(self.prefix + engine + '/result.json', self.case[engine])
        self.write_json(self.prefix + 'case.json', self.case)
        require({k: v for k, v in self.report.items() if k != 'cases'} ==
                {k: v for k, v in self.original_report.items() if k != 'cases'} and
                self.report['cases'][1:] == self.original_report['cases'][1:],
                'source/target/tool/expectation pins and second case remain exact')
        self.write_json('validation.json', self.report)

    def envelope_check(self):
        require(self.read_json('validation.json') == self.report and
                self.read_json(self.prefix + 'case.json') == self.case, 'private report/case propagation')
        for engine, phases in (('model', PHASES), ('qemu', QEMU_PHASES)):
            result = self.case[engine]
            require(result == self.read_json(self.prefix + engine + '/result.json') and
                    tuple(x['name'] for x in result['snapshots']) == phases, 'complete original result/schedule')
            if engine == 'model':
                require(result['snapshots'] == self.read_json(self.prefix + engine + '/snapshots.json'),
                        'complete model snapshot metadata propagation')
            for item in result['snapshots']:
                base = self.prefix + engine + '/'
                require(item == self.read_json(base + item['name'] + '/snapshot.json') and
                        item['registers'] == self.read_json(base + item['name'] + '/registers.json'),
                        'individual original snapshot/register envelopes')
                r = registers(item['registers'], engine)
                require(r['logical_ar'] == [r['physical_ar'][(4*r['windowbase']+i)%32] for i in range(16)],
                        'coherent physical/logical aliases')
                for region in item['regions']:
                    data = self.read(base + region['path'])
                    require(len(data) == region['bytes'] == region['captured_bytes'] and
                            sha(data) == region['sha256'], 'coherent raw region seal')
        for phase in PHASES:
            left, right = (self.snapshot(engine, phase) for engine in ('model', 'qemu'))
            require(registers(left['registers'], 'model') == registers(right['registers'], 'qemu'),
                    'coherent full paired register set')
            require([(x['start'], x['bytes'], x['sha256']) for x in left['regions']] ==
                    [(x['start'], x['bytes'], x['sha256']) for x in right['regions']],
                    'coherent full paired region set')
            for lrow, rrow in zip(left['regions'], right['regions']):
                require(self.read(self.prefix + 'model/' + lrow['path']) ==
                        self.read(self.prefix + 'qemu/' + rrow['path']), 'paired actual full bytes')
        data = self.read(self.prefix + 'qemu/host-interventions.jsonl')
        seal = self.case['qemu']['host_intervention_ledger']
        require(sha(data) == seal['sha256'] and len(data) == seal['bytes'] and
                len(self.ledger) == seal['lines'], 'coherent full ledger seal')
        self.snapshot_replies(False)
        return dict(paired_snapshots=11, qemu_snapshots=13, raw_seals=True,
                    full_paired_state=True, snapshot_replies=True,
                    pc_access_traces_untouched=True, not_a_semantic_acceptance=True)

    def preserve(self, control_root, baseline_manifest):
        current = tree_manifest(self.root)
        changed = {name for name in current if current[name] != baseline_manifest.get(name)}
        require(set(current) == set(baseline_manifest) and changed == set(self.before) and changed,
                'every changed member is tracked; no addition/deletion')
        delta = {}
        for name in sorted(changed):
            old, new = self.before[name], self.read(name)
            require(dict(bytes=len(old), sha256=sha(old)) == baseline_manifest[name],
                    'overlay before bytes match immutable baseline')
            atomic_write(control_root / 'before' / name, old)
            atomic_write(control_root / 'after' / name, new)
            delta[name] = dict(before=baseline_manifest[name], after=current[name])
        atomic_write(control_root / 'OVERLAY.json', json_bytes(dict(
            schema='hp1020-pages-copied-overlay-v1', control=self.name,
            reconstruction='Copy retained baseline-capture, then replace listed members with after/ bytes.',
            changed_members=delta, original_trace_kept=True, synthetic_not_execution=True,
            mutation_records=self.notes)))
        return delta


def wrong_first_page_witness(ev):
    ev.paired('pre-first-complete', ev.addresses['witness'] + 8864, b'\x80', b'\x00')
    ev.notes.append(dict(claim='First retained pixel differs from independent source at its actual completion boundary.'))


def wrong_second_page_output(ev):
    ev.paired('pre-second-output', ev.addresses['memory'] + 81936, b'\xa5', b'\xa4')
    ev.notes.append(dict(claim='Second original output allocation differs from independent page2 pixels.'))


def premature_first_page_completion(ev):
    ev.paired('pre-first-complete', ev.addresses['document'] + 13324, bytes(4), (4).to_bytes(4, 'big'))
    ev.notes.append(dict(claim='Rows declared completed before the actual first completion function executes.'))


def wrong_compact_io_address(ev):
    ev.paired('pre-first-output', ev.addresses['witness'] + 20, (0x220).to_bytes(4, 'big'), (0x22c).to_bytes(4, 'big'))
    ev.notes.append(dict(claim='Compact initial read row falsely names the packet-size word instead of endpoint control.'))


def omit_original_pjl_byte(ev):
    rows = [x for x in ev.case['model']['pages_api_events'] if x['kind'] == 'entry' and x['name'] == 'hp1020_image_output_feed']
    require(len(rows) == 16 and rows[0]['arguments'][2] == 64, 'exact original first64 PJL feed')
    before = copy.deepcopy(rows[0]);rows[0]['arguments'][2] = 63
    ev.notes.append(dict(kind='false-first-feed-length', original=before, changed=copy.deepcopy(rows[0]),
        claim='False by-value length skips an original PJL byte without altering sealed source or actual trace.'))


CONTROLS = (
    ('wrong-first-page-witness', wrong_first_page_witness,
     'ValueError: pre-first-complete: complete independent witness bytes'),
    ('wrong-second-page-output', wrong_second_page_output,
     'ValueError: pre-second-output: entire original output allocation, exact independently specified page'),
    ('premature-first-page-completion', premature_first_page_completion,
     'ValueError: pre-first-complete: original field ring_completed'),
    ('wrong-compact-io-address', wrong_compact_io_address,
     'ValueError: pre-first-output: complete independent witness bytes'),
    ('omitted-original-pjl-byte', omit_original_pjl_byte,
     'ValueError: actual unmodified original-generation input including all PJL/partial chunks'),
)


def run(args):
    original, repo, output = args.capture_root.resolve(), args.repo_root.resolve(), args.output_root.resolve()
    require(original.is_dir() and repo.is_dir(), 'existing complete accepted capture and repository')
    require(not output.exists() and output != original and original not in output.parents and
            output != repo and repo not in output.parents and output not in original.parents and
            output not in repo.parents, 'new output directory disjoint from capture and repository')
    originals = tree_manifest(original)
    report = json.loads((original / 'validation.json').read_bytes())
    require(report.get('status') == 'pass' and not any(k in report for k in
            ('error', 'source_seal_error', 'publication_error')), 'failed captures are never a control baseline')
    frozen = {}
    for name, expected in PINS.items():
        member = 'scripts/' + name
        data = (repo / member).read_bytes()
        require(sha(data) == expected == report['source_sha256'][member] and
                (original / 'source' / member).read_bytes() == data, 'exact original frozen checker dependency')
        frozen[name] = data
    output.mkdir()
    atomic_write(output / 'driver.py', Path(__file__).read_bytes())
    for name, data in frozen.items():
        atomic_write(output / 'checker' / name, data)
    atomic_write(output / 'original-members.json', json_bytes(originals))
    gate = load_gate(output / 'checker' / GATE)
    accepted, detail = gate.check_capture(original, source_root=repo)
    baseline_result = dict(accepted=accepted, detail=detail, capture=str(original), repo=str(repo),
                           gate_sha256=PINS[GATE], driver_sha256=sha(Path(__file__).read_bytes()))
    atomic_write(output / 'baseline-before.json', json_bytes(baseline_result))
    require(accepted, 'unchanged positive must pass before any evidence mutation: ' + str(detail))
    baseline = output / 'baseline-capture'
    shutil.copytree(original, baseline, copy_function=link_or_copy)
    require(tree_manifest(baseline) == originals, 'byte-exact retained immutable baseline')
    # Only neutral ELF symbol lookup after whole-baseline acceptance; these are
    # locations, not expectations read from runtime diagnostic fields.
    elf = gate.B.Elf((baseline / 'target/entry-usb.elf').read_bytes())
    addresses = {key: elf.symbol(name, size) for key, (name, size) in OBJECTS.items()}
    atomic_write(output / 'locations.json', json_bytes(addresses))
    results = []
    for name, mutate, expected in CONTROLS:
        folder = output / name
        folder.mkdir()
        result = dict(control=name, status='error', expected_error=expected,
                      synthetic_evidence_not_target_execution=True)
        evidence = None
        try:
            evidence = Evidence(baseline, folder / 'capture', name, addresses)
            mutate(evidence)
            evidence.sync()
            result['paired_envelope'] = evidence.envelope_check()
            result['changed_members'] = evidence.preserve(folder, originals)
            accepted_control, actual = gate.check_capture(evidence.root, source_root=repo)
            result['checker'] = dict(accepted=accepted_control, detail=actual)
            result['status'] = ('rejected-as-intended' if not accepted_control and
                                isinstance(actual, dict) and actual.get('error') == expected
                                else 'wrong-result-or-mechanism')
        except Exception as error:
            result['error'] = type(error).__name__ + ': ' + str(error)
            if evidence is not None:
                result['mutation_records'] = evidence.notes
                try:
                    result['changed_members'] = evidence.preserve(folder, originals)
                except Exception as partial:
                    result['preservation_error'] = type(partial).__name__ + ': ' + str(partial)
        atomic_write(folder / 'result.json', json_bytes(result))
        results.append(result)
        atomic_write(output / 'progress.json', json_bytes(results))
        print(name + ': ' + result['status'], flush=True)
    # A passing control count cannot hide source or baseline mutations.
    intact = tree_manifest(original) == originals and tree_manifest(baseline) == originals
    intact = intact and all((repo / 'scripts' / name).read_bytes() == data and
                            (output / 'checker' / name).read_bytes() == data for name, data in frozen.items())
    final_accepted, final_detail = gate.check_capture(original, source_root=repo)
    summary = dict(status='pass' if intact and final_accepted and
                   all(x['status'] == 'rejected-as-intended' for x in results) else 'fail',
                   count=len(results), controls=results, baseline_before=baseline_result,
                   baseline_after=dict(accepted=final_accepted, detail=final_detail),
                   original_and_retained_baseline_unchanged=intact, pins=PINS,
                   no_target_interpreter_qemu_build_or_hardware_execution=True,
                   original_pc_access_traces_and_source_target_tool_pins_unchanged=True)
    atomic_write(output / 'negative-controls.json', json_bytes(summary))
    return summary['status'] == 'pass'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('capture_root', type=Path)
    parser.add_argument('--repo-root', type=Path, required=True)
    parser.add_argument('--output-root', type=Path, required=True)
    args = parser.parse_args()
    try:
        passed = run(args)
    except Exception as error:
        print('STOP: ' + type(error).__name__ + ': ' + str(error), flush=True)
        raise SystemExit(2)
    raise SystemExit(0 if passed else 1)


if __name__ == '__main__':
    main()
