# Unexecuted original IN1 construction experiment

2026-10-05 lead draft, prepared during the real-host two-page full regression.
Only syntax parsing/source review has occurred; no original instruction or
validator from this draft has executed. Do not treat it as a passed experiment.

The immutable original-byte range and literals come from the separate bounded
stock-byte review. Enter after ENTRY; stop before the first publication-tail
instruction. The independent oracle writes only the first descriptor and current
pointer/remaining fields, preserving reserved/original/done bytes and all guards.
Both numeric source aliases (including an MMIO-shaped value) remain undereferenced.

Planned36 construction cases include64-byte boundaries, two fills/pointer shapes,
32-bit source addition wrap and a separate supplied512 cap. Four access controls
reject peripheral-shaped record/descriptor pointers before access. Ten excluded
PCs reject original entry, queue/cache, publication and IRQ paths before execution.
The observer retains full before/expected/after mutable memory, exact original
source/code, ordered access and executed-PC traces in fresh captures.

Neutral capture plumbing is copied from the established EP0 construction probe;
IN1 expected bytes/write PCs are separately transcribed, not imported from a model.
Execution must wait for the current full regression to finish. First preserve
the real-page checkpoint, then install/review this draft and execute sequentially.
All actual peripheral access, USB lifecycles, host receipt, mapping/cache/FIFO
settlement and physical printing remain outside this experiment.
