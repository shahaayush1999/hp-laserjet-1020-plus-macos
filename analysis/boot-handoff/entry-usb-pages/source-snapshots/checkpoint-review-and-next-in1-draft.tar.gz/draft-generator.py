from pathlib import Path
base = Path('scripts/validate-hp1020-usb-ep0-construction.py').read_text()
out = Path('/tmp/hp1020-in1-construction-draft-20261005')
out.mkdir(exist_ok=False)
header = '''#!/usr/bin/env python3
"""Guarded original bulk-IN1 arithmetic, never descriptor publication or USB.

Enter after the original ENTRY and stop before the publication tail. The normal
instruction bytes and all literal words stay original. Only CPU registers and
mutable RAM are supplied. No cache, queue, interrupt, controller or engine call
is executed. Neutral capture plumbing follows the existing EP0 construction
probe; the IN1 byte/write oracle is independently transcribed from original
instructions before execution. Zero-length arithmetic does not prove stock ZLPs.
"""
'''
imports = base[base.index('import ast\n'):base.index('STOCK_SHA =')].replace("OUT = ROOT/'analysis/usb-path/ep0-construction'", "OUT = ROOT/'analysis/usb-path/in1-construction'")
constants = '''STOCK_SHA = '2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d'
ENTRY, LIMIT = 0x1000899f, 0x10008b41
CODE = [(ENTRY,LIMIT)]
CODE_SHA = {(ENTRY,LIMIT): 'af1c30e9998c5abe000121111bebe7e4efc31d1543d361d5996056e0f47d8a34'}
ARENA, ARENA_SIZE = 0x22a00000, 0x1000
DESCRIPTOR, RECORD = ARENA+0x100, ARENA+0x300
DESC_CELL, CAP_CELL = 0x1001bc5c, 0x10021590
INITIAL_SP = STACK_TOP-0x100
EMPTY_FIXTURE = SimpleNamespace(path=None, execute_ranges=[])
LITERALS = {0x10005e50:CAP_CELL,0x10005e7c:DESC_CELL,
            0x10005e34:0x80000000,0x10005e80:0x08000000}
EXCLUDED = (0x1000899c, LIMIT, 0x10008b54, 0x10008b63, 0x10008b72,
            0x10008b78, 0x10008bac, 0x10008bcc, 0x100173c8, 0x10008208)
STORE_PCS = {
    'small_buffer':(0x10008a6b,0x10008a71,0x10008a77,0x10008a7a),
    'small_next':(0x10008a83,0x10008a86,0x10008a89,0x10008a8c),
    'small_status':(0x10008aa7,0x10008ab6,0x10008ac5,0x10008ad4),
    'capped_buffer':(0x100089c6,0x100089cc,0x100089d2,0x100089d5),
    'capped_status':(0x100089f0,0x100089ff,0x10008a0e,0x10008a1d),
    'capped_next':(0x10008a2b,0x10008a31,0x10008a37,0x10008a3a),
    'last_status':(0x10008b11,0x10008b20,0x10008b2f,0x10008b3e),
}

'''
helpers = base[base.index('def sha('):base.index('def case_specs(')]
cases = '''def case_specs():
    for seed in (0x31,0xcc):
        for pointer in (0x01234567,0xb3000400):
            for length in (0,1,63,64,65,128,129):
                yield dict(name=f'in1-n{length}-q64-p{pointer:08x}-s{seed:02x}',
                    seed=seed,length=length,pointer=pointer,cap=64,effect='descriptor')
        yield dict(name=f'in1-pointer-wrap-s{seed:02x}',seed=seed,length=65,
            pointer=0xfffffffc,cap=64,effect='descriptor')
        for length in (511,512,513):
            yield dict(name=f'in1-n{length}-q512-s{seed:02x}',seed=seed,
                length=length,pointer=0x91b2c3d0,cap=512,effect='descriptor')
        for mode,stop in (('record',0x100089a2),('descriptor',0x10008a6b)):
            yield dict(name=f'in1-mmio-{mode}-s{seed:02x}',seed=seed,length=1,
                pointer=0x01234567,cap=64,effect='none',reject_mmio=mode,stop=stop)


class ConstructionRAM(StopRAM):
    def __init__(self,program,case):
        self.recording,self.events,self.pc_trace = False,[],[]
        super().__init__(program,ENTRY,CODE.copy(),[(ARENA,ARENA_SIZE)])
        self.stop,self.case = case.get('stop',LIMIT),case
        for begin,end in self.write_ranges:
            self.put(begin,patterned(case['seed'],begin,end-begin))
        self.write(DESC_CELL,4,0xb3000034 if case.get('reject_mmio')=='descriptor' else DESCRIPTOR)
        self.write(CAP_CELL,4,case['cap'])
        self.write(RECORD,4,case['pointer'])
        self.write(RECORD+4,4,0x5973bda1)
        self.write(RECORD+8,4,case['length'])
        self.write(RECORD+12,4,0x2e4c6a89)
        self.registers = [(0x13579bdf+i*0x10203+case['seed']*0x01010101)&0xffffffff for i in range(16)]
        self.registers[0],self.registers[1] = STOP,INITIAL_SP
        self.registers[2] = 0xb3000000 if case.get('reject_mmio')=='record' else RECORD
        self.supplied_registers = self.registers.copy()

    def read(self,address,size):
        value = super().read(address,size)
        if self.recording:
            self.events.append(access(self.pc,'read',address,size,value))
        return value

    def write(self,address,size,value):
        self.span(address,size)
        super().write(address,size,value)
        if self.recording:
            self.events.append(access(self.pc,'write',address,size,value & ((1 << (8*size))-1)))

    def after_instruction(self,pc,nxt):
        self.pc_trace.append(pc)
        return super().after_instruction(pc,nxt)


'''
memhelpers=base[base.index('def memory_snapshot('):base.index('def expected_memory(')]
oracle='''def expected_memory(state,before):
    expected = {span:bytearray(data) for span,data in before.items()}
    writes = []
    def replace(address,data):
        found = [(a,b) for a,b in expected if a <= address and address+len(data) <= b]
        assert len(found)==1
        a,b=found[0]
        expected[a,b][address-a:address-a+len(data)] = data
    def word(pc,address,value):
        replace(address,struct.pack('>I',value))
        writes.append(access(pc,'write',address,4,value))
    def bytes4(key,offset,value):
        data=struct.pack('>I',value)
        replace(DESCRIPTOR+offset,data)
        for pc,index in zip(STORE_PCS[key],range(4)):
            writes.append(access(pc,'write',DESCRIPTOR+offset+index,1,data[index]))
    case=state.case
    if case['effect']=='descriptor':
        n,q,p=case['length'],case['cap'],case['pointer']
        # This literal oracle is independent of both execution engines. Neither
        # descriptor reserved word nor software original/done sentinels change.
        if n<=q:
            bytes4('small_buffer',8,(p+0x80000000)&0xffffffff)
            bytes4('small_next',12,0)
            bytes4('small_status',0,0x08000000|n)
            word(0x10008ad7,RECORD+8,0)
        else:
            bytes4('capped_buffer',8,(p+0x80000000)&0xffffffff)
            word(0x100089e0,RECORD,(p+q)&0xffffffff)
            bytes4('capped_status',0,q)
            bytes4('capped_next',12,DESCRIPTOR+16)
            word(0x10008a48,RECORD+8,n-q)
            bytes4('last_status',0,0x08000000|q)
    return {span:bytes(data) for span,data in expected.items()},writes


'''
execute = base[base.index('def qemu_memory_event('):base.index('def source_paths(')]
start=execute.index('        ram_inputs=dict(')
end=execute.index("    stem.with_suffix('.input.json')",start)
execute=execute[:start]+'''        ram_inputs=dict(descriptor_cpu=hex(DESCRIPTOR),descriptor_pointer_cell=hex(DESC_CELL),
            cap_cell=hex(CAP_CELL),cap=case['cap'],software_record=hex(RECORD),
            source_numeric_only=hex(case['pointer']),source_is_not_dereferenced=True))
'''+execute[end:]
execute=execute.replace('                runner.step()\n                if observed', '                retired_pc=state.pc\n                runner.step()\n                state.pc_trace.append(retired_pc)\n                if observed')
start=execute.index('    attempted =')
end=execute.index('        before_memory=',start)
execute=execute[:start]+'''    def span_bytes(memory,address,size):
        matches=[(a,b) for a,b in memory if a<=address and address+size<=b]
        assert len(matches)==1
        a,b=matches[0]
        return memory[a,b][address-a:address-a+size]
    result = dict(status='captured_unchecked',engine=engine,entry=hex(ENTRY),
        stop_before=hex(state.stop),failure=failure,registers=[hex(x) for x in state.registers],
        descriptor_hex=state.bytes_at(DESCRIPTOR,16).hex(),
        expected_descriptor_hex=span_bytes(expected,DESCRIPTOR,16).hex(),
        record_hex=state.bytes_at(RECORD,16).hex(),
        expected_record_hex=span_bytes(expected,RECORD,16).hex(),
'''+execute[end:]
execute=execute.replace("original_instructions_retired=[hex(pc) for pc in retired]", "original_instructions_retired=[hex(pc) for pc in state.pc_trace]")
start=execute.index("    if case['effect'] == 'descriptor':")
end=execute.index('    for begin,end in state.code_ranges:',start)
execute=execute[:start]+'''    # Exact read admission: the numeric source is never touched; only original
    # literal words, supplied cells, record and first descriptor may be read.
    read_spans=[(p,p+4) for p in LITERALS]+[(DESC_CELL,DESC_CELL+4),
        (CAP_CELL,CAP_CELL+4),(RECORD,RECORD+16),(DESCRIPTOR,DESCRIPTOR+16)]
    assert all(any(a<=int(e['address'],16) and int(e['address'],16)+e['size']<=b
        for a,b in read_spans) for e in state.events if e['kind']=='read')
    assert len(state.pc_trace)==len(set(state.pc_trace)), 'unexpected loop or second descriptor'
    assert not set(state.pc_trace)&set(EXCLUDED)
    assert state.registers[0:2]==state.supplied_registers[0:2], 'unexpected call or stack use'
'''+execute[end:]
execute=execute.replace("        pointer_oracle_checked=case['effect']=='pointer',original_code_unchanged=True,", "        source_never_dereferenced=True,original_code_unchanged=True,")
sourcepaths=base[base.index('def source_paths('):base.index('def audit(')]
audit='''def audit(program,blob):
    assert sha(blob)==STOCK_SHA
    sections,_=properties(blob)
    raw=section_bytes(blob,sections,ENTRY,LIMIT-ENTRY)
    assert sha(raw)==CODE_SHA[ENTRY,LIMIT]
    allowed={'l32i','l8ui','s32i','s8i','l32r','movi','mov','add','addi','sub',
             'or','slli','extui','memw','blt','bge','beqz','bnei','j'}
    pc,instructions=ENTRY,{}
    while pc<LIMIT:
        op,args,encoded=program.instruction(pc)
        assert op.removesuffix('.n') in allowed,(hex(pc),op)
        assert pc+len(encoded)<=LIMIT
        assert encoded==section_bytes(blob,sections,pc,len(encoded))
        instructions[hex(pc)]=dict(op=op,args=args,bytes=encoded.hex())
        pc+=len(encoded)
    assert pc==LIMIT
    original=Machine(program)
    for pc,value in LITERALS.items():
        assert original.read(pc,4)==value
    assert original.read(DESC_CELL,4)==0x900216d0
    return dict(ranges=[dict(begin=hex(ENTRY),end=hex(LIMIT),bytes=raw.hex(),sha256=sha(raw))],
        instructions=instructions,literals={hex(k):hex(v) for k,v in LITERALS.items()},
        original_descriptor_pointer='0x900216d0',entry_after_original_ENTRY=True)


'''
reject=base[base.index('def reject_excluded('):base.index('def main(')]
reject=reject.replace("case = dict(name='excluded-code',kind='in-zero',seed=0xcc,length=0,pointer=0x11223340,effect='none')", "case = dict(name='excluded-code',seed=0xcc,length=0,pointer=0x01234567,cap=64,effect='none')")
reject=reject.replace('state.code_ranges = ZERO_CODE+SMALL_CODE+OUT_CODE', 'state.code_ranges = CODE.copy()').replace('q.reset_cpu(ZERO_CODE[0][0])','q.reset_cpu(ENTRY)')
main=base[base.index('def main('):]
main=main.replace("prefix='hp1020-ep0-construction-'", "prefix='hp1020-in1-construction-'").replace('EP0 construction','IN1 construction')
main=main.replace("        version = q.version", "        version = q.version\n        qemu_identity = dict(path=q.binary,sha256=sha(Path(q.binary).read_bytes()))")
main=main.replace("                        'pointer_register_a8','before_memory','expected_memory',", "                        'record_hex','expected_record_hex','before_memory','expected_memory',")
start=main.index('    counts = dict(')
end=main.index("    text = json.dumps(report",start)
main=main[:start]+'''    counts = dict(construction=sum(c['input']['effect']=='descriptor' for c in results),
                  mmio_rejections=sum(bool(c['input'].get('reject_mmio')) for c in results))
    assert counts==dict(construction=36,mmio_rejections=4)
    assert len(results)==40 and len(excluded)==10
    report = dict(status='pass',cases=results,counts=counts,excluded_code_controls=excluded,
        source_sha256=sources,source_origins=origins,stock_elf_sha256=STOCK_SHA,
        qemu_version=version,qemu_identity=qemu_identity,original_byte_audit=evidence,
        private_literal_redirects=[],supplied_services=[],completed_bulk_in_transfers=0,
        actual_peripheral_accesses=0,controller_quiescence_established=False,
        original_entry_executed=False,
        scope='Original IN1 arithmetic cut: independent BE descriptor and record oracle, exact ordered writes/reads/PCs, every mutable RAM byte and guards agree in the interpreter and QEMU.',
        limits='Registers, pointer cells, positive cap and guarded RAM are supplied. Original ENTRY, queue, source/cache publication, controller accesses, interrupt completion, terminal external memory access, FIFO settlement and host receipt are excluded. Numeric source aliases are never dereferenced. Zero-length cases prove only construction arithmetic; stock queue selection ignores zero remaining. This is no completed USB, document or physical print lifecycle.')
'''+main[end:]
start=main.index("    markdown =")
end=main.index("    (capture/'report.json')",start)
main=main[:start]+'''    markdown = ('# Original bulk-IN1 construction cut\\n\\n'+report['scope']+'\\n\\n'+
        f'{counts["construction"]} construction profiles; {counts["mmio_rejections"]} access-gate controls; '
        f'{len(excluded)} excluded PCs. Counts are per engine and establish no USB lifecycle.\\n\\n'+report['limits']+'\\n')
'''+main[end:]
(out/'validate-hp1020-usb-in1-construction.py').write_text(header+imports+constants+helpers+cases+memhelpers+oracle+execute+sourcepaths+audit+reject+main)
print(out)
