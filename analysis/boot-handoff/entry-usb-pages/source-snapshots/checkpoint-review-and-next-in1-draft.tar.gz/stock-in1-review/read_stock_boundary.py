#!/usr/bin/env python3
"""Static read-only ELF/annotation review. No instruction execution or validators.

Writes only this /tmp directory. Objdump is the already present repository
research tool; this script builds/installs nothing and never accesses USB.
"""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
OUT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'scripts'))
from hp1020_xtensa_properties import properties, section_bytes

ELF = ROOT / 'analysis/sihp1020.elf'
OBJDUMP = Path('/tmp/hp1020-xtensa-manual-systemz/bin/xtensa-fsf-elf-objdump')
blob = ELF.read_bytes()
digest = lambda b: hashlib.sha256(b).hexdigest()
assert digest(blob) == '2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d'
sections, tables = properties(blob)
raw = lambda a, n: section_bytes(blob, sections, a, n)

# Decode from the ORIGINAL annotation boundary, never from a guessed mid-op PC.
ranges = [
    ('registration', 0x10007c00, 0x10007c5c),
    ('callback-vtable', 0x10008034, 0x1000807c),
    ('send-wrapper', 0x100081f4, 0x10008208),
    ('irq-in-selection', 0x1000837e, 0x100084b7),
    ('in1-builder', 0x1000899c, 0x10008b78),
    ('in1-construction-cut', 0x1000899f, 0x10008b41),
    ('in1-completed-list-drain', 0x10008b78, 0x10008bac),
    ('in1-submit-queue', 0x10008bac, 0x10008c24),
    ('startup-in1', 0x10008ff0, 0x100092f7),
    ('pjl-send', 0x1000cd44, 0x1000cd62),
    ('cache-helper-call-boundary-only', 0x100173c8, 0x100173e6),
]
all_rows = {}
annotations = []
for at, count in tables['.xt.insn']:
    if not any(at < end and start < at + count for _, start, end in ranges):
        continue
    annotations.append([hex(at), count])
    text = subprocess.check_output([str(OBJDUMP), '-d', f'--start-address={at}',
                                   f'--stop-address={at+count}', str(ELF)], text=True)
    pc = at
    for line in text.splitlines():
        m = re.match(r'\s*([0-9a-f]{8}):\s+([0-9a-f]{4,6})\s+(\S+)\s*(.*)', line)
        if not m:
            continue
        address = int(m[1], 16)
        data = bytes.fromhex(m[2])
        assert address == pc and data == raw(address, len(data)), line
        all_rows[address] = {'address': hex(address), 'bytes': data.hex(),
                             'op': m[3], 'args': m[4].strip(), 'line': line}
        pc += len(data)
    assert pc == at + count, (hex(at), count, hex(pc))

manifest = {'method': 'Static byte-checked annotation-bounded disassembly only; no target execution',
            'stock_elf': str(ELF), 'stock_sha256': digest(blob),
            'objdump': str(OBJDUMP), 'objdump_sha256': digest(OBJDUMP.read_bytes()),
            'property_helper_sha256': digest((ROOT / 'scripts/hp1020_xtensa_properties.py').read_bytes()),
            'annotations_decoded': annotations, 'regions': [], 'literals': [], 'sources': []}
for name, start, end in ranges:
    # The region bounds must be existing instruction boundaries. Last boundary
    # can coincide with the end of an annotated region.
    assert start in all_rows, hex(start)
    assert end in all_rows or any(end == a+n for a,n in tables['.xt.insn']), hex(end)
    rows = [v for a,v in all_rows.items() if start <= a < end]
    (OUT / f'{name}.txt').write_text('\n'.join(row['line'] for row in rows) + '\n')
    (OUT / f'{name}.bin').write_bytes(raw(start, end-start))
    manifest['regions'].append({'name': name, 'start': hex(start), 'end_exclusive': hex(end),
                                'sha256': digest(raw(start, end-start)), 'rows': len(rows)})

literal_addrs = [0x10005dd8, 0x10005de8, 0x10005e00, 0x10005e04, 0x10005e0c,
                 0x10005e10, 0x10005e14, 0x10005e34, 0x10005e50, 0x10005e7c,
                 0x10005e80, 0x10005e84, 0x10005e88, 0x10005e8c, 0x10005ed8,
                 0x10005edc, 0x10005ee0, 0x10005efc, 0x10005f00, 0x100060bc,
                 0x1001bc5c]
for at in literal_addrs:
    manifest['literals'].append({'address': hex(at), 'bytes': raw(at,4).hex(),
                                'value_be32': hex(int.from_bytes(raw(at,4),'big'))})
for name, at, count in [('stock-config-hs',0x100034b0,32), ('stock-config-fs',0x100034d0,32)]:
    data = raw(at,count)
    (OUT / f'{name}.bin').write_bytes(data)
    manifest['regions'].append({'name':name,'start':hex(at),'end_exclusive':hex(at+count),
                               'sha256':digest(data),'bytes':data.hex(' ')})
for path in [
    'analysis/usb-path/controller-reference/linux-v6.12/amd5536udc.h',
    'analysis/usb-path/controller-reference/linux-v6.12/snps_udc_core.c',
    'analysis/usb-path/controller-reference/linux-v6.12/provenance.json',
    'analysis/usb-path/controller-reference/manuals/README.md',
    'analysis/usb-path/controller-reference/manuals/provenance.json',
    'open-firmware/udc-ep0/hp1020_udc_ep0.c',
    'open-firmware/udc-ep0/hp1020_udc_ep0.h',
]:
    manifest['sources'].append({'path':path,'sha256':digest((ROOT/path).read_bytes())})
(OUT/'evidence.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'regions':len(manifest['regions']),'literals':len(manifest['literals']),
                  'instruction_regions':len(ranges),'output':str(OUT)},indent=2))
