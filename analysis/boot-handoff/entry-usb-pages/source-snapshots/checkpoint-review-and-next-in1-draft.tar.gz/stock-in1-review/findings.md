# Smallest justified bulk-IN/backchannel boundary

2026-10-05, bounded static review requested by the lead. No repository edits,
firmware execution, build, validator, USB/device operation, or installed-printing
change occurred. The existing macOS/HP path remains separate. This investigation
does not establish a working replacement or host receipt of any response.

`read_stock_boundary.py` reads the original ELF and decodes selected complete
`.xt.insn` annotation ranges with the already available objdump. It checks every
decoded instruction's address/bytes against the ELF before retaining the chosen
regions. `evidence.json` pins the ELF, reader dependency, objdump, thirteen code
regions, descriptor bytes, 21 literal words and reusable source references. The
ELF SHA256 is `2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d`.
The `.txt` and `.bin` files are read evidence, not execution captures.

## Result and reusable boundary

A one-packet, one-owner bulk-IN1 path is justified for the existing full-speed
64-byte software profile. It can reuse the established BE normal-descriptor
encoding, independent DMA span and staging-buffer rules, immutable original
cookie identity, explicit publication/acquisition hooks, retained-fault policy
and externally supplied settlement gates. Existing `udc-ep0` is useful source
material for this mechanism, but its endpoint/control-epoch allocator and status
stage semantics are specific to EP0. It is not an IN1 implementation.

The new owner needs to reserve a real bulk-IN request, retain its original cookie
and response bytes, publish a separate IN1 descriptor, and handle its own pending
completion/cancellation through adapter service/reset. The lead is reviewing
that adapter seam separately. Do not copy the original heap/list internals or
the original descriptor's reserved-byte retention as a requirement.

Keep three events distinct: release of external descriptor/source memory,
FIFO/USB transfer completion, and application response delivery to the host.
Original code and Linux have early DMA-oriented completion conventions. They
do not provide a host-visible PJL success observation. An offline supplied-RAM
test can verify bytes and ownership at the new boundary without claiming the
last two events.

## Original endpoint and descriptor facts

Both original 32-byte configuration descriptors expose interface 0,
class/subclass/protocol 07/01/02 and bulk OUT 01 followed by bulk IN **81**.
The exact IN descriptors are:

* `0x100034c9`: `07 05 81 02 00 02 00` (512-byte maximum packet).
* `0x100034e9`: `07 05 81 02 40 00 00` (64-byte maximum packet).

The original IN1 descriptor builder is `[0x1000899c,0x10008b78)`, SHA256
`8aaafd9f2211e3dcc41bc596483b6d74b4a3cc9bc012028d471bcecb3440c9ba`.
Its pointer literal `0x10005e7c -> 0x1001bc5c` references a pointer cell whose
file-backed value is `0x900216d0`. Its publication literal
`0x10005e84 -> 0xb3000034` matches classic Synopsys IN1 DESPTR; its control
literal `0x10005e88 -> 0xb3000020` matches IN1 control. Endpoint interrupt
mask bit 1 is `0x00000002`, not OUT1's `0x00020000`.

Let Q be the supplied positive stock batching word at `0x10021590`, P the
current source pointer at software-record+0, and N its remaining length at +8.
For normal nonnegative lengths, the instruction-derived construction is:

| Field | N <= Q | N > Q |
|---|---|---|
| Descriptor +0, BE32 | `0x08000000 | N` | `0x08000000 | Q` |
| Descriptor +4..7 | Preserved, not written | Preserved, not written |
| Descriptor +8, BE32 | `(P + 0x80000000) mod 2^32` | Same |
| Descriptor +12, BE32 | 0 | descriptor base +16 |
| Software current pointer +0 | Unchanged | P+Q |
| Software remaining +8 | 0 | N-Q |
| Original pointer +4 / done +12 | Unchanged | Unchanged |

The branch at `0x10008a4e` tests a8 for zero **after** its increment from 0 to 1.
Thus the capped branch builds one descriptor and then ORs L into that first
record. A nonzero next pointer does not establish a multi-descriptor transfer.
The last flag makes it the terminal record under the referenced family rule.

Q is loaded via `0x10005e50 -> 0x10021590`. Startup's cold-wrapper branch writes
512 (`0x100090f4..0x1000911c`); the other branch reads the existing IN1 max-packet
register `0xb300002c` into Q (`0x100090fd..0x10009108`). This is inherited
controller state in that branch, not a measured current packet mode. Q is also
used for OUT1 programming. The new restricted profile should require its own
explicit MPS64/mode facts rather than inheriting this RAM word or alias mapping.

The pinned family header defines normal descriptors as 16 bytes: status,
reserved word, buffer pointer, next pointer (`amd5536udc.h:462` onward).
IN TXBYTES occupies low16, L is bit27, TX status is bits29:28 and buffer owner
is bits31:30: HOST_READY=0, DMA_BUSY=1, DMA_DONE=2, HOST_BUSY=3
(`amd5536udc.h:313..325`). For bounded N<=64, the original initial status has
owner0, TX0 and L1. Low16 is a programmed transmit length; it is not proof of
host-delivered bytes.

## Submission, completion and software ownership

The old `usb-bulk-callbacks-model.md` label for **0x10008bac** as a receive
completion/queue callback is misleading. It is the USB **send/queue** callback:

1. `0x10008bb9` obtains a semaphore with caller timeout. Failure returns 0.
2. `0x10008bc4..0x10008bcc` passes caller source and length to `0x100173c8`.
   Original helper bytes `[0x100173c8,0x100173e6)` decode `dhwb` stepping 16
   bytes and `dsync`; this is intended cache publication, not observed physical
   coherence. The cache helper was inspected only and remains outside the RAM
   construction experiment.
3. `0x10008bcf` retires completed queue heads; `0x10008bdc` allocates a 32-byte
   node. Bytes at `0x10008be1..0x10008bf2` set next=0, node+12=node+16 and an
   inner record `{current_source, original_source, remaining, done=0}`. There is
   no source copy here: the original source allocation remains retained.
4. `0x10008bf8` appends the node to list `0x10022740`; `0x10008c10` clears bit1
   in endpoint interrupt mask `0xb3000418`. The routine marks software-active
   state when idle, releases the semaphore and returns the requested length at
   `0x10008c1f`. That return is queue acceptance, not USB delivery.

This send direction is independently anchored by callback wiring:

* Startup loads `0x10005f00 -> 0x10008bac` and installs it in registration
  argument word3 (`0x100091db/0x100091e0`), then calls `0x10007c00`.
* Registration writes that argument to transport-record+8 at `0x10007c33`.
* Vtable initialization installs `0x100081f4` at transport-record+16
  (`0x10008072/0x10008077`). Wrapper `0x100081f4` calls record+8 with source,
  length and timeout200.
* `0x1000cd44` gets strlen(response), then calls current transport-object+16.
  This is a compatible PJL-to-USB write chain. This bounded review does not
  establish that runtime pointer `0x10023868` always selects the USB record.
  That internal mapping need not be replicated by the replacement.

For a pending IN token/status snapshot (`IN` bit6), the stock ISR chooses lane
mask2 and, if active byte `0x1001bc6d` is clear, walks the list for a record with
nonzero remaining (`0x1000840e..0x10008436`). It calls builder `0x1000899c` at
`0x100083d4` and sets active at `0x100083da`.

The builder's publication tail is outside the proposed safe cut:

* `0x10008b54`: writes descriptor pointer to `0xb3000034`.
* `0x10008b63`: clears bit1 in `0xb3000418`.
* `0x10008b72`: ORs8 (family Poll Demand) into `0xb3000020`.

On saved `TDC` bit10 (`0x400`), the ISR acknowledges it and handles lane2
separately (`0x10008446..0x100084a6`): only when active is set does it clear
active, scan for an inner record with remaining=0/done=0, mark done=1, and mask
IN1 if that is the final node. It does **not** read descriptor owner, TX status
or a completed TX count in this branch. Descriptor construction has already
reduced remaining before TDC. Error bits HE/BNA are acknowledged earlier from
the same snapshot without skipping the later IN/TDC branches. None of this is
an immutable, original-cookie-tagged success record.

`0x10008b78` later frees each consecutive done queue head's retained ORIGINAL
source (+4), pops the node and frees the node. This distinguishes pointer/length
bookkeeping, DMA completion notification and software memory lifetime.

The queue selector rejects remaining=0, so constructing a zero-length descriptor
in isolation does not prove stock emits a ZLP. No automatic extra ZLP after an
exact-Q final chunk is present in these inspected roots.

## Exact safe next stock construction experiment

Use **entry 0x1000899f**, after ENTRY, and **stop 0x10008b41**, before the
publication tail. Exact range SHA256:
`af1c30e9998c5abe000121111bebe7e4efc31d1543d361d5996056e0f47d8a34`.
All instructions in this cut are standard integer operations, RAM loads/stores,
branches and memw; there are no calls, cache operations or peripheral accesses.

Supply only:

* Logical a2 -> aligned guarded 16-byte software record. Fields +0=current
  numerical source, +4=retained original pointer sentinel, +8=N, +12=done
  sentinel. Neither source pointer is dereferenced by this cut.
* Original `0x1001bc5c` pointer cell -> guarded, aligned 16-byte descriptor.
* Original word `0x10021590` -> Q (64 initially; optional separate512 cases).
* Guarded RAM/fills and test-engine CPU setup. The whole-record pointer cells
  and arena are supplied, not recovered hardware state. a3..a10 and SAR are
  initialized by reached instructions as needed; a1 is not used inside the cut.

Keep original literal words `0x10005e34=0x80000000` and
`0x10005e80=0x08000000` unchanged. Check full guarded memory, preserved descriptor
reserved word and owner-record +4/+12, source non-dereference, and exact stop.
Useful independent cases: N=0/1/63/64/65/128/129 with Q64, two fills; Q512
boundary cases are separate. N=0 is only an arithmetic/construction case.
The externally selected valid-length range must exclude negative/signed-invalid
inputs; stock does not sanitize them here. Add terminal-address rejection if
the test executor could otherwise cross the publication cut. No test should
redirect or execute publication merely to simplify its endpoint.

## Reuse versus exact unresolved pieces

Reuse the EP0 IN encoding/staging/immutable-cookie discipline in
`open-firmware/udc-ep0/hp1020_udc_ep0.c:108..202`: explicit16-byte descriptor,
owned64-byte staging, CPU/DMA addresses supplied separately, bounded copy after
admission, one-time exposure, retained failures, and release only after current
identity and externally justified terminal memory access. Its conservative
owner2/TX0/L1 completion policy is a replacement choice, stricter than this
stock ISR. Its separately supplied `in_actual` already avoids treating low16
as self-validating success evidence. Do not transplant EP0 status callbacks or
assume control-generation identity is the bulk identity.

Pinned Linux's data-IN ISR (`snps_udc_core.c:2282..2332`) completes on TDC and
sets actual=requested; its purported last-descriptor completion walk
(`:994..1002`) only checks L/next. These are API conventions. The existing
primary-manual review in `controller-reference/manuals/README.md:73..99`
records TDC as memory-to-FIFO, with FIFO retaining data for USB retries. Sony
bulk-IN flow p1222 steps5..8 explicitly puts TDC before IN/DATA/ACK. This review
did not re-download manuals; URLs/revisions/PDF hashes remain in the pinned
provenance. Do not import newer Sony XFERDONE/TXEMPTY bits into HP.

Open questions that matter to a usable owner:

1. HP's actual current IN DMA mode, physical descriptor ownership updates,
   TX-status semantics and valid packet-count meaning. Static family agreement
   and arithmetic do not establish these.
2. CPU/DMA address mapping and aliases, cache-line/visibility ordering,
   source/descriptor terminal access, and stale-event identity. The original
   +0x80000000 arithmetic and cache helper are evidence of intent only.
3. Exact mapping from a physical TDC/fault/FIFO observation into TinyUSB's
   bulk completion contract, including safe staging reuse while FIFO retries
   persist. A supplied software completion may advance an owner; it must not
   claim host receipt of a PJL response.
4. Cancellation/reset/disconnect/configuration reuse must settle old IN
   descriptors, payloads, pending callbacks and FIFO/toggle/halt state. An old
   TDC snapshot, software done word or queue drain cannot produce that promise.
5. Bounded response packetization, backpressure and message termination. A
   first reply shorter than64 avoids inferring exact-multiple/ZLP policy from
   the stock roots; larger/multiple replies need an explicit contract and tests.
6. PJL parsing/response content and useful printer-status provenance are
   separate work. Completing an IN packet owner does not make either truthful.

No physical blocker is needed for the next guarded construction test or bounded
software-owner implementation. Hardware evidence is still required before a
physical DCD can turn the external promises into observations.
