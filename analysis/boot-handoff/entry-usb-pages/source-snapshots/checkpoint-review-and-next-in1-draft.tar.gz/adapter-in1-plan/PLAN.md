# Next practical boundary: bulk-IN/backchannel

2026-10-05 lead source review; no new implementation or execution. Current
production sources remain frozen during the real-page full regression.
One independent reviewer completed the original IN1 byte/control review in
/tmp/hp1020-bulk-in-boundary-20261005; this lead review instead concerns current
reusable C integration. Do not count
this proposal as a tested feature or a physical status/USB result.

## Confirmed current software gap

The programming layer opens OUT1/IN1 with MPS64, but the adapter has only three
owners (EP0 OUT, EP0 IN, bulk OUT). owner_for cannot bind IN1 and driver_xfer
explicitly rejects a non-OUT endpoint. No bulk-IN message can currently travel
through this adapter. Its TRANSPORT_RESET promise mentions bulk IN, but has no
active IN owner to verify. EP0 status/ID replies are a different path.

The next useful original-code experiment is a bounded IN1 descriptor-construction
slice before its publication tail, with all cache, queue and peripheral access
excluded. Pin independent source arithmetic/byte expectations before execution.
Retain actual reserved bytes rather than copying the EP0 zeroing assumption.
Use asymmetric addresses and fills and lengths around one-packet and batch caps.
Supplied pointer arithmetic is not a proven CPU/DMA mapping. A descriptor or TDC
is not by itself host acknowledgement or whole-response delivery.

## Proposed implementation direction, not an accepted public API

After that evidence, add one optional bounded bulk-IN packet at a time through
the real TinyUSB transfer path. Reuse its endpoint claim/BUSY/callback handling,
original by-value cookies, separate service drainage and explicit cancellation.
Do not clone HP queues or add an RTOS. A caller-owned immutable response and
separate stationary64-byte DMA staging can follow the existing EP0 pattern;
application message formatting and multi-packet framing remain separate.
Zero-length packets must be explicit application choices, never implicit EOF.

A fourth owner needs real changes to owner_for, bind, complete, packet_fault,
deliver and class callbacks. Audit every bulk predicate: OUT reservations must
not be confused with IN results, while reset, programming cleanup and endpoint
reselection must retain/drain both directions. Current no_owners helpers in
udc-program and udc-publish explicitly enumerate only three records. Cancelling
an IN request must keep its original bytes/cookie until actual settlement and
queued-event drainage; a late SUCCESS may release ownership without becoming a
new-generation application success. A rejected submission after binding still
owns the buffer. Neither new SETUP nor a timeout proves settlement.

The final API must state exactly when the application can reuse its original
response buffer, how it obtains the original result, and how a result awaiting
consumption interacts with reset. Prefer a polled completion record over a
reentrant callback. Preserve successful send versus physical host acknowledgement
as distinct facts. Do not infer actual IN byte count from descriptor low16.

## Design issues to settle before implementation

Current fence advances the transport epoch even for document errors and blocks
input globally. Define which status responses may still be sent while input is
stopped, instead of assuming every input error makes status unavailable. The
current synchronous output progress callback cannot reenter adapter service;
long engine waits therefore need a future cooperative progress design if status
must remain responsive. These are concrete integration questions, not proof that
offline progress is impossible. First bound the healthy packet path and retained
reset/error ownership, without claiming full live printer status support.

Existing entry gates pin exact linked images and hand-derived object layouts.
Any production change requires fresh admission/layout/stack review and complete
execution of affected profiles, preserving previous source/capture snapshots.
Do not preserve old addresses artificially or edit report hashes. No production
change is included in the current real-page checkpoint.
