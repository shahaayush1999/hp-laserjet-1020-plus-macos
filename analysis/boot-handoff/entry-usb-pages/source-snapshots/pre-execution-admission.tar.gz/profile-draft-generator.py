from pathlib import Path
import hashlib, json, shutil
root=Path.cwd(); old=root/'open-firmware/entry-usb-test'; new=root/'open-firmware/entry-usb-pages-test'
new.mkdir(exist_ok=True)
def replace(s,a,b,n=1):
    assert s.count(a)==n,(a,s.count(a),n)
    return s.replace(a,b)
for name in ('startup.S','runtime.ld','hp1020_usb_runtime_layout.c','layout-objects.tsv'):
    assert not (new/name).exists();shutil.copyfile(old/name,new/name)
s=(old/'hp1020_usb_runtime_contract.h').read_text()
s=replace(s,'Authored as an unexecuted public-contract draft on 2026-10-03.','Real two-page public contract, drafted before execution on 2026-10-05.')
for a,b in [('VERSION 1u','VERSION 3u'),('INPUT_BYTES 352u','INPUT_BYTES 967u'),('DATA_PACKETS 12u','DATA_PACKETS 16u'),('BULK_PACKETS 13u','BULK_PACKETS 17u'),('BINDS 14u','BINDS 18u'),('IO_ROWS 240u','IO_ROWS 308u'),('RANGE_ROWS 65u','RANGE_ROWS 85u'),('PIXEL_BYTES 64u','PIXEL_BYTES 192u'),('DOCUMENT_EVENTS 2u','DOCUMENT_EVENTS 1u')]:s=replace(s,a,b)
s=replace(s,'scope0\n * means configuration programming; scope1..13 means that supplied bulk event.\n * A scope is a log label, never a replacement transfer/ingress identity.','The row index is its immutable ordinal minus one. Configuration and\n * bulk scopes are independently reconstructed from the complete ordered calls;\n * no log field is a production transfer/ingress identity.')
s=replace(s,'uint32_t scope, ordinal, kind, argument, value, outcome;','uint32_t kind, argument, value, outcome;')
begin=s.index('    uint8_t head_guard[16];');end=s.index('\n};',begin)
s=s[:begin]+'''    uint8_t head_guard[16];                                      /* +0 */
    struct hp1020_usb_runtime_io_row io[308];                     /* +16 */
    uint8_t io_guard[16];                                        /* +4944 */
    struct hp1020_usb_runtime_range_row ranges[85];               /* +4960 */
    uint8_t range_padding[12], range_guard[16];                   /* +8020,+8032 */
    struct hp1020_usb_runtime_bind_row binds[18];                 /* +8048 */
    uint8_t bind_padding[8], bind_guard[16];                      /* +8696,+8704 */
    struct hp1020_usb_runtime_device_images device;              /* +8720 */
    uint8_t pixels[192];                                         /* +8864 */
    struct hp1020_usb_runtime_document_row documents[1];          /* +9056 */
    uint8_t reserved[140];                                       /* +9076 */'''+s[end:]
s=replace(s,'io_row) == 24','io_row) == 16')
for a,b in [('ranges) == 5792','ranges) == 4960'),('binds) == 8160','binds) == 8048'),('device) == 8688','device) == 8720'),('pixels) == 8832','pixels) == 8864'),('documents) == 8896','documents) == 9056'),('reserved) == 8936','reserved) == 9076')]:s=replace(s,a,b)
(new/'hp1020_usb_runtime_contract.h').write_text(s)
s=(old/'layout-fields.tsv').read_text()
for a,b in [('io\t16\t5760','io\t16\t4928'),('ranges\t5792\t2340','ranges\t4960\t3060'),('binds\t8160\t504','binds\t8048\t648'),('device\t8688\t144','device\t8720\t144'),('pixels\t8832\t64','pixels\t8864\t192'),('documents\t8896\t40','documents\t9056\t20')]:s=replace(s,a,b)
(new/'layout-fields.tsv').write_text(s)
(new/'CONTRACT.md').write_text('''# Continuous full real-host two-page RAM contract

Drafted 2026-10-05 before target build or execution. This is a separate offline
profile; no upload, physical controller/cache/engine behavior or printing is
implemented or established. It keeps every production C source, full buffer,
startup, linker, RAM/code cap and stack unchanged from the healthy entry profile.

The retained first host job is967 bytes, SHA256
`8ccf8bc1391e9025e3bd0a196dd155a04b967271bbb2a896bfd185453c0ed669`.
Unchanged vendored foo2zjs encodes literal128x4 and256x4 pages in one invocation.
All268 prefix and27 suffix PJL bytes, including the actual timestamp, are retained.
The full original JBIG decoder independently recovered exact64+128 source pixels.
Framing consumption does not implement responses to the included PJL commands.
No geometry/header rewrite, input truncation or timestamp normalization is allowed.

One entry owns initialization/CPU/stack/BSS. Initial reset/configuration, original
EP0 status completion and three separately supplied recovery promises establish
G2. The967 bytes enter in16 consecutive real receive packets (fifteen64, then7),
without a close, reset or special boundary between pages. At their actual output
callback entries require the independent first/second page plan, ring contents,
full original state and accepted/completed history. One END_DOC event is(2,1,0,2),
then the remaining raw suffix is consumed. At the sole close a seventeenth eager
OUT is still owned. An explicit supplied SUCCESS ZLP settles that owner, then
next service, empty pump, sole finish and own park. No host calls/reset/repair.

Two ordinary CPU paint cases. Natural stops: after-normalization, pre-c,
pre-first-output, pre-first-complete, pre-second-output, pre-document-event,
pre-close, pre-final-service, pre-finish, park. The first completion stop is the
actual ring-complete entry after acceptance. It separates two occurrences of the
same output function without a hidden skip or debugger single-step.

The target32 public table is manually derived before build:16 objects101 fields,
layout header(0x4850554c,3,457,16,101). Provider204 bytes remains unchanged.
Evidence stays9216 bytes/cap10176:308 four-word I/O rows,85 original nine-word
range rows,18 original nine-word binds,144 device bytes,192 exact pixels and one
20-byte event. Every I/O ordinal is its array index+1 and scope follows the full
independently reconstructed schedule; no event is discarded or hashed away.
Final308 I/O=19 initial+17*17,85 ranges=17*5,18 binds=1 status+17 bulk;
before-close305 I/O and82 ranges leave the final acquisition pending.
Header/table comments state the exact offsets and guards; unused bytes stayzero.

A new whole-linked audit, independent callback/stack review and exact ELF pin
must precede either CPU engine. Old stack bounds do not transfer automatically.
Admission requires full paired RAM/CPU snapshots, raw PC/access replay, original
function transitions, descriptor/payload poison and range checks, all exact
pixels and final storage; producer counters/hashes alone cannot accept a run.
No result exists until a fresh run passes its separate independent capture gate.
''')
(new/'LIBRARY_SELECTION.md').write_text('''# Exact compiler runtime closure for the real-page entry

Pre-build hypothesis: removing the healthy runtime's packet modulo-six removes
its sole __umodsi3 reference. Provider division still selects __udivsi3. Retain
both original pinned archive members as evidence, but admit exactly _udivsi3.o
in the new actual map and no __umodsi3 symbol. An unexpected selection stops
admission; preserve it and review the source instead of broadening silently.
The accepted reset audit supplies the unchanged archive/member/byte rules.
''')
# Preserve this declaration before producing implementations; no target execution.
p=Path('/tmp/hp1020-pages-public-contract-20261005');p.mkdir(exist_ok=False)
for path in new.iterdir():
    if path.is_file():shutil.copyfile(path,p/path.name)
(p/'sha256.json').write_text(json.dumps({x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(p.iterdir())},indent=2)+'\n')
# Small changes to healthy execution, never any production component.
s=(old/'hp1020_usb_runtime.c').read_text()
s=replace(s,'const uint32_t fragment=packet%6u;\n        const uint32_t bytes=fragment==5u ? 32u : 64u;\n        if(!acquire(fragment*64u,bytes)', 'const uint32_t offset=packet*64u;\n        const uint32_t left=HP1020_USB_RUNTIME_INPUT_BYTES-offset;\n        const uint32_t bytes=left<64u ? left : 64u;\n        if(!acquire(offset,bytes)')
s=replace(s,'if(!acquire(0,0)','if(!acquire(HP1020_USB_RUNTIME_INPUT_BYTES,0)')
(new/'hp1020_usb_runtime.c').write_text(s)
s=(old/'hp1020_usb_runtime_ram.c').read_text()
s=replace(s,'Authored as an unexecuted RAM-provider draft, 2026-10-03.','Real two-page RAM provider; unexecuted draft, 2026-10-05.')
s=replace(s,'{P.scope,n+1,kind,argument,value,outcome}','{kind,argument,value,outcome}')
s=replace(s,'P.scope>13','P.scope>HP1020_USB_RUNTIME_BULK_PACKETS',2)
s=replace(s,'scope>13','scope>HP1020_USB_RUNTIME_BULK_PACKETS')
s=replace(s,'MW(PIXEL_BYTES)>64 || view.rows>(64-MW(PIXEL_BYTES))/ring->stride','MW(PIXEL_BYTES)>HP1020_USB_RUNTIME_PIXEL_BYTES ||\n       view.rows>(HP1020_USB_RUNTIME_PIXEL_BYTES-MW(PIXEL_BYTES))/ring->stride')
s=replace(s,'!healthy() || !room(n,2)','!healthy() || !room(n,HP1020_USB_RUNTIME_DOCUMENT_EVENTS)')
s=replace(s,'offset>352 || count>352-offset','offset>HP1020_USB_RUNTIME_INPUT_BYTES || count>HP1020_USB_RUNTIME_INPUT_BYTES-offset')
(new/'hp1020_usb_runtime_ram.c').write_text(s)
fixtures=root/'analysis/boot-handoff/entry-usb-pages/fixtures';fixtures.mkdir(parents=True,exist_ok=False)
for name in ('whole-job.zjs','source.pbm','pixels.bin','page1.jbg','page2.jbg','page1.decoded','page2.decoded','validation.json','encoder-output.json'):
    shutil.copyfile(Path('/tmp/hp1020-real-multipage-first-20261005')/name,fixtures/name)
print('Draft source and public contract created; no target build or execution.')
