# Independent first real-page acceptance draft

Frozen before target execution on 2026-10-05. No candidate imports, gate runs,
tests, model/QEMU execution or printer operations were performed by this agent.
Only static source/ELF metadata reading, original host fixture reading, manual
state derivation, syntax parsing and source sealing were performed. Lead owns
all admission decisions and all validation.

Independent input is the entire967-byte unmodified original foo2zjs job,
including its timestamp and268/27-byte PJL framing. Literal PBM source rows,
128x4/256x4 geometry, exact192 pixels, complete original chunk boundaries,
JBIG consumed/padding split, full input source/host-reference provenance are
frozen. Original source image may carry PJL commands; this profile only consumes
framing, and does not claim to respond to/execute those commands.

The standalone semantic and public-layout files are embedded byte-for-byte in
the gate. Only the unchanged hash-pinned prior independent gate supplies neutral
readers. New runtime/audit/observer/generator/result oracles are never imported.
Original complete_chunk calls the page boundary while framing is still2, then
restores1 after consumer return. END_DOC clears framing before its callback and
increments documents_completed/document_first_page only after callback return.
Actual receive is READY until the pumping callback unwinds and release occurs.
The first-complete stop observes accepted4/completed0/pixels64 inside the first
output callback; the second output must already have one complete predecessor.

Ten real natural stops, eleven paired snapshots/case, two ordinary paint cases.
Raw access replay, actual CALL/RET/tail/JX operand metadata, original cookie and
buffer identity, initial whole zero scans, original EP0/promises, full witness,
all receive tails, full output allocation, exact plan and output/event timing,
sole final owned ZLP/service/empty pump/finish and actual park are required.
No cancelled/WAIT/STALE cases are included. The four-word I/O array retains all
308 rows; ordinal/scope are reconstructed independently alongside85 full range
rows and18 genuine bind rows, rather than trusting compressed row counters.

Existing source anchors: semantic-core/hp1020_semantic.c complete_chunk,
image-core/hp1020_image_stream.c chunk_in/boundary_out,
image-core/hp1020_image_output.c boundary/drain/progress,
image-core/hp1020_image_ring.c peek/accept/complete,
usb-receive-core/hp1020_usb_document.c pump/document_out,
tinyusb-printer-adapter/hp1020_tusb_adapter.c pump/finish, and the accepted
healthy profile's frozen public provider contract. Header/ELF identity follows
the lead's first admitted link after its preserved pre-execution extern-size
compile stop. Earlier unfinished static drafts and source-only framing/header
corrections remain at hp1020-pages-gate-first-static-draft-20261005 under/tmp.
