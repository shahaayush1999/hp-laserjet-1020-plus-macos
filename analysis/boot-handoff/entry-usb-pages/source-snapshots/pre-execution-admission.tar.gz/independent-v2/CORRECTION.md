# Pre-execution V2 correction

V1 remains at /tmp/hp1020-pages-independent-gate-v1-20261005. No target or gate
has executed. Source review of unchanged provider bind_record, acquire and
ram_note proves mailbox LAST_COOKIE/LAST_SLOT words62..67 are first written by
ram_note at close; all four new natural callback stops precede that call.
V2 changes only their early diagnostic expectations tozero. Original provider,
OUT and adapter cookies, raw input/pixels, all late expectations, semantic and
layout literals, C/ELF and observer bytes remain unchanged. No report edited.
