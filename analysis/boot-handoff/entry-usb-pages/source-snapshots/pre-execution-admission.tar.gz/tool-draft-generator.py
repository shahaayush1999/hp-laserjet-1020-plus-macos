from pathlib import Path
import hashlib,re
root=Path.cwd();scripts=root/'scripts';source=root/'open-firmware/entry-usb-pages-test'
def put(name,s):
    p=scripts/name;assert not p.exists(),p;p.write_text(s)
def sub(s,a,b,n=1):
    assert s.count(a)==n,(a,s.count(a),n);return s.replace(a,b)
# Build is deliberately the original26 C units and startup, only3 fixture units differ.
s=(scripts/'build-hp1020-entry-usb-target.sh').read_text()
s=s.replace('entry-usb-test','entry-usb-pages-test').replace('entry-usb/target','entry-usb-pages/target')
s=sub(s,'analysis/boot-handoff/entry-ram/fixtures/small-black.zjs','analysis/boot-handoff/entry-usb-pages/fixtures/whole-job.zjs')
s=s.replace('352','967').replace('ad339333c0d37ee41da13849184caebec4b55d8f913eb30f9565e30cd33a062d','8ccf8bc1391e9025e3bd0a196dd155a04b967271bbb2a896bfd185453c0ed669')
s=s.replace('hp1020_entry_usb_audit import','hp1020_entry_usb_pages_audit import')
s=s.replace('hp1020-entry-usb-source','hp1020-entry-usb-pages-source')
s=s.replace('exact two members','exact selected member').replace('RAM USB lifetime','RAM full-job lifetime')
put('build-hp1020-entry-usb-pages-target.sh',s)
# New local audit calls pinned unchanged neutral code; all profile choices local.
s=(scripts/'hp1020_entry_usb_reset_audit.py').read_text()
s=s.replace('entry-usb-reset','entry-usb-pages').replace('RESET_SELECTED','PAGES_SELECTED').replace('RESET_LIBGCC','PAGES_LIBGCC')
s=s.replace('reset-profile','real-page-profile').replace('reset profile','real-page profile').replace('reset link','real-page link').replace('reset map','real-page map').replace('before a reset build','before a real-page build')
s=sub(s,'PIN,INPUT_SHA256,','PIN,')
s=sub(s,'CONTRACT_PINS = {',"INPUT_SHA256 = '8ccf8bc1391e9025e3bd0a196dd155a04b967271bbb2a896bfd185453c0ed669'\nCONTRACT_PINS = {")
a=s.index('CONTRACT_PINS = {');b=s.index('\n}',a)+2
pins={n:hashlib.sha256((source/n).read_bytes()).hexdigest() for n in ('LIBRARY_SELECTION.md','hp1020_usb_runtime_contract.h','layout-objects.tsv','layout-fields.tsv','startup.S','runtime.ld')}
s=s[:a]+'CONTRACT_PINS = '+repr(pins)+s[b:]
s=s.replace('len(fields) == 118','len(fields) == 101').replace('range(1, 119)','range(1, 102)')
s=s.replace('== 2100','== 1828').replace('16, 118','16, 101').replace('0x4850554c, 2, 525','0x4850554c, 3, 457')
s=s.replace("'>525I'","'>457I'").replace(', 2100)',', 1828)').replace("('hp1020_usb_runtime_input', 352,","('hp1020_usb_runtime_input', 967,")
s=sub(s,"('hp1020_usb_runtime_setup_record', 16, digest(bytes.fromhex('80000000000000000009010000000000'))),\n            ('hp1020_usb_runtime_reset_record', 16, digest(bytes.fromhex('80000000000000002102000000000000')))","('hp1020_usb_runtime_setup_record', 16, digest(bytes.fromhex('80000000000000000009010000000000')))")
put('hp1020_entry_usb_pages_audit.py',s)
roles=(('after-normalization','hp1020_entry_after_normalization'),('pre-c','hp1020_entry_before_c'),('pre-first-output','output'),('pre-first-complete','hp1020_image_ring_complete'),('pre-second-output','output'),('pre-document-event','document_event'),('pre-close','hp1020_tusb_adapter_close_input'),('pre-final-service','hp1020_udc_publish_service'),('pre-finish','hp1020_tusb_adapter_finish'),('park','hp1020_entry_park'))
extras=('hp1020_usb_runtime_ram_install_bulk','hp1020_usb_receive_complete_data','hp1020_usb_receive_release','hp1020_image_output_feed','hp1020_image_ring_accept','hp1020_image_ring_complete','dcd_edpt0_status_complete','driver_xfer','document_out','output','document_event')
for old,new in [('hp1020_entry_usb_reset_machine.py','hp1020_entry_usb_pages_machine.py'),('hp1020_entry_usb_reset_qemu.py','hp1020_entry_usb_pages_qemu.py')]:
    s=(scripts/old).read_text().replace('Reset','Pages').replace('reset','pages').replace('twenty','ten')
    # Only checkpoint cardinality literals; CPU/register/addresses stay fixed.
    s=re.sub(r'(?<![\w])20(?![\w])','10',s)
    s=s.replace("== 23, 'complete", "== 13, 'complete")
    a=s.index('CHECKPOINT_ROLES = (');b=s.index('\nCORE_NAMES',a)
    s=s[:a]+'CHECKPOINT_ROLES = '+repr(roles)+'\n'+s[b:]
    if 'machine' in new:
        a=s.index('ADDITIONAL_ENTRIES = (');b=s.index('\nMAX_INSTRUCTIONS',a)
        s=s[:a]+'ADDITIONAL_ENTRIES = '+repr(extras)+'\n'+s[b:]
    put(new,s)
# New local runner leaves original schemas/gates/artifacts untouched.
s=(scripts/'validate-hp1020-entry-usb-reset.py').read_text().replace('entry-usb-reset','entry-usb-pages').replace('entry_usb_reset','entry_usb_pages').replace('EntryUSBReset','EntryUSBPages')
s=s.replace('reset_api','pages_api').replace('reset_seen','pages_seen').replace('reset_observations','pages_observations').replace('reset_checkpoints','pages_checkpoints')
s=s.replace('USB reset RAM','USB real-page RAM').replace('USB reset','USB real-page')
s=re.sub(r"REVIEWED_TARGET_SHA256='[a-f0-9]+'", "REVIEWED_TARGET_SHA256='UNREVIEWED_NO_EXECUTION'",s)
s=sub(s,'# Actual first linked image covered by the independent fixed-workload7904-byte\n# stack/callback review. Audit-only may investigate a new image; execution may\n# not silently reuse this review when any linked byte changes.','# No linked image admitted yet. Audit-only may investigate new bytes; a new\n# source-bound static stack/callback review must pin the exact ELF before execution.')
a=s.index('CHECKPOINT_SYMBOLS=(');b=s.index('\n\ndef need',a)
s=s[:a]+'CHECKPOINT_SYMBOLS='+repr(roles)+'\n'+s[b:]
s=sub(s,'make_input=base.make_input','''def make_input(capture, oracle):
    original=OUT/'fixtures/whole-job.zjs'
    data=original.read_bytes()
    need(data==oracle.STREAM and len(data)==967 and sha(data)==oracle.STREAM_SHA256,
         'unchanged real host job differs from independently frozen literals')
    folder=capture/'input';folder.mkdir()
    for name in ('whole-job.zjs','source.pbm','pixels.bin','encoder-output.json','validation.json'):
        (folder/name).write_bytes((OUT/'fixtures'/name).read_bytes())
    info=dict(source=str(original.relative_to(ROOT)),input_sha256=sha(data),bytes=len(data),
              independent_literal_match=True, normalized=False)
    save(folder/'provenance.json',info);return info''')
s=sub(s,"('CONTRACT.md','AMENDMENT.md','ACCEPTANCE.md','ADDENDUM.md','LIBRARY_SELECTION.md')","('CONTRACT.md','LIBRARY_SELECTION.md')")
s=s.replace('len(fields)==118','len(fields)==101').replace('0x4850554c,2,525,16,118','0x4850554c,3,457,16,101')
s=s.replace(',2100)',',1828)').replace("'>525I'","'>457I'")
s=s.replace("program.symbols['hp1020_usb_runtime_input'],352)","program.symbols['hp1020_usb_runtime_input'],967)")
s=s.replace('len(CHECKPOINT_SYMBOLS)==20','len(CHECKPOINT_SYMBOLS)==10')
s=s.replace('20 natural','10 natural')
a=s.index("    lines=['# One entry");b=s.index("    (OUT/'capture.tar.gz')",a)
s=s[:a]+'''    lines=['# One entry through a complete real-host two-page RAM job','',
      'Two continuous interpreter/QEMU cases passed the independent raw-capture gate.',
      'All967 original foo2zjs bytes, including PJL, enter one receive generation.',
      'Two distinct pages yield192 exact source pixel bytes and one document event.',
      'Final owned SUCCESS ZLP, next service, empty pump and sole finish precede park.',
      'No physical controller/cache/engine behavior or printing is established.','',
      f'Cases: {len(cases)}; paired checkpoints: {sum(c["paired_checkpoints"] for c in cases)}; observed instructions: {steps}.',
      f'Minimum SP: `{minimum:#x}`; observed stack use: {STACK[0]+STACK[1]-minimum} bytes.','',
      'Exact source and raw evidence seals are in validation.json and capture-manifest.json.','']
'''+s[b:]
put('validate-hp1020-entry-usb-pages.py',s)
print('New profile-only tools drafted; target execution locked.')
