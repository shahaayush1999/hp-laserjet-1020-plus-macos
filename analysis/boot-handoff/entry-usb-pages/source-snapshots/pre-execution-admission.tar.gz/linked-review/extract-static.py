"""Read saved text/ELF bytes and compiler metadata only; no target execution/import."""
import hashlib,json,re,struct
from pathlib import Path
P=Path(__file__).resolve().parent
j=json.loads((P/'inputs/linked-audit.json').read_text())
elf=(P/'inputs/target/entry-usb.elf').read_bytes()
assert hashlib.sha256(elf).hexdigest()=='e907a88d58415e2fe7ee97711a738f203420fb162f016a25e9f299d6194aed9b'
head=struct.unpack_from('>16sHHIIIIIHHHHHH',elf)
shoff,shentsize,shnum=head[6],head[11],head[12]
sections=[struct.unpack_from('>IIIIIIIIII',elf,shoff+i*shentsize) for i in range(shnum)]
def raw_at(a,n):
 rows=[s for s in sections if s[1]!=8 and s[2]&2 and s[3]<=a and a+n<=s[3]+s[5]]
 assert len(rows)==1,(hex(a),n)
 s=rows[0];return elf[s[4]+a-s[3]:s[4]+a-s[3]+n]
funcs=[]
for line in (P/'inputs/target/symbols.txt').read_text().splitlines():
 m=re.fullmatch(r'([0-9a-f]+) ([0-9a-f]+) ([TtWw]) (\S+)',line)
 if m: funcs.append(dict(address=int(m[1],16),size=int(m[2],16),name=m[4]))
assert len(funcs)==269
assert {(r['address'],r['size'],r['name']) for r in funcs}=={(r['address'],r['size'],r['name']) for r in j['function_symbols']}
def owner(a):
 f=[f for f in funcs if f['address']<=a<f['address']+f['size']]
 return min(f,key=lambda f:f['size']) if f else None
def label(f):return f"{f['address']:08x}:{f['name']}" if f else '?'
inst={}
for line in (P/'inputs/annotated-disassembly.txt').read_text().splitlines():
 m=re.match(r'^([0-9a-f]{8}):\s+([0-9a-f]{4,6})\s+([a-z0-9_.]+)(?:\s+(.*))?$',line)
 if not m:continue
 a=int(m[1],16);b=bytes.fromhex(m[2]); op=m[3];args=m[4] or ''
 assert raw_at(a,len(b))==b,(hex(a),line)
 row=dict(address=a,hex=m[2],op=op,args=args,function=label(owner(a)))
 if a in inst:assert inst[a]==row
 inst[a]=row
assert len(inst)==j['annotated_instructions']
byfunc={}
for a,row in sorted(inst.items()):byfunc.setdefault(row['function'],[]).append(row)
dynamic=[];direct=[];sp=[]
for name,rows in byfunc.items():
 for i,r in enumerate(rows):
  op,args=r['op'],r['args']
  if op in ('callx0','jx'):
   out=dict(r);out['predecessors']=rows[max(0,i-10):i];dynamic.append(out)
  if op in ('call0','j'):
   mt=re.match(r'([0-9a-f]{8})',args)
   if mt:
    t=int(mt[1],16); f=owner(t)
    if op=='call0' or label(f)!=name:direct.append(dict(r,target=t,target_function=label(f)))
  operands=args.split('<')[0].strip().split(',')
  if operands and operands[0].strip()=='a1' and op not in ('s32i','s32i.n','s16i','s8i','beq','bne','beqz','bnez','beqz.n','bnez.n','bltu','bgeu','bnone','bany','bbci','bbsi','blt','bge','beqi','bnei','bltui','bgeui','bgei','blti'):
   sp.append(dict(r,predecessors=rows[max(0,i-2):i]))
(P/'static-extraction.json').write_text(json.dumps(dict(functions=funcs,dynamic=dynamic,direct=direct,sp=sp),indent=2)+'\n')
with (P/'dynamic-sites.txt').open('w') as out:
 for r in dynamic:
  out.write('\n'+r['function']+'\n')
  for q in r['predecessors']+[r]:out.write(f"{q['address']:08x} {q['hex']} {q['op']} {q['args']}\n")
with (P/'sp-destinations.txt').open('w') as out:
 for r in sp:
  out.write('\n'+r['function']+'\n')
  for q in r['predecessors']+[r]:out.write(f"{q['address']:08x} {q['hex']} {q['op']} {q['args']}\n")
print('functions',len(funcs),'annotated-instructions',len(inst),'direct-call-or-cross-function-j',len(direct),'dynamic',len(dynamic),'SP destinations',len(sp))
from collections import Counter
print('SP op counts',dict(Counter(r['op'] for r in sp)))
print('dynamic counts',dict(Counter(r['op'] for r in dynamic)))
for r in dynamic:print(r['function'],f"{r['address']:08x}",r['op'],r['args'])
resolved=[]; unresolved=[]
for r in dynamic:
 q=r['predecessors'][-1] if r['predecessors'] else None
 if r['op']=='jx' and q and q['op']=='l32r' and q['args'].startswith(r['args']+', '):
  literal=int(q['args'].split(', ')[1].split()[0],16)
  dest=int.from_bytes(raw_at(literal,4),'big'); target=owner(dest)
  assert target and target['address']==dest,(r,hex(dest))
  resolved.append(dict(address=r['address'],function=r['function'],register=r['args'],literal=literal,target=dest,target_function=label(target)))
 else:unresolved.append(r)
(P/'literal-tail-targets.json').write_text(json.dumps(resolved,indent=2)+'\n')
print('\nLiteral JX tails',len(resolved))
for r in resolved:print(hex(r['address']),r['function'],'->',r['target_function'])
print('\nNonliteral dynamic sites',len(unresolved))
for r in unresolved:print(hex(r['address']),r['function'],r['op'],r['args'])
