# Fresh linked review: continuous real two-page job

2026-10-05. Targete907a88d58415e2fe7ee97711a738f203420fb162f016a25e9f299d6194aed9b.
Read-only review; no target instruction executed. The new whole-linked audit
passes. Text42812+rodata4048=46860/53216; full zero140244, document memory114704,
witness9216, stack8192. Exact24 production/startup object inputs match accepted
healthy USB. Only runtime/provider/layout object inputs differ. Libgcc selects
only originaludiv; both preserved original member bytes remain pinned.

All269 sized functions and every original annotated instruction were compared
with saved ELF bytes.264 C frames are static; taking the maximum frame among
all equal compiler names and summing every retained function gives7472 bytes.
This happens to equal the old healthy arithmetic but was recomputed afresh.
The five other symbols are startup/normalization/parks and stack-freeudiv.
All340 SP destinations are captured:323 fixed aligned ADDI, four ADDMI,
11 ADD.N, one ADD and one startup L32R. Large frames are runtime208,
providerinit240,publish176,EP0init144,acquire160,chunk_in256. Complete contexts
retain original allocation/restoration literals. No variable stack allocation.

Every93 indirect site is classified:45 literal tails read from currentELF,
37 fixed source-bound callbacks, eight bounded internal switch tables and three
unavailable callbacks. Current pointer words, table entries, exact predecessor
L32R references and target-relative offsets are checked; original classification
is only an input. The37 callback sites retain unchanged production source and
exact relative transfer op/register. Runtime/provider deltas add no indirect
call or callback reentry. Class table init/deinit/reset/open/control/transfer
pointers and literal-NULL sof/xfer_isr are verified against actuallinkedwords;
queue interrupt pointer is actualusbd_int_set. Generic deferred calls have no
producer in this fixed workload; originalproducer is GC-discarded. A fresh graph
includes all directcalls/cross-functionjumps,actualtails/fixedcallbacks and has
no cycle. Thus the all-retained-frame sum is a conservative ceiling under these
bindings, never a measured peak or general arbitrary-input/IRQ/exception bound.

The sibling runtime differs only in consuming967 consecutive bytes rather than
two repeated352-byte fixtures, and reporting finalZLPoffset967. Provider changes
only compact four-word I/O storage and exact17/192/one-event limits. Actual
cookie checks/cachecopy/ownership/service and ring accept/complete are unchanged.
At32 and16byte strides both four-row outputs fit a single8192-byte ring slot;
no recursive feed/service is introduced. PJL is scanned, not interpreted.
New10naturalstops use first ring-complete entry between two same-PCoutput stops;
no hidden breakpoint skip, host call, extra reset or post-seed mutation.

Admission is limited to this exact image and fixed two ordinary-paint cases.
Independent raw acceptance remains mandatory before publishing a passing result.
No physical boot/RAM/cache/USB/engine/printing or power-cycle evidence is added.
