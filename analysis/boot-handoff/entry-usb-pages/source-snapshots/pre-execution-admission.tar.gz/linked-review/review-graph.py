"""Read-only static proof over exact saved ELF/objects/disassembly; no ISA execution."""
from pathlib import Path
from collections import defaultdict
import hashlib,json,re,struct
P=Path(__file__).resolve().parent
OLD=Path('/tmp/hp1020-entry-usb-reset-linked-review-20261003')
new=json.loads((P/'static-extraction.json').read_text())
old=json.loads((OLD/'static-extraction.json').read_text())
prior=json.loads((OLD/'callback-graph.json').read_text())
audit=json.loads((P/'inputs/linked-audit.json').read_text())
elf=(P/'inputs/target/entry-usb.elf').read_bytes()
assert hashlib.sha256(elf).hexdigest()=='e907a88d58415e2fe7ee97711a738f203420fb162f016a25e9f299d6194aed9b'
h=struct.unpack_from('>16sHHIIIIIHHHHHH',elf)
sections=[struct.unpack_from('>IIIIIIIIII',elf,h[6]+i*h[11]) for i in range(h[12])]
def raw(a,n):
 ss=[s for s in sections if s[1]!=8 and s[2]&2 and s[3]<=a and a+n<=s[3]+s[5]];assert len(ss)==1
 s=ss[0];return elf[s[4]+a-s[3]:s[4]+a-s[3]+n]
def words(a,n):return struct.unpack('>'+'I'*n,raw(a,4*n))
def indices(fs):
 by=defaultdict(list);out={}
 for f in sorted(fs,key=lambda f:f['address']):
  key=(f['name'],len(by[f['name']]));out[f['address']]=key;by[f['name']].append(f)
 return out,{key:next(f for f in fs if f['address']==a) for a,key in out.items()}
oindex,obykey=indices(old['functions']);nindex,nbykey=indices(new['functions'])
def label(f):return f"{f['address']:08x}:{f['name']}"
def owner(r,which):
 fs=which['functions'];rows=[f for f in fs if f['address']<=r<f['address']+f['size']];assert len(rows)==1,(r,rows)
 return rows[0]
def mapped(pc):
 of=owner(pc,old);nf=nbykey[oindex[of['address']]]
 # Exact offset correspondence is required, never inferred from adjacent labels.
 at=nf['address']+pc-of['address']
 return at,of,nf
nd={r['address']:r for r in new['dynamic']};od={r['address']:r for r in old['dynamic']}
classified={};callbacks=[];switches=[];excluded=[]
for row in prior['fixed_callback_sites']:
 pc,of,nf=mapped(row['pc']);before=od[row['pc']];after=nd[pc]
 assert (before['op'],before['args'])==(after['op'],after['args'])
 tf=nbykey[oindex[row['target']]]
 classified[pc]='fixed callback';callbacks.append(dict(pc=pc,function=label(nf),target=tf['address'],target_function=label(tf),old_pc=row['pc'],binding='unchanged explicit production/provider binding; actual direct graph reviewed'))
for row in prior['switches']:
 pc,of,nf=mapped(row['pc']);delta=nf['address']-of['address'];r=nd[pc]
 literal=row['literal']+delta
 assert any(x['op']=='l32r' and re.search(r',\s*'+f'{literal:x}'+r'\b',x['args']) for x in r['predecessors'])
 table=words(literal,1)[0];targets=words(table,len(row['targets']))
 assert tuple(t-of['address'] for t in row['targets'])==tuple(t-nf['address'] for t in targets)
 assert all(nf['address']+12<t<nf['address']+nf['size'] for t in targets)
 assert (od[row['pc']]['op'],od[row['pc']]['args'])==(r['op'],r['args'])
 classified[pc]='bounded internal switch';switches.append(dict(pc=pc,literal=literal,table=table,targets=targets,function=label(nf),old_pc=row['pc']))
for row in prior['excluded_sites']:
 pc,of,nf=mapped(row['pc']);r=nd[pc]
 assert (od[row['pc']]['op'],od[row['pc']]['args'])==(r['op'],r['args'])
 classified[pc]='excluded';excluded.append(dict(pc=pc,reason=row['reason'].replace('usbd_defer_func','usbd_defer_func'),old_pc=row['pc']))
tails=json.loads((P/'literal-tail-targets.json').read_text())
for r in tails:assert r['address'] not in classified;classified[r['address']]='literal function tail'
assert set(classified)==set(nd),(set(nd)-set(classified),set(classified)-set(nd))
names=audit['symbols'];class_words=words(names['class_driver'],9)
def named(n):return nbykey[(n,0)]['address']
assert class_words[1:]==tuple(named(n) for n in ('driver_init','driver_deinit','driver_reset','driver_open','driver_control','driver_xfer'))+(0,0)
assert words(names['_usbd_qdef'],1)==(named('usbd_int_set'),)
assert not any(f['name']=='usbd_defer_func' for f in new['functions'])
# Fresh entire graph, including all conditionals; no cycles allowed.
g={label(f):set() for f in new['functions']};edges=[]
for r in new['direct']:
 if r['target_function']==r['function'] and r['op']!='call0':continue
 assert r['target_function'] in g
 g[r['function']].add(r['target_function']);edges.append((r['function'],r['target_function'],'direct'))
for r in tails+callbacks:g[r['function']].add(r['target_function']);edges.append((r['function'],r['target_function'],'indirect'))
seen=set();active=[]
def visit(n):
 assert n not in active,('simultaneous-recursion',active,n)
 if n in seen:return
 active.append(n)
 for m in sorted(g[n]):visit(m)
 active.pop();seen.add(n)
for n in sorted(g):visit(n)
# Compile reports include outgoing parameter space. Sum every retained frame;
# duplicate local names take max, giving a conservative bound for acyclic graph.
frames={}
for line in (P/'conservative-frames.txt').read_text().splitlines():
 if line.startswith('CONSERVATIVE'):continue
 address,size,name,frame=line.split();frames[int(address,16)]=int(frame)
assert len(frames)==264 and sum(frames.values())==7472
assert set(nindex)-set(frames)=={named(n) for n in ('hp1020_entry_normalize','hp1020_entry_start','hp1020_entry_park','hp1020_entry_unexpected_park','__udivsi3')}
# All production object bytes plus startup are unchanged from accepted healthy.
base=Path('/tmp/hp1020-entry-usb-tm_iuvrp/target');same=[];changed=[]
for p in sorted((P/'inputs/target').glob('*.o')):
 q=base/p.name;assert q.is_file()
 (same if p.read_bytes()==q.read_bytes() else changed).append(p.name)
assert len(same)==24 and changed==['hp1020_usb_runtime.o','hp1020_usb_runtime_layout.o','hp1020_usb_runtime_ram.o'],changed
result=dict(status='pass',target_sha256=hashlib.sha256(elf).hexdigest(),fixed_callbacks=callbacks,
 switches=switches,excluded=excluded,literal_tails=tails,class_driver_words=class_words,
 queue_interrupt_pointer=named('usbd_int_set'),all_dynamic_sites=len(classified),cycles=[],edges=edges,
 conservative_static_bytes=7472,stack_capacity=8192,retained_c_functions=264,
 unchanged_input_objects=same,changed_profile_objects=changed,
 scope='Fixed serialized supplied-RAM workload, no async/exception/deferred-call producer. Static arithmetic; no observed peak.')
(P/'callback-graph.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print('Static graph: PASS',len(classified),'dynamic sites;',sum(frames.values()),'of8192 conservative frame bytes;',len(same),'unchanged objects')
