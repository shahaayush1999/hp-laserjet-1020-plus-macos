"""Compare all prior component cases and four entry experiments after regression."""
from pathlib import Path
import copy,gzip,hashlib,json,re
ROOT=Path('/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos')
BEFORE=Path('/tmp/hp1020-pages-before-full-baseline-20261005')
OUT=Path('/tmp/hp1020-full-entry-usb-pages-comparison-20261005.json')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
load=lambda p:json.loads(p.read_text())
assert 'All offline checks passed. No printer was contacted.' in Path('/tmp/hp1020-full-entry-usb-pages-20261005.log').read_text()
assert not OUT.exists()
result=dict(status='pass',components=[],entries=[],source='exact accepted reports and original captured bytes')
for name,digest in load(BEFORE/'manifest.json')['files'].items():
    assert sha((BEFORE/name).read_bytes())==digest,name
for before in sorted((BEFORE/'analysis/usb-path').glob('*/validation.json')):
    after=ROOT/before.relative_to(BEFORE);a,b=load(before),load(after)
    assert a['status']==b['status']=='pass'
    assert a['cases']==b['cases'] and a['target']['cases']==b['target']['cases'],before
    result['components'].append(dict(name=before.parent.name,host_cases=len(b['cases']),target_cases=len(b['target']['cases']),
        complete_case_arrays_unchanged=True,before_sha256=sha(before.read_bytes()),after_sha256=sha(after.read_bytes())))
assert len(result['components'])==11
for name,count in (('entry-ram',6),('entry-usb',6),('entry-usb-reset',2),('entry-usb-pages',2)):
    old_report=BEFORE/'analysis/boot-handoff'/name/'validation.json'
    new_report=ROOT/'analysis/boot-handoff'/name/'validation.json'
    a,b=load(old_report),load(new_report);A=Path(a['capture']);B=Path(b['capture'])
    assert A!=B and a['status']==b['status']=='pass'
    assert load(A/'independent-gate.json')['ok'] and load(B/'independent-gate.json')['ok']
    assert (B/'validation.json').read_bytes()==new_report.read_bytes()
    assert a['source_sha256']==b['source_sha256'],name+' changed tested sources'
    assert a['target_sha256'].keys()==b['target_sha256'].keys()
    metadata=[]
    for n in a['target_sha256']:
        x=(A/'target'/n).read_bytes();y=(B/'target'/n).read_bytes()
        assert sha(x)==a['target_sha256'][n] and sha(y)==b['target_sha256'][n]
        if x==y:continue
        assert name!='entry-ram' and n.endswith(('.d','.su')),n
        pattern=(name+'-source\\.[A-Za-z0-9]{6}').encode()
        xs=set(re.findall(pattern,x));ys=set(re.findall(pattern,y));assert len(xs)==len(ys)==1
        left=next(iter(xs));right=next(iter(ys));assert x.replace(left,right)==y
        metadata.append(dict(file=n,before_prefix=left.decode(),after_prefix=right.decode()))
    rows=[]
    for old,new in zip(a['cases'],b['cases']):
        assert old['case']==new['case'];case=old['case'];x=copy.deepcopy(old);y=copy.deepcopy(new)
        for row in (x,y):
            q=row['qemu'];assert q['cleanup']['returncode']==0 and not q['cleanup']['still_running']
            q['cleanup'].pop('pid');q.pop('elapsed_seconds')
            q['host_intervention_ledger'].pop('sha256');q['host_intervention_ledger'].pop('bytes')
            sock=q['qemu']['args'][18];assert re.fullmatch(r'unix:/tmp/hp1020-qemu-[^/]+/gdb\.sock,server=on,wait=off',sock)
            q['qemu']['args'][18]='same private socket shape'
        assert x==y,(name,case)
        raw_ledgers=[];pids=[]
        for root,original in ((A,old),(B,new)):
            raw=(root/'cases'/case/'qemu/host-interventions.jsonl').read_bytes()
            seal=original['qemu']['host_intervention_ledger'];assert len(raw)==seal['bytes'] and sha(raw)==seal['sha256']
            ledger=[json.loads(z) for z in raw.splitlines()];assert len(ledger)==seal['lines']
            clean=[z for z in ledger if z.get('kind')=='process-cleanup'];assert len(clean)==1
            raw_ledgers.append(raw);pids.append(clean[0]['pid'])
        left,right=(('"pid":'+str(pid)+',').encode() for pid in pids)
        assert raw_ledgers[0].count(left)==raw_ledgers[1].count(right)==1
        assert raw_ledgers[0].replace(left,right)==raw_ledgers[1]
        assert len(raw_ledgers[1])-len(raw_ledgers[0])==len(right)-len(left)
        for trace,seal in (('accesses.bin.gz','access_sha256'),('steps.bin.gz','step_sha256')):
            x=gzip.decompress((A/'cases'/case/'model/traces'/trace).read_bytes())
            y=gzip.decompress((B/'cases'/case/'model/traces'/trace).read_bytes())
            assert x==y and sha(x)==old['model'][seal]==new['model'][seal]
        snapshot_members=0
        for engine in ('model','qemu'):
            for previous,current in zip(old[engine]['snapshots'],new[engine]['snapshots']):
                assert previous==current
                for region in previous['regions']:
                    x=(A/'cases'/case/engine/region['path']).read_bytes()
                    y=(B/'cases'/case/engine/region['path']).read_bytes()
                    assert x==y and len(x)==region['bytes']==region['captured_bytes'] and sha(x)==region['sha256']
                    snapshot_members+=1
        rows.append(dict(case=case,complete_state_and_actual_trace_bytes_unchanged=True,raw_snapshot_members=snapshot_members,
                         actual_debugger_commands_and_replies_unchanged_except_cleanup_pid=True))
    assert len(rows)==len(a['cases'])==len(b['cases'])==count
    result['entries'].append(dict(name=name,old_capture=str(A),new_capture=str(B),tested_sources_unchanged=True,
        target_code_and_objects_unchanged=True,temporary_metadata_differences=metadata,cases=rows))
OUT.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print('All11 component case arrays and all16 entry cases match accepted results and original raw traces/snapshots; only proved temporary metadata differs.')
