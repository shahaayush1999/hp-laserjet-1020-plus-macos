from pathlib import Path
import ast,hashlib,json
root=Path.cwd();out=Path('/tmp/hp1020-callback-correction-draft-20261005');out.mkdir(exist_ok=False)
source=root/'scripts/model-hp1020-usb-bulk-callbacks.py'
s=source.read_text();replacements={
'"""Model the stock USB bulk receive callbacks exported from Ghidra."""':'"""Model stock USB receive and outgoing queue callbacks, with original-byte gates."""',
'import argparse\n':'import argparse\nimport hashlib\n',
'"bulk_rx_complete"':'"bulk_tx_queue"',
'"bulk_completion_state"':'"bulk_tx_queue_state"',
'"bulk_completion_lock"':'"bulk_tx_queue_lock"',
'ghidra_export_has_completion_callback':'ghidra_export_has_historically_rx_named_send_callback',
'completion_allocates_pending_node':'send_allocates_pending_node',
'completion_appends_pending_transfer':'send_appends_pending_transfer',
'completion_clears_usb_status_bit':'send_unmasks_in1_interrupt',
'completion_sets_state_if_idle':'send_sets_queue_state_if_idle',
'Static model of the stock USB bulk receive callback layer.':'Static model of separate stock USB receive and outgoing send/queue callbacks.',
'"role": "completion/queue path"':'"role": "outgoing send/queue acceptance"',
'Allocates a 0x20 byte pending-transfer node, appends it to list 0x10022740, clears bit 1 in USB status register 0xb3000418, and marks completion state 0x100212d0 active when idle.':'Publishes the caller source for DMA, retains its pointer and requested length in a 0x20-byte queue node, appends to list 0x10022740 and unmasks IN1 via bit1 of 0xb3000418. Returns accepted length before transmission; later done-head cleanup frees the retained source.',
'"role": "secondary read wrapper"':'"role": "send wrapper"',
'Calls the param_1+8 slot with a fixed timeout of 200.':'Calls the registered outgoing slot at record+8 with source, length and timeout200; its return is queue acceptance, not host receipt.',
'"The real USB work is a bulk OUT producer that fills a buffer, sets event bit 0x20000, tracks remaining bytes, and re-arms endpoint receive."':'"Bulk OUT feeds parser input; bulk IN separately carries outgoing replies. The return channel cannot be inferred from receive completion."',
'"The next open-code prototype target after endpoint-0 proof is a small bulk-receive ring plus parser callback shim, not the print engine."':'"Reuse bounded open ownership and buffers rather than HP heap queues. Keep queue acceptance, source/DMA release, FIFO settlement and host receipt distinct."',
'This is an offline static model built from saved Ghidra decompilation. It does not contact the printer.':'This offline static model checks saved decompilation against pinned original byte ranges. Historical RX-like export names are retained; the second callback is an outgoing send queue. No function or device is executed.',
'- `0x10008bac` is the stock completion/queue callback: it creates a pending-transfer node, clears a USB status bit, and wakes the receive state.':'- `0x10008bac` queues outgoing bytes and returns accepted length. It retains the source for later DMA/completion cleanup; it is not a receive-completion callback.',
'- The ZjStream parser can be kept behind a read-callback shim; the missing open-code piece is the USB bulk OUT producer that feeds that shim.':'- `0x100081f4` calls that outgoing slot with timeout200. Queue acceptance is distinct from DMA release, FIFO settlement and host-visible receipt.',
}
for before,after in replacements.items():
    assert before in s,before
    s=s.replace(before,after)
# Read-only whole-region seals tie the corrected labels to the independently
# reviewed original instructions, not only to historical Ghidra needles.
j=json.loads(Path('/tmp/hp1020-bulk-in-boundary-20261005/evidence.json').read_text())
selected=('registration','callback-vtable','send-wrapper','in1-completed-list-drain','in1-submit-queue','startup-in1','pjl-send','cache-helper-call-boundary-only','stock-config-fs','stock-config-hs')
regions={row['name']:(int(row['start'],16),int(row['end_exclusive'],16),row['sha256']) for row in j['regions'] if row['name'] in selected}
insert="\nSTOCK_SHA256 = '2111560068db47ceca21fa550db4c7c34f5595b5a5d137ae4a19631e40e3601d'\n# Literal, independently reviewed original ranges; all checks below are reads.\nORIGINAL_REGIONS = {\n"+''.join(f'    {name!r}: ({a:#x}, {b:#x}, {h!r}),\n' for name,(a,b,h) in regions.items())+"}\n\n"
s=s.replace('\n\nclass ElfImage:',insert+'\nclass ElfImage:')
start=s.index('    def read_u32(');end=s.index('\n\ndef fmt32(',start)
s=s[:start]+'''    def read_bytes(self, addr: int, size: int) -> bytes:
        for p_offset, p_vaddr, p_filesz in self.load_segments:
            if p_vaddr <= addr and addr + size <= p_vaddr + p_filesz:
                off = p_offset + (addr - p_vaddr)
                return self.data[off:off + size]
        raise ValueError(f"address 0x{addr:08x}+{size} is not file-backed")

    def read_u32(self, addr: int) -> int:
        return struct.unpack(">I", self.read_bytes(addr, 4))[0]
'''+s[end:]
s=s.replace('    constants = {name:', '''    digest = hashlib.sha256(elf.data).hexdigest()
    original_checks = [{"name": "original_stock_elf", "status": "present" if digest == STOCK_SHA256 else "missing",
        "sha256": digest, "expected_sha256": STOCK_SHA256}]
    for name, (begin, end, expected) in ORIGINAL_REGIONS.items():
        actual = hashlib.sha256(elf.read_bytes(begin, end-begin)).hexdigest()
        original_checks.append({"name": name, "begin": fmt32(begin), "end_exclusive": fmt32(end),
            "sha256": actual, "expected_sha256": expected, "status": "present" if actual == expected else "missing"})
    for name, address, expected in (("registered_send", 0x10005f00, 0x10008bac),
                                  ("send_wrapper", 0x10005dd8, 0x100081f4)):
        actual = elf.read_u32(address)
        original_checks.append({"name": name, "address": fmt32(address), "value": fmt32(actual),
            "expected_value": fmt32(expected), "status": "present" if actual == expected else "missing"})
    constants = {name:''')
s=s.replace('    fail_count = sum(item["status"] != "present" for item in checks)', '    fail_count = sum(item["status"] != "present" for item in checks + original_checks)')
s=s.replace('        "constants": constants,', '''        "constants": constants,
        "stock_elf_sha256": digest,
        "original_byte_checks": original_checks,
        "direction_correction": {
            "old_label": "bulk_rx_complete", "corrected_role": "bulk_tx_queue",
            "historical_export_names_preserved": True,
            "basis": "Startup registers 0x10008bac at record+8; 0x100081f4 forwards source/length/timeout there. The queue retains source/length and returns length; 0x10008b78 later frees done heads' original sources.",
            "limits": "Static original instructions only. No semaphore/cache/MMIO/queue/completion executed. Current PJL transport pointer selection and host receipt remain unproved.",
        },''')
s=s.replace('    lines.extend(["", "## Open-Firmware Meaning", ""])', '''    lines.extend(["", "## Corrected Direction and Original Bytes", "",
        report["direction_correction"]["basis"], "", report["direction_correction"]["limits"], "",
        "| Check | Status |", "|---|---|"])
    for item in report["original_byte_checks"]:
        lines.append(f"| `{item['name']}` | `{item['status']}` |")
    lines.extend(["", "## Open-Firmware Meaning", ""])''')
ast.parse(s);(out/source.name).write_text(s)
p=root/'scripts/model-hp1020-usb-parser-shim-contract.py';t=p.read_text();assert 'registered_completion_callback' in t
t=t.replace('registered_completion_callback','registered_outgoing_queue_callback');ast.parse(t);(out/p.name).write_text(t)
p=root/'scripts/check-hp1020-analysis-consistency.py';t=p.read_text()
before='and any(item.get("address") == "0x10008bac" and item.get("name") == "bulk_rx_complete" for item in usb_bulk_callbacks.get("callback_roles", []))'
assert before in t;t=t.replace(before,before.replace('bulk_rx_complete','bulk_tx_queue')+'\n            and len(usb_bulk_callbacks.get("original_byte_checks", [])) == 13\n            and all(item.get("status") == "present" for item in usb_bulk_callbacks.get("original_byte_checks", []))')
t=t.replace('The USB bulk callback model must preserve the read/copy callback, completion queue callback, event bit, endpoint ack register, and status-bit clear.', 'The USB bulk callback model must distinguish the original read/copy and outgoing queue callbacks, with pinned original-byte direction checks and receive event/ack facts.')
ast.parse(t);(out/p.name).write_text(t)
(out/'README.md').write_text('Unexecuted source correction draft, prepared while full regression runs. No generated report changed. Install only after the real-page checkpoint. Original Ghidra names/files remain historical captures. Changes correct outgoing callback/USB mask meaning and downstream parser-shim label, with thirteen original ELF/region/literal gates. Full validation required after shared-gate changes.\n')
(out/'manifest.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()},indent=2)+'\n')
print(out)
