from pathlib import Path
import json,gzip,hashlib,re,copy
A=Path('/tmp/hp1020-entry-usb-pages-1i84bayj');B=Path('/tmp/hp1020-entry-usb-pages-bffsbyps')
load=lambda p:json.loads(p.read_text());sha=lambda x:hashlib.sha256(x).hexdigest()
a,b=(load(p/'validation.json') for p in (A,B))
assert not load(A/'independent-gate.json')['ok'] and load(B/'independent-gate.json')['ok']
changed=[n for n in a['source_sha256'] if a['source_sha256'][n]!=b['source_sha256'][n]]
assert changed==['scripts/check-hp1020-entry-usb-pages.py']
metadata=[]
for n in a['target_sha256']:
 x=(A/'target'/n).read_bytes();y=(B/'target'/n).read_bytes()
 assert sha(x)==a['target_sha256'][n] and sha(y)==b['target_sha256'][n]
 if x==y:continue
 assert n.endswith(('.d','.su')),n
 pat=rb'entry-usb-pages-source\.[A-Za-z0-9]{6}'
 xs,ys=(set(re.findall(pat,z)) for z in (x,y));assert len(xs)==len(ys)==1
 assert x.replace(next(iter(xs)),next(iter(ys)))==y,n
 metadata.append(n)
rows=[]
for old,new in zip(a['cases'],b['cases']):
 assert old['case']==new['case'] and old['model']==new['model']
 name=old['case'];x,y=copy.deepcopy(old),copy.deepcopy(new)
 for c in (x,y):
  q=c['qemu'];assert q['cleanup']['returncode']==0 and not q['cleanup']['still_running']
  q['cleanup'].pop('pid');q.pop('elapsed_seconds');q['host_intervention_ledger'].pop('bytes');q['host_intervention_ledger'].pop('sha256')
  assert re.fullmatch(r'unix:/tmp/hp1020-qemu-[^/]+/gdb\.sock,server=on,wait=off',q['qemu']['args'][18]);q['qemu']['args'][18]='private socket'
 assert x==y
 for file in ('steps.bin.gz','accesses.bin.gz'):
  assert gzip.decompress((A/'cases'/name/'model/traces'/file).read_bytes())==gzip.decompress((B/'cases'/name/'model/traces'/file).read_bytes())
 for engine in ('model','qemu'):
  assert old[engine]['snapshots']==new[engine]['snapshots']
  for snapshot in old[engine]['snapshots']:
   for region in snapshot['regions']:
    x=(A/'cases'/name/engine/region['path']).read_bytes();y=(B/'cases'/name/engine/region['path']).read_bytes()
    assert x==y and sha(x)==region['sha256']
 ledgers=[(p/'cases'/name/'qemu/host-interventions.jsonl').read_bytes() for p in (A,B)]
 pids=[str(c['qemu']['cleanup']['pid']) for c in (old,new)]
 left,right=(('"pid":'+v+',').encode() for v in pids)
 assert ledgers[0].count(left)==ledgers[1].count(right)==1 and ledgers[0].replace(left,right)==ledgers[1]
 rows.append({'case':name,'instructions':new['model']['instructions'],'observed_stack_bytes':0x10016020-new['model']['minimum_sp'],'complete_raw_traces_snapshots_and_target_bytes_identical':True})
result={'status':'pass','scope':'Both executions identical apart from checker source and proved temporary build/process/socket/time metadata. First remains an overall V2 failure; second accepted by V3.','changed_sources':changed,'temporary_object_metadata':metadata,'cases':rows}
out=Path('/tmp/hp1020-pages-first-second-comparison-20261005.json');assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
