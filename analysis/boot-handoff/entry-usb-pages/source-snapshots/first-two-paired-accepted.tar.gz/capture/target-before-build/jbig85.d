/Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos/analysis/boot-handoff/entry-usb-pages/target/jbig85.o: \
 /Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos/vendor/jbigkit-2.1/libjbig/jbig85.c \
 /Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos/open-firmware/image-core/freestanding/stdlib.h \
 /Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos/open-firmware/image-core/freestanding/string.h \
 /private/tmp/hp1020-xtensa-gcc14/lib/gcc/xtensa-fsf-elf/14.3.0/include/stddef.h \
 /Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos/open-firmware/image-core/freestanding/assert.h \
 /Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos/vendor/jbigkit-2.1/libjbig/jbig85.h \
 /Users/aayush/Documents/shahaayush1999/hp-laserjet-1020-plus-macos/vendor/jbigkit-2.1/libjbig/jbig_ar.h
